﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

// Token: 0x020000DB RID: 219
[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
[CompilerGenerated]
[DebuggerNonUserCode]
internal class Class43
{
	// Token: 0x060006FF RID: 1791 RVA: 0x0003F08C File Offset: 0x0003D28C
	internal Class43()
	{
	}

	// Token: 0x170002FE RID: 766
	// (get) Token: 0x06000700 RID: 1792 RVA: 0x00067B24 File Offset: 0x00065D24
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static ResourceManager ResourceManager_0
	{
		get
		{
			if (Class43.resourceManager_0 == null)
			{
				Class43.resourceManager_0 = new ResourceManager(<Module>.DeserealizeFromByteArrayV2_1<string>(2996712786U), typeof(Class43).Assembly);
			}
			return Class43.resourceManager_0;
		}
	}

	// Token: 0x170002FF RID: 767
	// (get) Token: 0x06000701 RID: 1793 RVA: 0x00067B60 File Offset: 0x00065D60
	// (set) Token: 0x06000702 RID: 1794 RVA: 0x00067B74 File Offset: 0x00065D74
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static CultureInfo CultureInfo_0
	{
		get
		{
			return Class43.cultureInfo_0;
		}
		set
		{
			Class43.cultureInfo_0 = value;
		}
	}

	// Token: 0x17000300 RID: 768
	// (get) Token: 0x06000703 RID: 1795 RVA: 0x00067B88 File Offset: 0x00065D88
	internal static byte[] Byte_0
	{
		get
		{
			return (byte[])Class43.ResourceManager_0.GetObject(<Module>.DeserealizeFromByteArrayV2_1<string>(1553532074U), Class43.cultureInfo_0);
		}
	}

	// Token: 0x17000301 RID: 769
	// (get) Token: 0x06000704 RID: 1796 RVA: 0x00067BB4 File Offset: 0x00065DB4
	internal static Bitmap Bitmap_0
	{
		get
		{
			return (Bitmap)Class43.ResourceManager_0.GetObject(<Module>.DeserializeFromByteArrayV2<string>(1285978534U), Class43.cultureInfo_0);
		}
	}

	// Token: 0x040009C6 RID: 2502
	private static ResourceManager resourceManager_0;

	// Token: 0x040009C7 RID: 2503
	private static CultureInfo cultureInfo_0;
}
