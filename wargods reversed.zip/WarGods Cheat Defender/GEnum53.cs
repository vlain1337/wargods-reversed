﻿using System;

// Token: 0x020000EF RID: 239
public enum GEnum53
{
	// Token: 0x04000A2A RID: 2602
	const_0,
	// Token: 0x04000A2B RID: 2603
	const_1,
	// Token: 0x04000A2C RID: 2604
	const_2,
	// Token: 0x04000A2D RID: 2605
	const_3,
	// Token: 0x04000A2E RID: 2606
	const_4,
	// Token: 0x04000A2F RID: 2607
	const_5,
	// Token: 0x04000A30 RID: 2608
	const_6,
	// Token: 0x04000A31 RID: 2609
	const_7,
	// Token: 0x04000A32 RID: 2610
	const_8,
	// Token: 0x04000A33 RID: 2611
	const_9,
	// Token: 0x04000A34 RID: 2612
	const_10,
	// Token: 0x04000A35 RID: 2613
	const_11,
	// Token: 0x04000A36 RID: 2614
	const_12,
	// Token: 0x04000A37 RID: 2615
	const_13,
	// Token: 0x04000A38 RID: 2616
	const_14,
	// Token: 0x04000A39 RID: 2617
	const_15,
	// Token: 0x04000A3A RID: 2618
	const_16,
	// Token: 0x04000A3B RID: 2619
	const_17,
	// Token: 0x04000A3C RID: 2620
	const_18,
	// Token: 0x04000A3D RID: 2621
	const_19,
	// Token: 0x04000A3E RID: 2622
	const_20,
	// Token: 0x04000A3F RID: 2623
	const_21,
	// Token: 0x04000A40 RID: 2624
	const_22,
	// Token: 0x04000A41 RID: 2625
	const_23,
	// Token: 0x04000A42 RID: 2626
	const_24,
	// Token: 0x04000A43 RID: 2627
	const_25,
	// Token: 0x04000A44 RID: 2628
	const_26,
	// Token: 0x04000A45 RID: 2629
	const_27,
	// Token: 0x04000A46 RID: 2630
	const_28,
	// Token: 0x04000A47 RID: 2631
	const_29,
	// Token: 0x04000A48 RID: 2632
	const_30,
	// Token: 0x04000A49 RID: 2633
	const_31,
	// Token: 0x04000A4A RID: 2634
	const_32,
	// Token: 0x04000A4B RID: 2635
	const_33,
	// Token: 0x04000A4C RID: 2636
	const_34,
	// Token: 0x04000A4D RID: 2637
	const_35,
	// Token: 0x04000A4E RID: 2638
	const_36,
	// Token: 0x04000A4F RID: 2639
	const_37,
	// Token: 0x04000A50 RID: 2640
	const_38,
	// Token: 0x04000A51 RID: 2641
	const_39,
	// Token: 0x04000A52 RID: 2642
	const_40,
	// Token: 0x04000A53 RID: 2643
	const_41,
	// Token: 0x04000A54 RID: 2644
	const_42,
	// Token: 0x04000A55 RID: 2645
	const_43
}
