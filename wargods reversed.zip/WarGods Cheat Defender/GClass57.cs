﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020000D4 RID: 212
public class GClass57
{
	// Token: 0x170002E0 RID: 736
	// (get) Token: 0x060006B9 RID: 1721 RVA: 0x000670E8 File Offset: 0x000652E8
	// (set) Token: 0x060006BA RID: 1722 RVA: 0x000670FC File Offset: 0x000652FC
	public uint UInt32_0 { get; set; }

	// Token: 0x170002E1 RID: 737
	// (get) Token: 0x060006BB RID: 1723 RVA: 0x00067110 File Offset: 0x00065310
	// (set) Token: 0x060006BC RID: 1724 RVA: 0x00067124 File Offset: 0x00065324
	public uint UInt32_1 { get; set; }

	// Token: 0x170002E2 RID: 738
	// (get) Token: 0x060006BD RID: 1725 RVA: 0x00067138 File Offset: 0x00065338
	// (set) Token: 0x060006BE RID: 1726 RVA: 0x0006714C File Offset: 0x0006534C
	public string String_0 { get; set; }

	// Token: 0x170002E3 RID: 739
	// (get) Token: 0x060006BF RID: 1727 RVA: 0x00067160 File Offset: 0x00065360
	// (set) Token: 0x060006C0 RID: 1728 RVA: 0x00067174 File Offset: 0x00065374
	public string String_1 { get; set; }

	// Token: 0x060006C1 RID: 1729 RVA: 0x00067188 File Offset: 0x00065388
	public GClass57(string string_2, string string_3, uint uint_2, uint uint_3)
	{
		this.String_0 = string_2;
		this.String_1 = string_3;
		this.UInt32_0 = uint_2;
		this.UInt32_1 = uint_3;
	}

	// Token: 0x060006C2 RID: 1730 RVA: 0x000671B8 File Offset: 0x000653B8
	public virtual string ToString()
	{
		return string.Format(<Module>.DeserializeFromByteArray2<string>(1326830228U), new object[]
		{
			Class15.SanitizeString(this.String_0),
			Class15.char_2,
			Class15.SanitizeString(this.String_1),
			Class15.char_2,
			this.UInt32_0,
			Class15.char_2,
			this.UInt32_1
		});
	}

	// Token: 0x0400099E RID: 2462
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x0400099F RID: 2463
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x040009A0 RID: 2464
	[CompilerGenerated]
	private string string_0;

	// Token: 0x040009A1 RID: 2465
	[CompilerGenerated]
	private string string_1;
}
