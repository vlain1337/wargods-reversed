﻿using System;
using System.IO;
using System.Runtime.CompilerServices;

// Token: 0x02000054 RID: 84
public class GClass33
{
	// Token: 0x060002D8 RID: 728 RVA: 0x0004C7A4 File Offset: 0x0004A9A4
	public GClass33(byte[] byte_0, int int_0, bool bool_0)
	{
		this.UInt64_0 = (bool_0 ? BitConverter.ToUInt64(byte_0, int_0) : ((ulong)BitConverter.ToUInt32(byte_0, int_0)));
	}

	// Token: 0x060002D9 RID: 729 RVA: 0x0004C7D4 File Offset: 0x0004A9D4
	public GClass33(BinaryReader binaryReader_0, int int_0, bool bool_0)
	{
		if (int_0 == 0 || (long)int_0 >= binaryReader_0.BaseStream.Length)
		{
			throw new ArgumentException(<Module>.DeserializeFromByteArrayV2<string>(3367237028U));
		}
		binaryReader_0.BaseStream.Seek((long)int_0, SeekOrigin.Begin);
		byte[] array = new byte[bool_0 ? 8 : 4];
		if (binaryReader_0.Read(array, 0, array.Length) != array.Length)
		{
			throw new IOException(<Module>.DeserializeFromByteArray<string>(1545899249U));
		}
		this.UInt64_0 = (bool_0 ? BitConverter.ToUInt64(array, 0) : ((ulong)BitConverter.ToUInt32(array, 0)));
	}

	// Token: 0x17000133 RID: 307
	// (get) Token: 0x060002DA RID: 730 RVA: 0x0004C864 File Offset: 0x0004AA64
	// (set) Token: 0x060002DB RID: 731 RVA: 0x0004C878 File Offset: 0x0004AA78
	public ulong UInt64_0 { get; set; }

	// Token: 0x04000285 RID: 645
	[CompilerGenerated]
	private ulong ulong_0;
}
