﻿// Token: 0x020000BA RID: 186
public partial class MAIN : global::System.Windows.Forms.Form
{
}
