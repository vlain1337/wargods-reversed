﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;

// Token: 0x0200003A RID: 58
public static class GClass18
{
	// Token: 0x0600017E RID: 382 RVA: 0x00048EC4 File Offset: 0x000470C4
	public static string smethod_0(byte[] byte_0)
	{
		return Encoding.UTF8.GetString(byte_0).TrimEnd(new char[1]);
	}

	// Token: 0x0600017F RID: 383 RVA: 0x00048EE8 File Offset: 0x000470E8
	public static string smethod_1(ushort ushort_0)
	{
		string result = <Module>.DeserializeFromByteArrayV2<string>(1648303711U);
		if (ushort_0 <= 497)
		{
			if (ushort_0 > 388)
			{
				if (ushort_0 <= 450)
				{
					switch (ushort_0)
					{
					case 418:
						result = <Module>.DeserealizeFromByteArrayV2_1<string>(3126540819U);
						break;
					case 419:
						result = <Module>.DeserializeFromByteArray2<string>(3864486998U);
						break;
					case 420:
						result = <Module>.DeserializeFromByteArrayV2<string>(2472823864U);
						break;
					case 421:
					case 423:
						break;
					case 422:
						result = <Module>.DeserializeFromByteArrayV2<string>(184173092U);
						break;
					case 424:
						result = <Module>.DeserializeFromByteArray<string>(1279438612U);
						break;
					default:
						if (ushort_0 != 448)
						{
							if (ushort_0 == 450)
							{
								result = <Module>.DeserializeFromByteArray2<string>(1807104325U);
							}
						}
						else
						{
							result = <Module>.DeserializeFromByteArray3<string>(143934643U);
						}
						break;
					}
				}
				else if (ushort_0 == 467)
				{
					result = <Module>.DeserializeFromByteArray<string>(3545338547U);
				}
				else if (ushort_0 == 496)
				{
					result = <Module>.DeserializeFromByteArray2<string>(3357809533U);
				}
				else if (ushort_0 == 497)
				{
					result = <Module>.DeserializeFromByteArray3<string>(2059858418U);
				}
			}
			else if (ushort_0 > 354)
			{
				switch (ushort_0)
				{
				case 358:
					result = <Module>.DeserealizeFromByteArrayV2_1<string>(4063103604U);
					break;
				case 359:
					break;
				case 360:
					result = <Module>.DeserializeFromByteArray<string>(1916573074U);
					break;
				case 361:
					result = <Module>.DeserealizeFromByteArrayV2_1<string>(3376088088U);
					break;
				default:
					if (ushort_0 != 387)
					{
						if (ushort_0 == 388)
						{
							result = <Module>.DeserializeFromByteArray3<string>(3893306440U);
						}
					}
					else
					{
						result = <Module>.DeserializeFromByteArray<string>(585118166U);
					}
					break;
				}
			}
			else if (ushort_0 != 332)
			{
				if (ushort_0 != 333)
				{
					if (ushort_0 == 354)
					{
						result = <Module>.DeserealizeFromByteArrayV2_1<string>(489726664U);
					}
				}
				else
				{
					result = <Module>.DeserealizeFromByteArrayV2_1<string>(1211317020U);
				}
			}
			else
			{
				result = <Module>.DeserealizeFromByteArrayV2_1<string>(1932907376U);
			}
		}
		else if (ushort_0 <= 1126)
		{
			if (ushort_0 <= 616)
			{
				if (ushort_0 == 512)
				{
					result = <Module>.DeserealizeFromByteArrayV2_1<string>(581446511U);
				}
				else if (ushort_0 != 614)
				{
					if (ushort_0 == 616)
					{
						result = <Module>.DeserializeFromByteArray<string>(2833053442U);
					}
				}
				else
				{
					result = <Module>.DeserializeFromByteArray2<string>(2148988666U);
				}
			}
			else if (ushort_0 == 644)
			{
				result = <Module>.DeserializeFromByteArray<string>(3845941119U);
			}
			else if (ushort_0 == 870)
			{
				result = <Module>.DeserializeFromByteArray2<string>(1388900049U);
			}
			else if (ushort_0 == 1126)
			{
				result = <Module>.DeserializeFromByteArray3<string>(3290618055U);
			}
		}
		else if (ushort_0 > 3772)
		{
			if (ushort_0 != 34404)
			{
				if (ushort_0 == 36929)
				{
					result = <Module>.DeserializeFromByteArray<string>(3133656014U);
				}
				else if (ushort_0 == 49390)
				{
					result = <Module>.DeserializeFromByteArray2<string>(955431786U);
				}
			}
			else
			{
				result = <Module>.DeserializeFromByteArray2<string>(1327844101U);
			}
		}
		else if (ushort_0 == 1312)
		{
			result = <Module>.DeserializeFromByteArray3<string>(1818783064U);
		}
		else if (ushort_0 == 3311)
		{
			result = <Module>.DeserializeFromByteArray<string>(2045617694U);
		}
		else if (ushort_0 == 3772)
		{
			result = <Module>.DeserealizeFromByteArrayV2_1<string>(838517169U);
		}
		return result;
	}

	// Token: 0x06000180 RID: 384 RVA: 0x00049220 File Offset: 0x00047420
	public static GClass18.GClass19 smethod_2(ushort ushort_0)
	{
		return new GClass18.GClass19(ushort_0);
	}

	// Token: 0x06000181 RID: 385 RVA: 0x00049234 File Offset: 0x00047434
	public static string smethod_3(uint uint_0)
	{
		switch (uint_0)
		{
		case 1U:
			return <Module>.DeserializeFromByteArray<string>(864464072U);
		case 2U:
			return <Module>.DeserializeFromByteArray<string>(3752825817U);
		case 3U:
			return <Module>.DeserializeFromByteArrayV2<string>(391565370U);
		case 4U:
			return <Module>.DeserealizeFromByteArrayV2_1<string>(3836126502U);
		case 5U:
			return <Module>.DeserializeFromByteArrayV2<string>(1268544902U);
		case 6U:
			return <Module>.DeserializeFromByteArray2<string>(506699536U);
		case 7U:
			return <Module>.DeserializeFromByteArray<string>(1952502392U);
		case 8U:
			return <Module>.DeserializeFromByteArray3<string>(4058257946U);
		case 9U:
			return <Module>.DeserializeFromByteArray<string>(2496521552U);
		case 10U:
			return <Module>.DeserializeFromByteArray2<string>(4041578215U);
		case 11U:
			return <Module>.DeserializeFromByteArray<string>(3509409229U);
		case 14U:
			return <Module>.DeserializeFromByteArrayV2<string>(2123041843U);
		case 16U:
			return <Module>.DeserializeFromByteArray<string>(4053428389U);
		case 17U:
			return <Module>.DeserializeFromByteArray<string>(2418078902U);
		case 19U:
			return <Module>.DeserealizeFromByteArrayV2_1<string>(934718300U);
		case 20U:
			return <Module>.DeserializeFromByteArray3<string>(2345347601U);
		case 21U:
			return <Module>.DeserealizeFromByteArrayV2_1<string>(3425709706U);
		case 22U:
			return <Module>.DeserealizeFromByteArrayV2_1<string>(4001477313U);
		case 23U:
			return <Module>.DeserializeFromByteArrayV2<string>(2360410909U);
		case 24U:
			return <Module>.DeserializeFromByteArrayV2<string>(3504736295U);
		}
		return <Module>.DeserealizeFromByteArrayV2_1<string>(3951855695U);
	}

	// Token: 0x06000182 RID: 386 RVA: 0x00049394 File Offset: 0x00047594
	public static string smethod_4(ushort ushort_0)
	{
		string result = <Module>.DeserializeFromByteArray3<string>(2338995696U);
		switch (ushort_0)
		{
		case 1:
			result = <Module>.DeserializeFromByteArray<string>(4050136382U);
			break;
		case 2:
			result = <Module>.DeserializeFromByteArrayV2<string>(2078076661U);
			break;
		case 3:
			result = <Module>.DeserializeFromByteArray2<string>(802791916U);
			break;
		case 5:
			result = <Module>.DeserializeFromByteArray2<string>(2756437413U);
			break;
		case 7:
			result = <Module>.DeserializeFromByteArrayV2<string>(2100559252U);
			break;
		case 8:
			result = <Module>.DeserializeFromByteArray3<string>(2668898708U);
			break;
		case 9:
			result = <Module>.DeserializeFromByteArray3<string>(3899658345U);
			break;
		case 10:
			result = <Module>.DeserealizeFromByteArrayV2_1<string>(2343324172U);
			break;
		case 11:
			result = <Module>.DeserializeFromByteArray<string>(1462377209U);
			break;
		case 12:
			result = <Module>.DeserealizeFromByteArrayV2_1<string>(2995764848U);
			break;
		case 13:
			result = <Module>.DeserializeFromByteArrayV2<string>(1193602932U);
			break;
		case 14:
			result = <Module>.DeserealizeFromByteArrayV2_1<string>(1372186547U);
			break;
		}
		return result;
	}

	// Token: 0x06000183 RID: 387 RVA: 0x00049494 File Offset: 0x00047694
	public static List<string> smethod_5(uint uint_0)
	{
		List<string> list = new List<string>();
		foreach (GClass12.SectionFlags sectionFlags in (GClass12.SectionFlags[])Enum.GetValues(typeof(GClass12.SectionFlags)))
		{
			if ((uint_0 & (uint)sectionFlags) == (uint)sectionFlags)
			{
				list.Add(sectionFlags.ToString());
			}
		}
		return list;
	}

	// Token: 0x06000184 RID: 388 RVA: 0x000494EC File Offset: 0x000476EC
	public static void smethod_6(ushort ushort_0, ulong ulong_0, byte[] byte_0)
	{
		byte[] bytes = BitConverter.GetBytes(ushort_0);
		checked
		{
			byte_0[(int)((IntPtr)ulong_0)] = bytes[0];
			byte_0[(int)((IntPtr)(unchecked(ulong_0 + 1UL)))] = bytes[1];
		}
	}

	// Token: 0x06000185 RID: 389 RVA: 0x00049518 File Offset: 0x00047718
	public static void smethod_7(uint uint_0, uint uint_1, byte[] byte_0)
	{
		byte[] bytes = BitConverter.GetBytes(uint_0);
		byte_0[(int)uint_1] = bytes[0];
		byte_0[(int)(uint_1 + 1U)] = bytes[1];
		byte_0[(int)(uint_1 + 2U)] = bytes[2];
		byte_0[(int)(uint_1 + 3U)] = bytes[3];
	}

	// Token: 0x06000186 RID: 390 RVA: 0x0004954C File Offset: 0x0004774C
	public static void smethod_8(ulong ulong_0, ulong ulong_1, byte[] byte_0)
	{
		byte[] bytes = BitConverter.GetBytes(ulong_0);
		checked
		{
			byte_0[(int)((IntPtr)ulong_1)] = bytes[0];
			byte_0[(int)((IntPtr)(unchecked(ulong_1 + 1UL)))] = bytes[1];
			byte_0[(int)((IntPtr)(unchecked(ulong_1 + 2UL)))] = bytes[2];
			byte_0[(int)((IntPtr)(unchecked(ulong_1 + 3UL)))] = bytes[3];
			byte_0[(int)((IntPtr)(unchecked(ulong_1 + 4UL)))] = bytes[4];
			byte_0[(int)((IntPtr)(unchecked(ulong_1 + 5UL)))] = bytes[5];
			byte_0[(int)((IntPtr)(unchecked(ulong_1 + 6UL)))] = bytes[6];
			byte_0[(int)((IntPtr)(unchecked(ulong_1 + 7UL)))] = bytes[7];
		}
	}

	// Token: 0x06000187 RID: 391 RVA: 0x000495E0 File Offset: 0x000477E0
	internal static string smethod_9(object object_0, string string_0)
	{
		PropertyInfo[] properties = object_0.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);
		StringBuilder stringBuilder = new StringBuilder();
		PropertyInfo[] array = properties;
		for (int i = 0; i < array.Length; i++)
		{
			bool isArray = array[i].PropertyType.IsArray;
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000188 RID: 392 RVA: 0x00049624 File Offset: 0x00047824
	public static uint smethod_10(uint uint_0, GClass31[] gclass31_0)
	{
		uint num = 0U;
		while ((ulong)num < (ulong)((long)gclass31_0.Length) && (gclass31_0[(int)num].UInt32_2 > uint_0 || uint_0 >= gclass31_0[(int)num].UInt32_2 + gclass31_0[(int)num].UInt32_1))
		{
			num += 1U;
		}
		if ((ulong)num >= (ulong)((long)gclass31_0.Length))
		{
			throw new Exception(<Module>.DeserializeFromByteArray3<string>(2427823354U));
		}
		return uint_0 - gclass31_0[(int)num].UInt32_2 + gclass31_0[(int)num].UInt32_4;
	}

	// Token: 0x06000189 RID: 393 RVA: 0x0004968C File Offset: 0x0004788C
	public static ulong smethod_11(ulong ulong_0, GClass31[] gclass31_0)
	{
		uint num = 0U;
		while ((ulong)num < (ulong)((long)gclass31_0.Length) && ((ulong)gclass31_0[(int)num].UInt32_2 > ulong_0 || ulong_0 >= (ulong)(gclass31_0[(int)num].UInt32_2 + gclass31_0[(int)num].UInt32_1)))
		{
			num += 1U;
		}
		if ((ulong)num >= (ulong)((long)gclass31_0.Length))
		{
			throw new Exception(<Module>.DeserializeFromByteArrayV2<string>(3772082149U));
		}
		return ulong_0 - (ulong)gclass31_0[(int)num].UInt32_2 + (ulong)gclass31_0[(int)num].UInt32_4;
	}

	// Token: 0x0600018A RID: 394 RVA: 0x000496F8 File Offset: 0x000478F8
	public static string smethod_12(ulong ulong_0, byte[] byte_0)
	{
		ulong num = GClass18.smethod_15(ulong_0, byte_0);
		char[] array = new char[num + 1UL];
		Array.Clear(array, 0, array.Length);
		for (ulong num2 = 0UL; num2 < num; num2 += 1UL)
		{
			checked
			{
				array[(int)((IntPtr)num2)] = (char)byte_0[(int)((IntPtr)(unchecked(ulong_0 + num2)))];
			}
		}
		return new string(array).TrimEnd(new char[1]);
	}

	// Token: 0x0600018B RID: 395 RVA: 0x00049760 File Offset: 0x00047960
	public static string smethod_13(byte[] byte_0)
	{
		ulong num = GClass18.smethod_14(byte_0);
		char[] array = new char[num + 1UL];
		Array.Clear(array, 0, array.Length);
		for (ulong num2 = 0UL; num2 < num; num2 += 1UL)
		{
			checked
			{
				array[(int)((IntPtr)num2)] = (char)byte_0[(int)((IntPtr)num2)];
			}
		}
		return new string(array).TrimEnd(new char[1]);
	}

	// Token: 0x0600018C RID: 396 RVA: 0x000497C8 File Offset: 0x000479C8
	public static ulong smethod_14(byte[] byte_0)
	{
		ulong num = 0UL;
		while (byte_0[(int)(checked((IntPtr)num))] != 0 && num < (ulong)byte_0.Length)
		{
			num += 1UL;
		}
		return num;
	}

	// Token: 0x0600018D RID: 397 RVA: 0x000497FC File Offset: 0x000479FC
	public static ulong smethod_15(ulong ulong_0, byte[] byte_0)
	{
		ulong num = ulong_0;
		ulong num2 = 0UL;
		while (byte_0[(int)(checked((IntPtr)num))] != 0)
		{
			num2 += 1UL;
			num += 1UL;
		}
		return num2;
	}

	// Token: 0x0600018E RID: 398 RVA: 0x00049838 File Offset: 0x00047A38
	public static int smethod_16(IEnumerable ienumerable_0)
	{
		ICollection collection = ienumerable_0 as ICollection;
		if (collection != null)
		{
			return collection.Count;
		}
		int num = 0;
		IEnumerator enumerator = ienumerable_0.GetEnumerator();
		while (enumerator.MoveNext())
		{
			num++;
		}
		return num;
	}

	// Token: 0x0600018F RID: 399 RVA: 0x00049870 File Offset: 0x00047A70
	public static string smethod_17(IEnumerable<byte> ienumerable_0)
	{
		StringBuilder stringBuilder = new StringBuilder(GClass18.smethod_16(ienumerable_0) * 2);
		foreach (byte b in ienumerable_0)
		{
			stringBuilder.AppendFormat(<Module>.DeserializeFromByteArrayV2<string>(1468442983U), b);
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000190 RID: 400 RVA: 0x000498E0 File Offset: 0x00047AE0
	public static string smethod_18(IEnumerable<ushort> ienumerable_0)
	{
		StringBuilder stringBuilder = new StringBuilder(GClass18.smethod_16(ienumerable_0) * 2);
		foreach (ushort num in ienumerable_0)
		{
			stringBuilder.AppendFormat(<Module>.DeserealizeFromByteArrayV2_1<string>(143978264U), num);
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000191 RID: 401 RVA: 0x00049950 File Offset: 0x00047B50
	public static string smethod_19(ushort ushort_0)
	{
		return <Module>.DeserializeFromByteArray3<string>(2871912138U) + ushort_0.ToString(<Module>.DeserializeFromByteArray<string>(1762979781U));
	}

	// Token: 0x06000192 RID: 402 RVA: 0x00049980 File Offset: 0x00047B80
	public static string smethod_20(uint uint_0)
	{
		return <Module>.DeserializeFromByteArrayV2<string>(41783349U) + uint_0.ToString(<Module>.DeserealizeFromByteArrayV2_1<string>(677647642U));
	}

	// Token: 0x06000193 RID: 403 RVA: 0x000499B0 File Offset: 0x00047BB0
	public static string smethod_21(ulong ulong_0)
	{
		return <Module>.DeserializeFromByteArrayV2<string>(41783349U) + ulong_0.ToString(<Module>.DeserializeFromByteArray<string>(825242747U));
	}

	// Token: 0x06000194 RID: 404 RVA: 0x000499E0 File Offset: 0x00047BE0
	public static bool smethod_22(string string_0)
	{
		bool result;
		try
		{
			new X509Certificate2(X509Certificate.CreateFromSignedFile(string_0));
			return true;
		}
		catch (Exception)
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000195 RID: 405 RVA: 0x00049A14 File Offset: 0x00047C14
	public static bool smethod_23(string string_0, bool bool_0)
	{
		X509Certificate2 x509Certificate2_;
		bool result;
		try
		{
			x509Certificate2_ = new X509Certificate2(X509Certificate.CreateFromSignedFile(string_0));
			goto IL_15;
		}
		catch (Exception)
		{
			result = false;
		}
		return result;
		IL_15:
		return GClass18.smethod_25(x509Certificate2_, bool_0);
	}

	// Token: 0x06000196 RID: 406 RVA: 0x00049A50 File Offset: 0x00047C50
	public static bool smethod_24(string string_0)
	{
		return Class8.smethod_1(string_0);
	}

	// Token: 0x06000197 RID: 407 RVA: 0x00049A64 File Offset: 0x00047C64
	public static bool smethod_25(X509Certificate2 x509Certificate2_0, bool bool_0)
	{
		return new X509Chain
		{
			ChainPolicy = 
			{
				RevocationFlag = X509RevocationFlag.ExcludeRoot,
				RevocationMode = (bool_0 ? X509RevocationMode.Online : X509RevocationMode.Offline),
				UrlRetrievalTimeout = new TimeSpan(0, 0, 5),
				VerificationFlags = X509VerificationFlags.NoFlag
			}
		}.Build(x509Certificate2_0);
	}

	// Token: 0x040001BD RID: 445
	public static readonly int int_0 = 256;

	// Token: 0x0200003B RID: 59
	public class GClass19
	{
		// Token: 0x06000199 RID: 409 RVA: 0x00049AD4 File Offset: 0x00047CD4
		public GClass19(ushort ushort_0)
		{
			if ((ushort_0 & 1) > 0)
			{
				this.Boolean_0 = true;
			}
			if ((ushort_0 & 2) > 0)
			{
				this.Boolean_1 = true;
			}
			if ((ushort_0 & 4) > 0)
			{
				this.Boolean_2 = true;
			}
			if ((ushort_0 & 8) > 0)
			{
				this.Boolean_3 = true;
			}
			if ((ushort_0 & 16) > 0)
			{
				this.Boolean_4 = true;
			}
			if ((ushort_0 & 32) > 0)
			{
				this.Boolean_5 = true;
			}
			if ((ushort_0 & 128) > 0)
			{
				this.Boolean_6 = true;
			}
			if ((ushort_0 & 256) > 0)
			{
				this.Boolean_7 = true;
			}
			if ((ushort_0 & 512) > 0)
			{
				this.Boolean_8 = true;
			}
			if ((ushort_0 & 1024) > 0)
			{
				this.Boolean_9 = true;
			}
			if ((ushort_0 & 2048) > 0)
			{
				this.Boolean_10 = true;
			}
			if ((ushort_0 & 4096) > 0)
			{
				this.Boolean_11 = true;
			}
			if ((ushort_0 & 8192) > 0)
			{
				this.Boolean_12 = true;
			}
			if ((ushort_0 & 16384) > 0)
			{
				this.Boolean_13 = true;
			}
			if ((ushort_0 & 32768) > 0)
			{
				this.Boolean_14 = true;
			}
		}

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x0600019A RID: 410 RVA: 0x00049BD0 File Offset: 0x00047DD0
		// (set) Token: 0x0600019B RID: 411 RVA: 0x00049BE4 File Offset: 0x00047DE4
		public bool Boolean_0 { get; private set; }

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x0600019C RID: 412 RVA: 0x00049BF8 File Offset: 0x00047DF8
		// (set) Token: 0x0600019D RID: 413 RVA: 0x00049C0C File Offset: 0x00047E0C
		public bool Boolean_1 { get; private set; }

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x0600019E RID: 414 RVA: 0x00049C20 File Offset: 0x00047E20
		// (set) Token: 0x0600019F RID: 415 RVA: 0x00049C34 File Offset: 0x00047E34
		public bool Boolean_2 { get; private set; }

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x060001A0 RID: 416 RVA: 0x00049C48 File Offset: 0x00047E48
		// (set) Token: 0x060001A1 RID: 417 RVA: 0x00049C5C File Offset: 0x00047E5C
		public bool Boolean_3 { get; private set; }

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x060001A2 RID: 418 RVA: 0x00049C70 File Offset: 0x00047E70
		// (set) Token: 0x060001A3 RID: 419 RVA: 0x00049C84 File Offset: 0x00047E84
		public bool Boolean_4 { get; private set; }

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x060001A4 RID: 420 RVA: 0x00049C98 File Offset: 0x00047E98
		// (set) Token: 0x060001A5 RID: 421 RVA: 0x00049CAC File Offset: 0x00047EAC
		public bool Boolean_5 { get; private set; }

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x060001A6 RID: 422 RVA: 0x00049CC0 File Offset: 0x00047EC0
		// (set) Token: 0x060001A7 RID: 423 RVA: 0x00049CD4 File Offset: 0x00047ED4
		public bool Boolean_6 { get; private set; }

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x060001A8 RID: 424 RVA: 0x00049CE8 File Offset: 0x00047EE8
		// (set) Token: 0x060001A9 RID: 425 RVA: 0x00049CFC File Offset: 0x00047EFC
		public bool Boolean_7 { get; private set; }

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x060001AA RID: 426 RVA: 0x00049D10 File Offset: 0x00047F10
		// (set) Token: 0x060001AB RID: 427 RVA: 0x00049D24 File Offset: 0x00047F24
		public bool Boolean_8 { get; private set; }

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x060001AC RID: 428 RVA: 0x00049D38 File Offset: 0x00047F38
		// (set) Token: 0x060001AD RID: 429 RVA: 0x00049D4C File Offset: 0x00047F4C
		public bool Boolean_9 { get; private set; }

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x060001AE RID: 430 RVA: 0x00049D60 File Offset: 0x00047F60
		// (set) Token: 0x060001AF RID: 431 RVA: 0x00049D74 File Offset: 0x00047F74
		public bool Boolean_10 { get; private set; }

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x060001B0 RID: 432 RVA: 0x00049D88 File Offset: 0x00047F88
		// (set) Token: 0x060001B1 RID: 433 RVA: 0x00049D9C File Offset: 0x00047F9C
		public bool Boolean_11 { get; private set; }

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x060001B2 RID: 434 RVA: 0x00049DB0 File Offset: 0x00047FB0
		// (set) Token: 0x060001B3 RID: 435 RVA: 0x00049DC4 File Offset: 0x00047FC4
		public bool Boolean_12 { get; private set; }

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x060001B4 RID: 436 RVA: 0x00049DD8 File Offset: 0x00047FD8
		// (set) Token: 0x060001B5 RID: 437 RVA: 0x00049DEC File Offset: 0x00047FEC
		public bool Boolean_13 { get; private set; }

		// Token: 0x170000BE RID: 190
		// (get) Token: 0x060001B6 RID: 438 RVA: 0x00049E00 File Offset: 0x00048000
		// (set) Token: 0x060001B7 RID: 439 RVA: 0x00049E14 File Offset: 0x00048014
		public bool Boolean_14 { get; private set; }

		// Token: 0x060001B8 RID: 440 RVA: 0x00049E28 File Offset: 0x00048028
		public virtual string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder(<Module>.DeserializeFromByteArrayV2<string>(2063088267U));
			stringBuilder.Append(GClass18.smethod_9(this, <Module>.DeserializeFromByteArray<string>(900393390U)));
			return stringBuilder.ToString();
		}

		// Token: 0x040001BE RID: 446
		[CompilerGenerated]
		private bool bool_0;

		// Token: 0x040001BF RID: 447
		[CompilerGenerated]
		private bool bool_1;

		// Token: 0x040001C0 RID: 448
		[CompilerGenerated]
		private bool bool_2;

		// Token: 0x040001C1 RID: 449
		[CompilerGenerated]
		private bool bool_3;

		// Token: 0x040001C2 RID: 450
		[CompilerGenerated]
		private bool bool_4;

		// Token: 0x040001C3 RID: 451
		[CompilerGenerated]
		private bool bool_5;

		// Token: 0x040001C4 RID: 452
		[CompilerGenerated]
		private bool bool_6;

		// Token: 0x040001C5 RID: 453
		[CompilerGenerated]
		private bool bool_7;

		// Token: 0x040001C6 RID: 454
		[CompilerGenerated]
		private bool bool_8;

		// Token: 0x040001C7 RID: 455
		[CompilerGenerated]
		private bool bool_9;

		// Token: 0x040001C8 RID: 456
		[CompilerGenerated]
		private bool bool_10;

		// Token: 0x040001C9 RID: 457
		[CompilerGenerated]
		private bool bool_11;

		// Token: 0x040001CA RID: 458
		[CompilerGenerated]
		private bool bool_12;

		// Token: 0x040001CB RID: 459
		[CompilerGenerated]
		private bool bool_13;

		// Token: 0x040001CC RID: 460
		[CompilerGenerated]
		private bool bool_14;
	}
}
