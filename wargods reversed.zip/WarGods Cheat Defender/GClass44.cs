﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;

// Token: 0x02000071 RID: 113
public class GClass44
{
	// Token: 0x1700015F RID: 351
	// (get) Token: 0x0600038B RID: 907 RVA: 0x0004F5F4 File Offset: 0x0004D7F4
	// (set) Token: 0x0600038C RID: 908 RVA: 0x0004F608 File Offset: 0x0004D808
	public long Int64_0 { get; set; }

	// Token: 0x17000160 RID: 352
	// (get) Token: 0x0600038D RID: 909 RVA: 0x0004F61C File Offset: 0x0004D81C
	// (set) Token: 0x0600038E RID: 910 RVA: 0x0004F630 File Offset: 0x0004D830
	public GEnum48 GEnum48_0 { get; set; }

	// Token: 0x17000161 RID: 353
	// (get) Token: 0x0600038F RID: 911 RVA: 0x0004F644 File Offset: 0x0004D844
	// (set) Token: 0x06000390 RID: 912 RVA: 0x0004F658 File Offset: 0x0004D858
	public GEnum21 GEnum21_0 { get; set; }

	// Token: 0x17000162 RID: 354
	// (get) Token: 0x06000391 RID: 913 RVA: 0x0004F66C File Offset: 0x0004D86C
	public bool Boolean_0
	{
		get
		{
			if (this.nullable_0 == null)
			{
				this.nullable_0 = new bool?(File.Exists(this.String_1));
			}
			return this.nullable_0.Value;
		}
	}

	// Token: 0x17000163 RID: 355
	// (get) Token: 0x06000392 RID: 914 RVA: 0x0004F6A8 File Offset: 0x0004D8A8
	// (set) Token: 0x06000393 RID: 915 RVA: 0x0004F6BC File Offset: 0x0004D8BC
	public string String_0 { get; set; }

	// Token: 0x17000164 RID: 356
	// (get) Token: 0x06000394 RID: 916 RVA: 0x0004F6D0 File Offset: 0x0004D8D0
	// (set) Token: 0x06000395 RID: 917 RVA: 0x0004F6E4 File Offset: 0x0004D8E4
	public string String_1 { get; set; }

	// Token: 0x17000165 RID: 357
	// (get) Token: 0x06000396 RID: 918 RVA: 0x0004F6F8 File Offset: 0x0004D8F8
	public string String_2
	{
		get
		{
			if (this.string_2 == null || this.string_2.Length != 64)
			{
				this.string_2 = Class15.ExtractRelativePath(this.String_1);
			}
			return this.string_2;
		}
	}

	// Token: 0x17000166 RID: 358
	// (get) Token: 0x06000397 RID: 919 RVA: 0x0004F734 File Offset: 0x0004D934
	public string String_3
	{
		get
		{
			if (this.string_3 == null || this.string_3.Length != 32)
			{
				this.string_3 = Class15.CalculateMD5HashFromFile(this.String_1);
			}
			return this.string_3;
		}
	}

	// Token: 0x06000398 RID: 920 RVA: 0x0004F774 File Offset: 0x0004D974
	private string method_0(string string_6)
	{
		string result = "";
		try
		{
			FileVersionInfo versionInfo = FileVersionInfo.GetVersionInfo(this.String_1);
			result = string.Format(<Module>.DeserializeFromByteArray<string>(1678235876U), new object[]
			{
				Class15.SanitizeString(versionInfo.OriginalFilename),
				Class15.SanitizeString(versionInfo.InternalName),
				Class15.SanitizeString(versionInfo.LegalCopyright),
				Class15.SanitizeString(versionInfo.CompanyName),
				Class15.SanitizeString(versionInfo.Language)
			});
		}
		catch
		{
			result = <Module>.DeserializeFromByteArray2<string>(441953499U);
		}
		return result;
	}

	// Token: 0x17000167 RID: 359
	// (get) Token: 0x06000399 RID: 921 RVA: 0x0004F810 File Offset: 0x0004DA10
	public string String_4
	{
		get
		{
			if (this.string_4 == null)
			{
				this.string_4 = this.method_0(this.String_1);
			}
			return this.string_4;
		}
	}

	// Token: 0x17000168 RID: 360
	// (get) Token: 0x0600039A RID: 922 RVA: 0x0004F840 File Offset: 0x0004DA40
	// (set) Token: 0x0600039B RID: 923 RVA: 0x0004F854 File Offset: 0x0004DA54
	public long Int64_1 { get; set; }

	// Token: 0x17000169 RID: 361
	// (get) Token: 0x0600039C RID: 924 RVA: 0x0004F868 File Offset: 0x0004DA68
	// (set) Token: 0x0600039D RID: 925 RVA: 0x0004F87C File Offset: 0x0004DA7C
	public uint UInt32_0 { get; set; }

	// Token: 0x0600039E RID: 926 RVA: 0x0004F890 File Offset: 0x0004DA90
	private string method_1(string string_6)
	{
		string result = "";
		try
		{
			X509Certificate2 x509Certificate = new X509Certificate2(this.String_1);
			string text = Class15.SanitizeString(x509Certificate.SubjectName.Name);
			string text2 = Class15.SanitizeString(x509Certificate.IssuerName.Name);
			string text3 = x509Certificate.NotBefore.ToString(Class15.string_0, CultureInfo.InvariantCulture);
			string text4 = x509Certificate.NotAfter.ToString(Class15.string_0, CultureInfo.InvariantCulture);
			string text5 = x509Certificate.Version.ToString();
			result = string.Format(<Module>.DeserializeFromByteArrayV2<string>(513917760U), new object[]
			{
				text5,
				text,
				text2,
				text3,
				text4
			});
		}
		catch
		{
			result = <Module>.DeserializeFromByteArray<string>(3215107912U);
		}
		return result;
	}

	// Token: 0x1700016A RID: 362
	// (get) Token: 0x0600039F RID: 927 RVA: 0x0004F964 File Offset: 0x0004DB64
	public string String_5
	{
		get
		{
			if (this.string_5 == null)
			{
				this.string_5 = this.method_1(this.String_1);
			}
			return this.string_5;
		}
	}

	// Token: 0x1700016B RID: 363
	// (get) Token: 0x060003A0 RID: 928 RVA: 0x0004F994 File Offset: 0x0004DB94
	// (set) Token: 0x060003A1 RID: 929 RVA: 0x0004F9A8 File Offset: 0x0004DBA8
	public DateTime? Nullable_0 { get; set; }

	// Token: 0x1700016C RID: 364
	// (get) Token: 0x060003A2 RID: 930 RVA: 0x0004F9BC File Offset: 0x0004DBBC
	public long Int64_2
	{
		get
		{
			if (this.nullable_1 == null)
			{
				try
				{
					FileInfo fileInfo = new FileInfo(this.String_1);
					this.nullable_1 = new long?(fileInfo.Length);
				}
				catch
				{
					this.nullable_1 = new long?(0L);
				}
			}
			return this.nullable_1.Value;
		}
	}

	// Token: 0x1700016D RID: 365
	// (get) Token: 0x060003A3 RID: 931 RVA: 0x0004FA28 File Offset: 0x0004DC28
	public GClass17 GClass17_0
	{
		get
		{
			return this.gclass17_0;
		}
	}

	// Token: 0x1700016E RID: 366
	// (get) Token: 0x060003A4 RID: 932 RVA: 0x0004FA3C File Offset: 0x0004DC3C
	// (set) Token: 0x060003A5 RID: 933 RVA: 0x0004FA50 File Offset: 0x0004DC50
	public GEnum51 GEnum51_0 { get; private set; }

	// Token: 0x1700016F RID: 367
	// (get) Token: 0x060003A6 RID: 934 RVA: 0x0004FA64 File Offset: 0x0004DC64
	// (set) Token: 0x060003A7 RID: 935 RVA: 0x0004FAA8 File Offset: 0x0004DCA8
	private bool Boolean_1
	{
		get
		{
			object obj = this.object_0;
			bool result;
			lock (obj)
			{
				result = this.bool_0;
			}
			return result;
		}
		set
		{
			object obj = this.object_0;
			lock (obj)
			{
				this.bool_0 = value;
			}
		}
	}

	// Token: 0x060003A8 RID: 936 RVA: 0x0004FAEC File Offset: 0x0004DCEC
	public void method_2(string string_6, string string_7, uint uint_1, uint uint_2)
	{
		object obj = this.object_1;
		lock (obj)
		{
			this.list_0.Add(new GClass57(string_6, string_7, uint_1, uint_2));
		}
	}

	// Token: 0x060003A9 RID: 937
	public static string NormalizeFilePath(string string_6, bool bool_1, ref GEnum51 genum51_1)
	{
		if (string_6 == null)
		{
			throw new ArgumentException();
		}
		string text = string_6;
		try
		{
			if (text.StartsWith(<Module>.DeserializeFromByteArrayV2<string>(818259150U)))
			{
				text = text.Substring(4);
			}
			else if (!text.StartsWith(<Module>.DeserializeFromByteArray<string>(644091533U)))
			{
				string text2 = text.ToLowerInvariant();
				if (text2.StartsWith(<Module>.DeserializeFromByteArray<string>(1339633844U)))
				{
					text = Path.Combine(Environment.ExpandEnvironmentVariables(<Module>.DeserealizeFromByteArrayV2_1<string>(1070139302U)), text.Substring(12));
				}
				else if (text2.StartsWith(<Module>.DeserializeFromByteArray2<string>(3125159639U)))
				{
					StringBuilder stringBuilder = new StringBuilder(256);
					foreach (string text3 in Environment.GetLogicalDrives())
					{
						if (GClass45.QueryDosDevice(text3.Substring(0, 2), stringBuilder, 256) > 0U)
						{
							string text4 = stringBuilder.ToString().ToLowerInvariant();
							if (text2.StartsWith(text4))
							{
								string text5 = text.Substring(text4.Length);
								if (text5.Length > 0 && text5.StartsWith(<Module>.DeserializeFromByteArray<string>(477047453U)))
								{
									text5 = text5.Substring(1);
								}
								text = Path.Combine(text3.Substring(0, 2), text5);
								break;
							}
						}
					}
				}
			}
			else
			{
				text = text.Substring(3);
			}
			text = new FileInfo(text).FullName;
		}
		catch
		{
		}
		if (bool_1)
		{
			if (genum51_1 == GEnum51.const_2)
			{
				try
				{
					string text6 = Class15.ComposePath();
					string text7 = text;
					if (text7.ToLowerInvariant().StartsWith(text6.ToLowerInvariant()))
					{
						text7 = Path.Combine(Class15.ComposePath3(), text.Substring(text6.Length));
						if (!File.Exists(text7))
						{
							genum51_1 |= GEnum51.const_1;
						}
						else
						{
							text = text7;
						}
					}
				}
				catch
				{
				}
			}
			if (genum51_1 == GEnum51.const_1)
			{
				string text8 = Class15.ComposePath();
				if (text.ToLowerInvariant().StartsWith(text8.ToLowerInvariant()))
				{
					text = Path.Combine(Class15.ComposePath2(), text.Substring(text8.Length));
				}
			}
		}
		return text;
	}

	// Token: 0x060003AA RID: 938 RVA: 0x0004FD64 File Offset: 0x0004DF64
	private GClass44()
	{
		this.object_0 = new object();
		this.Boolean_1 = false;
		this.Int64_0 = -1L;
		this.GEnum21_0 = GEnum21.const_0;
		this.GEnum48_0 = GEnum48.const_0;
		this.String_0 = null;
		this.String_1 = null;
		this.string_3 = null;
		this.string_2 = null;
		this.string_4 = null;
		this.Int64_1 = 0L;
		this.string_5 = null;
		this.nullable_1 = new long?(0L);
		this.Nullable_0 = null;
		this.UInt32_0 = 0U;
		this.gclass17_0 = null;
		this.gclass0_0 = new GClass0();
		this.GEnum51_0 = GEnum51.const_0;
		this.object_1 = new object();
		this.list_0 = new List<GClass57>();
	}

	// Token: 0x060003AB RID: 939 RVA: 0x0004FE44 File Offset: 0x0004E044
	public GClass44(string string_6, GEnum48 genum48_1, bool bool_1 = false) : this()
	{
		this.GEnum48_0 = genum48_1;
		this.String_0 = string_6;
		this.String_1 = this.String_0;
		if (bool_1)
		{
			this.method_3();
		}
	}

	// Token: 0x060003AC RID: 940 RVA: 0x0004FE7C File Offset: 0x0004E07C
	public GClass44(string string_6, GEnum48 genum48_1, bool bool_1, GEnum51 genum51_1 = GEnum51.const_0, bool bool_2 = false) : this()
	{
		this.GEnum48_0 = genum48_1;
		this.String_0 = string_6;
		this.String_1 = GClass44.NormalizeFilePath(string_6, bool_1, ref genum51_1);
		this.GEnum51_0 = genum51_1;
		if (bool_2)
		{
			this.method_3();
		}
	}

	// Token: 0x060003AD RID: 941 RVA: 0x0004FEC0 File Offset: 0x0004E0C0
	public void method_3()
	{
		/*
An exception occurred when decompiling this method (060003AD)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void GClass44::method_3()

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 271
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060003AE RID: 942 RVA: 0x000501D4 File Offset: 0x0004E3D4
	public virtual string ToString()
	{
		string text = string.Empty;
		string result;
		try
		{
			if (this.GClass17_0 != null)
			{
				try
				{
					text = this.GClass17_0.ToString();
				}
				catch
				{
					text = string.Empty;
				}
			}
			List<string> list = new List<string>();
			for (int i = 0; i < this.list_0.Count; i++)
			{
				list.Add(this.list_0[i].ToString());
			}
			string text2 = Convert.ToBase64String(Encoding.UTF8.GetBytes(Class15.ListToString(list, ';')));
			result = string.Format(<Module>.DeserializeFromByteArray2<string>(3109895652U), new object[]
			{
				this.Int64_0,
				(int)this.GEnum48_0,
				(int)this.GEnum21_0,
				Class15.SanitizeString(this.String_1),
				this.String_3,
				this.String_2,
				(this.Nullable_0 == null) ? "" : this.Nullable_0.Value.ToString(Class15.string_0, CultureInfo.InvariantCulture),
				this.Int64_1,
				this.Int64_2,
				this.Boolean_0 ? <Module>.DeserializeFromByteArray2<string>(3165454329U) : <Module>.DeserializeFromByteArray3<string>(1552324843U),
				this.UInt32_0,
				text,
				this.String_4,
				this.String_5,
				this.gclass0_0.method_0(<Module>.DeserializeFromByteArray3<string>(3315926663U)),
				text2
			});
		}
		catch (Exception ex)
		{
			throw ex;
		}
		return result;
	}

	// Token: 0x04000367 RID: 871
	[CompilerGenerated]
	private long long_0;

	// Token: 0x04000368 RID: 872
	[CompilerGenerated]
	private GEnum48 genum48_0;

	// Token: 0x04000369 RID: 873
	[CompilerGenerated]
	private GEnum21 genum21_0;

	// Token: 0x0400036A RID: 874
	private bool? nullable_0;

	// Token: 0x0400036B RID: 875
	[CompilerGenerated]
	private string string_0;

	// Token: 0x0400036C RID: 876
	[CompilerGenerated]
	private string string_1;

	// Token: 0x0400036D RID: 877
	private string string_2;

	// Token: 0x0400036E RID: 878
	private string string_3;

	// Token: 0x0400036F RID: 879
	private string string_4;

	// Token: 0x04000370 RID: 880
	[CompilerGenerated]
	private long long_1;

	// Token: 0x04000371 RID: 881
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x04000372 RID: 882
	private string string_5;

	// Token: 0x04000373 RID: 883
	private long? nullable_1;

	// Token: 0x04000374 RID: 884
	[CompilerGenerated]
	private DateTime? nullable_2;

	// Token: 0x04000375 RID: 885
	private GClass17 gclass17_0;

	// Token: 0x04000376 RID: 886
	[CompilerGenerated]
	private GEnum51 genum51_0;

	// Token: 0x04000377 RID: 887
	public GClass0 gclass0_0;

	// Token: 0x04000378 RID: 888
	private object object_0;

	// Token: 0x04000379 RID: 889
	private bool bool_0;

	// Token: 0x0400037A RID: 890
	private object object_1;

	// Token: 0x0400037B RID: 891
	private List<GClass57> list_0;

	// Token: 0x0400037C RID: 892
	private object object_2 = new object();
}
