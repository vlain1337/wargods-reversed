﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x02000048 RID: 72
public class GClass21
{
	// Token: 0x060001CC RID: 460 RVA: 0x0004A2CC File Offset: 0x000484CC
	public GClass21(byte[] byte_0, int int_1)
	{
		this.method_0(byte_0, int_1);
	}

	// Token: 0x060001CD RID: 461 RVA: 0x0004A2E8 File Offset: 0x000484E8
	private void method_0(byte[] byte_0, int int_1)
	{
		this.UInt32_0 = BitConverter.ToUInt32(byte_0, int_1);
		this.UInt32_1 = BitConverter.ToUInt32(byte_0, int_1 + 4);
		this.UInt16_0 = BitConverter.ToUInt16(byte_0, int_1 + 8);
		this.UInt16_1 = BitConverter.ToUInt16(byte_0, int_1 + 10);
		this.UInt32_2 = BitConverter.ToUInt32(byte_0, int_1 + 12);
		this.UInt32_3 = BitConverter.ToUInt32(byte_0, int_1 + 16);
		this.UInt32_4 = BitConverter.ToUInt32(byte_0, int_1 + 20);
		this.UInt32_5 = BitConverter.ToUInt32(byte_0, int_1 + 24);
	}

	// Token: 0x060001CE RID: 462 RVA: 0x0004A370 File Offset: 0x00048570
	public GClass21(BinaryReader binaryReader_0, int int_1 = 0)
	{
		if (int_1 == 0 || (long)int_1 >= binaryReader_0.BaseStream.Length)
		{
			throw new ArgumentException(<Module>.DeserializeFromByteArrayV2<string>(1673231540U));
		}
		binaryReader_0.BaseStream.Seek((long)int_1, SeekOrigin.Begin);
		byte[] array = new byte[GClass21.int_0];
		if (binaryReader_0.Read(array, 0, array.Length) == array.Length)
		{
			this.method_0(array, 0);
			return;
		}
		throw new IOException(<Module>.DeserializeFromByteArrayV2<string>(528906154U));
	}

	// Token: 0x170000C1 RID: 193
	// (get) Token: 0x060001CF RID: 463 RVA: 0x0004A3EC File Offset: 0x000485EC
	// (set) Token: 0x060001D0 RID: 464 RVA: 0x0004A400 File Offset: 0x00048600
	public uint UInt32_0 { get; set; }

	// Token: 0x170000C2 RID: 194
	// (get) Token: 0x060001D1 RID: 465 RVA: 0x0004A414 File Offset: 0x00048614
	// (set) Token: 0x060001D2 RID: 466 RVA: 0x0004A428 File Offset: 0x00048628
	public uint UInt32_1 { get; set; }

	// Token: 0x170000C3 RID: 195
	// (get) Token: 0x060001D3 RID: 467 RVA: 0x0004A43C File Offset: 0x0004863C
	// (set) Token: 0x060001D4 RID: 468 RVA: 0x0004A450 File Offset: 0x00048650
	public ushort UInt16_0 { get; set; }

	// Token: 0x170000C4 RID: 196
	// (get) Token: 0x060001D5 RID: 469 RVA: 0x0004A464 File Offset: 0x00048664
	// (set) Token: 0x060001D6 RID: 470 RVA: 0x0004A478 File Offset: 0x00048678
	public ushort UInt16_1 { get; set; }

	// Token: 0x170000C5 RID: 197
	// (get) Token: 0x060001D7 RID: 471 RVA: 0x0004A48C File Offset: 0x0004868C
	// (set) Token: 0x060001D8 RID: 472 RVA: 0x0004A4A0 File Offset: 0x000486A0
	public uint UInt32_2 { get; set; }

	// Token: 0x170000C6 RID: 198
	// (get) Token: 0x060001D9 RID: 473 RVA: 0x0004A4B4 File Offset: 0x000486B4
	// (set) Token: 0x060001DA RID: 474 RVA: 0x0004A4C8 File Offset: 0x000486C8
	public uint UInt32_3 { get; set; }

	// Token: 0x170000C7 RID: 199
	// (get) Token: 0x060001DB RID: 475 RVA: 0x0004A4DC File Offset: 0x000486DC
	// (set) Token: 0x060001DC RID: 476 RVA: 0x0004A4F0 File Offset: 0x000486F0
	public uint UInt32_4 { get; set; }

	// Token: 0x170000C8 RID: 200
	// (get) Token: 0x060001DD RID: 477 RVA: 0x0004A504 File Offset: 0x00048704
	// (set) Token: 0x060001DE RID: 478 RVA: 0x0004A518 File Offset: 0x00048718
	public uint UInt32_5 { get; set; }

	// Token: 0x060001DF RID: 479 RVA: 0x0004A52C File Offset: 0x0004872C
	public virtual string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder(<Module>.DeserializeFromByteArray<string>(4283959708U));
		stringBuilder.Append(GClass18.smethod_9(this, <Module>.DeserealizeFromByteArrayV2_1<string>(1190186032U)));
		return stringBuilder.ToString();
	}

	// Token: 0x04000208 RID: 520
	[NonSerialized]
	public static readonly int int_0 = 28;

	// Token: 0x04000209 RID: 521
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x0400020A RID: 522
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x0400020B RID: 523
	[CompilerGenerated]
	private ushort ushort_0;

	// Token: 0x0400020C RID: 524
	[CompilerGenerated]
	private ushort ushort_1;

	// Token: 0x0400020D RID: 525
	[CompilerGenerated]
	private uint uint_2;

	// Token: 0x0400020E RID: 526
	[CompilerGenerated]
	private uint uint_3;

	// Token: 0x0400020F RID: 527
	[CompilerGenerated]
	private uint uint_4;

	// Token: 0x04000210 RID: 528
	[CompilerGenerated]
	private uint uint_5;
}
