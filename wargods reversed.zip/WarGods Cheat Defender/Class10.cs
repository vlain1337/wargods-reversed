﻿using System;
using System.Collections.Generic;
using System.IO;

// Token: 0x02000059 RID: 89
internal class Class10
{
	// Token: 0x06000318 RID: 792 RVA: 0x0004D17C File Offset: 0x0004B37C
	private GClass27[] method_0(byte[] byte_0, uint uint_0, GClass31[] gclass31_0, uint uint_1)
	{
		List<GClass27> list = new List<GClass27>();
		for (uint num = 0U; num < uint_1; num += 1U)
		{
			GClass27 gclass = new GClass27(byte_0, (int)((ulong)uint_0 + (ulong)((long)GClass27.int_0 * (long)((ulong)num))));
			if (gclass.UInt32_0 == 0U && gclass.UInt32_2 == 0U && gclass.UInt32_3 == 0U && gclass.UInt32_4 == 0U)
			{
				break;
			}
			list.Add(gclass);
		}
		return list.ToArray();
	}

	// Token: 0x06000319 RID: 793 RVA: 0x0004D1E0 File Offset: 0x0004B3E0
	private GClass27[] method_1(BinaryReader binaryReader_0, uint uint_0, GClass31[] gclass31_0, uint uint_1)
	{
		if ((ulong)uint_0 < (ulong)binaryReader_0.BaseStream.Length)
		{
			List<GClass27> list = new List<GClass27>();
			uint num = 0U;
			byte[] array = new byte[GClass27.int_0];
			binaryReader_0.BaseStream.Seek((long)((ulong)uint_0), SeekOrigin.Begin);
			while (num < uint_1 && binaryReader_0.Read(array, 0, array.Length) == array.Length)
			{
				GClass27 gclass = new GClass27(array, 0);
				if (gclass.UInt32_0 == 0U && gclass.UInt32_2 == 0U && gclass.UInt32_3 == 0U && gclass.UInt32_4 == 0U)
				{
					break;
				}
				list.Add(gclass);
				num += 1U;
			}
			return list.ToArray();
		}
		throw new IOException();
	}

	// Token: 0x0600031A RID: 794 RVA: 0x0004D278 File Offset: 0x0004B478
	private GClass27[] method_2(IntPtr intptr_0, IntPtr intptr_1, IntPtr intptr_2, uint uint_0)
	{
		if (intptr_0 == IntPtr.Zero)
		{
			throw new IOException();
		}
		IntPtr intptr_3 = (IntPtr)(intptr_1.ToInt64() + intptr_2.ToInt64());
		if (GClass16.smethod_1(intptr_0, intptr_3))
		{
			List<GClass27> list = new List<GClass27>();
			uint num = 0U;
			byte[] array = new byte[GClass27.int_0];
			uint num2 = 0U;
			while (num < uint_0)
			{
				if (GClass16.ReadProcessMemory(intptr_0, intptr_3, array, (uint)array.Length, ref num2) && (ulong)num2 == (ulong)((long)array.Length))
				{
					GClass27 gclass = new GClass27(array, 0);
					if (gclass.UInt32_0 != 0U || gclass.UInt32_2 != 0U || gclass.UInt32_3 != 0U || gclass.UInt32_4 != 0U)
					{
						list.Add(gclass);
						num += 1U;
						intptr_3 = (IntPtr)(intptr_3.ToInt64() + (long)array.Length);
						continue;
					}
				}
				IL_BC:
				return list.ToArray();
			}
			goto IL_BC;
		}
		throw new IOException();
	}
}
