﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x0200002F RID: 47
public class GClass14
{
	// Token: 0x0600010C RID: 268 RVA: 0x000427F0 File Offset: 0x000409F0
	public GClass14(string string_1, uint uint_1, ushort ushort_1)
	{
		this.String_0 = string_1;
		this.UInt32_0 = uint_1;
		this.UInt16_0 = ushort_1;
	}

	// Token: 0x1700008D RID: 141
	// (get) Token: 0x0600010D RID: 269 RVA: 0x00042818 File Offset: 0x00040A18
	// (set) Token: 0x0600010E RID: 270 RVA: 0x0004282C File Offset: 0x00040A2C
	public string String_0 { get; set; }

	// Token: 0x1700008E RID: 142
	// (get) Token: 0x0600010F RID: 271 RVA: 0x00042840 File Offset: 0x00040A40
	// (set) Token: 0x06000110 RID: 272 RVA: 0x00042854 File Offset: 0x00040A54
	public uint UInt32_0 { get; set; }

	// Token: 0x1700008F RID: 143
	// (get) Token: 0x06000111 RID: 273 RVA: 0x00042868 File Offset: 0x00040A68
	// (set) Token: 0x06000112 RID: 274 RVA: 0x0004287C File Offset: 0x00040A7C
	public ushort UInt16_0 { get; set; }

	// Token: 0x04000164 RID: 356
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04000165 RID: 357
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x04000166 RID: 358
	[CompilerGenerated]
	private ushort ushort_0;
}
