﻿using System;

// Token: 0x02000069 RID: 105
public enum GEnum20 : uint
{
	// Token: 0x04000304 RID: 772
	const_0,
	// Token: 0x04000305 RID: 773
	const_1,
	// Token: 0x04000306 RID: 774
	const_2,
	// Token: 0x04000307 RID: 775
	const_3 = 4U,
	// Token: 0x04000308 RID: 776
	const_4 = 8U,
	// Token: 0x04000309 RID: 777
	const_5 = 16U,
	// Token: 0x0400030A RID: 778
	const_6 = 32U
}
