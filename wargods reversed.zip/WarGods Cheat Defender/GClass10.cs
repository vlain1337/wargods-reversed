﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200001C RID: 28
public class GClass10
{
	// Token: 0x060000ED RID: 237
	[DllImport("ntdll.dll")]
	private static extern uint RtlGetCompressionWorkSpaceSize(ushort ushort_1, ref ulong ulong_0, ref ulong ulong_1);

	// Token: 0x060000EE RID: 238
	[DllImport("ntdll.dll")]
	private static extern uint RtlDecompressBufferEx(ushort ushort_1, byte[] byte_0, int int_0, byte[] byte_1, int int_1, ref int int_2, byte[] byte_2);

	// Token: 0x060000EF RID: 239 RVA: 0x00042208 File Offset: 0x00040408
	public static byte[] smethod_0(byte[] byte_0, ulong ulong_0)
	{
		byte[] array = new byte[ulong_0];
		ulong num = 0UL;
		ulong num2 = 0UL;
		if (GClass10.RtlGetCompressionWorkSpaceSize(4, ref num, ref num2) != 0U)
		{
			return null;
		}
		byte[] byte_ = new byte[num2];
		int num3 = 0;
		if (GClass10.RtlDecompressBufferEx(4, array, array.Length, byte_0, byte_0.Length, ref num3, byte_) != 0U)
		{
			return null;
		}
		return array;
	}

	// Token: 0x040000B5 RID: 181
	private const ushort ushort_0 = 4;
}
