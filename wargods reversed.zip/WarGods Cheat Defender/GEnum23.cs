﻿using System;

// Token: 0x02000072 RID: 114
public enum GEnum23
{
	// Token: 0x0400037E RID: 894
	const_0,
	// Token: 0x0400037F RID: 895
	const_1,
	// Token: 0x04000380 RID: 896
	const_2,
	// Token: 0x04000381 RID: 897
	const_3 = 4,
	// Token: 0x04000382 RID: 898
	const_4 = 8,
	// Token: 0x04000383 RID: 899
	const_5 = 16,
	// Token: 0x04000384 RID: 900
	const_6 = 32,
	// Token: 0x04000385 RID: 901
	const_7 = 64,
	// Token: 0x04000386 RID: 902
	const_8 = 128,
	// Token: 0x04000387 RID: 903
	const_9 = 256,
	// Token: 0x04000388 RID: 904
	const_10 = 512,
	// Token: 0x04000389 RID: 905
	const_11 = 1024,
	// Token: 0x0400038A RID: 906
	const_12 = 2048,
	// Token: 0x0400038B RID: 907
	const_13 = 4096,
	// Token: 0x0400038C RID: 908
	const_14 = 8192,
	// Token: 0x0400038D RID: 909
	const_15 = 16384,
	// Token: 0x0400038E RID: 910
	const_16 = 32768,
	// Token: 0x0400038F RID: 911
	const_17 = 65536,
	// Token: 0x04000390 RID: 912
	const_18 = 131072,
	// Token: 0x04000391 RID: 913
	const_19 = 262144,
	// Token: 0x04000392 RID: 914
	const_20 = 524288,
	// Token: 0x04000393 RID: 915
	const_21 = 1048576,
	// Token: 0x04000394 RID: 916
	const_22 = 2097152,
	// Token: 0x04000395 RID: 917
	const_23 = 4194304,
	// Token: 0x04000396 RID: 918
	const_24 = 8388608,
	// Token: 0x04000397 RID: 919
	const_25 = 16777216
}
