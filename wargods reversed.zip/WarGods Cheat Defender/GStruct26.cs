﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020000B4 RID: 180
public struct GStruct26
{
	// Token: 0x04000923 RID: 2339
	public IntPtr intptr_0;

	// Token: 0x04000924 RID: 2340
	public IntPtr intptr_1;

	// Token: 0x04000925 RID: 2341
	public uint uint_0;

	// Token: 0x04000926 RID: 2342
	public uint uint_1;

	// Token: 0x04000927 RID: 2343
	public uint uint_2;

	// Token: 0x04000928 RID: 2344
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32, ArraySubType = UnmanagedType.I2)]
	public char[] char_0;
}
