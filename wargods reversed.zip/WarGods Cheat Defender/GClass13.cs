﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;

// Token: 0x0200002D RID: 45
public class GClass13
{
	// Token: 0x06000101 RID: 257 RVA: 0x00042360 File Offset: 0x00040560
	public GClass13(byte[] byte_0)
	{
		this.List_0 = new List<string>();
		this.method_0(byte_0);
	}

	// Token: 0x06000102 RID: 258 RVA: 0x00042388 File Offset: 0x00040588
	public GClass13(X509Certificate2 x509Certificate2_0)
	{
		this.List_0 = new List<string>();
		foreach (X509Extension x509Extension in x509Certificate2_0.Extensions)
		{
			if (x509Extension.Oid.Value == <Module>.DeserealizeFromByteArrayV2_1<string>(1456219258U))
			{
				this.method_0(x509Extension.RawData);
			}
		}
	}

	// Token: 0x1700008C RID: 140
	// (get) Token: 0x06000103 RID: 259 RVA: 0x000423EC File Offset: 0x000405EC
	// (set) Token: 0x06000104 RID: 260 RVA: 0x00042400 File Offset: 0x00040600
	public List<string> List_0 { get; set; }

	// Token: 0x06000105 RID: 261 RVA: 0x00042414 File Offset: 0x00040614
	private void method_0(byte[] byte_0)
	{
		int num = byte_0.Length;
		int i = 0;
		while (i < num - 5)
		{
			if (byte_0[i] != 104)
			{
				goto IL_3C;
			}
			if (byte_0[i + 1] != 116)
			{
				goto IL_3C;
			}
			if (byte_0[i + 2] != 116)
			{
				goto IL_3C;
			}
			if (byte_0[i + 3] != 112 || byte_0[i + 4] != 58)
			{
				goto IL_3C;
			}
			goto IL_7A;
			IL_196:
			i++;
			continue;
			IL_3C:
			if (byte_0[i] != 108)
			{
				goto IL_196;
			}
			if (byte_0[i + 1] != 100)
			{
				goto IL_196;
			}
			if (byte_0[i + 2] != 97)
			{
				goto IL_196;
			}
			if (byte_0[i + 3] != 112 || byte_0[i + 4] != 58)
			{
				goto IL_196;
			}
			IL_7A:
			List<byte> list = new List<byte>();
			int j = i;
			while (j < num)
			{
				if (byte_0[j - 4] == 46 && byte_0[j - 3] == 99)
				{
					if (byte_0[j - 2] == 114)
					{
						if (byte_0[j - 1] == 108)
						{
							goto IL_102;
						}
					}
				}
				if (byte_0[j] == 98)
				{
					if (byte_0[j + 1] == 97)
					{
						if (byte_0[j + 2] == 115)
						{
							if (byte_0[j + 3] == 101)
							{
								goto IL_102;
							}
						}
					}
				}
				if (byte_0[j] >= 32 && byte_0[j] <= 126)
				{
					list.Add(byte_0[j]);
					j++;
					continue;
				}
				i = j;
				break;
				IL_102:
				i = j;
				break;
			}
			string text = Encoding.ASCII.GetString(list.ToArray());
			if (this.method_1(text) && text.StartsWith(<Module>.DeserializeFromByteArray2<string>(1623646803U)) && text.EndsWith(<Module>.DeserializeFromByteArray2<string>(3964968602U)))
			{
				this.List_0.Add(text);
			}
			if (text.StartsWith(<Module>.DeserializeFromByteArrayV2<string>(2977380301U), StringComparison.InvariantCulture))
			{
				text = <Module>.DeserializeFromByteArray2<string>(3174352011U) + text.Split(new char[]
				{
					'/'
				})[2];
				this.List_0.Add(text);
				goto IL_196;
			}
			goto IL_196;
		}
	}

	// Token: 0x06000106 RID: 262 RVA: 0x000425C4 File Offset: 0x000407C4
	private bool method_1(string string_0)
	{
		Uri uri;
		return Uri.TryCreate(string_0, UriKind.Absolute, out uri) && (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps);
	}

	// Token: 0x04000163 RID: 355
	[CompilerGenerated]
	private List<string> list_0;
}
