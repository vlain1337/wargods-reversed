﻿using System;

// Token: 0x020000F9 RID: 249
public enum GEnum57
{
	// Token: 0x04000B33 RID: 2867
	const_0,
	// Token: 0x04000B34 RID: 2868
	const_1
}
