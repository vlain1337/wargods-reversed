﻿using System;
using System.Management;
using System.Runtime.CompilerServices;
using Microsoft.Win32;

// Token: 0x020000E5 RID: 229
internal class Class52
{
	// Token: 0x17000324 RID: 804
	// (get) Token: 0x06000761 RID: 1889 RVA: 0x00069884 File Offset: 0x00067A84
	// (set) Token: 0x06000762 RID: 1890 RVA: 0x00069898 File Offset: 0x00067A98
	public string String_0 { get; set; }

	// Token: 0x17000325 RID: 805
	// (get) Token: 0x06000763 RID: 1891 RVA: 0x000698AC File Offset: 0x00067AAC
	// (set) Token: 0x06000764 RID: 1892 RVA: 0x000698C0 File Offset: 0x00067AC0
	public string String_1 { get; set; }

	// Token: 0x17000326 RID: 806
	// (get) Token: 0x06000765 RID: 1893 RVA: 0x000698D4 File Offset: 0x00067AD4
	// (set) Token: 0x06000766 RID: 1894 RVA: 0x000698E8 File Offset: 0x00067AE8
	public string String_2 { get; set; }

	// Token: 0x17000327 RID: 807
	// (get) Token: 0x06000767 RID: 1895 RVA: 0x000698FC File Offset: 0x00067AFC
	// (set) Token: 0x06000768 RID: 1896 RVA: 0x00069910 File Offset: 0x00067B10
	public string String_3 { get; set; }

	// Token: 0x06000769 RID: 1897 RVA: 0x00069924 File Offset: 0x00067B24
	public Class52(string string_4 = "", string string_5 = "", string string_6 = "", string string_7 = "")
	{
		this.String_0 = string_4;
		this.String_1 = string_5;
		this.String_2 = string_6;
		this.String_3 = string_7;
	}

	// Token: 0x0600076A RID: 1898 RVA: 0x00069954 File Offset: 0x00067B54
	public virtual string ToString()
	{
		return string.Format(<Module>.DeserealizeFromByteArrayV2_1<string>(2163874521U), new object[]
		{
			Class15.SanitizeString(this.String_0),
			Class15.char_2,
			Class15.SanitizeString(this.String_1),
			Class15.char_2,
			Class15.SanitizeString(this.String_2),
			Class15.char_2,
			Class15.SanitizeString(this.String_3)
		});
	}

	// Token: 0x0600076B RID: 1899 RVA: 0x000699D8 File Offset: 0x00067BD8
	public static string smethod_0()
	{
		Class52 @class = new Class52("", "", "", "");
		try
		{
			using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = new ManagementObjectSearcher(Class14.String_14, Class14.String_187).Get().GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					ManagementObject managementObject = (ManagementObject)enumerator.Current;
					try
					{
						@class.String_0 = managementObject.GetPropertyValue(Class14.String_179).ToString().Trim();
					}
					catch
					{
						@class.String_0 = string.Empty;
					}
					try
					{
						IL_7D:
						@class.String_1 = managementObject.GetPropertyValue(Class14.String_189).ToString().Trim();
					}
					catch
					{
						@class.String_1 = string.Empty;
					}
					try
					{
						@class.String_2 = managementObject.GetPropertyValue(Class14.String_32).ToString().Trim();
					}
					catch
					{
						@class.String_2 = string.Empty;
					}
					try
					{
						@class.String_3 = managementObject.GetPropertyValue(Class14.String_174).ToString().Trim();
					}
					catch
					{
						@class.String_3 = string.Empty;
					}
					if (!(@class.String_0 == string.Empty) || !(@class.String_1 == string.Empty))
					{
						break;
					}
					if (!(@class.String_2 == string.Empty))
					{
						break;
					}
					continue;
					goto IL_7D;
				}
			}
		}
		catch
		{
		}
		if (@class.String_0.Length == 0)
		{
			@class.String_0 = RegistryStuff.GetStringValueFromRegistry(Registry.LocalMachine, Class14.String_38, Class14.String_184);
			if (@class.String_0 == null)
			{
				@class.String_0 = string.Empty;
			}
		}
		if (@class.String_1.Length == 0)
		{
			@class.String_1 = RegistryStuff.GetStringValueFromRegistry(Registry.LocalMachine, Class14.String_38, Class14.String_124);
			if (@class.String_1 == null)
			{
				@class.String_1 = string.Empty;
			}
		}
		if (@class.String_3.Length == 0)
		{
			@class.String_3 = RegistryStuff.GetStringValueFromRegistry(Registry.LocalMachine, Class14.String_38, Class14.String_36);
			if (@class.String_3 == null)
			{
				@class.String_3 = string.Empty;
			}
		}
		return @class.ToString();
	}

	// Token: 0x040009EA RID: 2538
	[CompilerGenerated]
	private string string_0;

	// Token: 0x040009EB RID: 2539
	[CompilerGenerated]
	private string string_1;

	// Token: 0x040009EC RID: 2540
	[CompilerGenerated]
	private string string_2;

	// Token: 0x040009ED RID: 2541
	[CompilerGenerated]
	private string string_3;
}
