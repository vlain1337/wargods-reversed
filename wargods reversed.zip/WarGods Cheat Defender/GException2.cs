﻿using System;

// Token: 0x02000020 RID: 32
public class GException2 : Exception
{
	// Token: 0x060000FE RID: 254 RVA: 0x00042320 File Offset: 0x00040520
	public GException2()
	{
	}

	// Token: 0x060000FF RID: 255 RVA: 0x00042334 File Offset: 0x00040534
	public GException2(string string_0) : base(string_0)
	{
	}

	// Token: 0x06000100 RID: 256 RVA: 0x00042348 File Offset: 0x00040548
	public GException2(string string_0, Exception exception_0) : base(string_0, exception_0)
	{
	}
}
