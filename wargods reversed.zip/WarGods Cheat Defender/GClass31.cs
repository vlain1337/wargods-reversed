﻿using System;
using System.IO;
using System.Runtime.CompilerServices;

// Token: 0x02000052 RID: 82
public class GClass31
{
	// Token: 0x060002B1 RID: 689 RVA: 0x0004BF68 File Offset: 0x0004A168
	public GClass31(byte[] byte_1, int int_0, uint uint_9, bool bool_0 = true)
	{
		this.Byte_0 = new byte[]
		{
			byte_1[int_0],
			byte_1[int_0 + 1],
			byte_1[int_0 + 2],
			byte_1[int_0 + 3],
			byte_1[int_0 + 4],
			byte_1[int_0 + 5],
			byte_1[int_0 + 6],
			byte_1[int_0 + 7]
		};
		this.UInt32_0 = BitConverter.ToUInt32(byte_1, int_0 + 8);
		this.UInt32_1 = this.UInt32_0;
		this.UInt32_2 = BitConverter.ToUInt32(byte_1, int_0 + 12);
		this.UInt32_3 = BitConverter.ToUInt32(byte_1, int_0 + 16);
		this.UInt32_4 = BitConverter.ToUInt32(byte_1, int_0 + 20);
		this.UInt32_5 = BitConverter.ToUInt32(byte_1, int_0 + 24);
		this.UInt32_6 = BitConverter.ToUInt32(byte_1, int_0 + 28);
		this.UInt16_0 = BitConverter.ToUInt16(byte_1, int_0 + 32);
		this.UInt16_1 = BitConverter.ToUInt16(byte_1, int_0 + 34);
		this.UInt32_7 = BitConverter.ToUInt32(byte_1, int_0 + 36);
		if (bool_0)
		{
			try
			{
				long num = (long)((ulong)(this.UInt32_4 + this.UInt32_3));
				if (uint_9 > 0U && num % (long)((ulong)uint_9) != 0L)
				{
					int num2 = (int)((double)num / uint_9);
					num2++;
					num = (long)((ulong)uint_9 * (ulong)((long)num2));
				}
				if (num != 0L)
				{
					if (num > (long)byte_1.Length)
					{
						num = (long)byte_1.Length;
					}
					string text;
					if (Class6.smethod_3(byte_1, out text, (long)((ulong)this.UInt32_4), num, 4096))
					{
						this.String_0 = text;
					}
					else
					{
						this.String_0 = null;
					}
				}
				else
				{
					this.String_0 = Class6.smethod_0(string.Empty);
				}
				return;
			}
			catch
			{
				this.String_0 = null;
				return;
			}
		}
		this.String_0 = null;
	}

	// Token: 0x060002B2 RID: 690 RVA: 0x0004C0FC File Offset: 0x0004A2FC
	public GClass31(BinaryReader binaryReader_0, int int_0, uint uint_9, bool bool_0 = true)
	{
		byte[] array = new byte[GClass31.uint_0];
		if (binaryReader_0.Read(array, 0, array.Length) != array.Length)
		{
			throw new IOException(<Module>.DeserializeFromByteArray3<string>(2231161829U));
		}
		this.Byte_0 = new byte[]
		{
			array[int_0],
			array[int_0 + 1],
			array[int_0 + 2],
			array[int_0 + 3],
			array[int_0 + 4],
			array[int_0 + 5],
			array[int_0 + 6],
			array[int_0 + 7]
		};
		this.UInt32_0 = BitConverter.ToUInt32(array, int_0 + 8);
		this.UInt32_1 = this.UInt32_0;
		this.UInt32_2 = BitConverter.ToUInt32(array, int_0 + 12);
		this.UInt32_3 = BitConverter.ToUInt32(array, int_0 + 16);
		this.UInt32_4 = BitConverter.ToUInt32(array, int_0 + 20);
		this.UInt32_5 = BitConverter.ToUInt32(array, int_0 + 24);
		this.UInt32_6 = BitConverter.ToUInt32(array, int_0 + 28);
		this.UInt16_0 = BitConverter.ToUInt16(array, int_0 + 32);
		this.UInt16_1 = BitConverter.ToUInt16(array, int_0 + 34);
		this.UInt32_7 = BitConverter.ToUInt32(array, int_0 + 36);
		if (bool_0)
		{
			try
			{
				long num = (long)((ulong)(this.UInt32_4 + this.UInt32_3));
				if (uint_9 > 0U && num % (long)((ulong)uint_9) != 0L)
				{
					int num2 = (int)((double)num / uint_9);
					num2++;
					num = (long)((ulong)uint_9 * (ulong)((long)num2));
				}
				if (num != 0L)
				{
					if (num > binaryReader_0.BaseStream.Length)
					{
						num = binaryReader_0.BaseStream.Length;
					}
					string text;
					if (Class6.md5_crypto(binaryReader_0, out text, (long)((ulong)this.UInt32_4), num, 4096))
					{
						this.String_0 = text;
					}
					else
					{
						this.String_0 = null;
					}
				}
				else
				{
					this.String_0 = Class6.smethod_0(string.Empty);
				}
				return;
			}
			catch
			{
				this.String_0 = null;
				return;
			}
		}
		this.String_0 = null;
	}

	// Token: 0x060002B3 RID: 691 RVA: 0x0004C2CC File Offset: 0x0004A4CC
	public GClass31(IntPtr intptr_0, IntPtr intptr_1, uint uint_9, bool bool_0 = true)
	{
		byte[] array = new byte[GClass31.uint_0];
		uint num = 0U;
		if (!GClass16.ReadProcessMemory(intptr_0, intptr_1, array, (uint)array.Length, ref num) || (ulong)num != (ulong)((long)array.Length))
		{
			throw new IOException(<Module>.DeserializeFromByteArray2<string>(2701313253U));
		}
		this.Byte_0 = new byte[]
		{
			array[0],
			array[1],
			array[2],
			array[3],
			array[4],
			array[5],
			array[6],
			array[7]
		};
		this.UInt32_0 = BitConverter.ToUInt32(array, 8);
		this.UInt32_1 = this.UInt32_0;
		this.UInt32_2 = BitConverter.ToUInt32(array, 12);
		this.UInt32_3 = BitConverter.ToUInt32(array, 16);
		this.UInt32_4 = BitConverter.ToUInt32(array, 20);
		this.UInt32_5 = BitConverter.ToUInt32(array, 24);
		this.UInt32_6 = BitConverter.ToUInt32(array, 28);
		this.UInt16_0 = BitConverter.ToUInt16(array, 32);
		this.UInt16_1 = BitConverter.ToUInt16(array, 34);
		this.UInt32_7 = BitConverter.ToUInt32(array, 36);
		if (!bool_0)
		{
			this.String_0 = null;
			return;
		}
		this.String_0 = null;
	}

	// Token: 0x17000123 RID: 291
	// (get) Token: 0x060002B4 RID: 692 RVA: 0x0004C3F4 File Offset: 0x0004A5F4
	// (set) Token: 0x060002B5 RID: 693 RVA: 0x0004C408 File Offset: 0x0004A608
	public byte[] Byte_0 { get; private set; }

	// Token: 0x17000124 RID: 292
	// (get) Token: 0x060002B6 RID: 694 RVA: 0x0004C41C File Offset: 0x0004A61C
	// (set) Token: 0x060002B7 RID: 695 RVA: 0x0004C430 File Offset: 0x0004A630
	public uint UInt32_0 { get; private set; }

	// Token: 0x17000125 RID: 293
	// (get) Token: 0x060002B8 RID: 696 RVA: 0x0004C444 File Offset: 0x0004A644
	// (set) Token: 0x060002B9 RID: 697 RVA: 0x0004C458 File Offset: 0x0004A658
	public uint UInt32_1 { get; private set; }

	// Token: 0x17000126 RID: 294
	// (get) Token: 0x060002BA RID: 698 RVA: 0x0004C46C File Offset: 0x0004A66C
	// (set) Token: 0x060002BB RID: 699 RVA: 0x0004C480 File Offset: 0x0004A680
	public uint UInt32_2 { get; private set; }

	// Token: 0x17000127 RID: 295
	// (get) Token: 0x060002BC RID: 700 RVA: 0x0004C494 File Offset: 0x0004A694
	// (set) Token: 0x060002BD RID: 701 RVA: 0x0004C4A8 File Offset: 0x0004A6A8
	public uint UInt32_3 { get; private set; }

	// Token: 0x17000128 RID: 296
	// (get) Token: 0x060002BE RID: 702 RVA: 0x0004C4BC File Offset: 0x0004A6BC
	// (set) Token: 0x060002BF RID: 703 RVA: 0x0004C4D0 File Offset: 0x0004A6D0
	public uint UInt32_4 { get; private set; }

	// Token: 0x17000129 RID: 297
	// (get) Token: 0x060002C0 RID: 704 RVA: 0x0004C4E4 File Offset: 0x0004A6E4
	// (set) Token: 0x060002C1 RID: 705 RVA: 0x0004C4F8 File Offset: 0x0004A6F8
	public uint UInt32_5 { get; private set; }

	// Token: 0x1700012A RID: 298
	// (get) Token: 0x060002C2 RID: 706 RVA: 0x0004C50C File Offset: 0x0004A70C
	// (set) Token: 0x060002C3 RID: 707 RVA: 0x0004C520 File Offset: 0x0004A720
	public uint UInt32_6 { get; private set; }

	// Token: 0x1700012B RID: 299
	// (get) Token: 0x060002C4 RID: 708 RVA: 0x0004C534 File Offset: 0x0004A734
	// (set) Token: 0x060002C5 RID: 709 RVA: 0x0004C548 File Offset: 0x0004A748
	public ushort UInt16_0 { get; private set; }

	// Token: 0x1700012C RID: 300
	// (get) Token: 0x060002C6 RID: 710 RVA: 0x0004C55C File Offset: 0x0004A75C
	// (set) Token: 0x060002C7 RID: 711 RVA: 0x0004C570 File Offset: 0x0004A770
	public ushort UInt16_1 { get; private set; }

	// Token: 0x1700012D RID: 301
	// (get) Token: 0x060002C8 RID: 712 RVA: 0x0004C584 File Offset: 0x0004A784
	// (set) Token: 0x060002C9 RID: 713 RVA: 0x0004C598 File Offset: 0x0004A798
	public uint UInt32_7 { get; private set; }

	// Token: 0x1700012E RID: 302
	// (get) Token: 0x060002CA RID: 714 RVA: 0x0004C5AC File Offset: 0x0004A7AC
	// (set) Token: 0x060002CB RID: 715 RVA: 0x0004C5C0 File Offset: 0x0004A7C0
	public string String_0 { get; private set; }

	// Token: 0x060002CC RID: 716 RVA: 0x0004C5D4 File Offset: 0x0004A7D4
	public virtual string ToString()
	{
		string text = "";
		try
		{
			text = Class15.ByteArrayToHexString(this.Byte_0);
		}
		catch
		{
			text = "";
		}
		return string.Format(<Module>.DeserializeFromByteArray3<string>(3138370359U), new object[]
		{
			text,
			this.String_0 ?? Class14.String_215,
			this.UInt32_7,
			this.UInt32_4,
			this.UInt32_3
		});
	}

	// Token: 0x04000274 RID: 628
	[NonSerialized]
	public static readonly uint uint_0 = 40U;

	// Token: 0x04000275 RID: 629
	[CompilerGenerated]
	private byte[] byte_0;

	// Token: 0x04000276 RID: 630
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x04000277 RID: 631
	[CompilerGenerated]
	private uint uint_2;

	// Token: 0x04000278 RID: 632
	[CompilerGenerated]
	private uint uint_3;

	// Token: 0x04000279 RID: 633
	[CompilerGenerated]
	private uint uint_4;

	// Token: 0x0400027A RID: 634
	[CompilerGenerated]
	private uint uint_5;

	// Token: 0x0400027B RID: 635
	[CompilerGenerated]
	private uint uint_6;

	// Token: 0x0400027C RID: 636
	[CompilerGenerated]
	private uint uint_7;

	// Token: 0x0400027D RID: 637
	[CompilerGenerated]
	private ushort ushort_0;

	// Token: 0x0400027E RID: 638
	[CompilerGenerated]
	private ushort ushort_1;

	// Token: 0x0400027F RID: 639
	[CompilerGenerated]
	private uint uint_8;

	// Token: 0x04000280 RID: 640
	[CompilerGenerated]
	private string string_0;
}
