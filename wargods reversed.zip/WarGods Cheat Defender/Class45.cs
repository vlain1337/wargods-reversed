﻿using System;
using System.Globalization;
using System.Runtime.CompilerServices;

// Token: 0x020000DE RID: 222
internal class Class45
{
	// Token: 0x17000307 RID: 775
	// (get) Token: 0x06000713 RID: 1811 RVA: 0x00067FF0 File Offset: 0x000661F0
	// (set) Token: 0x06000714 RID: 1812 RVA: 0x00068004 File Offset: 0x00066204
	public bool Boolean_0 { get; set; }

	// Token: 0x17000308 RID: 776
	// (get) Token: 0x06000715 RID: 1813 RVA: 0x00068018 File Offset: 0x00066218
	// (set) Token: 0x06000716 RID: 1814 RVA: 0x0006802C File Offset: 0x0006622C
	public string String_0 { get; set; }

	// Token: 0x17000309 RID: 777
	// (get) Token: 0x06000717 RID: 1815 RVA: 0x00068040 File Offset: 0x00066240
	// (set) Token: 0x06000718 RID: 1816 RVA: 0x00068054 File Offset: 0x00066254
	public bool Boolean_1 { get; set; }

	// Token: 0x1700030A RID: 778
	// (get) Token: 0x06000719 RID: 1817 RVA: 0x00068068 File Offset: 0x00066268
	// (set) Token: 0x0600071A RID: 1818 RVA: 0x0006807C File Offset: 0x0006627C
	public DateTime DateTime_0 { get; set; }

	// Token: 0x1700030B RID: 779
	// (get) Token: 0x0600071B RID: 1819 RVA: 0x00068090 File Offset: 0x00066290
	// (set) Token: 0x0600071C RID: 1820 RVA: 0x000680A4 File Offset: 0x000662A4
	public string String_1 { get; set; }

	// Token: 0x1700030C RID: 780
	// (get) Token: 0x0600071D RID: 1821 RVA: 0x000680B8 File Offset: 0x000662B8
	// (set) Token: 0x0600071E RID: 1822 RVA: 0x000680CC File Offset: 0x000662CC
	public string String_2 { get; set; }

	// Token: 0x0600071F RID: 1823 RVA: 0x000680E0 File Offset: 0x000662E0
	public Class45()
	{
		/*
An exception occurred when decompiling this method (0600071F)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void Class45::.ctor()

 ---> System.Exception: Inconsistent stack size at IL_17A
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 443
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 271
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06000720 RID: 1824 RVA: 0x00068288 File Offset: 0x00066488
	public virtual string ToString()
	{
		return string.Format(<Module>.DeserializeFromByteArrayV2<string>(2969252172U), new object[]
		{
			this.Boolean_0 ? <Module>.DeserializeFromByteArrayV2<string>(2800123294U) : <Module>.DeserializeFromByteArrayV2<string>(1655797908U),
			Class15.char_2,
			Class15.SanitizeString(this.String_0),
			Class15.char_2,
			this.Boolean_1 ? <Module>.DeserializeFromByteArray3<string>(423071921U) : <Module>.DeserializeFromByteArray3<string>(1552324843U),
			Class15.char_2,
			this.DateTime_0.ToString(Class15.string_0, CultureInfo.InvariantCulture),
			Class15.char_2,
			this.String_1,
			Class15.char_2,
			this.String_2
		});
	}

	// Token: 0x06000721 RID: 1825 RVA: 0x0006836C File Offset: 0x0006656C
	public static string smethod_0()
	{
		return new Class45().ToString();
	}

	// Token: 0x040009CD RID: 2509
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x040009CE RID: 2510
	[CompilerGenerated]
	private string string_0;

	// Token: 0x040009CF RID: 2511
	[CompilerGenerated]
	private bool bool_1;

	// Token: 0x040009D0 RID: 2512
	[CompilerGenerated]
	private DateTime dateTime_0;

	// Token: 0x040009D1 RID: 2513
	[CompilerGenerated]
	private string string_1;

	// Token: 0x040009D2 RID: 2514
	[CompilerGenerated]
	private string string_2;
}
