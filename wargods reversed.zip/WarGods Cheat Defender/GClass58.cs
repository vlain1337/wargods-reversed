﻿using System;
using System.IO;
using System.Runtime.CompilerServices;

// Token: 0x020000D6 RID: 214
public class GClass58
{
	// Token: 0x170002E4 RID: 740
	// (get) Token: 0x060006C3 RID: 1731 RVA: 0x0006723C File Offset: 0x0006543C
	// (set) Token: 0x060006C4 RID: 1732 RVA: 0x00067250 File Offset: 0x00065450
	public string String_0 { get; private set; }

	// Token: 0x170002E5 RID: 741
	// (get) Token: 0x060006C5 RID: 1733 RVA: 0x00067264 File Offset: 0x00065464
	// (set) Token: 0x060006C6 RID: 1734 RVA: 0x00067278 File Offset: 0x00065478
	public string String_1 { get; private set; }

	// Token: 0x170002E6 RID: 742
	// (get) Token: 0x060006C7 RID: 1735 RVA: 0x0006728C File Offset: 0x0006548C
	// (set) Token: 0x060006C8 RID: 1736 RVA: 0x000672A0 File Offset: 0x000654A0
	public uint UInt32_0 { get; private set; }

	// Token: 0x170002E7 RID: 743
	// (get) Token: 0x060006C9 RID: 1737 RVA: 0x000672B4 File Offset: 0x000654B4
	// (set) Token: 0x060006CA RID: 1738 RVA: 0x000672C8 File Offset: 0x000654C8
	public long Int64_0 { get; private set; }

	// Token: 0x170002E8 RID: 744
	// (get) Token: 0x060006CB RID: 1739 RVA: 0x000672DC File Offset: 0x000654DC
	// (set) Token: 0x060006CC RID: 1740 RVA: 0x000672F0 File Offset: 0x000654F0
	public DateTime? Nullable_0 { get; private set; }

	// Token: 0x170002E9 RID: 745
	// (get) Token: 0x060006CD RID: 1741 RVA: 0x00067304 File Offset: 0x00065504
	// (set) Token: 0x060006CE RID: 1742 RVA: 0x00067318 File Offset: 0x00065518
	public GEnum52 GEnum52_0 { get; private set; }

	// Token: 0x060006CF RID: 1743 RVA: 0x0006732C File Offset: 0x0006552C
	public GClass58(string string_2, uint uint_1, long long_1, GEnum52 genum52_1)
	{
		this.String_1 = string_2;
		string text = string_2;
		if (text != null)
		{
			int num = text.IndexOf(<Module>.DeserializeFromByteArray<string>(1396446240U));
			if (num <= -1)
			{
				num = text.IndexOf(<Module>.DeserializeFromByteArray3<string>(2522705881U));
				if (num > -1)
				{
					text = text.Substring(num + 2);
				}
				else
				{
					num = text.IndexOf(<Module>.DeserealizeFromByteArrayV2_1<string>(3037699330U));
					if (num > -1)
					{
						text = text.Substring(num + 1);
					}
				}
			}
			else
			{
				text = text.Substring(num + 3);
			}
			if (text.Length >= 38 && text[0] == '{' && text[37] == '}')
			{
				string text2 = text.Substring(0, 38);
				if (Class15.ValidateGuidString(text2))
				{
					string text3 = GClass45.smethod_9(new Guid(text2), GClass45.GEnum41.flag_6);
					if (text3 != null && text3.Length > 0)
					{
						if (text.Length > 38)
						{
							string text4 = text.Substring(38);
							if (text4.StartsWith(<Module>.DeserializeFromByteArray<string>(477047453U)))
							{
								text4 = text4.Substring(1);
							}
							text = Path.Combine(text3, text4);
						}
						else
						{
							text = text3;
						}
					}
				}
			}
		}
		this.String_0 = GClass45.NormalizePath(text);
		this.UInt32_0 = uint_1;
		this.Int64_0 = long_1;
		try
		{
			this.Nullable_0 = new DateTime?(DateTime.FromFileTimeUtc(long_1));
		}
		catch (ArgumentOutOfRangeException)
		{
			this.Nullable_0 = null;
		}
		this.GEnum52_0 = genum52_1;
	}

	// Token: 0x040009A6 RID: 2470
	[CompilerGenerated]
	private string string_0;

	// Token: 0x040009A7 RID: 2471
	[CompilerGenerated]
	private string string_1;

	// Token: 0x040009A8 RID: 2472
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x040009A9 RID: 2473
	[CompilerGenerated]
	private long long_0;

	// Token: 0x040009AA RID: 2474
	[CompilerGenerated]
	private DateTime? nullable_0;

	// Token: 0x040009AB RID: 2475
	[CompilerGenerated]
	private GEnum52 genum52_0;
}
