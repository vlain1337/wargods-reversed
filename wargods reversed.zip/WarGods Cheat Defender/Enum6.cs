﻿using System;

// Token: 0x02000043 RID: 67
internal enum Enum6
{
	// Token: 0x040001E9 RID: 489
	const_0 = 1,
	// Token: 0x040001EA RID: 490
	const_1,
	// Token: 0x040001EB RID: 491
	const_2 = 4,
	// Token: 0x040001EC RID: 492
	const_3 = 16,
	// Token: 0x040001ED RID: 493
	const_4 = 32,
	// Token: 0x040001EE RID: 494
	const_5 = 64,
	// Token: 0x040001EF RID: 495
	const_6 = 128,
	// Token: 0x040001F0 RID: 496
	const_7 = 256,
	// Token: 0x040001F1 RID: 497
	const_8 = 512,
	// Token: 0x040001F2 RID: 498
	const_9 = 1024,
	// Token: 0x040001F3 RID: 499
	const_10 = 2048
}
