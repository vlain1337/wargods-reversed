﻿using System;
using System.IO;
using System.Runtime.CompilerServices;

// Token: 0x02000055 RID: 85
public class GClass34
{
	// Token: 0x060002DC RID: 732 RVA: 0x0004C88C File Offset: 0x0004AA8C
	public GClass34(byte[] byte_0, int int_0, bool bool_0)
	{
		this.method_0(byte_0, int_0, bool_0);
	}

	// Token: 0x060002DD RID: 733 RVA: 0x0004C8A8 File Offset: 0x0004AAA8
	public GClass34(BinaryReader binaryReader_0, int int_0, bool bool_0)
	{
		if (int_0 == 0 || (long)int_0 >= binaryReader_0.BaseStream.Length)
		{
			throw new ArgumentException(<Module>.DeserializeFromByteArray3<string>(2453206221U));
		}
		binaryReader_0.BaseStream.Seek((long)int_0, SeekOrigin.Begin);
		byte[] array = new byte[bool_0 ? GClass34.uint_0 : GClass34.uint_1];
		if (binaryReader_0.Read(array, 0, array.Length) != array.Length)
		{
			throw new IOException(<Module>.DeserealizeFromByteArrayV2_1<string>(2084650588U));
		}
		this.method_0(array, 0, bool_0);
	}

	// Token: 0x060002DE RID: 734 RVA: 0x0004C92C File Offset: 0x0004AB2C
	private void method_0(byte[] byte_0, int int_0, bool bool_0)
	{
		if (bool_0)
		{
			this.UInt64_0 = BitConverter.ToUInt64(byte_0, int_0);
			int_0 += 8;
			this.UInt64_1 = BitConverter.ToUInt64(byte_0, int_0);
			int_0 += 8;
			this.UInt64_2 = BitConverter.ToUInt64(byte_0, int_0);
			int_0 += 8;
			this.UInt64_3 = BitConverter.ToUInt64(byte_0, int_0);
			int_0 += 8;
			this.UInt32_0 = BitConverter.ToUInt32(byte_0, int_0);
			int_0 += 4;
			this.UInt32_1 = BitConverter.ToUInt32(byte_0, int_0);
			return;
		}
		this.UInt64_0 = (ulong)BitConverter.ToUInt32(byte_0, int_0);
		int_0 += 4;
		this.UInt64_1 = (ulong)BitConverter.ToUInt32(byte_0, int_0);
		int_0 += 4;
		this.UInt64_2 = (ulong)BitConverter.ToUInt32(byte_0, int_0);
		int_0 += 4;
		this.UInt64_3 = (ulong)BitConverter.ToUInt32(byte_0, int_0);
		int_0 += 4;
		this.UInt32_0 = BitConverter.ToUInt32(byte_0, int_0);
		int_0 += 4;
		this.UInt32_1 = BitConverter.ToUInt32(byte_0, int_0);
	}

	// Token: 0x17000134 RID: 308
	// (get) Token: 0x060002DF RID: 735 RVA: 0x0004CA10 File Offset: 0x0004AC10
	// (set) Token: 0x060002E0 RID: 736 RVA: 0x0004CA24 File Offset: 0x0004AC24
	public ulong UInt64_0 { get; set; }

	// Token: 0x17000135 RID: 309
	// (get) Token: 0x060002E1 RID: 737 RVA: 0x0004CA38 File Offset: 0x0004AC38
	// (set) Token: 0x060002E2 RID: 738 RVA: 0x0004CA4C File Offset: 0x0004AC4C
	public ulong UInt64_1 { get; set; }

	// Token: 0x17000136 RID: 310
	// (get) Token: 0x060002E3 RID: 739 RVA: 0x0004CA60 File Offset: 0x0004AC60
	// (set) Token: 0x060002E4 RID: 740 RVA: 0x0004CA74 File Offset: 0x0004AC74
	public ulong UInt64_2 { get; set; }

	// Token: 0x17000137 RID: 311
	// (get) Token: 0x060002E5 RID: 741 RVA: 0x0004CA88 File Offset: 0x0004AC88
	// (set) Token: 0x060002E6 RID: 742 RVA: 0x0004CA9C File Offset: 0x0004AC9C
	public ulong UInt64_3 { get; set; }

	// Token: 0x17000138 RID: 312
	// (get) Token: 0x060002E7 RID: 743 RVA: 0x0004CAB0 File Offset: 0x0004ACB0
	// (set) Token: 0x060002E8 RID: 744 RVA: 0x0004CAC4 File Offset: 0x0004ACC4
	public uint UInt32_0 { get; set; }

	// Token: 0x17000139 RID: 313
	// (get) Token: 0x060002E9 RID: 745 RVA: 0x0004CAD8 File Offset: 0x0004ACD8
	// (set) Token: 0x060002EA RID: 746 RVA: 0x0004CAEC File Offset: 0x0004ACEC
	public uint UInt32_1 { get; set; }

	// Token: 0x1700013A RID: 314
	// (get) Token: 0x060002EB RID: 747 RVA: 0x0004CB00 File Offset: 0x0004AD00
	// (set) Token: 0x060002EC RID: 748 RVA: 0x0004CB14 File Offset: 0x0004AD14
	public GClass33[] GClass33_0 { get; set; }

	// Token: 0x04000286 RID: 646
	[NonSerialized]
	public static readonly uint uint_0 = 40U;

	// Token: 0x04000287 RID: 647
	[NonSerialized]
	public static readonly uint uint_1 = 24U;

	// Token: 0x04000288 RID: 648
	[CompilerGenerated]
	private ulong ulong_0;

	// Token: 0x04000289 RID: 649
	[CompilerGenerated]
	private ulong ulong_1;

	// Token: 0x0400028A RID: 650
	[CompilerGenerated]
	private ulong ulong_2;

	// Token: 0x0400028B RID: 651
	[CompilerGenerated]
	private ulong ulong_3;

	// Token: 0x0400028C RID: 652
	[CompilerGenerated]
	private uint uint_2;

	// Token: 0x0400028D RID: 653
	[CompilerGenerated]
	private uint uint_3;

	// Token: 0x0400028E RID: 654
	[CompilerGenerated]
	private GClass33[] gclass33_0;
}
