﻿using System;

// Token: 0x0200006E RID: 110
public enum GEnum22
{
	// Token: 0x04000336 RID: 822
	const_0 = 1,
	// Token: 0x04000337 RID: 823
	const_1,
	// Token: 0x04000338 RID: 824
	const_2,
	// Token: 0x04000339 RID: 825
	const_3,
	// Token: 0x0400033A RID: 826
	const_4,
	// Token: 0x0400033B RID: 827
	const_5,
	// Token: 0x0400033C RID: 828
	const_6 = 8,
	// Token: 0x0400033D RID: 829
	const_7,
	// Token: 0x0400033E RID: 830
	const_8,
	// Token: 0x0400033F RID: 831
	const_9,
	// Token: 0x04000340 RID: 832
	const_10,
	// Token: 0x04000341 RID: 833
	const_11,
	// Token: 0x04000342 RID: 834
	const_12,
	// Token: 0x04000343 RID: 835
	const_13,
	// Token: 0x04000344 RID: 836
	const_14,
	// Token: 0x04000345 RID: 837
	const_15,
	// Token: 0x04000346 RID: 838
	const_16,
	// Token: 0x04000347 RID: 839
	const_17,
	// Token: 0x04000348 RID: 840
	const_18,
	// Token: 0x04000349 RID: 841
	const_19,
	// Token: 0x0400034A RID: 842
	const_20,
	// Token: 0x0400034B RID: 843
	const_21,
	// Token: 0x0400034C RID: 844
	const_22,
	// Token: 0x0400034D RID: 845
	const_23,
	// Token: 0x0400034E RID: 846
	const_24,
	// Token: 0x0400034F RID: 847
	const_25,
	// Token: 0x04000350 RID: 848
	const_26,
	// Token: 0x04000351 RID: 849
	const_27,
	// Token: 0x04000352 RID: 850
	const_28,
	// Token: 0x04000353 RID: 851
	const_29,
	// Token: 0x04000354 RID: 852
	const_30,
	// Token: 0x04000355 RID: 853
	const_31,
	// Token: 0x04000356 RID: 854
	const_32,
	// Token: 0x04000357 RID: 855
	const_33,
	// Token: 0x04000358 RID: 856
	const_34,
	// Token: 0x04000359 RID: 857
	const_35,
	// Token: 0x0400035A RID: 858
	const_36,
	// Token: 0x0400035B RID: 859
	const_37,
	// Token: 0x0400035C RID: 860
	const_38,
	// Token: 0x0400035D RID: 861
	const_39,
	// Token: 0x0400035E RID: 862
	const_40,
	// Token: 0x0400035F RID: 863
	const_41
}
