﻿using System;

// Token: 0x020000B3 RID: 179
public enum GEnum49
{
	// Token: 0x040008FC RID: 2300
	const_0 = 1,
	// Token: 0x040008FD RID: 2301
	const_1,
	// Token: 0x040008FE RID: 2302
	const_2,
	// Token: 0x040008FF RID: 2303
	const_3,
	// Token: 0x04000900 RID: 2304
	const_4,
	// Token: 0x04000901 RID: 2305
	const_5,
	// Token: 0x04000902 RID: 2306
	const_6,
	// Token: 0x04000903 RID: 2307
	const_7,
	// Token: 0x04000904 RID: 2308
	const_8,
	// Token: 0x04000905 RID: 2309
	const_9,
	// Token: 0x04000906 RID: 2310
	const_10,
	// Token: 0x04000907 RID: 2311
	const_11,
	// Token: 0x04000908 RID: 2312
	const_12,
	// Token: 0x04000909 RID: 2313
	const_13,
	// Token: 0x0400090A RID: 2314
	const_14,
	// Token: 0x0400090B RID: 2315
	const_15,
	// Token: 0x0400090C RID: 2316
	const_16,
	// Token: 0x0400090D RID: 2317
	const_17 = 19,
	// Token: 0x0400090E RID: 2318
	const_18,
	// Token: 0x0400090F RID: 2319
	const_19,
	// Token: 0x04000910 RID: 2320
	const_20,
	// Token: 0x04000911 RID: 2321
	const_21,
	// Token: 0x04000912 RID: 2322
	const_22,
	// Token: 0x04000913 RID: 2323
	const_23,
	// Token: 0x04000914 RID: 2324
	const_24,
	// Token: 0x04000915 RID: 2325
	const_25,
	// Token: 0x04000916 RID: 2326
	const_26,
	// Token: 0x04000917 RID: 2327
	const_27,
	// Token: 0x04000918 RID: 2328
	const_28,
	// Token: 0x04000919 RID: 2329
	const_29,
	// Token: 0x0400091A RID: 2330
	const_30,
	// Token: 0x0400091B RID: 2331
	const_31,
	// Token: 0x0400091C RID: 2332
	const_32,
	// Token: 0x0400091D RID: 2333
	const_33,
	// Token: 0x0400091E RID: 2334
	const_34,
	// Token: 0x0400091F RID: 2335
	const_35,
	// Token: 0x04000920 RID: 2336
	const_36,
	// Token: 0x04000921 RID: 2337
	const_37,
	// Token: 0x04000922 RID: 2338
	const_38
}
