﻿using System;

// Token: 0x02000041 RID: 65
internal enum Enum4
{
	// Token: 0x040001E0 RID: 480
	const_0,
	// Token: 0x040001E1 RID: 481
	const_1
}
