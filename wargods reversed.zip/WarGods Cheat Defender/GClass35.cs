﻿using System;
using System.IO;
using System.Runtime.CompilerServices;

// Token: 0x02000056 RID: 86
public class GClass35
{
	// Token: 0x060002EE RID: 750 RVA: 0x0004CB44 File Offset: 0x0004AD44
	public GClass35(byte[] byte_0, int int_1, int int_2)
	{
		this.method_0(byte_0, int_1, int_2);
	}

	// Token: 0x060002EF RID: 751 RVA: 0x0004CB60 File Offset: 0x0004AD60
	public GClass35(BinaryReader binaryReader_0, int int_1, int int_2)
	{
		if (int_1 == 0 || (long)(int_1 + int_2) >= binaryReader_0.BaseStream.Length)
		{
			throw new ArgumentException(<Module>.DeserializeFromByteArray2<string>(1864904701U));
		}
		binaryReader_0.BaseStream.Seek((long)int_1, SeekOrigin.Begin);
		byte[] array = new byte[int_2];
		if (binaryReader_0.Read(array, 0, array.Length) != array.Length)
		{
			throw new IOException(<Module>.DeserializeFromByteArrayV2<string>(453964184U));
		}
		this.method_0(array, 0, int_2);
	}

	// Token: 0x060002F0 RID: 752 RVA: 0x0004CBD8 File Offset: 0x0004ADD8
	private void method_0(byte[] byte_0, int int_1, int int_2)
	{
		/*
An exception occurred when decompiling this method (060002F0)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void GClass35::method_0(System.Byte[],System.Int32,System.Int32)

 ---> System.Exception: Inconsistent stack size at IL_5E
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 443
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 271
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x1700013B RID: 315
	// (get) Token: 0x060002F1 RID: 753 RVA: 0x0004CCC4 File Offset: 0x0004AEC4
	// (set) Token: 0x060002F2 RID: 754 RVA: 0x0004CCD8 File Offset: 0x0004AED8
	public uint UInt32_0 { get; private set; }

	// Token: 0x1700013C RID: 316
	// (get) Token: 0x060002F3 RID: 755 RVA: 0x0004CCEC File Offset: 0x0004AEEC
	// (set) Token: 0x060002F4 RID: 756 RVA: 0x0004CD00 File Offset: 0x0004AF00
	public string String_0 { get; private set; }

	// Token: 0x1700013D RID: 317
	// (get) Token: 0x060002F5 RID: 757 RVA: 0x0004CD14 File Offset: 0x0004AF14
	// (set) Token: 0x060002F6 RID: 758 RVA: 0x0004CD28 File Offset: 0x0004AF28
	public uint UInt32_1 { get; private set; }

	// Token: 0x1700013E RID: 318
	// (get) Token: 0x060002F7 RID: 759 RVA: 0x0004CD3C File Offset: 0x0004AF3C
	// (set) Token: 0x060002F8 RID: 760 RVA: 0x0004CD50 File Offset: 0x0004AF50
	public string String_1 { get; private set; }

	// Token: 0x0400028F RID: 655
	[NonSerialized]
	private static readonly int int_0 = 24;

	// Token: 0x04000290 RID: 656
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x04000291 RID: 657
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04000292 RID: 658
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x04000293 RID: 659
	[CompilerGenerated]
	private string string_1;
}
