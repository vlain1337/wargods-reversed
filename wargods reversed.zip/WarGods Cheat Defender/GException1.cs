﻿using System;

// Token: 0x0200001F RID: 31
public class GException1 : Exception
{
	// Token: 0x060000FB RID: 251 RVA: 0x00042320 File Offset: 0x00040520
	public GException1()
	{
	}

	// Token: 0x060000FC RID: 252 RVA: 0x00042334 File Offset: 0x00040534
	public GException1(string string_0) : base(string_0)
	{
	}

	// Token: 0x060000FD RID: 253 RVA: 0x00042348 File Offset: 0x00040548
	public GException1(string string_0, Exception exception_0) : base(string_0, exception_0)
	{
	}
}
