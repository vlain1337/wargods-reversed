﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x0200001D RID: 29
public class GClass11
{
	// Token: 0x060000F1 RID: 241 RVA: 0x00042260 File Offset: 0x00040460
	public GClass11(int int_1, DateTimeOffset dateTimeOffset_1, string string_2, string string_3)
	{
		this.Int32_0 = int_1;
		this.DateTimeOffset_0 = dateTimeOffset_1;
		this.String_0 = string_2;
		this.String_1 = string_3;
		this.List_0 = new List<GClass3>();
		this.List_1 = new List<string>();
	}

	// Token: 0x17000086 RID: 134
	// (get) Token: 0x060000F2 RID: 242 RVA: 0x000422A8 File Offset: 0x000404A8
	public int Int32_0 { get; }

	// Token: 0x17000087 RID: 135
	// (get) Token: 0x060000F3 RID: 243 RVA: 0x000422BC File Offset: 0x000404BC
	public DateTimeOffset DateTimeOffset_0 { get; }

	// Token: 0x17000088 RID: 136
	// (get) Token: 0x060000F4 RID: 244 RVA: 0x000422D0 File Offset: 0x000404D0
	public string String_0 { get; }

	// Token: 0x17000089 RID: 137
	// (get) Token: 0x060000F5 RID: 245 RVA: 0x000422E4 File Offset: 0x000404E4
	public string String_1 { get; }

	// Token: 0x1700008A RID: 138
	// (get) Token: 0x060000F6 RID: 246 RVA: 0x000422F8 File Offset: 0x000404F8
	public List<GClass3> List_0 { get; }

	// Token: 0x1700008B RID: 139
	// (get) Token: 0x060000F7 RID: 247 RVA: 0x0004230C File Offset: 0x0004050C
	public List<string> List_1 { get; }

	// Token: 0x040000B6 RID: 182
	[CompilerGenerated]
	private readonly int int_0;

	// Token: 0x040000B7 RID: 183
	[CompilerGenerated]
	private readonly DateTimeOffset dateTimeOffset_0;

	// Token: 0x040000B8 RID: 184
	[CompilerGenerated]
	private readonly string string_0;

	// Token: 0x040000B9 RID: 185
	[CompilerGenerated]
	private readonly string string_1;

	// Token: 0x040000BA RID: 186
	[CompilerGenerated]
	private readonly List<GClass3> list_0;

	// Token: 0x040000BB RID: 187
	[CompilerGenerated]
	private readonly List<string> list_1;
}
