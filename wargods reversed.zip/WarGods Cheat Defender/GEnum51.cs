﻿using System;

// Token: 0x020000D5 RID: 213
public enum GEnum51 : uint
{
	// Token: 0x040009A3 RID: 2467
	const_0,
	// Token: 0x040009A4 RID: 2468
	const_1,
	// Token: 0x040009A5 RID: 2469
	const_2
}
