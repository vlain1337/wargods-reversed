﻿using System;
using System.Management;
using System.Runtime.CompilerServices;
using Microsoft.Win32;

// Token: 0x020000DF RID: 223
internal class Class46
{
	// Token: 0x1700030D RID: 781
	// (get) Token: 0x06000722 RID: 1826 RVA: 0x00068384 File Offset: 0x00066584
	// (set) Token: 0x06000723 RID: 1827 RVA: 0x00068398 File Offset: 0x00066598
	public string String_0 { get; set; }

	// Token: 0x1700030E RID: 782
	// (get) Token: 0x06000724 RID: 1828 RVA: 0x000683AC File Offset: 0x000665AC
	// (set) Token: 0x06000725 RID: 1829 RVA: 0x000683C0 File Offset: 0x000665C0
	public string String_1 { get; set; }

	// Token: 0x1700030F RID: 783
	// (get) Token: 0x06000726 RID: 1830 RVA: 0x000683D4 File Offset: 0x000665D4
	// (set) Token: 0x06000727 RID: 1831 RVA: 0x000683E8 File Offset: 0x000665E8
	public string String_2 { get; set; }

	// Token: 0x17000310 RID: 784
	// (get) Token: 0x06000728 RID: 1832 RVA: 0x000683FC File Offset: 0x000665FC
	// (set) Token: 0x06000729 RID: 1833 RVA: 0x00068410 File Offset: 0x00066610
	public string String_3 { get; set; }

	// Token: 0x17000311 RID: 785
	// (get) Token: 0x0600072A RID: 1834 RVA: 0x00068424 File Offset: 0x00066624
	// (set) Token: 0x0600072B RID: 1835 RVA: 0x00068438 File Offset: 0x00066638
	public string String_4 { get; set; }

	// Token: 0x17000312 RID: 786
	// (get) Token: 0x0600072C RID: 1836 RVA: 0x0006844C File Offset: 0x0006664C
	// (set) Token: 0x0600072D RID: 1837 RVA: 0x00068460 File Offset: 0x00066660
	public string String_5 { get; set; }

	// Token: 0x0600072E RID: 1838 RVA: 0x00068474 File Offset: 0x00066674
	public Class46()
	{
		this.String_0 = string.Empty;
		this.String_1 = string.Empty;
		this.String_2 = string.Empty;
		this.String_3 = string.Empty;
		this.String_4 = string.Empty;
		this.String_5 = string.Empty;
	}

	// Token: 0x0600072F RID: 1839 RVA: 0x000684CC File Offset: 0x000666CC
	public virtual string ToString()
	{
		return string.Format(<Module>.DeserializeFromByteArray3<string>(4096047587U), new object[]
		{
			Class15.SanitizeString(this.String_0),
			Class15.char_2,
			Class15.SanitizeString(this.String_1),
			Class15.char_2,
			Class15.SanitizeString(this.String_2),
			Class15.char_2,
			Class15.SanitizeString(this.String_3),
			Class15.char_2,
			Class15.SanitizeString(this.String_4),
			Class15.char_2,
			Class15.SanitizeString(this.String_5)
		});
	}

	// Token: 0x06000730 RID: 1840 RVA: 0x00068588 File Offset: 0x00066788
	public static string smethod_0()
	{
		Class46 @class = new Class46();
		try
		{
			using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = new ManagementObjectSearcher(Class14.String_14, Class14.String_238).Get().GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					ManagementObject managementObject = (ManagementObject)enumerator.Current;
					try
					{
						@class.String_0 = managementObject.GetPropertyValue(Class14.String_222).ToString().Trim();
					}
					catch
					{
						@class.String_0 = string.Empty;
					}
					try
					{
						IL_69:
						@class.String_1 = managementObject.GetPropertyValue(Class14.String_84).ToString().Trim();
					}
					catch
					{
						@class.String_1 = string.Empty;
					}
					try
					{
						@class.String_2 = managementObject.GetPropertyValue(Class14.String_226).ToString().Trim();
					}
					catch
					{
						@class.String_2 = string.Empty;
					}
					try
					{
						@class.String_3 = managementObject.GetPropertyValue(Class14.String_145).ToString().Trim();
					}
					catch
					{
						@class.String_3 = string.Empty;
					}
					try
					{
						@class.String_4 = Class15.smethod_10(managementObject.GetPropertyValue(Class14.String_64).ToString().Trim().Replace(<Module>.DeserializeFromByteArray<string>(3133938773U), "").ToUpper());
					}
					catch
					{
						@class.String_4 = string.Empty;
					}
					try
					{
						@class.String_5 = managementObject.GetPropertyValue(Class14.String_179).ToString().Trim();
					}
					catch
					{
						@class.String_5 = string.Empty;
					}
					if (!(@class.String_0 == string.Empty) || !(@class.String_2 == string.Empty))
					{
						break;
					}
					if (!(@class.String_4 == string.Empty))
					{
						break;
					}
					continue;
					goto IL_69;
				}
			}
		}
		catch
		{
		}
		if (@class.String_5.Length == 0)
		{
			@class.String_5 = RegistryStuff.GetStringValueFromRegistry(Registry.LocalMachine, Class14.String_38, Class14.String_72);
			if (@class.String_5 == null)
			{
				@class.String_5 = string.Empty;
			}
		}
		if (@class.String_0.Length == 0)
		{
			@class.String_0 = RegistryStuff.GetStringValueFromRegistry(Registry.LocalMachine, Class14.String_38, Class14.String_140);
			if (@class.String_0 == null)
			{
				@class.String_0 = string.Empty;
			}
		}
		return @class.ToString();
	}

	// Token: 0x040009D3 RID: 2515
	[CompilerGenerated]
	private string string_0;

	// Token: 0x040009D4 RID: 2516
	[CompilerGenerated]
	private string string_1;

	// Token: 0x040009D5 RID: 2517
	[CompilerGenerated]
	private string string_2;

	// Token: 0x040009D6 RID: 2518
	[CompilerGenerated]
	private string string_3;

	// Token: 0x040009D7 RID: 2519
	[CompilerGenerated]
	private string string_4;

	// Token: 0x040009D8 RID: 2520
	[CompilerGenerated]
	private string string_5;
}
