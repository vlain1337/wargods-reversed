﻿using System;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x0200004B RID: 75
public class GClass24
{
	// Token: 0x0600021E RID: 542 RVA: 0x0004ACF4 File Offset: 0x00048EF4
	public GClass24(byte[] byte_0, int int_1 = 0)
	{
		this.UInt32_0 = BitConverter.ToUInt32(byte_0, int_1);
		this.UInt32_1 = BitConverter.ToUInt32(byte_0, int_1 + 4);
		this.UInt16_0 = BitConverter.ToUInt16(byte_0, int_1 + 8);
		this.UInt16_1 = BitConverter.ToUInt16(byte_0, int_1 + 10);
		this.UInt32_2 = BitConverter.ToUInt32(byte_0, int_1 + 12);
		this.UInt32_3 = BitConverter.ToUInt32(byte_0, int_1 + 16);
		this.UInt32_4 = BitConverter.ToUInt32(byte_0, int_1 + 20);
		this.UInt32_5 = BitConverter.ToUInt32(byte_0, int_1 + 24);
		this.UInt32_6 = BitConverter.ToUInt32(byte_0, int_1 + 28);
		this.UInt32_7 = BitConverter.ToUInt32(byte_0, int_1 + 32);
		this.UInt32_8 = BitConverter.ToUInt32(byte_0, int_1 + 36);
	}

	// Token: 0x170000E4 RID: 228
	// (get) Token: 0x0600021F RID: 543 RVA: 0x0004ADB4 File Offset: 0x00048FB4
	// (set) Token: 0x06000220 RID: 544 RVA: 0x0004ADC8 File Offset: 0x00048FC8
	public uint UInt32_0 { get; set; }

	// Token: 0x170000E5 RID: 229
	// (get) Token: 0x06000221 RID: 545 RVA: 0x0004ADDC File Offset: 0x00048FDC
	// (set) Token: 0x06000222 RID: 546 RVA: 0x0004ADF0 File Offset: 0x00048FF0
	public uint UInt32_1 { get; set; }

	// Token: 0x170000E6 RID: 230
	// (get) Token: 0x06000223 RID: 547 RVA: 0x0004AE04 File Offset: 0x00049004
	// (set) Token: 0x06000224 RID: 548 RVA: 0x0004AE18 File Offset: 0x00049018
	public ushort UInt16_0 { get; set; }

	// Token: 0x170000E7 RID: 231
	// (get) Token: 0x06000225 RID: 549 RVA: 0x0004AE2C File Offset: 0x0004902C
	// (set) Token: 0x06000226 RID: 550 RVA: 0x0004AE40 File Offset: 0x00049040
	public ushort UInt16_1 { get; set; }

	// Token: 0x170000E8 RID: 232
	// (get) Token: 0x06000227 RID: 551 RVA: 0x0004AE54 File Offset: 0x00049054
	// (set) Token: 0x06000228 RID: 552 RVA: 0x0004AE68 File Offset: 0x00049068
	public uint UInt32_2 { get; set; }

	// Token: 0x170000E9 RID: 233
	// (get) Token: 0x06000229 RID: 553 RVA: 0x0004AE7C File Offset: 0x0004907C
	// (set) Token: 0x0600022A RID: 554 RVA: 0x0004AE90 File Offset: 0x00049090
	public uint UInt32_3 { get; set; }

	// Token: 0x170000EA RID: 234
	// (get) Token: 0x0600022B RID: 555 RVA: 0x0004AEA4 File Offset: 0x000490A4
	// (set) Token: 0x0600022C RID: 556 RVA: 0x0004AEB8 File Offset: 0x000490B8
	public uint UInt32_4 { get; set; }

	// Token: 0x170000EB RID: 235
	// (get) Token: 0x0600022D RID: 557 RVA: 0x0004AECC File Offset: 0x000490CC
	// (set) Token: 0x0600022E RID: 558 RVA: 0x0004AEE0 File Offset: 0x000490E0
	public uint UInt32_5 { get; set; }

	// Token: 0x170000EC RID: 236
	// (get) Token: 0x0600022F RID: 559 RVA: 0x0004AEF4 File Offset: 0x000490F4
	// (set) Token: 0x06000230 RID: 560 RVA: 0x0004AF08 File Offset: 0x00049108
	public uint UInt32_6 { get; set; }

	// Token: 0x170000ED RID: 237
	// (get) Token: 0x06000231 RID: 561 RVA: 0x0004AF1C File Offset: 0x0004911C
	// (set) Token: 0x06000232 RID: 562 RVA: 0x0004AF30 File Offset: 0x00049130
	public uint UInt32_7 { get; set; }

	// Token: 0x170000EE RID: 238
	// (get) Token: 0x06000233 RID: 563 RVA: 0x0004AF44 File Offset: 0x00049144
	// (set) Token: 0x06000234 RID: 564 RVA: 0x0004AF58 File Offset: 0x00049158
	public uint UInt32_8 { get; set; }

	// Token: 0x06000235 RID: 565 RVA: 0x0004AF6C File Offset: 0x0004916C
	public virtual string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder(<Module>.DeserializeFromByteArray<string>(683312858U));
		stringBuilder.Append(GClass18.smethod_9(this, <Module>.DeserializeFromByteArrayV2<string>(3969376509U)));
		return stringBuilder.ToString();
	}

	// Token: 0x0400022E RID: 558
	[NonSerialized]
	public static readonly int int_0 = 40;

	// Token: 0x0400022F RID: 559
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x04000230 RID: 560
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x04000231 RID: 561
	[CompilerGenerated]
	private ushort ushort_0;

	// Token: 0x04000232 RID: 562
	[CompilerGenerated]
	private ushort ushort_1;

	// Token: 0x04000233 RID: 563
	[CompilerGenerated]
	private uint uint_2;

	// Token: 0x04000234 RID: 564
	[CompilerGenerated]
	private uint uint_3;

	// Token: 0x04000235 RID: 565
	[CompilerGenerated]
	private uint uint_4;

	// Token: 0x04000236 RID: 566
	[CompilerGenerated]
	private uint uint_5;

	// Token: 0x04000237 RID: 567
	[CompilerGenerated]
	private uint uint_6;

	// Token: 0x04000238 RID: 568
	[CompilerGenerated]
	private uint uint_7;

	// Token: 0x04000239 RID: 569
	[CompilerGenerated]
	private uint uint_8;
}
