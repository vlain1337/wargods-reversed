﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x0200001B RID: 27
public class GClass9 : GInterface0
{
	// Token: 0x060000D6 RID: 214 RVA: 0x00041B04 File Offset: 0x0003FD04
	public GClass9(byte[] byte_1, string string_1)
	{
		this.String_0 = string_1;
		this.Byte_0 = byte_1;
		byte[] dst = new byte[84];
		Buffer.BlockCopy(byte_1, 0, dst, 0, 84);
		this.GClass2_0 = new GClass2(dst);
		FileInfo fileInfo = new FileInfo(string_1);
		this.DateTimeOffset_0 = new DateTimeOffset(fileInfo.CreationTimeUtc);
		this.DateTimeOffset_1 = new DateTimeOffset(fileInfo.LastWriteTimeUtc);
		this.DateTimeOffset_2 = new DateTimeOffset(fileInfo.LastAccessTimeUtc);
		byte[] array = new byte[224];
		Buffer.BlockCopy(byte_1, 84, array, 0, 224);
		this.Int32_0 = BitConverter.ToInt32(array, 0);
		this.Int32_1 = BitConverter.ToInt32(array, 4);
		this.Int32_2 = BitConverter.ToInt32(array, 8);
		this.Int32_3 = BitConverter.ToInt32(array, 12);
		this.Int32_4 = BitConverter.ToInt32(array, 16);
		this.Int32_5 = BitConverter.ToInt32(array, 20);
		this.Int32_6 = BitConverter.ToInt32(array, 24);
		this.Int32_7 = BitConverter.ToInt32(array, 28);
		this.Int32_8 = BitConverter.ToInt32(array, 32);
		this.Int32_9 = BitConverter.ToInt32(array, 36);
		byte[] array2 = new byte[64];
		Buffer.BlockCopy(array, 44, array2, 0, 64);
		this.Prop_0 = new List<DateTimeOffset>();
		for (int i = 0; i < 8; i++)
		{
			long num = BitConverter.ToInt64(array2, i * 8);
			if (num > 0L)
			{
				this.Prop_0.Add(DateTimeOffset.FromFileTime(num).ToUniversalTime());
			}
		}
		this.Int32_10 = BitConverter.ToInt32(array, 124);
		BitConverter.ToInt32(array, 128);
		BitConverter.ToInt32(array, 132);
		BitConverter.ToInt32(array, 128);
		byte[] array3 = new byte[this.Int32_1 * 32];
		Buffer.BlockCopy(byte_1, this.Int32_0, array3, 0, this.Int32_1 * 32);
		int j = 0;
		this.Prop_3 = new List<GClass1>();
		byte[] dst2 = new byte[32];
		while (j < array3.Length)
		{
			Buffer.BlockCopy(array3, j, dst2, 0, 32);
			this.Prop_3.Add(new GClass1(array3, false));
			j += 32;
		}
		this.Prop_4 = new List<GClass4>();
		byte[] array4 = new byte[8 * this.Int32_3];
		Buffer.BlockCopy(byte_1, this.Int32_2, array4, 0, 8 * this.Int32_3);
		int k = 0;
		byte[] array5 = new byte[8];
		while (k < array4.Length)
		{
			Buffer.BlockCopy(array4, k, array5, 0, 8);
			this.Prop_4.Add(new GClass4(array5, true));
			k += 8;
		}
		byte[] array6 = new byte[this.Int32_5];
		Buffer.BlockCopy(byte_1, this.Int32_4, array6, 0, this.Int32_5);
		string[] collection = Encoding.Unicode.GetString(array6).Split(new char[1], StringSplitOptions.RemoveEmptyEntries);
		this.Prop_2 = new List<string>();
		this.Prop_2.AddRange(collection);
		byte[] array7 = new byte[this.Int32_8];
		Buffer.BlockCopy(byte_1, this.Int32_6, array7, 0, this.Int32_8);
		this.Prop_1 = new List<GClass11>();
		byte[] array8 = new byte[96];
		for (int l = 0; l < this.Int32_7; l++)
		{
			int srcOffset = l * 96;
			Buffer.BlockCopy(array7, srcOffset, array8, 0, 96);
			int num2 = BitConverter.ToInt32(array8, 0);
			int num3 = BitConverter.ToInt32(array8, 4);
			long fileTime = BitConverter.ToInt64(array8, 8);
			byte[] array9 = new byte[num3 * 2];
			Buffer.BlockCopy(byte_1, this.Int32_6 + num2, array9, 0, num3 * 2);
			string @string = Encoding.Unicode.GetString(array9);
			string string_2 = BitConverter.ToInt32(array8, 16).ToString(<Module>.DeserializeFromByteArray<string>(2611176279U));
			this.Prop_1.Add(new GClass11(num2, DateTimeOffset.FromFileTime(fileTime).ToUniversalTime(), string_2, @string));
			int num4 = BitConverter.ToInt32(array8, 20);
			int num5 = BitConverter.ToInt32(array8, 24);
			int num6 = BitConverter.ToInt32(array8, 28);
			int num7 = BitConverter.ToInt32(array8, 32);
			int srcOffset2 = this.Int32_6 + num4;
			byte[] array10 = new byte[num5];
			Buffer.BlockCopy(byte_1, srcOffset2, array10, 0, num5);
			BitConverter.ToInt32(array10, 0);
			int num8 = BitConverter.ToInt32(array10, 4);
			j = 8;
			byte[] dst3 = new byte[8];
			while (j < array10.Length && this.Prop_1[this.Prop_1.Count - 1].List_0.Count < num8)
			{
				Buffer.BlockCopy(array10, j, dst3, 0, 8);
				this.Prop_1[this.Prop_1.Count - 1].List_0.Add(new GClass3(dst3));
				j += 8;
			}
			int num9 = this.Int32_6 + num6;
			byte[] array11 = new byte[byte_1.Length - num9];
			Buffer.BlockCopy(byte_1, num9, array11, 0, byte_1.Length - num9);
			j = 0;
			for (int m = 0; m < num7; m++)
			{
				int num10 = (int)(BitConverter.ToInt16(array11, j) * 2 + 2);
				j += 2;
				string item = Encoding.Unicode.GetString(array11, j, num10).Trim(new char[1]);
				this.Prop_1[this.Prop_1.Count - 1].List_1.Add(item);
				j += num10;
			}
		}
	}

	// Token: 0x17000070 RID: 112
	// (get) Token: 0x060000D7 RID: 215 RVA: 0x00042050 File Offset: 0x00040250
	public byte[] Byte_0 { get; }

	// Token: 0x17000071 RID: 113
	// (get) Token: 0x060000D8 RID: 216 RVA: 0x00042064 File Offset: 0x00040264
	public string String_0 { get; }

	// Token: 0x17000072 RID: 114
	// (get) Token: 0x060000D9 RID: 217 RVA: 0x00042078 File Offset: 0x00040278
	public DateTimeOffset DateTimeOffset_0 { get; }

	// Token: 0x17000073 RID: 115
	// (get) Token: 0x060000DA RID: 218 RVA: 0x0004208C File Offset: 0x0004028C
	public DateTimeOffset DateTimeOffset_1 { get; }

	// Token: 0x17000074 RID: 116
	// (get) Token: 0x060000DB RID: 219 RVA: 0x000420A0 File Offset: 0x000402A0
	public DateTimeOffset DateTimeOffset_2 { get; }

	// Token: 0x17000075 RID: 117
	// (get) Token: 0x060000DC RID: 220 RVA: 0x000420B4 File Offset: 0x000402B4
	public GClass2 GClass2_0 { get; }

	// Token: 0x17000076 RID: 118
	// (get) Token: 0x060000DD RID: 221 RVA: 0x000420C8 File Offset: 0x000402C8
	public int Int32_0 { get; }

	// Token: 0x17000077 RID: 119
	// (get) Token: 0x060000DE RID: 222 RVA: 0x000420DC File Offset: 0x000402DC
	public int Int32_1 { get; }

	// Token: 0x17000078 RID: 120
	// (get) Token: 0x060000DF RID: 223 RVA: 0x000420F0 File Offset: 0x000402F0
	public int Int32_2 { get; }

	// Token: 0x17000079 RID: 121
	// (get) Token: 0x060000E0 RID: 224 RVA: 0x00042104 File Offset: 0x00040304
	public int Int32_3 { get; }

	// Token: 0x1700007A RID: 122
	// (get) Token: 0x060000E1 RID: 225 RVA: 0x00042118 File Offset: 0x00040318
	public int Int32_4 { get; }

	// Token: 0x1700007B RID: 123
	// (get) Token: 0x060000E2 RID: 226 RVA: 0x0004212C File Offset: 0x0004032C
	public int Int32_5 { get; }

	// Token: 0x1700007C RID: 124
	// (get) Token: 0x060000E3 RID: 227 RVA: 0x00042140 File Offset: 0x00040340
	public int Int32_6 { get; }

	// Token: 0x1700007D RID: 125
	// (get) Token: 0x060000E4 RID: 228 RVA: 0x00042154 File Offset: 0x00040354
	public int Int32_7 { get; }

	// Token: 0x1700007E RID: 126
	// (get) Token: 0x060000E5 RID: 229 RVA: 0x00042168 File Offset: 0x00040368
	public int Int32_8 { get; }

	// Token: 0x1700007F RID: 127
	// (get) Token: 0x060000E6 RID: 230 RVA: 0x0004217C File Offset: 0x0004037C
	public int Int32_9 { get; }

	// Token: 0x17000080 RID: 128
	// (get) Token: 0x060000E7 RID: 231 RVA: 0x00042190 File Offset: 0x00040390
	public List<DateTimeOffset> Prop_0 { get; }

	// Token: 0x17000081 RID: 129
	// (get) Token: 0x060000E8 RID: 232 RVA: 0x000421A4 File Offset: 0x000403A4
	public List<GClass11> Prop_1 { get; }

	// Token: 0x17000082 RID: 130
	// (get) Token: 0x060000E9 RID: 233 RVA: 0x000421B8 File Offset: 0x000403B8
	public int Int32_10 { get; }

	// Token: 0x17000083 RID: 131
	// (get) Token: 0x060000EA RID: 234 RVA: 0x000421CC File Offset: 0x000403CC
	public List<string> Prop_2 { get; }

	// Token: 0x17000084 RID: 132
	// (get) Token: 0x060000EB RID: 235 RVA: 0x000421E0 File Offset: 0x000403E0
	public List<GClass1> Prop_3 { get; }

	// Token: 0x17000085 RID: 133
	// (get) Token: 0x060000EC RID: 236 RVA: 0x000421F4 File Offset: 0x000403F4
	public List<GClass4> Prop_4 { get; }

	// Token: 0x0400009F RID: 159
	[CompilerGenerated]
	private readonly byte[] byte_0;

	// Token: 0x040000A0 RID: 160
	[CompilerGenerated]
	private readonly string string_0;

	// Token: 0x040000A1 RID: 161
	[CompilerGenerated]
	private readonly DateTimeOffset dateTimeOffset_0;

	// Token: 0x040000A2 RID: 162
	[CompilerGenerated]
	private readonly DateTimeOffset dateTimeOffset_1;

	// Token: 0x040000A3 RID: 163
	[CompilerGenerated]
	private readonly DateTimeOffset dateTimeOffset_2;

	// Token: 0x040000A4 RID: 164
	[CompilerGenerated]
	private readonly GClass2 gclass2_0;

	// Token: 0x040000A5 RID: 165
	[CompilerGenerated]
	private readonly int int_0;

	// Token: 0x040000A6 RID: 166
	[CompilerGenerated]
	private readonly int int_1;

	// Token: 0x040000A7 RID: 167
	[CompilerGenerated]
	private readonly int int_2;

	// Token: 0x040000A8 RID: 168
	[CompilerGenerated]
	private readonly int int_3;

	// Token: 0x040000A9 RID: 169
	[CompilerGenerated]
	private readonly int int_4;

	// Token: 0x040000AA RID: 170
	[CompilerGenerated]
	private readonly int int_5;

	// Token: 0x040000AB RID: 171
	[CompilerGenerated]
	private readonly int int_6;

	// Token: 0x040000AC RID: 172
	[CompilerGenerated]
	private readonly int int_7;

	// Token: 0x040000AD RID: 173
	[CompilerGenerated]
	private readonly int int_8;

	// Token: 0x040000AE RID: 174
	[CompilerGenerated]
	private readonly int int_9;

	// Token: 0x040000AF RID: 175
	[CompilerGenerated]
	private readonly List<DateTimeOffset> list_0;

	// Token: 0x040000B0 RID: 176
	[CompilerGenerated]
	private readonly List<GClass11> list_1;

	// Token: 0x040000B1 RID: 177
	[CompilerGenerated]
	private readonly int int_10;

	// Token: 0x040000B2 RID: 178
	[CompilerGenerated]
	private readonly List<string> list_2;

	// Token: 0x040000B3 RID: 179
	[CompilerGenerated]
	private readonly List<GClass1> list_3;

	// Token: 0x040000B4 RID: 180
	[CompilerGenerated]
	private readonly List<GClass4> list_4;
}
