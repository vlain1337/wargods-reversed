﻿using System;
using System.ComponentModel;

// Token: 0x02000011 RID: 17
public enum GEnum1
{
	// Token: 0x04000045 RID: 69
	[Description("Windows XP or Windows Server 2003")]
	const_0 = 17,
	// Token: 0x04000046 RID: 70
	[Description("Windows Vista or Windows 7")]
	const_1 = 23,
	// Token: 0x04000047 RID: 71
	[Description("Windows 8.0, Windows 8.1, or Windows Server 2012(R2)")]
	const_2 = 26,
	// Token: 0x04000048 RID: 72
	[Description("Windows 10")]
	const_3 = 30
}
