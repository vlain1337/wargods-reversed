﻿using System;

// Token: 0x0200005B RID: 91
public class GException3 : Exception
{
	// Token: 0x06000320 RID: 800 RVA: 0x00042334 File Offset: 0x00040534
	public GException3(string string_0) : base(string_0)
	{
	}
}
