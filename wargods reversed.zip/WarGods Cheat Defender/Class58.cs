﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020000F7 RID: 247
internal class Class58
{
	// Token: 0x17000347 RID: 839
	// (get) Token: 0x060007CA RID: 1994 RVA: 0x0006B3DC File Offset: 0x000695DC
	// (set) Token: 0x060007CB RID: 1995 RVA: 0x0006B3F0 File Offset: 0x000695F0
	public string String_0 { get; private set; }

	// Token: 0x17000348 RID: 840
	// (get) Token: 0x060007CC RID: 1996 RVA: 0x0006B404 File Offset: 0x00069604
	// (set) Token: 0x060007CD RID: 1997 RVA: 0x0006B418 File Offset: 0x00069618
	public long Int64_0 { get; private set; }

	// Token: 0x17000349 RID: 841
	// (get) Token: 0x060007CE RID: 1998 RVA: 0x0006B42C File Offset: 0x0006962C
	// (set) Token: 0x060007CF RID: 1999 RVA: 0x0006B440 File Offset: 0x00069640
	public DateTime? Nullable_0 { get; private set; }

	// Token: 0x1700034A RID: 842
	// (get) Token: 0x060007D0 RID: 2000 RVA: 0x0006B454 File Offset: 0x00069654
	// (set) Token: 0x060007D1 RID: 2001 RVA: 0x0006B468 File Offset: 0x00069668
	public GEnum58 GEnum58_0 { get; private set; }

	// Token: 0x060007D2 RID: 2002 RVA: 0x0006B47C File Offset: 0x0006967C
	public Class58(string string_1, long long_1, GEnum58 genum58_1)
	{
		this.String_0 = string_1;
		this.Int64_0 = long_1;
		try
		{
			this.Nullable_0 = new DateTime?(DateTime.FromFileTimeUtc(long_1));
		}
		catch (ArgumentOutOfRangeException)
		{
			this.Nullable_0 = null;
		}
		this.GEnum58_0 = genum58_1;
	}

	// Token: 0x04000B2E RID: 2862
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04000B2F RID: 2863
	[CompilerGenerated]
	private long long_0;

	// Token: 0x04000B30 RID: 2864
	[CompilerGenerated]
	private DateTime? nullable_0;

	// Token: 0x04000B31 RID: 2865
	[CompilerGenerated]
	private GEnum58 genum58_0;
}
