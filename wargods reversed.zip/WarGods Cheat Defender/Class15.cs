﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;

// Token: 0x020000B8 RID: 184
internal class Class15
{
	// Token: 0x060005D3 RID: 1491 RVA: 0x00058784 File Offset: 0x00056984
	public static string ListToString(List<string> list_0, char char_3 = ';')
	{
		if (list_0 == null)
		{
			return null;
		}
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < list_0.Count; i++)
		{
			stringBuilder.Append(list_0[i].ToString());
			if (i + 1 < list_0.Count)
			{
				stringBuilder.Append(char_3);
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x060005D4 RID: 1492 RVA: 0x000587DC File Offset: 0x000569DC
	public static string ListToString2(List<long> list_0, char char_3 = ';')
	{
		if (list_0 == null)
		{
			return null;
		}
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < list_0.Count; i++)
		{
			stringBuilder.Append(list_0[i].ToString());
			if (i + 1 < list_0.Count)
			{
				stringBuilder.Append(char_3);
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x060005D5 RID: 1493 RVA: 0x00058834 File Offset: 0x00056A34
	public static string ConcatenateStrings(string[] string_4, char char_3 = ';')
	{
		if (string_4 == null)
		{
			return null;
		}
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < string_4.Length; i++)
		{
			stringBuilder.Append(string_4[i].ToString());
			if (i + 1 < string_4.Length)
			{
				stringBuilder.Append(char_3);
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x060005D6 RID: 1494 RVA: 0x00058880 File Offset: 0x00056A80
	public static string GetSystemDirectory()
	{
		return Path.GetDirectoryName(Environment.GetFolderPath(Environment.SpecialFolder.System));
	}

	// Token: 0x060005D7 RID: 1495 RVA: 0x0005889C File Offset: 0x00056A9C
	public static string ComposePath()
	{
		return Path.Combine(Class15.GetSystemDirectory(), Class14.String_182 + <Module>.DeserealizeFromByteArrayV2_1<string>(528946535U));
	}

	// Token: 0x060005D8 RID: 1496 RVA: 0x000588C8 File Offset: 0x00056AC8
	public static string ComposePath2()
	{
		return Path.Combine(Class15.GetSystemDirectory(), Class14.String_122 + <Module>.DeserializeFromByteArray<string>(477047453U));
	}

	// Token: 0x060005D9 RID: 1497 RVA: 0x000588F4 File Offset: 0x00056AF4
	public static string ComposePath3()
	{
		return Path.Combine(Class15.GetSystemDirectory(), Class14.String_200 + <Module>.DeserializeFromByteArray2<string>(1171514142U));
	}

	// Token: 0x060005DA RID: 1498
	public static string NormalizeFilePath(string string_4)
	{
		if (string.IsNullOrEmpty(string_4))
		{
			return null;
		}
		string result = null;
		try
		{
			string fullPath = Path.GetFullPath(string_4);
			result = fullPath.Substring(Path.GetPathRoot(fullPath).Length);
		}
		catch
		{
		}
		return result;
	}

	// Token: 0x060005DB RID: 1499 RVA: 0x00058968 File Offset: 0x00056B68
	public static string ExtractRelativePath(string string_4)
	{
		FileStream fileStream = null;
		try
		{
			try
			{
				fileStream = new FileStream(string_4, FileMode.Open, FileAccess.Read, FileShare.Read);
			}
			catch
			{
				fileStream = new FileStream(string_4, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			}
			byte[] byte_;
			using (BinaryReader binaryReader = new BinaryReader(fileStream))
			{
				byte_ = new SHA256Managed().ComputeHash(binaryReader.BaseStream);
			}
			return Class15.ByteArrayToHexString(byte_);
		}
		catch
		{
		}
		finally
		{
			if (fileStream != null)
			{
				fileStream.Close();
			}
		}
		return Class14.String_215;
	}

	// Token: 0x060005DC RID: 1500 RVA: 0x00058A08 File Offset: 0x00056C08
	public static string ComputeSHA256Hash(FileStream fileStream_0)
	{
		try
		{
			BinaryReader binaryReader = new BinaryReader(fileStream_0);
			return Class15.ByteArrayToHexString(new SHA256Managed().ComputeHash(binaryReader.BaseStream));
		}
		catch
		{
		}
		return Class14.String_215;
	}

	// Token: 0x060005DD RID: 1501 RVA: 0x00058A50 File Offset: 0x00056C50
	public static string smethod_10(string string_4)
	{
		return Class15.ByteArrayToHexString(new SHA256Managed().ComputeHash(Encoding.Default.GetBytes(string_4)));
	}

	// Token: 0x060005DE RID: 1502 RVA: 0x00058A78 File Offset: 0x00056C78
	public static string CalculateMD5HashFromFile(string string_4)
	{
		FileStream fileStream = null;
		try
		{
			if (File.Exists(string_4))
			{
				MD5CryptoServiceProvider md5CryptoServiceProvider = new MD5CryptoServiceProvider();
				try
				{
					fileStream = new FileStream(string_4, FileMode.Open, FileAccess.Read, FileShare.Read);
				}
				catch
				{
					fileStream = new FileStream(string_4, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
				}
				md5CryptoServiceProvider.ComputeHash(fileStream);
				return Class15.ByteArrayToHexString(md5CryptoServiceProvider.Hash);
			}
		}
		catch
		{
		}
		finally
		{
			if (fileStream != null)
			{
				fileStream.Close();
			}
		}
		return Class14.String_215;
	}

	// Token: 0x060005DF RID: 1503 RVA: 0x00058B04 File Offset: 0x00056D04
	public static string CalculateMD5HashFromStream(FileStream fileStream_0)
	{
		try
		{
			MD5CryptoServiceProvider md5CryptoServiceProvider = new MD5CryptoServiceProvider();
			md5CryptoServiceProvider.ComputeHash(fileStream_0);
			return Class15.ByteArrayToHexString(md5CryptoServiceProvider.Hash);
		}
		catch
		{
		}
		return Class14.String_215;
	}

	// Token: 0x060005E0 RID: 1504 RVA: 0x00058B48 File Offset: 0x00056D48
	public static string MD5HashFromString(string string_4)
	{
		try
		{
			return Class15.ByteArrayToHexString(MD5.Create().ComputeHash(Encoding.Default.GetBytes(string_4)));
		}
		catch
		{
		}
		return <Module>.DeserealizeFromByteArrayV2_1<string>(1226200051U);
	}

	// Token: 0x060005E1 RID: 1505 RVA: 0x00058B94 File Offset: 0x00056D94
	public static string ByteArrayToHexString(byte[] byte_0)
	{
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < byte_0.Length; i++)
		{
			stringBuilder.Append(byte_0[i].ToString(<Module>.DeserializeFromByteArray2<string>(2792172980U)));
		}
		return stringBuilder.ToString().ToUpper();
	}

	// Token: 0x060005E2 RID: 1506 RVA: 0x00058BE0 File Offset: 0x00056DE0
	public static string[] FindFilesByPattern(string string_4, string string_5, bool bool_0)
	{
		string[] result;
		try
		{
			result = Directory.GetFiles(string_4, string_5, (!bool_0) ? SearchOption.TopDirectoryOnly : SearchOption.AllDirectories);
		}
		catch
		{
			result = null;
		}
		return result;
	}

	// Token: 0x060005E3 RID: 1507 RVA: 0x00058C14 File Offset: 0x00056E14
	public static bool HasSpecialChars(string string_4)
	{
		if (string_4 == null)
		{
			return false;
		}
		foreach (char c in string_4)
		{
			if (c == Class15.Class16.char_0 || (c >= Class15.Class16.char_1 && c < Class15.Class16.char_2) || (c > Class15.Class16.char_3 && c < Class15.Class16.char_4))
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060005E4 RID: 1508 RVA: 0x00058C6C File Offset: 0x00056E6C
	public static long FileLineCount(string string_4)
	{
		FileStream fileStream = null;
		long num = 0L;
		try
		{
			try
			{
				fileStream = new FileStream(string_4, FileMode.Open, FileAccess.Read, FileShare.Read);
			}
			catch
			{
				fileStream = new FileStream(string_4, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			}
			using (StreamReader streamReader = new StreamReader(fileStream))
			{
				while (streamReader.ReadLine() != null)
				{
					num += 1L;
				}
			}
		}
		catch
		{
		}
		finally
		{
			if (fileStream != null)
			{
				fileStream.Close();
			}
		}
		return num;
	}

	// Token: 0x060005E5 RID: 1509 RVA: 0x00058D0C File Offset: 0x00056F0C
	public static string FileToString(string string_4)
	{
		FileStream fileStream = null;
		string result = string.Empty;
		try
		{
			try
			{
				fileStream = new FileStream(string_4, FileMode.Open, FileAccess.Read, FileShare.Read);
			}
			catch
			{
				fileStream = new FileStream(string_4, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			}
			using (StreamReader streamReader = new StreamReader(fileStream))
			{
				result = streamReader.ReadToEnd();
			}
		}
		finally
		{
			if (fileStream != null)
			{
				fileStream.Close();
			}
		}
		return result;
	}

	// Token: 0x060005E6 RID: 1510 RVA: 0x00058D88 File Offset: 0x00056F88
	public static bool IsStringPrintable(string string_4)
	{
		if (string_4 == null)
		{
			return false;
		}
		foreach (char c in string_4)
		{
			if (c < '\t' || ((c < '\t' || c > '\v') && (c < ' ' || c > '~')))
			{
				return false;
			}
		}
		return true;
	}

	// Token: 0x060005E7 RID: 1511 RVA: 0x00058DD4 File Offset: 0x00056FD4
	public static int SubstringOccurrencesCount(string string_4, string string_5)
	{
		int num = 0;
		try
		{
			int num2 = 0;
			while ((num2 = string_4.IndexOf(string_5, num2)) != -1)
			{
				num2 += string_5.Length;
				num++;
			}
		}
		catch
		{
		}
		return num;
	}

	// Token: 0x060005E8 RID: 1512 RVA: 0x00058E1C File Offset: 0x0005701C
	public static bool ValidateGuidString(string string_4)
	{
		if (string_4 == null)
		{
			return false;
		}
		try
		{
			new Guid(string_4);
			return true;
		}
		catch
		{
		}
		return false;
	}

	// Token: 0x060005E9 RID: 1513 RVA: 0x00058E50 File Offset: 0x00057050
	public static string SanitizeString(string string_4)
	{
		if (string_4 == null)
		{
			return string.Empty;
		}
		string_4 = string_4.Replace(Class15.char_0.ToString(), Class15.string_1);
		string_4 = string_4.Replace(Class15.char_1.ToString(), Class15.string_2);
		string_4 = string_4.Replace(Class15.char_2.ToString(), Class15.string_3);
		string_4 = string_4.Trim();
		return string_4;
	}

	// Token: 0x060005EA RID: 1514 RVA: 0x00058EC0 File Offset: 0x000570C0
	public static int SearchBytePattern(byte[] byte_0, byte[] byte_1, string string_4, int int_2 = 0, int int_3 = 0)
	{
		if (byte_0 != null && byte_1 != null && byte_1.Length == string_4.Length && string_4.Length != 0)
		{
			int result = -1;
			if (int_3 != 0)
			{
				int_3 -= byte_1.Length;
			}
			else
			{
				int_3 = byte_0.Length - byte_1.Length;
			}
			if (byte_0.Length != 0 && byte_1.Length != 0 && int_2 <= int_3 && byte_0.Length >= byte_1.Length)
			{
				if (string_4[0] == '\0')
				{
					throw new ArgumentException();
				}
				for (int i = int_2; i < int_3; i++)
				{
					if (byte_0[i] == byte_1[0])
					{
						if (byte_0.Length <= 1)
						{
							result = i;
							break;
						}
						bool flag = true;
						for (int j = 1; j < byte_1.Length; j++)
						{
							if (string_4[j] != '?')
							{
								if (byte_0[i + j] != byte_1[j])
								{
									flag = false;
									break;
								}
							}
						}
						if (flag)
						{
							result = i;
							break;
						}
					}
				}
			}
			return result;
		}
		throw new ArgumentNullException();
	}

	// Token: 0x060005EB RID: 1515 RVA: 0x00058F8C File Offset: 0x0005718C
	public static bool get_ip_address(string string_4)
	{
		IPAddress ipaddress = null;
		return !string.IsNullOrEmpty(string_4) && IPAddress.TryParse(string_4, out ipaddress);
	}

	// Token: 0x060005EC RID: 1516 RVA: 0x00058FB0 File Offset: 0x000571B0
	public static bool IsLongAboveLimit(long long_2)
	{
		return long_2 - Class15.long_1 > 0L;
	}

	// Token: 0x060005ED RID: 1517 RVA: 0x00058FD4 File Offset: 0x000571D4
	public static int ByteArrayComparison(byte[] byte_0, byte[] byte_1, int int_2, ref int int_3)
	{
		if (byte_0 != null && byte_1 != null && int_2 >= -1)
		{
			if (int_2 != 0)
			{
				if (int_2 > byte_0.Length || int_2 > byte_1.Length)
				{
					throw new Exception(<Module>.DeserializeFromByteArray<string>(2131492635U));
				}
			}
			else if (byte_0.Length <= byte_1.Length)
			{
				int_2 = byte_0.Length;
			}
			else
			{
				int_2 = byte_1.Length;
			}
			int_3 = int_2;
			for (int i = 0; i < int_2; i++)
			{
				if (byte_0[i] > byte_1[i])
				{
					int_3 = i;
					return 1;
				}
				if (byte_0[i] < byte_1[i])
				{
					int_3 = i;
					return -1;
				}
			}
			return 0;
		}
		throw new Exception(<Module>.DeserializeFromByteArrayV2<string>(3923777395U));
	}

	// Token: 0x060005EE RID: 1518 RVA: 0x00059058 File Offset: 0x00057258
	public static List<DirectoryInfo> DirectoryPathList(DirectoryInfo directoryInfo_0)
	{
		if (directoryInfo_0 == null)
		{
			return null;
		}
		List<DirectoryInfo> list = new List<DirectoryInfo>();
		DirectoryInfo directoryInfo = directoryInfo_0;
		while (directoryInfo.Name != directoryInfo.Root.Name)
		{
			list.Add(directoryInfo);
			directoryInfo = directoryInfo.Parent;
		}
		list.Add(directoryInfo.Root);
		list.Reverse();
		return list;
	}

	// Token: 0x060005EF RID: 1519 RVA: 0x000590B0 File Offset: 0x000572B0
	public static List<DirectoryInfo> DirectoryHierarchyFromPath(string string_4)
	{
		if (string_4 == null)
		{
			return null;
		}
		return Class15.DirectoryPathList(new DirectoryInfo(string_4));
	}

	// Token: 0x060005F0 RID: 1520 RVA: 0x000590D0 File Offset: 0x000572D0
	public static string[] GetFilesRecursivelyWithDepth(string string_4, string string_5, int int_2 = 1)
	{
		List<string> list = new List<string>();
		if (int_2 <= 0)
		{
			return list.ToArray();
		}
		try
		{
			string[] files = Directory.GetFiles(string_4, string_5, SearchOption.TopDirectoryOnly);
			list.AddRange(files);
			foreach (string string_6 in Directory.GetDirectories(string_4))
			{
				list.AddRange(Class15.GetFilesRecursivelyWithDepth(string_6, string_5, int_2 - 1));
			}
		}
		catch (UnauthorizedAccessException)
		{
		}
		return list.ToArray();
	}

	// Token: 0x060005F1 RID: 1521 RVA: 0x00059148 File Offset: 0x00057348
	public static bool StringExistsInList(List<string> list_0, string string_4, bool bool_0 = false)
	{
		if (list_0 != null && string_4 != null)
		{
			if (bool_0)
			{
				foreach (string b in list_0)
				{
					if (string_4 == b)
					{
						return true;
					}
				}
				return false;
			}
			string a = string_4.ToLowerInvariant();
			foreach (string text in list_0)
			{
				if (a == text.ToLowerInvariant())
				{
					return true;
				}
			}
			return false;
		}
		return false;
	}

	// Token: 0x04000937 RID: 2359
	public static readonly int int_0 = 60000;

	// Token: 0x04000938 RID: 2360
	public static readonly int int_1 = 256;

	// Token: 0x04000939 RID: 2361
	public static readonly string string_0 = <Module>.DeserializeFromByteArrayV2<string>(4168640658U);

	// Token: 0x0400093A RID: 2362
	public static readonly char char_0 = ';';

	// Token: 0x0400093B RID: 2363
	public static readonly string string_1 = <Module>.DeserealizeFromByteArrayV2_1<string>(2987750218U);

	// Token: 0x0400093C RID: 2364
	public static readonly char char_1 = '|';

	// Token: 0x0400093D RID: 2365
	public static readonly string string_2 = <Module>.DeserializeFromByteArray3<string>(797066973U);

	// Token: 0x0400093E RID: 2366
	public static readonly char char_2 = '!';

	// Token: 0x0400093F RID: 2367
	public static readonly string string_3 = <Module>.DeserializeFromByteArrayV2<string>(1582667244U);

	// Token: 0x04000940 RID: 2368
	public static readonly long long_0 = 76561197960265728L;

	// Token: 0x04000941 RID: 2369
	public static readonly long long_1 = 76561190000000000L;

	// Token: 0x020000B9 RID: 185
	public static class Class16
	{
		// Token: 0x04000942 RID: 2370
		public static char char_0 = '\0';

		// Token: 0x04000943 RID: 2371
		public static char char_1 = '\u0005';

		// Token: 0x04000944 RID: 2372
		public static char char_2 = '\b';

		// Token: 0x04000945 RID: 2373
		public static char char_3 = '\r';

		// Token: 0x04000946 RID: 2374
		public static char char_4 = '\u001a';
	}
}
