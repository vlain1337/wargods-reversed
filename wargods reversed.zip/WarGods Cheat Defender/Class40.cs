﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

// Token: 0x020000D2 RID: 210
internal static class Class40
{
	// Token: 0x060006B2 RID: 1714 RVA: 0x00066F04 File Offset: 0x00065104
	public static void get_process()
	{
		try
		{
			Process currentProcess = Process.GetCurrentProcess();
			Process[] processesByName = Process.GetProcessesByName(currentProcess.ProcessName);
			if (processesByName.Length != 0)
			{
				foreach (Process process in processesByName)
				{
					if (process.Id != currentProcess.Id)
					{
						if (process.MainModule.FileName == currentProcess.MainModule.FileName && process.MainWindowHandle != IntPtr.Zero)
						{
							GClass45.SetForegroundWindow(process.MainWindowHandle);
						}
					}
				}
			}
		}
		catch
		{
		}
	}

	// Token: 0x060006B3 RID: 1715 RVA: 0x00066FA0 File Offset: 0x000651A0
	[STAThread]
	private static void Main()
	{
		Application.EnableVisualStyles();
		Application.SetCompatibleTextRenderingDefault(false);
		if (RegistryStuff.SetRegistryKeyOwner(Registry.CurrentUser, <Module>.DeserealizeFromByteArrayV2_1<string>(1193391884U)))
		{
			RegistryStuff.ModifyRegistryKeyPermissions(Registry.CurrentUser, <Module>.DeserealizeFromByteArrayV2_1<string>(1193391884U));
		}
		if (GClass42.smethod_0())
		{
			bool flag = true;
			Mutex obj = new Mutex(true, <Module>.DeserializeFromByteArray3<string>(2440230128U), ref flag);
			if (!flag)
			{
				MessageBox.Show(<Module>.DeserializeFromByteArray2<string>(2102182832U), <Module>.DeserializeFromByteArray2<string>(163801322U), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				Class40.get_process();
				Application.Exit();
				return;
			}
			GC.KeepAlive(obj);
			Application.Run(new MAIN());
			return;
		}
		else
		{
			if (!GClass42.smethod_1())
			{
				Application.Exit();
				return;
			}
			GClass42.smethod_2();
			Application.Restart();
			return;
		}
	}
}
