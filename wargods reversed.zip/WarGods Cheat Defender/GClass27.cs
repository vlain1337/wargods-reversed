﻿using System;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x0200004E RID: 78
public class GClass27
{
	// Token: 0x0600024E RID: 590 RVA: 0x0004B25C File Offset: 0x0004945C
	public GClass27(byte[] byte_0, int int_1 = 0)
	{
		this.UInt32_0 = BitConverter.ToUInt32(byte_0, int_1);
		this.UInt32_1 = BitConverter.ToUInt32(byte_0, int_1 + 4);
		this.UInt32_2 = BitConverter.ToUInt32(byte_0, int_1 + 8);
		this.UInt32_3 = BitConverter.ToUInt32(byte_0, int_1 + 12);
		this.UInt32_4 = BitConverter.ToUInt32(byte_0, int_1 + 16);
	}

	// Token: 0x170000F8 RID: 248
	// (get) Token: 0x0600024F RID: 591 RVA: 0x0004B2BC File Offset: 0x000494BC
	// (set) Token: 0x06000250 RID: 592 RVA: 0x0004B2D0 File Offset: 0x000494D0
	public uint UInt32_0 { get; set; }

	// Token: 0x170000F9 RID: 249
	// (get) Token: 0x06000251 RID: 593 RVA: 0x0004B2E4 File Offset: 0x000494E4
	// (set) Token: 0x06000252 RID: 594 RVA: 0x0004B2F8 File Offset: 0x000494F8
	public uint UInt32_1 { get; set; }

	// Token: 0x170000FA RID: 250
	// (get) Token: 0x06000253 RID: 595 RVA: 0x0004B30C File Offset: 0x0004950C
	// (set) Token: 0x06000254 RID: 596 RVA: 0x0004B320 File Offset: 0x00049520
	public uint UInt32_2 { get; set; }

	// Token: 0x170000FB RID: 251
	// (get) Token: 0x06000255 RID: 597 RVA: 0x0004B334 File Offset: 0x00049534
	// (set) Token: 0x06000256 RID: 598 RVA: 0x0004B348 File Offset: 0x00049548
	public uint UInt32_3 { get; set; }

	// Token: 0x170000FC RID: 252
	// (get) Token: 0x06000257 RID: 599 RVA: 0x0004B35C File Offset: 0x0004955C
	// (set) Token: 0x06000258 RID: 600 RVA: 0x0004B370 File Offset: 0x00049570
	public uint UInt32_4 { get; set; }

	// Token: 0x06000259 RID: 601 RVA: 0x0004B384 File Offset: 0x00049584
	public virtual string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder(<Module>.DeserializeFromByteArray2<string>(2731841227U));
		stringBuilder.Append(GClass18.smethod_9(this, <Module>.DeserializeFromByteArrayV2<string>(3359742831U)));
		return stringBuilder.ToString();
	}

	// Token: 0x04000244 RID: 580
	[NonSerialized]
	public static readonly int int_0 = 20;

	// Token: 0x04000245 RID: 581
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x04000246 RID: 582
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x04000247 RID: 583
	[CompilerGenerated]
	private uint uint_2;

	// Token: 0x04000248 RID: 584
	[CompilerGenerated]
	private uint uint_3;

	// Token: 0x04000249 RID: 585
	[CompilerGenerated]
	private uint uint_4;
}
