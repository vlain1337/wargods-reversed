﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x020000B5 RID: 181
public class GClass54
{
	// Token: 0x170002CF RID: 719
	// (get) Token: 0x060005C4 RID: 1476 RVA: 0x0005825C File Offset: 0x0005645C
	// (set) Token: 0x060005C5 RID: 1477 RVA: 0x00058270 File Offset: 0x00056470
	public GStruct26 GStruct26_0 { get; private set; }

	// Token: 0x170002D0 RID: 720
	// (get) Token: 0x060005C6 RID: 1478 RVA: 0x00058284 File Offset: 0x00056484
	// (set) Token: 0x060005C7 RID: 1479 RVA: 0x00058298 File Offset: 0x00056498
	public List<long> List_0 { get; private set; }

	// Token: 0x060005C8 RID: 1480 RVA: 0x000582AC File Offset: 0x000564AC
	public GClass54(GStruct26 gstruct26_1)
	{
		this.GStruct26_0 = gstruct26_1;
		this.List_0 = new List<long>();
	}

	// Token: 0x170002D1 RID: 721
	// (get) Token: 0x060005C9 RID: 1481 RVA: 0x000582D4 File Offset: 0x000564D4
	public string String_0
	{
		get
		{
			string text = new string(this.GStruct26_0.char_0).Trim();
			int num = text.IndexOf('\0');
			if (num > -1)
			{
				text = text.Substring(0, num);
			}
			return text.Trim();
		}
	}

	// Token: 0x04000929 RID: 2345
	[CompilerGenerated]
	private GStruct26 gstruct26_0;

	// Token: 0x0400092A RID: 2346
	[CompilerGenerated]
	private List<long> list_0;
}
