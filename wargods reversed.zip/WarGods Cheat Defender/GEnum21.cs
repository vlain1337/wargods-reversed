﻿using System;

// Token: 0x0200006D RID: 109
public enum GEnum21 : uint
{
	// Token: 0x0400031E RID: 798
	const_0,
	// Token: 0x0400031F RID: 799
	const_1,
	// Token: 0x04000320 RID: 800
	const_2,
	// Token: 0x04000321 RID: 801
	const_3,
	// Token: 0x04000322 RID: 802
	const_4,
	// Token: 0x04000323 RID: 803
	const_5,
	// Token: 0x04000324 RID: 804
	const_6,
	// Token: 0x04000325 RID: 805
	const_7,
	// Token: 0x04000326 RID: 806
	const_8,
	// Token: 0x04000327 RID: 807
	const_9 = 24U,
	// Token: 0x04000328 RID: 808
	const_10,
	// Token: 0x04000329 RID: 809
	const_11,
	// Token: 0x0400032A RID: 810
	const_12,
	// Token: 0x0400032B RID: 811
	const_13 = 34U,
	// Token: 0x0400032C RID: 812
	const_14 = 36U,
	// Token: 0x0400032D RID: 813
	const_15,
	// Token: 0x0400032E RID: 814
	const_16,
	// Token: 0x0400032F RID: 815
	const_17,
	// Token: 0x04000330 RID: 816
	const_18 = 52U,
	// Token: 0x04000331 RID: 817
	const_19 = 54U,
	// Token: 0x04000332 RID: 818
	const_20 = 56U,
	// Token: 0x04000333 RID: 819
	const_21 = 100U,
	// Token: 0x04000334 RID: 820
	const_22 = 128U
}
