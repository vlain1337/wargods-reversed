﻿using System;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x02000050 RID: 80
public class GClass29
{
	// Token: 0x17000100 RID: 256
	// (get) Token: 0x06000265 RID: 613 RVA: 0x0004B54C File Offset: 0x0004974C
	// (set) Token: 0x06000266 RID: 614 RVA: 0x0004B560 File Offset: 0x00049760
	public GClass20[] GClass20_0 { get; private set; }

	// Token: 0x06000267 RID: 615 RVA: 0x0004B574 File Offset: 0x00049774
	public GClass29(byte[] byte_2, int int_0 = 0, bool bool_0 = false)
	{
		this.UInt16_0 = BitConverter.ToUInt16(byte_2, int_0);
		this.Byte_0 = byte_2[int_0 + 2];
		this.Byte_1 = byte_2[int_0 + 3];
		this.UInt32_0 = BitConverter.ToUInt32(byte_2, int_0 + 4);
		this.UInt32_1 = BitConverter.ToUInt32(byte_2, int_0 + 8);
		this.UInt32_2 = BitConverter.ToUInt32(byte_2, int_0 + 12);
		this.UInt32_3 = BitConverter.ToUInt32(byte_2, int_0 + 16);
		this.UInt32_4 = BitConverter.ToUInt32(byte_2, int_0 + 20);
		this.UInt32_5 = (bool_0 ? 0U : BitConverter.ToUInt32(byte_2, int_0 + 24));
		if (bool_0)
		{
			this.UInt64_0 = (ulong)((long)int_0 + 24L);
		}
		else
		{
			this.UInt64_0 = (ulong)((long)int_0 + 28L);
		}
		this.UInt64_1 = (bool_0 ? BitConverter.ToUInt64(byte_2, int_0 + 24) : ((ulong)BitConverter.ToUInt32(byte_2, int_0 + 28)));
		this.UInt32_6 = BitConverter.ToUInt32(byte_2, int_0 + 32);
		this.UInt32_7 = BitConverter.ToUInt32(byte_2, int_0 + 36);
		this.UInt16_1 = BitConverter.ToUInt16(byte_2, int_0 + 40);
		this.UInt16_2 = BitConverter.ToUInt16(byte_2, int_0 + 42);
		this.UInt16_3 = BitConverter.ToUInt16(byte_2, int_0 + 44);
		this.UInt16_4 = BitConverter.ToUInt16(byte_2, int_0 + 46);
		this.UInt16_5 = BitConverter.ToUInt16(byte_2, int_0 + 48);
		this.UInt16_6 = BitConverter.ToUInt16(byte_2, int_0 + 50);
		this.UInt32_8 = BitConverter.ToUInt32(byte_2, int_0 + 52);
		this.UInt32_9 = BitConverter.ToUInt32(byte_2, int_0 + 56);
		this.UInt32_10 = BitConverter.ToUInt32(byte_2, int_0 + 60);
		this.UInt32_11 = BitConverter.ToUInt32(byte_2, int_0 + 64);
		this.UInt16_7 = BitConverter.ToUInt16(byte_2, int_0 + 68);
		this.UInt16_8 = BitConverter.ToUInt16(byte_2, int_0 + 70);
		this.UInt64_2 = (bool_0 ? BitConverter.ToUInt64(byte_2, int_0 + 72) : ((ulong)BitConverter.ToUInt32(byte_2, int_0 + 72)));
		this.UInt64_3 = (bool_0 ? BitConverter.ToUInt64(byte_2, int_0 + 80) : ((ulong)BitConverter.ToUInt32(byte_2, int_0 + 76)));
		this.UInt64_4 = (bool_0 ? BitConverter.ToUInt64(byte_2, int_0 + 88) : ((ulong)BitConverter.ToUInt32(byte_2, int_0 + 80)));
		this.UInt64_5 = (bool_0 ? BitConverter.ToUInt64(byte_2, int_0 + 96) : ((ulong)BitConverter.ToUInt32(byte_2, int_0 + 84)));
		this.UInt32_12 = (bool_0 ? BitConverter.ToUInt32(byte_2, int_0 + 104) : BitConverter.ToUInt32(byte_2, int_0 + 88));
		this.UInt32_13 = (bool_0 ? BitConverter.ToUInt32(byte_2, int_0 + 108) : BitConverter.ToUInt32(byte_2, int_0 + 92));
		this.GClass20_0 = new GClass20[16];
		for (uint num = 0U; num < 16U; num += 1U)
		{
			if (!bool_0)
			{
				this.GClass20_0[(int)num] = new GClass20(byte_2, (int)((long)(int_0 + 96) + (long)((ulong)(num * 8U))));
			}
			else
			{
				this.GClass20_0[(int)num] = new GClass20(byte_2, (int)((long)(int_0 + 112) + (long)((ulong)(num * 8U))));
			}
		}
	}

	// Token: 0x17000101 RID: 257
	// (get) Token: 0x06000268 RID: 616 RVA: 0x0004B848 File Offset: 0x00049A48
	// (set) Token: 0x06000269 RID: 617 RVA: 0x0004B85C File Offset: 0x00049A5C
	public ushort UInt16_0 { get; private set; }

	// Token: 0x17000102 RID: 258
	// (get) Token: 0x0600026A RID: 618 RVA: 0x0004B870 File Offset: 0x00049A70
	// (set) Token: 0x0600026B RID: 619 RVA: 0x0004B884 File Offset: 0x00049A84
	public byte Byte_0 { get; private set; }

	// Token: 0x17000103 RID: 259
	// (get) Token: 0x0600026C RID: 620 RVA: 0x0004B898 File Offset: 0x00049A98
	// (set) Token: 0x0600026D RID: 621 RVA: 0x0004B8AC File Offset: 0x00049AAC
	public byte Byte_1 { get; private set; }

	// Token: 0x17000104 RID: 260
	// (get) Token: 0x0600026E RID: 622 RVA: 0x0004B8C0 File Offset: 0x00049AC0
	// (set) Token: 0x0600026F RID: 623 RVA: 0x0004B8D4 File Offset: 0x00049AD4
	public uint UInt32_0 { get; private set; }

	// Token: 0x17000105 RID: 261
	// (get) Token: 0x06000270 RID: 624 RVA: 0x0004B8E8 File Offset: 0x00049AE8
	// (set) Token: 0x06000271 RID: 625 RVA: 0x0004B8FC File Offset: 0x00049AFC
	public uint UInt32_1 { get; private set; }

	// Token: 0x17000106 RID: 262
	// (get) Token: 0x06000272 RID: 626 RVA: 0x0004B910 File Offset: 0x00049B10
	// (set) Token: 0x06000273 RID: 627 RVA: 0x0004B924 File Offset: 0x00049B24
	public uint UInt32_2 { get; private set; }

	// Token: 0x17000107 RID: 263
	// (get) Token: 0x06000274 RID: 628 RVA: 0x0004B938 File Offset: 0x00049B38
	// (set) Token: 0x06000275 RID: 629 RVA: 0x0004B94C File Offset: 0x00049B4C
	public uint UInt32_3 { get; private set; }

	// Token: 0x17000108 RID: 264
	// (get) Token: 0x06000276 RID: 630 RVA: 0x0004B960 File Offset: 0x00049B60
	// (set) Token: 0x06000277 RID: 631 RVA: 0x0004B974 File Offset: 0x00049B74
	public uint UInt32_4 { get; private set; }

	// Token: 0x17000109 RID: 265
	// (get) Token: 0x06000278 RID: 632 RVA: 0x0004B988 File Offset: 0x00049B88
	// (set) Token: 0x06000279 RID: 633 RVA: 0x0004B99C File Offset: 0x00049B9C
	public uint UInt32_5 { get; private set; }

	// Token: 0x1700010A RID: 266
	// (get) Token: 0x0600027A RID: 634 RVA: 0x0004B9B0 File Offset: 0x00049BB0
	// (set) Token: 0x0600027B RID: 635 RVA: 0x0004B9C4 File Offset: 0x00049BC4
	public ulong UInt64_0 { get; set; }

	// Token: 0x1700010B RID: 267
	// (get) Token: 0x0600027C RID: 636 RVA: 0x0004B9D8 File Offset: 0x00049BD8
	// (set) Token: 0x0600027D RID: 637 RVA: 0x0004B9EC File Offset: 0x00049BEC
	public ulong UInt64_1 { get; private set; }

	// Token: 0x1700010C RID: 268
	// (get) Token: 0x0600027E RID: 638 RVA: 0x0004BA00 File Offset: 0x00049C00
	// (set) Token: 0x0600027F RID: 639 RVA: 0x0004BA14 File Offset: 0x00049C14
	public uint UInt32_6 { get; private set; }

	// Token: 0x1700010D RID: 269
	// (get) Token: 0x06000280 RID: 640 RVA: 0x0004BA28 File Offset: 0x00049C28
	// (set) Token: 0x06000281 RID: 641 RVA: 0x0004BA3C File Offset: 0x00049C3C
	public uint UInt32_7 { get; private set; }

	// Token: 0x1700010E RID: 270
	// (get) Token: 0x06000282 RID: 642 RVA: 0x0004BA50 File Offset: 0x00049C50
	// (set) Token: 0x06000283 RID: 643 RVA: 0x0004BA64 File Offset: 0x00049C64
	public ushort UInt16_1 { get; private set; }

	// Token: 0x1700010F RID: 271
	// (get) Token: 0x06000284 RID: 644 RVA: 0x0004BA78 File Offset: 0x00049C78
	// (set) Token: 0x06000285 RID: 645 RVA: 0x0004BA8C File Offset: 0x00049C8C
	public ushort UInt16_2 { get; private set; }

	// Token: 0x17000110 RID: 272
	// (get) Token: 0x06000286 RID: 646 RVA: 0x0004BAA0 File Offset: 0x00049CA0
	// (set) Token: 0x06000287 RID: 647 RVA: 0x0004BAB4 File Offset: 0x00049CB4
	public ushort UInt16_3 { get; private set; }

	// Token: 0x17000111 RID: 273
	// (get) Token: 0x06000288 RID: 648 RVA: 0x0004BAC8 File Offset: 0x00049CC8
	// (set) Token: 0x06000289 RID: 649 RVA: 0x0004BADC File Offset: 0x00049CDC
	public ushort UInt16_4 { get; private set; }

	// Token: 0x17000112 RID: 274
	// (get) Token: 0x0600028A RID: 650 RVA: 0x0004BAF0 File Offset: 0x00049CF0
	// (set) Token: 0x0600028B RID: 651 RVA: 0x0004BB04 File Offset: 0x00049D04
	public ushort UInt16_5 { get; private set; }

	// Token: 0x17000113 RID: 275
	// (get) Token: 0x0600028C RID: 652 RVA: 0x0004BB18 File Offset: 0x00049D18
	// (set) Token: 0x0600028D RID: 653 RVA: 0x0004BB2C File Offset: 0x00049D2C
	public ushort UInt16_6 { get; private set; }

	// Token: 0x17000114 RID: 276
	// (get) Token: 0x0600028E RID: 654 RVA: 0x0004BB40 File Offset: 0x00049D40
	// (set) Token: 0x0600028F RID: 655 RVA: 0x0004BB54 File Offset: 0x00049D54
	public uint UInt32_8 { get; private set; }

	// Token: 0x17000115 RID: 277
	// (get) Token: 0x06000290 RID: 656 RVA: 0x0004BB68 File Offset: 0x00049D68
	// (set) Token: 0x06000291 RID: 657 RVA: 0x0004BB7C File Offset: 0x00049D7C
	public uint UInt32_9 { get; private set; }

	// Token: 0x17000116 RID: 278
	// (get) Token: 0x06000292 RID: 658 RVA: 0x0004BB90 File Offset: 0x00049D90
	// (set) Token: 0x06000293 RID: 659 RVA: 0x0004BBA4 File Offset: 0x00049DA4
	public uint UInt32_10 { get; private set; }

	// Token: 0x17000117 RID: 279
	// (get) Token: 0x06000294 RID: 660 RVA: 0x0004BBB8 File Offset: 0x00049DB8
	// (set) Token: 0x06000295 RID: 661 RVA: 0x0004BBCC File Offset: 0x00049DCC
	public uint UInt32_11 { get; private set; }

	// Token: 0x17000118 RID: 280
	// (get) Token: 0x06000296 RID: 662 RVA: 0x0004BBE0 File Offset: 0x00049DE0
	// (set) Token: 0x06000297 RID: 663 RVA: 0x0004BBF4 File Offset: 0x00049DF4
	public ushort UInt16_7 { get; private set; }

	// Token: 0x17000119 RID: 281
	// (get) Token: 0x06000298 RID: 664 RVA: 0x0004BC08 File Offset: 0x00049E08
	// (set) Token: 0x06000299 RID: 665 RVA: 0x0004BC1C File Offset: 0x00049E1C
	public ushort UInt16_8 { get; private set; }

	// Token: 0x1700011A RID: 282
	// (get) Token: 0x0600029A RID: 666 RVA: 0x0004BC30 File Offset: 0x00049E30
	// (set) Token: 0x0600029B RID: 667 RVA: 0x0004BC44 File Offset: 0x00049E44
	public ulong UInt64_2 { get; private set; }

	// Token: 0x1700011B RID: 283
	// (get) Token: 0x0600029C RID: 668 RVA: 0x0004BC58 File Offset: 0x00049E58
	// (set) Token: 0x0600029D RID: 669 RVA: 0x0004BC6C File Offset: 0x00049E6C
	public ulong UInt64_3 { get; private set; }

	// Token: 0x1700011C RID: 284
	// (get) Token: 0x0600029E RID: 670 RVA: 0x0004BC80 File Offset: 0x00049E80
	// (set) Token: 0x0600029F RID: 671 RVA: 0x0004BC94 File Offset: 0x00049E94
	public ulong UInt64_4 { get; private set; }

	// Token: 0x1700011D RID: 285
	// (get) Token: 0x060002A0 RID: 672 RVA: 0x0004BCA8 File Offset: 0x00049EA8
	// (set) Token: 0x060002A1 RID: 673 RVA: 0x0004BCBC File Offset: 0x00049EBC
	public ulong UInt64_5 { get; private set; }

	// Token: 0x1700011E RID: 286
	// (get) Token: 0x060002A2 RID: 674 RVA: 0x0004BCD0 File Offset: 0x00049ED0
	// (set) Token: 0x060002A3 RID: 675 RVA: 0x0004BCE4 File Offset: 0x00049EE4
	public uint UInt32_12 { get; private set; }

	// Token: 0x1700011F RID: 287
	// (get) Token: 0x060002A4 RID: 676 RVA: 0x0004BCF8 File Offset: 0x00049EF8
	// (set) Token: 0x060002A5 RID: 677 RVA: 0x0004BD0C File Offset: 0x00049F0C
	public uint UInt32_13 { get; private set; }

	// Token: 0x060002A6 RID: 678 RVA: 0x0004BD20 File Offset: 0x00049F20
	public virtual string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder(<Module>.DeserializeFromByteArray<string>(1059066073U));
		stringBuilder.Append(GClass18.smethod_9(this, <Module>.DeserealizeFromByteArrayV2_1<string>(1336008781U)));
		foreach (GClass20 value in this.GClass20_0)
		{
			stringBuilder.Append(value);
		}
		return stringBuilder.ToString();
	}

	// Token: 0x0400024F RID: 591
	[NonSerialized]
	public static readonly uint uint_0 = 96U + 16U * GClass20.uint_0;

	// Token: 0x04000250 RID: 592
	[NonSerialized]
	public static readonly uint uint_1 = 112U + 16U * GClass20.uint_0;

	// Token: 0x04000251 RID: 593
	[CompilerGenerated]
	private GClass20[] gclass20_0;

	// Token: 0x04000252 RID: 594
	[CompilerGenerated]
	private ushort ushort_0;

	// Token: 0x04000253 RID: 595
	[CompilerGenerated]
	private byte byte_0;

	// Token: 0x04000254 RID: 596
	[CompilerGenerated]
	private byte byte_1;

	// Token: 0x04000255 RID: 597
	[CompilerGenerated]
	private uint uint_2;

	// Token: 0x04000256 RID: 598
	[CompilerGenerated]
	private uint uint_3;

	// Token: 0x04000257 RID: 599
	[CompilerGenerated]
	private uint uint_4;

	// Token: 0x04000258 RID: 600
	[CompilerGenerated]
	private uint uint_5;

	// Token: 0x04000259 RID: 601
	[CompilerGenerated]
	private uint uint_6;

	// Token: 0x0400025A RID: 602
	[CompilerGenerated]
	private uint uint_7;

	// Token: 0x0400025B RID: 603
	[CompilerGenerated]
	private ulong ulong_0;

	// Token: 0x0400025C RID: 604
	[CompilerGenerated]
	private ulong ulong_1;

	// Token: 0x0400025D RID: 605
	[CompilerGenerated]
	private uint uint_8;

	// Token: 0x0400025E RID: 606
	[CompilerGenerated]
	private uint uint_9;

	// Token: 0x0400025F RID: 607
	[CompilerGenerated]
	private ushort ushort_1;

	// Token: 0x04000260 RID: 608
	[CompilerGenerated]
	private ushort ushort_2;

	// Token: 0x04000261 RID: 609
	[CompilerGenerated]
	private ushort ushort_3;

	// Token: 0x04000262 RID: 610
	[CompilerGenerated]
	private ushort ushort_4;

	// Token: 0x04000263 RID: 611
	[CompilerGenerated]
	private ushort ushort_5;

	// Token: 0x04000264 RID: 612
	[CompilerGenerated]
	private ushort ushort_6;

	// Token: 0x04000265 RID: 613
	[CompilerGenerated]
	private uint uint_10;

	// Token: 0x04000266 RID: 614
	[CompilerGenerated]
	private uint uint_11;

	// Token: 0x04000267 RID: 615
	[CompilerGenerated]
	private uint uint_12;

	// Token: 0x04000268 RID: 616
	[CompilerGenerated]
	private uint uint_13;

	// Token: 0x04000269 RID: 617
	[CompilerGenerated]
	private ushort ushort_7;

	// Token: 0x0400026A RID: 618
	[CompilerGenerated]
	private ushort ushort_8;

	// Token: 0x0400026B RID: 619
	[CompilerGenerated]
	private ulong ulong_2;

	// Token: 0x0400026C RID: 620
	[CompilerGenerated]
	private ulong ulong_3;

	// Token: 0x0400026D RID: 621
	[CompilerGenerated]
	private ulong ulong_4;

	// Token: 0x0400026E RID: 622
	[CompilerGenerated]
	private ulong ulong_5;

	// Token: 0x0400026F RID: 623
	[CompilerGenerated]
	private uint uint_14;

	// Token: 0x04000270 RID: 624
	[CompilerGenerated]
	private uint uint_15;
}
