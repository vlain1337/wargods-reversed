﻿using System;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x0200006A RID: 106
internal class Class12
{
	// Token: 0x1700014E RID: 334
	// (get) Token: 0x06000344 RID: 836 RVA: 0x0004E370 File Offset: 0x0004C570
	public static string String_0
	{
		get
		{
			return <Module>.DeserializeFromByteArrayV2<string>(1285978534U);
		}
	}

	// Token: 0x1700014F RID: 335
	// (get) Token: 0x06000345 RID: 837 RVA: 0x0004E388 File Offset: 0x0004C588
	// (set) Token: 0x06000346 RID: 838 RVA: 0x0004E39C File Offset: 0x0004C59C
	public static bool Boolean_0 { get; set; }

	// Token: 0x17000150 RID: 336
	// (get) Token: 0x06000347 RID: 839 RVA: 0x0004E3B0 File Offset: 0x0004C5B0
	public static string String_1
	{
		get
		{
			return <Module>.DeserealizeFromByteArrayV2_1<string>(3063311602U);
		}
	}

	// Token: 0x17000151 RID: 337
	// (get) Token: 0x06000348 RID: 840 RVA: 0x0004E3C8 File Offset: 0x0004C5C8
	public static string String_2
	{
		get
		{
			return <Module>.DeserializeFromByteArrayV2<string>(3864457751U);
		}
	}

	// Token: 0x17000152 RID: 338
	// (get) Token: 0x06000349 RID: 841 RVA: 0x0004E3E0 File Offset: 0x0004C5E0
	public static string String_3
	{
		get
		{
			return <Module>.DeserializeFromByteArray3<string>(3201815150U);
		}
	}

	// Token: 0x0600034A RID: 842 RVA: 0x0004E3F8 File Offset: 0x0004C5F8
	public static string smethod_0(bool bool_1)
	{
		return (bool_1 ? Class12.String_1 : Class12.String_2) + <Module>.DeserializeFromByteArrayV2<string>(3009960810U) + Class12.String_3;
	}

	// Token: 0x0600034B RID: 843 RVA: 0x0004E428 File Offset: 0x0004C628
	public static string smethod_1(bool bool_1)
	{
		return Class12.smethod_0(bool_1) + <Module>.DeserializeFromByteArray<string>(1807280496U) + Class12.String_0;
	}

	// Token: 0x0600034C RID: 844 RVA: 0x0004E450 File Offset: 0x0004C650
	public static string smethod_2(bool bool_1, string string_0)
	{
		return Class12.smethod_1(bool_1) + <Module>.DeserializeFromByteArray2<string>(1803848753U) + string_0;
	}

	// Token: 0x0600034D RID: 845 RVA: 0x0004E474 File Offset: 0x0004C674
	public static string smethod_3(bool bool_1, long long_0)
	{
		return Class12.smethod_1(bool_1) + <Module>.DeserializeFromByteArray3<string>(480189560U) + long_0.ToString();
	}

	// Token: 0x17000153 RID: 339
	// (get) Token: 0x0600034E RID: 846 RVA: 0x0004E4A0 File Offset: 0x0004C6A0
	public static string String_4
	{
		get
		{
			return Application.ProductVersion;
		}
	}

	// Token: 0x17000154 RID: 340
	// (get) Token: 0x0600034F RID: 847 RVA: 0x0004E4B4 File Offset: 0x0004C6B4
	public static string String_5
	{
		get
		{
			string result = "";
			try
			{
				result = string.Format(<Module>.DeserializeFromByteArrayV2<string>(2430303920U), Application.ProductVersion, Environment.OSVersion);
			}
			catch
			{
				result = string.Format(<Module>.DeserializeFromByteArrayV2<string>(3879446145U), Application.ProductVersion);
			}
			return result;
		}
	}

	// Token: 0x0400030B RID: 779
	[CompilerGenerated]
	private static bool bool_0;
}
