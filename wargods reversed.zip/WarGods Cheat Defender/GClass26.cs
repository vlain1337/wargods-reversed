﻿using System;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x0200004D RID: 77
public class GClass26
{
	// Token: 0x06000248 RID: 584 RVA: 0x0004B19C File Offset: 0x0004939C
	public GClass26(byte[] byte_0, ulong ulong_0 = 0UL)
	{
		this.UInt16_0 = BitConverter.ToUInt16(byte_0, (int)ulong_0);
		this.String_0 = GClass18.smethod_12(ulong_0 + 2UL, byte_0);
	}

	// Token: 0x170000F6 RID: 246
	// (get) Token: 0x06000249 RID: 585 RVA: 0x0004B1D4 File Offset: 0x000493D4
	// (set) Token: 0x0600024A RID: 586 RVA: 0x0004B1E8 File Offset: 0x000493E8
	public ushort UInt16_0 { get; set; }

	// Token: 0x170000F7 RID: 247
	// (get) Token: 0x0600024B RID: 587 RVA: 0x0004B1FC File Offset: 0x000493FC
	// (set) Token: 0x0600024C RID: 588 RVA: 0x0004B210 File Offset: 0x00049410
	public string String_0 { get; set; }

	// Token: 0x0600024D RID: 589 RVA: 0x0004B224 File Offset: 0x00049424
	public virtual string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder(<Module>.DeserealizeFromByteArrayV2_1<string>(1988449457U));
		stringBuilder.Append(GClass18.smethod_9(this, <Module>.DeserializeFromByteArray<string>(4133658422U)));
		return stringBuilder.ToString();
	}

	// Token: 0x04000242 RID: 578
	[CompilerGenerated]
	private ushort ushort_0;

	// Token: 0x04000243 RID: 579
	[CompilerGenerated]
	private string string_0;
}
