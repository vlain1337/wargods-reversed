﻿using System;
using System.Windows.Forms;
using Microsoft.Win32;

// Token: 0x0200006F RID: 111
public class GClass42
{
	// Token: 0x0600037A RID: 890 RVA: 0x0004F03C File Offset: 0x0004D23C
	public static bool smethod_0()
	{
		uint num = 0U;
		if (!RegistryStuff.RetrieveRegistryKeyValue(Registry.CurrentUser, <Module>.DeserializeFromByteArrayV2<string>(3569104898U), <Module>.DeserializeFromByteArray<string>(330038174U), out num))
		{
			num = 0U;
		}
		return num == GClass42.uint_0;
	}

	// Token: 0x0600037B RID: 891 RVA: 0x0004F078 File Offset: 0x0004D278
	public static bool smethod_1()
	{
		string caption = <Module>.DeserializeFromByteArray3<string>(3024085575U);
		return MessageBox.Show(<Module>.DeserializeFromByteArray<string>(1811794368U) + <Module>.DeserializeFromByteArray2<string>(3967644818U) + <Module>.DeserealizeFromByteArrayV2_1<string>(2624567923U) + <Module>.DeserializeFromByteArray2<string>(2160562564U) + <Module>.DeserializeFromByteArray2<string>(1012797645U) + <Module>.DeserializeFromByteArray2<string>(2920651181U) + <Module>.DeserializeFromByteArray2<string>(1650774366U) + <Module>.DeserealizeFromByteArrayV2_1<string>(993466233U) + Class12.smethod_1(true) + <Module>.DeserializeFromByteArray3<string>(511825320U), caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;
	}

	// Token: 0x0600037C RID: 892 RVA: 0x0004F124 File Offset: 0x0004D324
	public static void smethod_2()
	{
		RegistryStuff.SetRegistryKeyValueDWORD(Registry.CurrentUser, <Module>.DeserializeFromByteArray3<string>(2116877045U), <Module>.DeserializeFromByteArray3<string>(4153338497U), GClass42.uint_0, true);
	}

	// Token: 0x04000360 RID: 864
	public static readonly uint uint_0 = 4U;
}
