﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020000D8 RID: 216
internal class Class41
{
	// Token: 0x170002EA RID: 746
	// (get) Token: 0x060006D3 RID: 1747 RVA: 0x00067668 File Offset: 0x00065868
	// (set) Token: 0x060006D4 RID: 1748 RVA: 0x0006767C File Offset: 0x0006587C
	public uint UInt32_0 { get; private set; }

	// Token: 0x170002EB RID: 747
	// (get) Token: 0x060006D5 RID: 1749 RVA: 0x00067690 File Offset: 0x00065890
	// (set) Token: 0x060006D6 RID: 1750 RVA: 0x000676A4 File Offset: 0x000658A4
	public uint UInt32_1 { get; private set; }

	// Token: 0x170002EC RID: 748
	// (get) Token: 0x060006D7 RID: 1751 RVA: 0x000676B8 File Offset: 0x000658B8
	// (set) Token: 0x060006D8 RID: 1752 RVA: 0x000676CC File Offset: 0x000658CC
	public long Int64_0 { get; private set; }

	// Token: 0x060006D9 RID: 1753 RVA: 0x000676E0 File Offset: 0x000658E0
	public Class41(byte[] byte_0)
	{
		if (byte_0 == null)
		{
			throw new ArgumentNullException();
		}
		if ((long)byte_0.Length != (long)((ulong)Class41.uint_0))
		{
			throw new ArgumentOutOfRangeException();
		}
		this.UInt32_0 = BitConverter.ToUInt32(byte_0, 0);
		this.UInt32_1 = BitConverter.ToUInt32(byte_0, 4);
		this.Int64_0 = BitConverter.ToInt64(byte_0, 8);
	}

	// Token: 0x040009AC RID: 2476
	public static readonly uint uint_0 = 16U;

	// Token: 0x040009AD RID: 2477
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x040009AE RID: 2478
	[CompilerGenerated]
	private uint uint_2;

	// Token: 0x040009AF RID: 2479
	[CompilerGenerated]
	private long long_0;
}
