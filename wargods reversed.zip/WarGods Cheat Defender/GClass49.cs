﻿using System;
using System.Diagnostics;
using System.IO;
using System.Management;
using System.Runtime.InteropServices;
using System.Text;

// Token: 0x020000A7 RID: 167
public class GClass49
{
	// Token: 0x0600040A RID: 1034 RVA: 0x000514D8 File Offset: 0x0004F6D8
	public static IntPtr GetThreadEntryPoint(uint uint_0)
	{
		IntPtr result = IntPtr.Zero;
		IntPtr intPtr = IntPtr.Zero;
		IntPtr intPtr2 = GClass45.OpenThread(64U, false, uint_0);
		if (!(intPtr2 == IntPtr.Zero))
		{
			try
			{
				intPtr = Marshal.AllocHGlobal(IntPtr.Size);
				if (GClass45.ZwQueryInformationThread(intPtr2, GClass45.GEnum33.const_0, intPtr, IntPtr.Size, IntPtr.Zero) == 0)
				{
					result = Marshal.ReadIntPtr(intPtr);
				}
			}
			catch
			{
			}
			finally
			{
				if (intPtr != IntPtr.Zero)
				{
					Marshal.FreeHGlobal(intPtr);
				}
			}
			GClass45.CloseHandle(intPtr2);
			return result;
		}
		return result;
	}

	// Token: 0x0600040B RID: 1035 RVA: 0x00051570 File Offset: 0x0004F770
	public static string GetModuleByAddress(Process process_0, IntPtr intptr_0)
	{
		if (process_0 != null && !(intptr_0 == IntPtr.Zero))
		{
			ProcessModuleCollection modules = process_0.Modules;
			for (int i = 0; i < modules.Count; i++)
			{
				if (modules[i].BaseAddress.ToInt64() <= intptr_0.ToInt64() && modules[i].BaseAddress.ToInt64() + (long)modules[i].ModuleMemorySize > intptr_0.ToInt64())
				{
					return modules[i].ModuleName;
				}
			}
			return null;
		}
		return null;
	}

	// Token: 0x0600040C RID: 1036
	public static string CouldNotBeDecompiled(DealWithItLULZ)(Process process_0, IntPtr intptr_0)
	{
		/*
An exception occurred when decompiling this method (0600040C)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.String GClass49::CouldNotBeDecompiled(DealWithItLULZ)(System.Diagnostics.Process,System.IntPtr)

 ---> System.Exception: Inconsistent stack size at IL_6C
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 443
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 271
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600040D RID: 1037 RVA: 0x000516B4 File Offset: 0x0004F8B4
	public static ProcessModule GetModuleByName(Process process_0, string string_0)
	{
		if (process_0 != null && string_0 != null)
		{
			ProcessModuleCollection modules = process_0.Modules;
			for (int i = 0; i < modules.Count; i++)
			{
				if (modules[i].ModuleName.ToLower() == string_0)
				{
					return modules[i];
				}
			}
			return null;
		}
		return null;
	}

	// Token: 0x0600040E RID: 1038 RVA: 0x00051708 File Offset: 0x0004F908
	public static IntPtr ResolveModuleBaseAddress(Process process_0, string string_0)
	{
		ProcessModule moduleByName = GClass49.GetModuleByName(process_0, string_0);
		if (moduleByName != null)
		{
			return moduleByName.BaseAddress;
		}
		return IntPtr.Zero;
	}

	// Token: 0x0600040F RID: 1039 RVA: 0x0005172C File Offset: 0x0004F92C
	public static ProcessModule FindProcessModule(Process process_0, string string_0, string string_1, GClass49.GEnum43 genum43_0 = GClass49.GEnum43.const_0)
	{
		if (process_0 != null && string_0 != null)
		{
			ProcessModuleCollection modules = process_0.Modules;
			string b = string_0.ToLower();
			string text = null;
			if (string_1 != null)
			{
				text = string_1.ToLower();
			}
			for (int i = 0; i < modules.Count; i++)
			{
				if (modules[i].ModuleName.ToLower() == b)
				{
					if (text == null)
					{
						return modules[i];
					}
					switch (genum43_0)
					{
					case GClass49.GEnum43.const_0:
						if (modules[i].FileName.ToLower() == text)
						{
							return modules[i];
						}
						break;
					case GClass49.GEnum43.const_1:
						if (modules[i].FileName.ToLower().Contains(text))
						{
							return modules[i];
						}
						break;
					case GClass49.GEnum43.const_2:
						if (modules[i].FileName.ToLower().StartsWith(text))
						{
							return modules[i];
						}
						break;
					case GClass49.GEnum43.const_3:
						if (modules[i].FileName.ToLower().EndsWith(text))
						{
							return modules[i];
						}
						break;
					}
				}
			}
			return null;
		}
		return null;
	}

	// Token: 0x06000410 RID: 1040 RVA: 0x00051848 File Offset: 0x0004FA48
	public static IntPtr GetModuleBaseAddressByName(Process process_0, string string_0)
	{
		if (process_0 != null && string_0 != null)
		{
			ProcessModuleCollection modules = process_0.Modules;
			for (int i = 0; i < modules.Count; i++)
			{
				if (modules[i].ModuleName == string_0)
				{
					return modules[i].BaseAddress;
				}
			}
			return IntPtr.Zero;
		}
		return IntPtr.Zero;
	}

	// Token: 0x06000411 RID: 1041 RVA: 0x000518A4 File Offset: 0x0004FAA4
	public static bool ModuleExistsAtAddress(Process process_0, IntPtr intptr_0)
	{
		return GClass49.GetModuleBaseAddress(process_0, intptr_0) != IntPtr.Zero;
	}

	// Token: 0x06000412 RID: 1042 RVA: 0x000518C4 File Offset: 0x0004FAC4
	public static IntPtr GetModuleBaseAddress(Process process_0, IntPtr intptr_0)
	{
		if (process_0 != null && !(intptr_0 == IntPtr.Zero))
		{
			ProcessModuleCollection modules = process_0.Modules;
			for (int i = 0; i < modules.Count; i++)
			{
				if (modules[i].BaseAddress.ToInt64() <= intptr_0.ToInt64() && modules[i].BaseAddress.ToInt64() + (long)modules[i].ModuleMemorySize > intptr_0.ToInt64())
				{
					return modules[i].BaseAddress;
				}
			}
			return IntPtr.Zero;
		}
		return IntPtr.Zero;
	}

	// Token: 0x06000413 RID: 1043 RVA: 0x0005195C File Offset: 0x0004FB5C
	public static bool CanExecuteCodeInMemory(GClass45.GStruct4 gstruct4_0)
	{
		return gstruct4_0.uint_1 == 4096U && ((gstruct4_0.uint_2 & 1U) == 0U && (gstruct4_0.uint_2 & 256U) == 0U && (gstruct4_0.uint_2 & 1024U) == 0U && gstruct4_0.uint_2 != 0U);
	}

	// Token: 0x06000414 RID: 1044 RVA: 0x000519AC File Offset: 0x0004FBAC
	public static bool IsMemoryRegionExecutable(Process process_0, IntPtr intptr_0)
	{
		if (process_0 == null)
		{
			return false;
		}
		GClass45.GStruct4 gstruct = default(GClass45.GStruct4);
		IntPtr intPtr = GClass45.OpenProcess(1040, false, process_0.Id);
		if (intPtr == IntPtr.Zero)
		{
			return false;
		}
		int num = GClass45.VirtualQueryEx(intPtr, intptr_0, out gstruct, Marshal.SizeOf(gstruct));
		GClass45.CloseHandle(intPtr);
		return num > 0 && GClass49.CanExecuteCodeInMemory(gstruct);
	}

	// Token: 0x06000415 RID: 1045 RVA: 0x00051A10 File Offset: 0x0004FC10
	public static bool IsExecutableRegion(IntPtr intptr_0, IntPtr intptr_1)
	{
		GClass45.GStruct4 gstruct = default(GClass45.GStruct4);
		return !(intptr_0 == IntPtr.Zero) && !(intptr_1 == IntPtr.Zero) && GClass45.VirtualQueryEx(intptr_0, intptr_1, out gstruct, Marshal.SizeOf(gstruct)) > 0 && GClass49.CanExecuteCodeInMemory(gstruct);
	}

	// Token: 0x06000416 RID: 1046 RVA: 0x00051A60 File Offset: 0x0004FC60
	public static uint SetFlagBits(uint uint_0)
	{
		uint num = 0U;
		if ((uint_0 & 16U) != 0U)
		{
			num = 10U;
		}
		if ((uint_0 & 32U) != 0U)
		{
			num |= 10U;
		}
		if ((uint_0 & 64U) != 0U)
		{
			num |= 14U;
		}
		if ((uint_0 & 128U) != 0U)
		{
			num |= 12U;
		}
		if ((uint_0 & 256U) != 0U)
		{
			num |= 16U;
		}
		if ((uint_0 & 1U) != 0U)
		{
			num |= 1U;
		}
		if ((uint_0 & 512U) != 0U)
		{
			num |= 32U;
		}
		if ((uint_0 & 2U) != 0U)
		{
			num |= 2U;
		}
		if ((uint_0 & 4U) != 0U)
		{
			num |= 6U;
		}
		if ((uint_0 & 1024U) != 0U)
		{
			num |= 4U;
		}
		if ((uint_0 & 8U) != 0U)
		{
			num |= 4U;
		}
		return num;
	}

	// Token: 0x06000417 RID: 1047 RVA: 0x00051AEC File Offset: 0x0004FCEC
	public static bool IsMemoryProtected(IntPtr intptr_0, IntPtr intptr_1)
	{
		GClass45.GStruct4 gstruct = default(GClass45.GStruct4);
		return !(intptr_0 == IntPtr.Zero) && !(intptr_1 == IntPtr.Zero) && GClass45.VirtualQueryEx(intptr_0, intptr_1, out gstruct, Marshal.SizeOf(gstruct)) > 0 && GClass49.HasFlag(gstruct.uint_2);
	}

	// Token: 0x06000418 RID: 1048 RVA: 0x00051B44 File Offset: 0x0004FD44
	public static bool HasFlag(uint uint_0)
	{
		return (GClass49.SetFlagBits(uint_0) & 8U) == 8U;
	}

	// Token: 0x06000419 RID: 1049 RVA: 0x00051B5C File Offset: 0x0004FD5C
	public static bool DetectProcessBitness(Process process_0)
	{
		IntPtr intPtr = GClass45.OpenProcess(1040, false, process_0.Id);
		bool result = false;
		if (intPtr != IntPtr.Zero)
		{
			try
			{
				if (!GClass45.IsWow64Process(intPtr, ref result))
				{
					result = false;
				}
			}
			catch
			{
			}
			GClass45.CloseHandle(intPtr);
		}
		return result;
	}

	// Token: 0x0600041A RID: 1050 RVA: 0x00051BB4 File Offset: 0x0004FDB4
	public static bool IsCurrentProcessElevated()
	{
		return GClass49.GetProcessPrivilegeLevel(Process.GetCurrentProcess()) != GClass49.GEnum45.const_0;
	}

	// Token: 0x0600041B RID: 1051 RVA: 0x00051BD4 File Offset: 0x0004FDD4
	public static GClass49.GEnum45 GetProcessPrivilegeLevel(Process process_0)
	{
		bool flag = IntPtr.Size == 8 || GClass49.DetectProcessBitness(Process.GetCurrentProcess());
		bool flag2 = GClass49.DetectProcessBitness(process_0);
		if (flag && flag2)
		{
			return GClass49.GEnum45.const_2;
		}
		if (flag && !flag2)
		{
			return GClass49.GEnum45.const_1;
		}
		return GClass49.GEnum45.const_0;
	}

	// Token: 0x0600041C RID: 1052 RVA: 0x00051C10 File Offset: 0x0004FE10
	public static bool IsProcessElevated(Process process_0)
	{
		GClass49.GEnum45 processPrivilegeLevel = GClass49.GetProcessPrivilegeLevel(process_0);
		return processPrivilegeLevel == GClass49.GEnum45.const_0 || processPrivilegeLevel == GClass49.GEnum45.const_2;
	}

	// Token: 0x0600041D RID: 1053 RVA: 0x00051C30 File Offset: 0x0004FE30
	public static string GetMemoryRegionInfo(Process process_0, IntPtr intptr_0)
	{
		if (process_0 == null)
		{
			return string.Empty;
		}
		string text = Class14.String_47;
		GClass45.GStruct4 gstruct = default(GClass45.GStruct4);
		IntPtr intPtr = GClass45.OpenProcess(1040, false, process_0.Id);
		if (intPtr == IntPtr.Zero)
		{
			return text;
		}
		try
		{
			if (GClass45.VirtualQueryEx(intPtr, intptr_0, out gstruct, Marshal.SizeOf(gstruct)) <= 0)
			{
				GClass45.CloseHandle(intPtr);
				return text;
			}
			uint flagBits;
			IntPtr value = GClass49.GetNextMemoryRegionAddress(process_0, intPtr, gstruct.intptr_0, out flagBits, true);
			uint num;
			if (!(value != IntPtr.Zero))
			{
				num = GClass49.SetFlagBits(gstruct.uint_2);
				value = (IntPtr)(gstruct.intptr_0.ToInt64() + gstruct.intptr_2.ToInt64());
			}
			else
			{
				num = GClass49.SetFlagBits(flagBits);
			}
			string text2 = null;
			if (gstruct.uint_3 == 16777216U)
			{
				text2 = GClass49.GetModuleByAddress(process_0, intptr_0);
			}
			if (text2 != null)
			{
				text2 = Class14.String_221 + text2;
			}
			else if (gstruct.uint_3 == 131072U)
			{
				text2 = Class14.String_205;
			}
			else
			{
				string text3 = GClass45.GetMappedFileNameInfo(intPtr, gstruct.intptr_0);
				if (text3 == null)
				{
					text3 = string.Empty;
				}
				if (text3.Length <= 0)
				{
					if (gstruct.uint_3 == 16777216U)
					{
						text2 = Class14.String_53;
					}
					else
					{
						text2 = Class14.String_76;
					}
				}
				else
				{
					text3 = Path.GetFileName(text3);
					if (gstruct.uint_3 == 16777216U)
					{
						text2 = Class14.String_88 + text3.ToString();
					}
					else
					{
						text2 = Class14.String_152 + text3.ToString();
					}
				}
			}
			char[] array = new char[]
			{
				'-',
				'-',
				'-'
			};
			if ((num & 2U) == 2U)
			{
				array[0] = 'r';
			}
			if ((num & 4U) == 4U)
			{
				array[1] = 'w';
			}
			if ((num & 8U) == 8U)
			{
				array[2] = 'x';
			}
			string text4 = new string(array);
			if (!GClass17.smethod_1(intPtr, gstruct.intptr_0))
			{
				text += Class14.String_74;
			}
			else
			{
				text += Class14.String_217;
			}
			text = string.Concat(new string[]
			{
				text,
				<Module>.DeserializeFromByteArrayV2<string>(1038036101U),
				gstruct.intptr_0.ToString(<Module>.DeserializeFromByteArrayV2<string>(2695046053U)),
				<Module>.DeserializeFromByteArray<string>(3617197183U),
				value.ToString(<Module>.DeserializeFromByteArray<string>(4071675807U)),
				<Module>.DeserealizeFromByteArrayV2_1<string>(1214359125U),
				text4.ToString(),
				<Module>.DeserializeFromByteArray<string>(3617197183U),
				text2
			});
			IntPtr value2 = IntPtr.Zero;
			uint num2 = 0U;
			for (int i = 0; i < process_0.Threads.Count; i++)
			{
				value2 = GClass49.GetThreadEntryPoint((uint)process_0.Threads[i].Id);
				if (!(value2 == IntPtr.Zero) && value2.ToInt64() >= gstruct.intptr_0.ToInt64() && value2.ToInt64() < value.ToInt64())
				{
					num2 += 1U;
				}
			}
			text = text + Class14.String_121 + num2.ToString();
		}
		catch
		{
		}
		GClass45.CloseHandle(intPtr);
		return text;
	}

	// Token: 0x0600041E RID: 1054 RVA: 0x00051F6C File Offset: 0x0005016C
	public static IntPtr GetNextMemoryRegionAddress(Process process_0, IntPtr intptr_0, IntPtr intptr_1, out uint uint_0, bool bool_1 = true)
	{
		GClass45.GStruct4 gstruct = default(GClass45.GStruct4);
		GClass45.GStruct4 gstruct2 = default(GClass45.GStruct4);
		IntPtr intPtr = IntPtr.Zero;
		GClass45.GStruct5 gstruct3 = default(GClass45.GStruct5);
		GClass45.GetSystemInfo(ref gstruct3);
		uint_0 = 0U;
		int num = GClass45.VirtualQueryEx(intptr_0, intptr_1, out gstruct2, Marshal.SizeOf(gstruct2));
		uint_0 = gstruct2.uint_2;
		if (num <= 0)
		{
			return IntPtr.Zero;
		}
		if (gstruct2.intptr_0.ToInt64() == 0L || gstruct2.intptr_2.ToInt64() == 0L)
		{
			return IntPtr.Zero;
		}
		if (!GClass49.CanExecuteCodeInMemory(gstruct2))
		{
			return (IntPtr)(gstruct2.intptr_0.ToInt64() + gstruct2.intptr_2.ToInt64());
		}
		if (gstruct2.uint_3 == 16777216U)
		{
			intPtr = GClass49.GetModuleBaseAddress(process_0, gstruct2.intptr_0);
			if (intPtr == IntPtr.Zero && gstruct2.uint_3 == 16777216U && GClass49.IsCurrentProcessElevated())
			{
				bool_1 = true;
			}
			string a = string.Empty;
			string b = string.Empty;
			if (bool_1)
			{
				a = GClass45.GetMappedFileNameInfo(intptr_0, gstruct2.intptr_0);
			}
			IntPtr intPtr2 = (IntPtr)(gstruct2.intptr_0.ToInt64() + gstruct2.intptr_2.ToInt64());
			IntPtr intptr_2 = gstruct3.intptr_1;
			while (GClass45.VirtualQueryEx(intptr_0, intPtr2, out gstruct, Marshal.SizeOf(gstruct)) > 0)
			{
				if (gstruct.intptr_0.ToInt64() != 0L && gstruct.intptr_2.ToInt64() != 0L)
				{
					if (gstruct.uint_3 != gstruct2.uint_3)
					{
						intPtr2 = gstruct.intptr_0;
					}
					else
					{
						if (GClass49.CanExecuteCodeInMemory(gstruct))
						{
							if (intPtr != IntPtr.Zero)
							{
								if (GClass49.GetModuleBaseAddress(process_0, gstruct.intptr_0) != intPtr)
								{
									bool flag = true;
									if (bool_1)
									{
										b = GClass45.GetMappedFileNameInfo(intptr_0, gstruct2.intptr_0);
										if (a == b)
										{
											flag = false;
										}
									}
									if (flag)
									{
										return gstruct.intptr_0;
									}
								}
							}
							else
							{
								bool flag = true;
								if (bool_1)
								{
									b = GClass45.GetMappedFileNameInfo(intptr_0, gstruct2.intptr_0);
									if (a == b)
									{
										flag = false;
									}
								}
								if (flag)
								{
									return (IntPtr)(gstruct.intptr_0.ToInt64() + gstruct.intptr_2.ToInt64());
								}
							}
						}
						else if (!(intPtr != IntPtr.Zero))
						{
							bool flag = true;
							if (bool_1)
							{
								b = GClass45.GetMappedFileNameInfo(intptr_0, gstruct2.intptr_0);
								if (a == b)
								{
									flag = false;
								}
							}
							if (flag)
							{
								return (IntPtr)(gstruct.intptr_0.ToInt64() + gstruct.intptr_2.ToInt64());
							}
						}
						else if (GClass49.GetModuleBaseAddress(process_0, gstruct.intptr_0) != intPtr)
						{
							bool flag = true;
							if (bool_1)
							{
								b = GClass45.GetMappedFileNameInfo(intptr_0, gstruct2.intptr_0);
								if (a == b)
								{
									flag = false;
								}
							}
							if (flag)
							{
								return gstruct.intptr_0;
							}
						}
						uint_0 |= gstruct.uint_2;
						intPtr2 = (IntPtr)(gstruct.intptr_0.ToInt64() + gstruct.intptr_2.ToInt64());
						if (intPtr2.ToInt64() < intptr_2.ToInt64())
						{
							continue;
						}
					}
				}
				else
				{
					intPtr2 = gstruct.intptr_0;
				}
				return intPtr2;
			}
			return gstruct.intptr_0;
		}
		return (IntPtr)(gstruct2.intptr_0.ToInt64() + gstruct2.intptr_2.ToInt64());
	}

	// Token: 0x0600041F RID: 1055 RVA: 0x000522D4 File Offset: 0x000504D4
	public static bool IsElevatedProcessWithMatchingSystemPath(string string_0)
	{
		if (!GClass49.IsCurrentProcessElevated())
		{
			return false;
		}
		string[] array = new string[]
		{
			<Module>.DeserializeFromByteArray2<string>(3625615638U),
			<Module>.DeserializeFromByteArray2<string>(4043819914U),
			<Module>.DeserializeFromByteArrayV2<string>(3029364231U),
			<Module>.DeserializeFromByteArray<string>(1348005241U)
		};
		string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.System);
		string_0 = string_0.ToLowerInvariant();
		for (int i = 0; i < array.Length; i++)
		{
			string text = Path.Combine(folderPath, array[i]);
			string b = text.ToLowerInvariant();
			if (string_0 == b)
			{
				return i >= array.Length - 1 || !File.Exists(text);
			}
		}
		return false;
	}

	// Token: 0x06000420 RID: 1056 RVA: 0x0005237C File Offset: 0x0005057C
	public static bool TryGetFullProcessImageName(Process process_0, out string string_0)
	{
		IntPtr intPtr = IntPtr.Zero;
		bool result = false;
		string_0 = null;
		if (GClass49.bool_0)
		{
			int num = 32768;
			StringBuilder stringBuilder = new StringBuilder(32768);
			try
			{
				intPtr = GClass45.OpenProcess(1024, false, process_0.Id);
				if (intPtr == IntPtr.Zero)
				{
					return result;
				}
				if (GClass45.QueryFullProcessImageName(intPtr, 0, stringBuilder, ref num))
				{
					string_0 = stringBuilder.ToString();
					result = true;
				}
				result = true;
			}
			catch (EntryPointNotFoundException)
			{
				GClass49.bool_0 = false;
			}
			catch (Exception)
			{
			}
			finally
			{
				if (intPtr != IntPtr.Zero)
				{
					GClass45.CloseHandle(intPtr);
				}
			}
			return result;
		}
		return result;
	}

	// Token: 0x06000421 RID: 1057 RVA: 0x0005243C File Offset: 0x0005063C
	public static string GetProcessInfoFromWMI(int int_0)
	{
		try
		{
			ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher(<Module>.DeserializeFromByteArrayV2<string>(2747029983U) + int_0.ToString());
			StringBuilder stringBuilder = new StringBuilder();
			using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator())
			{
				if (enumerator.MoveNext())
				{
					ManagementObject managementObject = (ManagementObject)enumerator.Current;
					stringBuilder.Append(managementObject[<Module>.DeserializeFromByteArray2<string>(3579823677U)].ToString());
				}
			}
			return stringBuilder.ToString().Trim();
		}
		catch
		{
		}
		return string.Empty;
	}

	// Token: 0x06000422 RID: 1058 RVA: 0x000524E8 File Offset: 0x000506E8
	public static string GetProcessNameFromMemory(int int_0)
	{
		IntPtr intPtr = IntPtr.Zero;
		bool flag = true;
		string result = string.Empty;
		try
		{
			intPtr = GClass45.OpenProcess(1040, false, int_0);
			if (intPtr != IntPtr.Zero)
			{
				GClass45.GStruct25 gstruct = default(GClass45.GStruct25);
				int num;
				if (GClass45.NtQueryInformationProcess(intPtr, 0, ref gstruct, Marshal.SizeOf(gstruct), out num) == 0 && gstruct.intptr_1 != IntPtr.Zero)
				{
					byte[] array = new byte[8];
					uint num2 = 0U;
					uint num3 = 4U;
					if (GClass45.ReadProcessMemory(intPtr, (IntPtr)(gstruct.intptr_1.ToInt64() + 16L), array, 4U, ref num2) && num2 == num3)
					{
						num3 = 2U;
						uint num4 = BitConverter.ToUInt32(array, 0);
						uint num5 = 64U;
						if (GClass45.ReadProcessMemory(intPtr, (IntPtr)((long)((ulong)(num4 + 64U))), array, 2U, ref num2) && num2 == num3)
						{
							ushort num6 = BitConverter.ToUInt16(array, 0);
							if (num6 > 0)
							{
								num3 = 4U;
								if (GClass45.ReadProcessMemory(intPtr, (IntPtr)((long)((ulong)(num4 + num5 + 4U))), array, 4U, ref num2))
								{
									if (num2 == num3)
									{
										uint num7 = BitConverter.ToUInt32(array, 0);
										byte[] array2 = new byte[(int)num6];
										if (GClass45.ReadProcessMemory(intPtr, (IntPtr)((long)((ulong)num7)), array2, (uint)array2.Length, ref num2) && num2 == (uint)array2.Length)
										{
											result = Encoding.Unicode.GetString(array2).Trim();
											flag = false;
										}
									}
								}
							}
						}
					}
				}
			}
		}
		catch (Exception)
		{
		}
		finally
		{
			if (intPtr != IntPtr.Zero)
			{
				GClass45.CloseHandle(intPtr);
			}
			if (flag)
			{
				result = GClass49.GetProcessInfoFromWMI(int_0);
			}
		}
		return result;
	}

	// Token: 0x06000423 RID: 1059 RVA: 0x000526A4 File Offset: 0x000508A4
	public static bool IsDEPEnabledForProcess(int int_0)
	{
		IntPtr intPtr = IntPtr.Zero;
		bool result = false;
		try
		{
			intPtr = GClass45.OpenProcess(1040, false, int_0);
			if (intPtr != IntPtr.Zero)
			{
				GClass45.GEnum42 genum = GClass45.GEnum42.flag_0;
				bool flag = false;
				if (GClass45.GetProcessDEPPolicy(intPtr, out genum, out flag))
				{
					if (genum == GClass45.GEnum42.flag_1)
					{
						if (flag)
						{
							result = true;
						}
					}
				}
			}
		}
		catch
		{
		}
		finally
		{
			if (intPtr != IntPtr.Zero)
			{
				GClass45.CloseHandle(intPtr);
			}
		}
		return result;
	}

	// Token: 0x06000424 RID: 1060 RVA: 0x00052728 File Offset: 0x00050928
	public static string ReadProcessMemoryString(IntPtr intptr_0, IntPtr intptr_1, int int_0, bool bool_1 = true, string string_0 = "")
	{
		string result = string_0;
		if (!(intptr_0 == IntPtr.Zero) && !(intptr_1 == IntPtr.Zero) && int_0 != 0)
		{
			try
			{
				byte[] array = new byte[int_0];
				uint num = 0U;
				if (GClass45.ReadProcessMemory(intptr_0, intptr_1, array, (uint)array.Length, ref num) && num > 0U)
				{
					string text;
					int num2;
					if (!bool_1)
					{
						text = Encoding.UTF8.GetString(array);
						num2 = text.IndexOf(<Module>.DeserializeFromByteArray<string>(3448931238U));
					}
					else
					{
						text = Encoding.ASCII.GetString(array);
						num2 = text.IndexOf('\0');
					}
					if (num2 > 0)
					{
						text = text.Substring(0, num2);
					}
					else if (num2 == 0)
					{
						text = string_0;
					}
					result = text;
				}
			}
			catch
			{
			}
			return result;
		}
		return result;
	}

	// Token: 0x06000425 RID: 1061 RVA: 0x000527E4 File Offset: 0x000509E4
	public static Process GetProcessInformation(Process process_0)
	{
		if (process_0 == null)
		{
			process_0 = Process.GetCurrentProcess();
		}
		Process process = GClass49.GetProcessFromId(process_0.Handle);
		if (process == null)
		{
			process = GClass49.GetProcessInfoUsingWMI(process_0);
		}
		return process;
	}

	// Token: 0x06000426 RID: 1062 RVA: 0x00052814 File Offset: 0x00050A14
	public static Process GetProcessFromId(IntPtr intptr_0)
	{
		try
		{
			GClass45.GStruct25 gstruct = default(GClass45.GStruct25);
			int num;
			if (GClass45.NtQueryInformationProcess(intptr_0, 0, ref gstruct, Marshal.SizeOf(gstruct), out num) != 0)
			{
				return null;
			}
			return Process.GetProcessById(gstruct.intptr_5.ToInt32());
		}
		catch (Exception)
		{
		}
		return null;
	}

	// Token: 0x06000427 RID: 1063 RVA: 0x00052870 File Offset: 0x00050A70
	public static Process GetProcessInfoUsingWMI(Process process_0)
	{
		try
		{
			using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = new ManagementObjectSearcher(<Module>.DeserializeFromByteArray<string>(2511194204U) + process_0.Id).Get().GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					ManagementObject managementObject = (ManagementObject)enumerator.Current;
					if (managementObject != null)
					{
						Process.GetProcessById(Convert.ToInt32(managementObject[<Module>.DeserealizeFromByteArrayV2_1<string>(4177393618U)]));
						break;
					}
				}
			}
		}
		catch
		{
		}
		return null;
	}

	// Token: 0x040005F7 RID: 1527
	private static bool bool_0 = true;

	// Token: 0x020000A8 RID: 168
	public enum GEnum43
	{
		// Token: 0x040005F9 RID: 1529
		const_0,
		// Token: 0x040005FA RID: 1530
		const_1,
		// Token: 0x040005FB RID: 1531
		const_2,
		// Token: 0x040005FC RID: 1532
		const_3
	}

	// Token: 0x020000A9 RID: 169
	public enum GEnum44 : uint
	{
		// Token: 0x040005FE RID: 1534
		const_0,
		// Token: 0x040005FF RID: 1535
		const_1,
		// Token: 0x04000600 RID: 1536
		const_2,
		// Token: 0x04000601 RID: 1537
		const_3 = 4U,
		// Token: 0x04000602 RID: 1538
		const_4 = 8U,
		// Token: 0x04000603 RID: 1539
		const_5 = 16U,
		// Token: 0x04000604 RID: 1540
		const_6 = 32U
	}

	// Token: 0x020000AA RID: 170
	public enum GEnum45
	{
		// Token: 0x04000606 RID: 1542
		const_0 = 1,
		// Token: 0x04000607 RID: 1543
		const_1,
		// Token: 0x04000608 RID: 1544
		const_2 = 4
	}
}
