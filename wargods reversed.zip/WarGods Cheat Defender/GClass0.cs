﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x0200000F RID: 15
public class GClass0
{
	// Token: 0x17000001 RID: 1
	// (get) Token: 0x06000047 RID: 71 RVA: 0x0003FD84 File Offset: 0x0003DF84
	// (set) Token: 0x06000048 RID: 72 RVA: 0x0003FD98 File Offset: 0x0003DF98
	public GEnum0 GEnum0_0 { get; set; }

	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000049 RID: 73 RVA: 0x0003FDAC File Offset: 0x0003DFAC
	// (set) Token: 0x0600004A RID: 74 RVA: 0x0003FDC0 File Offset: 0x0003DFC0
	public string String_0 { get; set; }

	// Token: 0x17000003 RID: 3
	// (get) Token: 0x0600004B RID: 75 RVA: 0x0003FDD4 File Offset: 0x0003DFD4
	// (set) Token: 0x0600004C RID: 76 RVA: 0x0003FDE8 File Offset: 0x0003DFE8
	public string String_1 { get; set; }

	// Token: 0x0600004D RID: 77 RVA: 0x0003FDFC File Offset: 0x0003DFFC
	public GClass0()
	{
		this.GEnum0_0 = GEnum0.const_0;
		this.String_1 = "";
		this.String_0 = "";
	}

	// Token: 0x0600004E RID: 78 RVA: 0x0003FE2C File Offset: 0x0003E02C
	public string method_0(string string_2 = "!")
	{
		return string.Format(<Module>.DeserealizeFromByteArrayV2_1<string>(3183522079U), new object[]
		{
			(int)this.GEnum0_0,
			string_2,
			(this.String_0 != null) ? Class15.SanitizeString(this.String_0) : string.Empty,
			string_2,
			(this.String_1 != null) ? Class15.SanitizeString(this.String_1) : string.Empty
		});
	}

	// Token: 0x04000040 RID: 64
	[CompilerGenerated]
	private GEnum0 genum0_0;

	// Token: 0x04000041 RID: 65
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04000042 RID: 66
	[CompilerGenerated]
	private string string_1;
}
