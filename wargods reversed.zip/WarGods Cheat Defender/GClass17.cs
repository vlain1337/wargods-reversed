﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;

// Token: 0x02000039 RID: 57
public class GClass17
{
	// Token: 0x06000123 RID: 291 RVA: 0x00045214 File Offset: 0x00043414
	public GClass17(string string_4, GEnum15 genum15_0 = GEnum15.const_0)
	{
		this.String_3 = string_4;
		FileStream fileStream = null;
		BinaryReader binaryReader = null;
		try
		{
			if (string_4.Length <= GClass18.int_0 && !string_4.Contains(<Module>.DeserializeFromByteArray3<string>(3791849231U)))
			{
				try
				{
					fileStream = new FileStream(string_4, FileMode.Open, FileAccess.Read, FileShare.Read);
					goto IL_64;
				}
				catch
				{
					fileStream = new FileStream(string_4, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
					goto IL_64;
				}
			}
			try
			{
				fileStream = GClass39.smethod_2(string_4, FileMode.Open, FileAccess.Read, FileShare.Read);
			}
			catch
			{
				fileStream = GClass39.smethod_2(string_4, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			}
			IL_64:
			binaryReader = new BinaryReader(fileStream);
			if (fileStream.Length > GClass17.long_0)
			{
				this.method_1(binaryReader, genum15_0);
			}
			else
			{
				byte[] array = new byte[fileStream.Length];
				binaryReader.Read(array, 0, array.Length);
				this.method_0(array, genum15_0);
			}
		}
		finally
		{
			if (binaryReader != null)
			{
				binaryReader.Close();
			}
			if (fileStream != null)
			{
				fileStream.Close();
			}
		}
	}

	// Token: 0x06000124 RID: 292 RVA: 0x00045304 File Offset: 0x00043504
	public GClass17(FileStream fileStream_0, GEnum15 genum15_0 = GEnum15.const_0)
	{
		this.String_3 = fileStream_0.Name;
		fileStream_0.Seek(0L, SeekOrigin.Begin);
		BinaryReader binaryReader_ = new BinaryReader(fileStream_0);
		this.method_1(binaryReader_, genum15_0);
	}

	// Token: 0x06000125 RID: 293 RVA: 0x00045344 File Offset: 0x00043544
	public GClass17(IntPtr intptr_0, IntPtr intptr_1, GEnum15 genum15_0 = GEnum15.const_0)
	{
		this.String_3 = <Module>.DeserializeFromByteArray3<string>(3626848219U) + intptr_1.ToString(<Module>.DeserializeFromByteArrayV2<string>(3097445936U));
		this.method_2(intptr_0, intptr_1, genum15_0);
	}

	// Token: 0x06000126 RID: 294 RVA: 0x00045388 File Offset: 0x00043588
	private void method_0(byte[] byte_0, GEnum15 genum15_0)
	{
		try
		{
			this.GClass23_0 = new GClass23(byte_0);
			if (this.GClass23_0.UInt16_0 != 23117)
			{
				this.GClass23_0 = null;
				throw new GException3(<Module>.DeserializeFromByteArray<string>(2574964202U));
			}
			this.Boolean_9 = (BitConverter.ToUInt16(byte_0, (int)(this.GClass23_0.UInt32_0 + 4U)) == 34404);
			uint num = this.Boolean_9 ? 264U : 248U;
			this.GClass28_0 = new GClass28(byte_0, this.GClass23_0.UInt32_0, this.Boolean_9);
			short num2 = (short)this.GClass28_0.UInt32_0;
			if (num2 != 17744)
			{
				if (num2 != 17742)
				{
					if (num2 != 17740)
					{
						if (num2 != 22604)
						{
							this.GClass23_0 = null;
							this.GClass28_0 = null;
							throw new GException4(string.Format(<Module>.DeserializeFromByteArray<string>(230621617U), num2.ToString(<Module>.DeserializeFromByteArray<string>(2611176279U))));
						}
					}
				}
			}
			this.GClass31_0 = this.method_16(byte_0, this.GClass28_0.GClass25_0.UInt16_1, (int)(this.GClass23_0.UInt32_0 + num), this.GClass28_0.GClass29_0.UInt32_7, (genum15_0 & GEnum15.const_12) == GEnum15.const_12 || genum15_0 == GEnum15.const_13);
			if ((genum15_0 & GEnum15.const_1) != GEnum15.const_1)
			{
				if (genum15_0 != GEnum15.const_13)
				{
					this.GClass30_0 = null;
					this.String_0 = null;
					goto IL_231;
				}
			}
			try
			{
				this.GClass30_0 = this.method_19(byte_0, this.GClass31_0, this.GClass28_0.GClass29_0.UInt32_7, this.GClass28_0.GClass29_0.GClass20_0[4], (genum15_0 & GEnum15.const_12) == GEnum15.const_12 || genum15_0 == GEnum15.const_13);
				if ((genum15_0 & GEnum15.const_12) != GEnum15.const_12)
				{
					if (genum15_0 != GEnum15.const_13)
					{
						goto IL_217;
					}
				}
				try
				{
					string text = <Module>.DeserializeFromByteArray2<string>(1220706514U);
					if (Class6.smethod_3(byte_0, out text, 0L, (long)((ulong)this.GClass30_0.UInt32_1), 4096))
					{
						this.String_0 = text;
					}
					else
					{
						this.String_0 = null;
					}
					goto IL_21E;
				}
				catch
				{
					this.String_0 = null;
					goto IL_21E;
				}
				IL_217:
				this.String_0 = null;
				IL_21E:;
			}
			catch (Exception)
			{
				this.GClass30_0 = null;
				this.String_0 = null;
			}
			IL_231:
			if ((genum15_0 & GEnum15.const_2) != GEnum15.const_2)
			{
				if (genum15_0 != GEnum15.const_13)
				{
					this.GClass24_0 = null;
					this.GClass14_0 = null;
					this.Boolean_1 = false;
					goto IL_30E;
				}
			}
			if (this.GClass28_0.GClass29_0.GClass20_0[0].UInt32_0 != 0U && this.GClass28_0.GClass29_0.GClass20_0[0].UInt32_1 > 0U)
			{
				try
				{
					this.GClass24_0 = new GClass24(byte_0, (int)GClass18.smethod_10(this.GClass28_0.GClass29_0.GClass20_0[0].UInt32_0, this.GClass31_0));
					this.GClass14_0 = this.method_13(byte_0, this.GClass24_0, this.GClass31_0);
					this.Boolean_1 = true;
					goto IL_30E;
				}
				catch
				{
					this.GClass24_0 = null;
					this.GClass14_0 = null;
					this.Boolean_1 = false;
					goto IL_30E;
				}
			}
			this.GClass24_0 = null;
			this.GClass14_0 = null;
			this.Boolean_1 = false;
			IL_30E:
			if ((genum15_0 & GEnum15.const_3) != GEnum15.const_3)
			{
				if (genum15_0 != GEnum15.const_13)
				{
					this.Boolean_2 = false;
					this.GClass27_0 = null;
					goto IL_3DD;
				}
			}
			if (this.GClass28_0.GClass29_0.GClass20_0[1].UInt32_0 != 0U && this.GClass28_0.GClass29_0.GClass20_0[1].UInt32_1 > 0U)
			{
				try
				{
					this.GClass27_0 = this.method_10(byte_0, GClass18.smethod_10(this.GClass28_0.GClass29_0.GClass20_0[1].UInt32_0, this.GClass31_0), this.GClass31_0);
					this.GClass15_0 = this.method_7(byte_0, this.GClass27_0, this.GClass31_0);
					this.Boolean_2 = true;
					goto IL_3DD;
				}
				catch
				{
					this.Boolean_2 = false;
					this.GClass27_0 = null;
					goto IL_3DD;
				}
			}
			this.Boolean_2 = false;
			this.GClass27_0 = null;
			IL_3DD:
			if ((genum15_0 & GEnum15.const_5) != GEnum15.const_5)
			{
				if (genum15_0 != GEnum15.const_13)
				{
					this.GClass21_0 = null;
					this.Boolean_3 = false;
					this.Boolean_4 = false;
					this.GClass35_0 = null;
					goto IL_516;
				}
			}
			if (this.GClass28_0.GClass29_0.GClass20_0[6].UInt32_0 != 0U && this.GClass28_0.GClass29_0.GClass20_0[6].UInt32_1 > 0U)
			{
				try
				{
					this.GClass21_0 = this.method_21(byte_0, GClass18.smethod_10(this.GClass28_0.GClass29_0.GClass20_0[6].UInt32_0, this.GClass31_0));
					this.Boolean_3 = true;
					try
					{
						if (2U == this.GClass21_0.UInt32_2)
						{
							this.GClass35_0 = new GClass35(byte_0, (int)this.GClass21_0.UInt32_5, (int)this.GClass21_0.UInt32_3);
							this.Boolean_4 = true;
						}
						else
						{
							this.GClass35_0 = null;
							this.Boolean_4 = false;
						}
					}
					catch
					{
						this.GClass35_0 = null;
						this.Boolean_4 = false;
					}
					goto IL_516;
				}
				catch
				{
					this.GClass21_0 = null;
					this.Boolean_3 = false;
					this.Boolean_4 = false;
					this.GClass35_0 = null;
					goto IL_516;
				}
			}
			this.GClass21_0 = null;
			this.Boolean_3 = false;
			this.Boolean_4 = false;
			this.GClass35_0 = null;
			IL_516:
			if ((genum15_0 & GEnum15.const_11) != GEnum15.const_11)
			{
				if (genum15_0 != GEnum15.const_13)
				{
					this.GClass36_0 = null;
					this.GClass37_0 = null;
					this.Boolean_5 = false;
					goto IL_5D5;
				}
			}
			if (this.GClass28_0.GClass29_0.GClass20_0[4].UInt32_0 != 0U && this.GClass28_0.GClass29_0.GClass20_0[4].UInt32_1 > 0U)
			{
				try
				{
					this.GClass36_0 = this.method_5(byte_0, this.GClass28_0.GClass29_0.GClass20_0[4].UInt32_0);
					this.Boolean_5 = true;
					goto IL_5D5;
				}
				catch
				{
					this.GClass36_0 = null;
					this.GClass37_0 = null;
					this.Boolean_5 = false;
					goto IL_5D5;
				}
			}
			this.GClass36_0 = null;
			this.GClass37_0 = null;
			this.Boolean_5 = false;
			IL_5D5:;
		}
		catch (Exception)
		{
		}
	}

	// Token: 0x06000127 RID: 295 RVA: 0x00045A34 File Offset: 0x00043C34
	private void method_1(BinaryReader binaryReader_0, GEnum15 genum15_0)
	{
		/*
An exception occurred when decompiling this method (06000127)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void GClass17::method_1(System.IO.BinaryReader,GEnum15)

 ---> System.Exception: Inconsistent stack size at IL_5EB
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 443
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 271
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06000128 RID: 296 RVA: 0x00046168 File Offset: 0x00044368
	private void method_2(IntPtr intptr_0, IntPtr intptr_1, GEnum15 genum15_0)
	{
		uint num = 0U;
		try
		{
			if (!GClass16.smethod_1(intptr_0, intptr_1))
			{
				throw new GException3(<Module>.DeserializeFromByteArray3<string>(239089453U));
			}
			byte[] array = new byte[GClass23.int_0];
			if (!GClass16.ReadProcessMemory(intptr_0, intptr_1, array, (uint)array.Length, ref num) || (ulong)num != (ulong)((long)array.Length))
			{
				this.GClass23_0 = null;
				throw new GException3(<Module>.DeserializeFromByteArray2<string>(2155065293U));
			}
			this.GClass23_0 = new GClass23(array);
			if (this.GClass23_0.UInt16_0 != 23117)
			{
				this.GClass23_0 = null;
				throw new GException3(<Module>.DeserializeFromByteArray<string>(2574964202U));
			}
			IntPtr intptr_2 = (IntPtr)(intptr_1.ToInt64() + (long)((ulong)this.GClass23_0.UInt32_0));
			if (!GClass16.smethod_1(intptr_0, intptr_2))
			{
				throw new GException4(<Module>.DeserializeFromByteArray2<string>(2155065293U));
			}
			array = new byte[GClass28.uint_1];
			if (GClass16.ReadProcessMemory(intptr_0, intptr_2, array, (uint)array.Length, ref num))
			{
				if ((ulong)num == (ulong)((long)array.Length))
				{
					this.Boolean_9 = (BitConverter.ToUInt16(array, 4) == 34404);
					uint num2 = this.Boolean_9 ? 264U : 248U;
					this.GClass28_0 = new GClass28(array, this.Boolean_9);
					short num3 = (short)this.GClass28_0.UInt32_0;
					if (num3 != 17744)
					{
						if (num3 != 17742)
						{
							if (num3 != 17740)
							{
								if (num3 != 22604)
								{
									throw new GException3(string.Format(<Module>.DeserializeFromByteArrayV2<string>(3119928527U), num3.ToString(<Module>.DeserealizeFromByteArrayV2_1<string>(1379546189U))));
								}
							}
						}
					}
					IntPtr intptr_3 = (IntPtr)(intptr_2.ToInt64() + (long)((ulong)num2));
					this.GClass31_0 = this.method_18(intptr_0, this.GClass28_0.GClass25_0.UInt16_1, intptr_3, this.GClass28_0.GClass29_0.UInt32_6, (genum15_0 & GEnum15.const_12) == GEnum15.const_12 || genum15_0 == GEnum15.const_13);
					this.GClass30_0 = null;
					this.String_0 = null;
					if ((genum15_0 & GEnum15.const_2) != GEnum15.const_2)
					{
						if (genum15_0 != GEnum15.const_13)
						{
							this.GClass24_0 = null;
							this.GClass14_0 = null;
							this.Boolean_1 = false;
							goto IL_2F5;
						}
					}
					if (this.GClass28_0.GClass29_0.GClass20_0[0].UInt32_0 != 0U && this.GClass28_0.GClass29_0.GClass20_0[0].UInt32_1 > 0U)
					{
						try
						{
							IntPtr intptr_4 = (IntPtr)((long)(this.GClass28_0.GClass29_0.UInt64_1 + (ulong)this.GClass28_0.GClass29_0.GClass20_0[0].UInt32_0));
							if (!GClass16.smethod_1(intptr_0, intptr_4))
							{
								throw new IOException();
							}
							array = new byte[GClass24.int_0];
							if (!GClass16.ReadProcessMemory(intptr_0, intptr_4, array, (uint)array.Length, ref num) || (ulong)num != (ulong)((long)array.Length))
							{
								this.GClass23_0 = null;
								throw new GException4(<Module>.DeserializeFromByteArray3<string>(2821146404U));
							}
							this.GClass24_0 = new GClass24(array, 0);
							this.GClass14_0 = this.method_15(intptr_0, intptr_1, this.GClass24_0);
							this.Boolean_1 = true;
							goto IL_2F5;
						}
						catch (Exception)
						{
							this.GClass24_0 = null;
							this.GClass14_0 = null;
							this.Boolean_1 = false;
							goto IL_2F5;
						}
					}
					this.GClass24_0 = null;
					this.GClass14_0 = null;
					this.Boolean_1 = false;
					IL_2F5:
					if ((genum15_0 & GEnum15.const_3) != GEnum15.const_3)
					{
						if (genum15_0 != GEnum15.const_13)
						{
							this.Boolean_2 = false;
							this.GClass27_0 = null;
							goto IL_3FA;
						}
					}
					if (this.GClass28_0.GClass29_0.GClass20_0[1].UInt32_0 != 0U && this.GClass28_0.GClass29_0.GClass20_0[1].UInt32_1 > 0U)
					{
						try
						{
							this.GClass27_0 = this.method_12(intptr_0, intptr_1, (IntPtr)((long)((ulong)this.GClass28_0.GClass29_0.GClass20_0[1].UInt32_0)));
							this.GClass15_0 = this.method_9(intptr_0, intptr_1, this.GClass27_0, true);
							this.Boolean_2 = true;
							goto IL_3FA;
						}
						catch (Exception)
						{
							this.Boolean_2 = false;
							this.GClass27_0 = null;
							goto IL_3FA;
						}
					}
					this.Boolean_2 = false;
					this.GClass27_0 = null;
					IL_3FA:
					this.GClass36_0 = null;
					this.GClass37_0 = null;
					this.Boolean_5 = false;
					return;
				}
			}
			this.GClass23_0 = null;
			throw new GException4(<Module>.DeserializeFromByteArray<string>(1862679097U));
		}
		catch (Exception)
		{
		}
	}

	// Token: 0x17000094 RID: 148
	// (get) Token: 0x06000129 RID: 297 RVA: 0x000465D8 File Offset: 0x000447D8
	public bool Boolean_0
	{
		get
		{
			return this.Boolean_1 && this.Boolean_2 && this.Boolean_5 && this.GClass23_0.UInt16_0 == 23117;
		}
	}

	// Token: 0x17000095 RID: 149
	// (get) Token: 0x0600012A RID: 298 RVA: 0x00046614 File Offset: 0x00044814
	// (set) Token: 0x0600012B RID: 299 RVA: 0x00046628 File Offset: 0x00044828
	public bool Boolean_1 { get; private set; }

	// Token: 0x17000096 RID: 150
	// (get) Token: 0x0600012C RID: 300 RVA: 0x0004663C File Offset: 0x0004483C
	// (set) Token: 0x0600012D RID: 301 RVA: 0x00046650 File Offset: 0x00044850
	public bool Boolean_2 { get; private set; }

	// Token: 0x17000097 RID: 151
	// (get) Token: 0x0600012E RID: 302 RVA: 0x00046664 File Offset: 0x00044864
	// (set) Token: 0x0600012F RID: 303 RVA: 0x00046678 File Offset: 0x00044878
	public bool Boolean_3 { get; private set; }

	// Token: 0x17000098 RID: 152
	// (get) Token: 0x06000130 RID: 304 RVA: 0x0004668C File Offset: 0x0004488C
	// (set) Token: 0x06000131 RID: 305 RVA: 0x000466A0 File Offset: 0x000448A0
	public bool Boolean_4 { get; private set; }

	// Token: 0x17000099 RID: 153
	// (get) Token: 0x06000132 RID: 306 RVA: 0x000466B4 File Offset: 0x000448B4
	// (set) Token: 0x06000133 RID: 307 RVA: 0x000466C8 File Offset: 0x000448C8
	public bool Boolean_5 { get; private set; }

	// Token: 0x1700009A RID: 154
	// (get) Token: 0x06000134 RID: 308 RVA: 0x000466DC File Offset: 0x000448DC
	// (set) Token: 0x06000135 RID: 309 RVA: 0x00046704 File Offset: 0x00044904
	public bool Boolean_6
	{
		get
		{
			return (this.GClass28_0.GClass25_0.UInt16_3 & 8192) > 0;
		}
		private set
		{
		}
	}

	// Token: 0x1700009B RID: 155
	// (get) Token: 0x06000136 RID: 310 RVA: 0x00046714 File Offset: 0x00044914
	// (set) Token: 0x06000137 RID: 311 RVA: 0x00046704 File Offset: 0x00044904
	public bool Boolean_7
	{
		get
		{
			return (this.GClass28_0.GClass25_0.UInt16_3 & 2) > 0;
		}
		private set
		{
		}
	}

	// Token: 0x1700009C RID: 156
	// (get) Token: 0x06000138 RID: 312 RVA: 0x00046738 File Offset: 0x00044938
	// (set) Token: 0x06000139 RID: 313 RVA: 0x00046704 File Offset: 0x00044904
	public bool Boolean_8
	{
		get
		{
			return this.X509Certificate2_0 != null;
		}
		private set
		{
		}
	}

	// Token: 0x0600013A RID: 314 RVA: 0x00046750 File Offset: 0x00044950
	public bool method_3(bool bool_6)
	{
		return this.Boolean_8 && GClass18.smethod_25(this.X509Certificate2_0, bool_6);
	}

	// Token: 0x1700009D RID: 157
	// (get) Token: 0x0600013B RID: 315 RVA: 0x00046774 File Offset: 0x00044974
	// (set) Token: 0x0600013C RID: 316 RVA: 0x00046788 File Offset: 0x00044988
	public bool Boolean_9 { get; private set; }

	// Token: 0x1700009E RID: 158
	// (get) Token: 0x0600013D RID: 317 RVA: 0x0004679C File Offset: 0x0004499C
	// (set) Token: 0x0600013E RID: 318 RVA: 0x00046704 File Offset: 0x00044904
	public bool Boolean_10
	{
		get
		{
			return !this.Boolean_9;
		}
		private set
		{
		}
	}

	// Token: 0x1700009F RID: 159
	// (get) Token: 0x0600013F RID: 319 RVA: 0x000467B4 File Offset: 0x000449B4
	// (set) Token: 0x06000140 RID: 320 RVA: 0x000467C8 File Offset: 0x000449C8
	public GClass23 GClass23_0 { get; private set; }

	// Token: 0x170000A0 RID: 160
	// (get) Token: 0x06000141 RID: 321 RVA: 0x000467DC File Offset: 0x000449DC
	// (set) Token: 0x06000142 RID: 322 RVA: 0x000467F0 File Offset: 0x000449F0
	public GClass28 GClass28_0 { get; private set; }

	// Token: 0x170000A1 RID: 161
	// (get) Token: 0x06000143 RID: 323 RVA: 0x00046804 File Offset: 0x00044A04
	// (set) Token: 0x06000144 RID: 324 RVA: 0x00046818 File Offset: 0x00044A18
	public GClass31[] GClass31_0 { get; private set; }

	// Token: 0x170000A2 RID: 162
	// (get) Token: 0x06000145 RID: 325 RVA: 0x0004682C File Offset: 0x00044A2C
	// (set) Token: 0x06000146 RID: 326 RVA: 0x00046840 File Offset: 0x00044A40
	public GClass30 GClass30_0 { get; private set; }

	// Token: 0x170000A3 RID: 163
	// (get) Token: 0x06000147 RID: 327 RVA: 0x00046854 File Offset: 0x00044A54
	// (set) Token: 0x06000148 RID: 328 RVA: 0x00046868 File Offset: 0x00044A68
	public string String_0 { get; private set; }

	// Token: 0x170000A4 RID: 164
	// (get) Token: 0x06000149 RID: 329 RVA: 0x0004687C File Offset: 0x00044A7C
	// (set) Token: 0x0600014A RID: 330 RVA: 0x00046890 File Offset: 0x00044A90
	public GClass24 GClass24_0 { get; private set; }

	// Token: 0x170000A5 RID: 165
	// (get) Token: 0x0600014B RID: 331 RVA: 0x000468A4 File Offset: 0x00044AA4
	// (set) Token: 0x0600014C RID: 332 RVA: 0x000468B8 File Offset: 0x00044AB8
	public GClass27[] GClass27_0 { get; private set; }

	// Token: 0x170000A6 RID: 166
	// (get) Token: 0x0600014D RID: 333 RVA: 0x000468CC File Offset: 0x00044ACC
	// (set) Token: 0x0600014E RID: 334 RVA: 0x000468E0 File Offset: 0x00044AE0
	public GClass14[] GClass14_0 { get; private set; }

	// Token: 0x170000A7 RID: 167
	// (get) Token: 0x0600014F RID: 335 RVA: 0x000468F4 File Offset: 0x00044AF4
	// (set) Token: 0x06000150 RID: 336 RVA: 0x00046908 File Offset: 0x00044B08
	public GClass15[] GClass15_0 { get; private set; }

	// Token: 0x170000A8 RID: 168
	// (get) Token: 0x06000151 RID: 337 RVA: 0x0004691C File Offset: 0x00044B1C
	// (set) Token: 0x06000152 RID: 338 RVA: 0x00046930 File Offset: 0x00044B30
	public GClass21 GClass21_0 { get; private set; }

	// Token: 0x170000A9 RID: 169
	// (get) Token: 0x06000153 RID: 339 RVA: 0x00046944 File Offset: 0x00044B44
	// (set) Token: 0x06000154 RID: 340 RVA: 0x00046958 File Offset: 0x00044B58
	public GClass35 GClass35_0 { get; private set; }

	// Token: 0x170000AA RID: 170
	// (get) Token: 0x06000155 RID: 341 RVA: 0x0004696C File Offset: 0x00044B6C
	// (set) Token: 0x06000156 RID: 342 RVA: 0x00046980 File Offset: 0x00044B80
	public GClass36 GClass36_0 { get; private set; }

	// Token: 0x170000AB RID: 171
	// (get) Token: 0x06000157 RID: 343 RVA: 0x00046994 File Offset: 0x00044B94
	// (set) Token: 0x06000158 RID: 344 RVA: 0x000469A8 File Offset: 0x00044BA8
	private protected X509Certificate2 X509Certificate2_0 { protected get; private set; }

	// Token: 0x170000AC RID: 172
	// (get) Token: 0x06000159 RID: 345 RVA: 0x000469BC File Offset: 0x00044BBC
	// (set) Token: 0x0600015A RID: 346 RVA: 0x000469D0 File Offset: 0x00044BD0
	public GClass37 GClass37_0 { get; private set; }

	// Token: 0x170000AD RID: 173
	// (get) Token: 0x0600015B RID: 347 RVA: 0x000469E4 File Offset: 0x00044BE4
	// (set) Token: 0x0600015C RID: 348 RVA: 0x00046704 File Offset: 0x00044904
	public string String_1
	{
		get
		{
			string result;
			if ((result = this.string_0) == null)
			{
				result = (this.string_0 = this.method_23());
			}
			return result;
		}
		private set
		{
		}
	}

	// Token: 0x170000AE RID: 174
	// (get) Token: 0x0600015D RID: 349 RVA: 0x00046A0C File Offset: 0x00044C0C
	// (set) Token: 0x0600015E RID: 350 RVA: 0x00046704 File Offset: 0x00044904
	public string String_2
	{
		get
		{
			string result;
			if ((result = this.string_1) == null)
			{
				result = (this.string_1 = this.method_24());
			}
			return result;
		}
		private set
		{
		}
	}

	// Token: 0x170000AF RID: 175
	// (get) Token: 0x0600015F RID: 351 RVA: 0x00046A34 File Offset: 0x00044C34
	// (set) Token: 0x06000160 RID: 352 RVA: 0x00046A48 File Offset: 0x00044C48
	public string String_3 { get; private set; }

	// Token: 0x06000161 RID: 353 RVA: 0x00046A5C File Offset: 0x00044C5C
	public GClass13 method_4()
	{
		if (this.X509Certificate2_0 == null)
		{
			return null;
		}
		return new GClass13(this.X509Certificate2_0);
	}

	// Token: 0x06000162 RID: 354 RVA: 0x00046A80 File Offset: 0x00044C80
	private GClass36 method_5(byte[] byte_0, uint uint_0)
	{
		GClass36 gclass = new GClass36(byte_0, (int)uint_0);
		if (gclass.UInt16_1 == 2)
		{
			byte[] byte_ = gclass.Byte_0;
			this.X509Certificate2_0 = new X509Certificate2(byte_);
			try
			{
				this.GClass37_0 = new GClass37(this.X509Certificate2_0);
			}
			catch
			{
				this.GClass37_0 = null;
			}
		}
		return gclass;
	}

	// Token: 0x06000163 RID: 355 RVA: 0x00046AE0 File Offset: 0x00044CE0
	private GClass36 method_6(BinaryReader binaryReader_0, uint uint_0)
	{
		GClass36 gclass = new GClass36(binaryReader_0, (int)uint_0);
		if (gclass.UInt16_1 == 2)
		{
			byte[] byte_ = gclass.Byte_0;
			this.X509Certificate2_0 = new X509Certificate2(byte_);
			try
			{
				this.GClass37_0 = new GClass37(this.X509Certificate2_0);
			}
			catch
			{
				this.GClass37_0 = null;
			}
		}
		return gclass;
	}

	// Token: 0x06000164 RID: 356 RVA: 0x00046B40 File Offset: 0x00044D40
	private GClass15[] method_7(byte[] byte_0, GClass27[] gclass27_1, GClass31[] gclass31_1)
	{
		List<GClass15> list = new List<GClass15>();
		uint num = this.Boolean_9 ? 8U : 4U;
		ulong num2 = this.Boolean_9 ? 9223372036854775808UL : 2147483648UL;
		ulong num3 = this.Boolean_9 ? 9223372036854775807UL : 2147483647UL;
		foreach (GClass27 gclass in gclass27_1)
		{
			string text = GClass18.smethod_12((ulong)GClass18.smethod_10(gclass.UInt32_3, gclass31_1), byte_0);
			uint num4 = (gclass.UInt32_0 != 0U) ? gclass.UInt32_0 : gclass.UInt32_4;
			if (num4 != 0U)
			{
				uint num5 = GClass18.smethod_10(num4, gclass31_1);
				if (num5 > 0U && (ulong)num5 < (ulong)((long)byte_0.Length))
				{
					uint num6 = 0U;
					while ((ulong)num6 < (ulong)((long)GClass17.int_3))
					{
						GClass32 gclass2 = new GClass32(byte_0, (int)(num5 + num6 * num), this.Boolean_9);
						if (gclass2.UInt64_0 == 0UL)
						{
							break;
						}
						if ((gclass2.UInt64_1 & num2) != num2)
						{
							int num7 = (int)GClass18.smethod_11(gclass2.UInt64_0, gclass31_1);
							if (num7 < 0 || num7 >= byte_0.Length)
							{
								break;
							}
							GClass26 gclass3 = new GClass26(byte_0, GClass18.smethod_11(gclass2.UInt64_0, gclass31_1));
							list.Add(new GClass15(gclass3.String_0, text, gclass3.UInt16_0, 0UL));
						}
						else
						{
							list.Add(new GClass15(null, text, (ushort)(gclass2.UInt64_1 & num3), 0UL));
						}
						num6 += 1U;
					}
				}
			}
		}
		return list.ToArray();
	}

	// Token: 0x06000165 RID: 357 RVA: 0x00046CDC File Offset: 0x00044EDC
	private GClass15[] method_8(BinaryReader binaryReader_0, GClass27[] gclass27_1, GClass31[] gclass31_1)
	{
		List<GClass15> list = new List<GClass15>();
		uint num = this.Boolean_9 ? 8U : 4U;
		ulong num2 = this.Boolean_9 ? 9223372036854775808UL : 2147483648UL;
		ulong num3 = this.Boolean_9 ? 9223372036854775807UL : 2147483647UL;
		byte[] array = new byte[GClass17.int_0];
		byte[] array2 = new byte[GClass17.int_1 + 2];
		int num4 = 50;
		byte[] array3 = new byte[(ulong)num * 50UL];
		foreach (GClass27 gclass in gclass27_1)
		{
			uint num5 = (gclass.UInt32_0 != 0U) ? gclass.UInt32_0 : gclass.UInt32_4;
			if (num5 != 0U)
			{
				uint num6 = GClass18.smethod_10(num5, gclass31_1);
				if ((ulong)num6 < (ulong)binaryReader_0.BaseStream.Length)
				{
					uint num7 = GClass18.smethod_10(gclass.UInt32_3, gclass31_1);
					string text = null;
					if ((ulong)num7 < (ulong)binaryReader_0.BaseStream.Length)
					{
						binaryReader_0.BaseStream.Seek((long)((ulong)num7), SeekOrigin.Begin);
						Array.Clear(array, 0, array.Length);
						if (binaryReader_0.Read(array, 0, array.Length) > 0)
						{
							text = GClass18.smethod_13(array);
						}
					}
					uint num8 = 0U;
					bool flag = true;
					while ((ulong)num8 < (ulong)((long)GClass17.int_3))
					{
						if (flag)
						{
							binaryReader_0.BaseStream.Seek((long)((ulong)(num6 + num8 * num)), SeekOrigin.Begin);
						}
						if ((long)binaryReader_0.Read(array3, 0, array3.Length) < (long)((ulong)num))
						{
							break;
						}
						uint num9 = 0U;
						while ((ulong)num9 < (ulong)((long)num4))
						{
							GClass32 gclass2 = new GClass32(array3, (int)num9, this.Boolean_9);
							if (gclass2.UInt64_0 == 0UL || gclass2.UInt64_0 >= (ulong)binaryReader_0.BaseStream.Length)
							{
								num8 = (uint)GClass17.int_3;
								break;
							}
							if ((gclass2.UInt64_1 & num2) == num2)
							{
								list.Add(new GClass15(null, text, (ushort)(gclass2.UInt64_1 & num3), 0UL));
								flag = false;
							}
							else
							{
								int num10 = (int)GClass18.smethod_11(gclass2.UInt64_0, gclass31_1);
								if (num10 < 0 || (long)num10 >= binaryReader_0.BaseStream.Length)
								{
									num8 = (uint)GClass17.int_3;
									break;
								}
								flag = true;
								binaryReader_0.BaseStream.Seek((long)num10, SeekOrigin.Begin);
								Array.Clear(array2, 0, array2.Length);
								if (binaryReader_0.Read(array2, 0, array2.Length) > 0)
								{
									GClass26 gclass3 = new GClass26(array2, 0UL);
									list.Add(new GClass15(gclass3.String_0, text, gclass3.UInt16_0, 0UL));
								}
							}
							num8 += 1U;
							num9 += num;
						}
					}
				}
			}
		}
		return list.ToArray();
	}

	// Token: 0x06000166 RID: 358 RVA: 0x00046F98 File Offset: 0x00045198
	private GClass15[] method_9(IntPtr intptr_0, IntPtr intptr_1, GClass27[] gclass27_1, bool bool_6 = true)
	{
		List<GClass15> list = new List<GClass15>();
		uint num = this.Boolean_9 ? 8U : 4U;
		ulong num2 = this.Boolean_9 ? 9223372036854775808UL : 2147483648UL;
		ulong num3 = this.Boolean_9 ? 9223372036854775807UL : 2147483647UL;
		byte[] array = new byte[GClass17.int_0];
		byte[] array2 = new byte[GClass17.int_1 + 2];
		byte[] array3 = new byte[(ulong)num * 50UL];
		byte[] array4 = new byte[(ulong)num * 50UL];
		uint num4 = 0U;
		uint num5 = 0U;
		uint num6 = 0U;
		bool flag = false;
		IntPtr intPtr = IntPtr.Zero;
		IntPtr intPtr2 = IntPtr.Zero;
		ulong ulong_ = 0UL;
		foreach (GClass27 gclass in gclass27_1)
		{
			uint num7;
			if (!bool_6)
			{
				num7 = 0U;
			}
			else
			{
				num7 = gclass.UInt32_4;
			}
			uint num8;
			if (gclass.UInt32_0 != 0U)
			{
				flag = false;
				num8 = gclass.UInt32_0;
			}
			else
			{
				flag = true;
				num8 = gclass.UInt32_4;
				num7 = 0U;
			}
			if (num8 != 0U)
			{
				IntPtr intPtr3 = (IntPtr)(intptr_1.ToInt64() + (long)((ulong)num8));
				if (num7 == 0U)
				{
					intPtr = IntPtr.Zero;
				}
				else
				{
					intPtr = (IntPtr)(intptr_1.ToInt64() + (long)((ulong)num7));
				}
				if (intPtr3 != IntPtr.Zero && GClass16.smethod_1(intptr_0, intPtr3))
				{
					IntPtr intPtr4 = (IntPtr)(intptr_1.ToInt64() + (long)((ulong)gclass.UInt32_3));
					string text = null;
					if (intPtr4 != IntPtr.Zero && GClass16.smethod_1(intptr_0, intPtr4))
					{
						Array.Clear(array, 0, array.Length);
						if (GClass16.ReadProcessMemory(intptr_0, intPtr4, array, (uint)array.Length, ref num4) && array.Length != 0)
						{
							text = GClass18.smethod_13(array);
						}
					}
					if (intPtr == IntPtr.Zero || !GClass16.smethod_1(intptr_0, intPtr))
					{
						intPtr = IntPtr.Zero;
					}
					uint num9 = 0U;
					while ((ulong)num9 < (ulong)((long)GClass17.int_3))
					{
						IntPtr intptr_2 = (IntPtr)(intPtr3.ToInt64() + (long)((ulong)(num9 * num)));
						if (intPtr3 == IntPtr.Zero || !GClass16.smethod_1(intptr_0, intptr_2) || !GClass16.ReadProcessMemory(intptr_0, intptr_2, array3, (uint)array3.Length, ref num5) || num5 < num)
						{
							break;
						}
						if (!(intPtr != IntPtr.Zero))
						{
							num6 = 0U;
							intPtr2 = IntPtr.Zero;
						}
						else
						{
							intPtr2 = (IntPtr)(intPtr.ToInt64() + (long)((ulong)(num9 * num)));
							if (!(intPtr2 == IntPtr.Zero) && GClass16.smethod_1(intptr_0, intPtr2))
							{
								if (!GClass16.ReadProcessMemory(intptr_0, intPtr2, array4, (uint)array4.Length, ref num6) || num6 < num)
								{
									intPtr2 = IntPtr.Zero;
									num6 = 0U;
								}
							}
							else
							{
								intPtr2 = IntPtr.Zero;
								num6 = 0U;
							}
						}
						for (uint num10 = 0U; num10 < num5; num10 += num)
						{
							GClass32 gclass2 = new GClass32(array3, (int)num10, this.Boolean_9);
							if (gclass2.UInt64_0 == 0UL)
							{
								num9 = (uint)GClass17.int_3;
								break;
							}
							if ((gclass2.UInt64_1 & num2) == num2)
							{
								if (num10 < num6)
								{
									try
									{
										GClass32 gclass3 = new GClass32(array4, (int)num10, this.Boolean_9);
										if (gclass3.UInt64_0 != 0UL && GClass16.smethod_1(intptr_0, (IntPtr)((long)gclass3.UInt64_0)))
										{
											ulong_ = gclass3.UInt64_0;
										}
										else
										{
											num6 = 0U;
											ulong_ = 0UL;
										}
										goto IL_4AD;
									}
									catch
									{
										num6 = 0U;
										ulong_ = 0UL;
										goto IL_4AD;
									}
									goto IL_34B;
								}
								goto IL_34B;
								IL_4AD:
								list.Add(new GClass15(null, text, (ushort)(gclass2.UInt64_1 & num3), ulong_));
								goto IL_44E;
								IL_34B:
								ulong_ = 0UL;
								goto IL_4AD;
							}
							IntPtr intPtr5 = (IntPtr)((long)gclass2.UInt64_0);
							if (!flag)
							{
								intPtr5 = (IntPtr)(intptr_1.ToInt64() + intPtr5.ToInt64());
							}
							if (intPtr5 == IntPtr.Zero || !GClass16.smethod_1(intptr_0, intPtr5))
							{
								num9 = (uint)GClass17.int_3;
								break;
							}
							Array.Clear(array2, 0, array2.Length);
							if (GClass16.ReadProcessMemory(intptr_0, intPtr5, array2, (uint)array2.Length, ref num4) && (ulong)num4 == (ulong)((long)array2.Length))
							{
								GClass26 gclass4 = new GClass26(array2, 0UL);
								if (num10 < num6)
								{
									try
									{
										GClass32 gclass3 = new GClass32(array4, (int)num10, this.Boolean_9);
										if (gclass3.UInt64_0 != 0UL && GClass16.smethod_1(intptr_0, (IntPtr)((long)gclass3.UInt64_0)))
										{
											ulong_ = gclass3.UInt64_0;
										}
										else
										{
											num6 = 0U;
											ulong_ = 0UL;
										}
										goto IL_483;
									}
									catch
									{
										num6 = 0U;
										ulong_ = 0UL;
										goto IL_483;
									}
									goto IL_441;
								}
								goto IL_441;
								IL_483:
								list.Add(new GClass15(gclass4.String_0, text, gclass4.UInt16_0, ulong_));
								goto IL_44E;
								IL_441:
								ulong_ = 0UL;
								goto IL_483;
							}
							num9 = (uint)GClass17.int_3;
							break;
							IL_44E:
							num9 += 1U;
						}
					}
				}
			}
		}
		return list.ToArray();
	}

	// Token: 0x06000167 RID: 359 RVA: 0x00047490 File Offset: 0x00045690
	private GClass27[] method_10(byte[] byte_0, uint uint_0, GClass31[] gclass31_1)
	{
		List<GClass27> list = new List<GClass27>();
		uint num = 0U;
		while ((ulong)num < (ulong)((long)GClass17.int_2))
		{
			GClass27 gclass = new GClass27(byte_0, (int)((ulong)uint_0 + (ulong)((long)GClass27.int_0 * (long)((ulong)num))));
			if (gclass.UInt32_0 == 0U && gclass.UInt32_2 == 0U && gclass.UInt32_3 == 0U && gclass.UInt32_4 == 0U)
			{
				break;
			}
			list.Add(gclass);
			num += 1U;
		}
		return list.ToArray();
	}

	// Token: 0x06000168 RID: 360 RVA: 0x000474F8 File Offset: 0x000456F8
	private GClass27[] method_11(BinaryReader binaryReader_0, uint uint_0, GClass31[] gclass31_1)
	{
		if ((ulong)uint_0 < (ulong)binaryReader_0.BaseStream.Length)
		{
			List<GClass27> list = new List<GClass27>();
			uint num = 0U;
			byte[] array = new byte[GClass27.int_0];
			binaryReader_0.BaseStream.Seek((long)((ulong)uint_0), SeekOrigin.Begin);
			while ((ulong)num < (ulong)((long)GClass17.int_2))
			{
				if (binaryReader_0.Read(array, 0, array.Length) == array.Length)
				{
					GClass27 gclass = new GClass27(array, 0);
					if (gclass.UInt32_0 != 0U || gclass.UInt32_2 != 0U || gclass.UInt32_3 != 0U || gclass.UInt32_4 != 0U)
					{
						list.Add(gclass);
						num += 1U;
						continue;
					}
				}
				IL_8A:
				return list.ToArray();
			}
			goto IL_8A;
		}
		throw new IOException();
	}

	// Token: 0x06000169 RID: 361 RVA: 0x00047598 File Offset: 0x00045798
	private GClass27[] method_12(IntPtr intptr_0, IntPtr intptr_1, IntPtr intptr_2)
	{
		if (intptr_0 == IntPtr.Zero)
		{
			throw new IOException();
		}
		IntPtr intptr_3 = (IntPtr)(intptr_1.ToInt64() + intptr_2.ToInt64());
		if (GClass16.smethod_1(intptr_0, intptr_3))
		{
			List<GClass27> list = new List<GClass27>();
			uint num = 0U;
			byte[] array = new byte[GClass27.int_0];
			uint num2 = 0U;
			while ((ulong)num < (ulong)((long)GClass17.int_2) && GClass16.ReadProcessMemory(intptr_0, intptr_3, array, (uint)array.Length, ref num2))
			{
				if ((ulong)num2 != (ulong)((long)array.Length))
				{
					break;
				}
				GClass27 gclass = new GClass27(array, 0);
				if (gclass.UInt32_0 == 0U && gclass.UInt32_2 == 0U && gclass.UInt32_3 == 0U && gclass.UInt32_4 == 0U)
				{
					break;
				}
				list.Add(gclass);
				num += 1U;
				intptr_3 = (IntPtr)(intptr_3.ToInt64() + (long)array.Length);
			}
			return list.ToArray();
		}
		throw new IOException();
	}

	// Token: 0x0600016A RID: 362 RVA: 0x00047670 File Offset: 0x00045870
	private GClass14[] method_13(byte[] byte_0, GClass24 gclass24_1, GClass31[] gclass31_1)
	{
		GClass14[] array = new GClass14[gclass24_1.UInt32_4];
		uint num = GClass18.smethod_10(gclass24_1.UInt32_6, gclass31_1);
		uint num2 = GClass18.smethod_10(gclass24_1.UInt32_8, gclass31_1);
		uint num3 = GClass18.smethod_10(gclass24_1.UInt32_7, gclass31_1);
		BitConverter.ToUInt32(byte_0, (int)num);
		uint num4 = 0U;
		while ((ulong)num4 < (ulong)((long)array.Length))
		{
			uint num5 = num4 + gclass24_1.UInt32_3;
			uint uint_ = BitConverter.ToUInt32(byte_0, (int)(num + 4U * num4));
			array[(int)num4] = new GClass14(null, uint_, (ushort)num5);
			num4 += 1U;
		}
		if ((ulong)num3 < (ulong)((long)byte_0.Length) && (ulong)num2 < (ulong)((long)byte_0.Length))
		{
			byte[] array2 = new byte[GClass17.int_0];
			for (uint num6 = 0U; num6 < gclass24_1.UInt32_5; num6 += 1U)
			{
				uint num7 = BitConverter.ToUInt32(byte_0, (int)(num3 + 4U * num6));
				if (num7 == 0U && (ulong)num7 >= (ulong)((long)byte_0.Length))
				{
					break;
				}
				uint num8 = GClass18.smethod_10(num7, gclass31_1);
				if (num8 == 0U && (ulong)num8 >= (ulong)((long)byte_0.Length))
				{
					break;
				}
				uint num9 = (uint)((long)byte_0.Length - (long)((ulong)num8));
				if ((ulong)num9 > (ulong)((long)GClass17.int_0))
				{
					num9 = (uint)GClass17.int_0;
				}
				Array.Clear(array2, 0, array2.Length);
				Array.Copy(byte_0, (long)((ulong)num8), array2, 0L, (long)((ulong)num9));
				string text = GClass18.smethod_13(array2);
				uint num10 = (uint)BitConverter.ToUInt16(byte_0, (int)(num2 + 2U * num6));
				if ((ulong)num10 > (ulong)((long)array.Length))
				{
					break;
				}
				array[(int)num10] = new GClass14(text, array[(int)num10].UInt32_0, array[(int)num10].UInt16_0);
			}
		}
		return array;
	}

	// Token: 0x0600016B RID: 363 RVA: 0x000477E8 File Offset: 0x000459E8
	private GClass14[] method_14(BinaryReader binaryReader_0, GClass24 gclass24_1, GClass31[] gclass31_1)
	{
		if (gclass24_1.UInt32_4 == 0U)
		{
			throw new IOException(<Module>.DeserializeFromByteArray2<string>(1272864780U));
		}
		GClass14[] array = new GClass14[gclass24_1.UInt32_4];
		uint num = GClass18.smethod_10(gclass24_1.UInt32_6, gclass31_1);
		uint num2 = GClass18.smethod_10(gclass24_1.UInt32_8, gclass31_1);
		uint num3 = GClass18.smethod_10(gclass24_1.UInt32_7, gclass31_1);
		binaryReader_0.BaseStream.Seek((long)((ulong)num), SeekOrigin.Begin);
		byte[] array2 = new byte[gclass24_1.UInt32_4 * 4U];
		if (binaryReader_0.Read(array2, 0, array2.Length) == array2.Length)
		{
			uint num4 = 0U;
			while ((ulong)num4 < (ulong)((long)array.Length))
			{
				uint num5 = num4 + gclass24_1.UInt32_3;
				uint uint_ = BitConverter.ToUInt32(array2, (int)(4U * num4));
				array[(int)num4] = new GClass14(null, uint_, (ushort)num5);
				num4 += 1U;
			}
			if ((ulong)num3 < (ulong)binaryReader_0.BaseStream.Length && (ulong)num2 < (ulong)binaryReader_0.BaseStream.Length)
			{
				binaryReader_0.BaseStream.Seek((long)((ulong)num3), SeekOrigin.Begin);
				if (gclass24_1.UInt32_5 > gclass24_1.UInt32_4)
				{
					array2 = new byte[gclass24_1.UInt32_5 * 4U];
				}
				else
				{
					Array.Clear(array2, 0, array2.Length);
				}
				if (binaryReader_0.Read(array2, 0, array2.Length) == array2.Length)
				{
					byte[] array3 = new byte[gclass24_1.UInt32_5 * 2U];
					binaryReader_0.BaseStream.Seek((long)((ulong)num2), SeekOrigin.Begin);
					if (binaryReader_0.Read(array3, 0, array3.Length) == array3.Length)
					{
						byte[] array4 = new byte[GClass17.int_0];
						for (num4 = 0U; num4 < gclass24_1.UInt32_5; num4 += 1U)
						{
							uint num6 = BitConverter.ToUInt32(array2, (int)(4U * num4));
							if (num6 == 0U && (ulong)num6 >= (ulong)binaryReader_0.BaseStream.Length)
							{
								break;
							}
							uint num7 = GClass18.smethod_10(num6, gclass31_1);
							if (num7 == 0U && (ulong)num7 >= (ulong)binaryReader_0.BaseStream.Length)
							{
								break;
							}
							binaryReader_0.BaseStream.Seek((long)((ulong)num7), SeekOrigin.Begin);
							Array.Clear(array4, 0, array4.Length);
							binaryReader_0.Read(array4, 0, array4.Length);
							string text = GClass18.smethod_13(array4);
							uint num8 = (uint)BitConverter.ToUInt16(array3, (int)(2U * num4));
							array[(int)num8] = new GClass14(text, array[(int)num8].UInt32_0, array[(int)num8].UInt16_0);
						}
					}
				}
			}
			return array;
		}
		throw new IOException(<Module>.DeserializeFromByteArrayV2<string>(496484128U));
	}

	// Token: 0x0600016C RID: 364 RVA: 0x00047A38 File Offset: 0x00045C38
	private GClass14[] method_15(IntPtr intptr_0, IntPtr intptr_1, GClass24 gclass24_1)
	{
		if (gclass24_1.UInt32_4 == 0U)
		{
			throw new IOException(<Module>.DeserializeFromByteArray<string>(3115691355U));
		}
		GClass14[] array = new GClass14[gclass24_1.UInt32_4];
		IntPtr intptr_2 = (IntPtr)(intptr_1.ToInt64() + (long)((ulong)gclass24_1.UInt32_6));
		IntPtr intptr_3 = (IntPtr)(intptr_1.ToInt64() + (long)((ulong)gclass24_1.UInt32_8));
		IntPtr intptr_4 = (IntPtr)(intptr_1.ToInt64() + (long)((ulong)gclass24_1.UInt32_7));
		if (!GClass16.smethod_1(intptr_0, intptr_2))
		{
			throw new IOException(<Module>.DeserializeFromByteArray<string>(2253104964U));
		}
		byte[] array2 = new byte[gclass24_1.UInt32_4 * 4U];
		uint num = 0U;
		if (GClass16.ReadProcessMemory(intptr_0, intptr_2, array2, (uint)array2.Length, ref num) && (ulong)num == (ulong)((long)array2.Length))
		{
			uint num2 = 0U;
			while ((ulong)num2 < (ulong)((long)array.Length))
			{
				uint num3 = num2 + gclass24_1.UInt32_3;
				uint uint_ = BitConverter.ToUInt32(array2, (int)(4U * num2));
				array[(int)num2] = new GClass14(null, uint_, (ushort)num3);
				num2 += 1U;
			}
			if (intptr_4.ToInt64() >= 0L && GClass16.smethod_1(intptr_0, intptr_4) && GClass16.smethod_1(intptr_0, intptr_3))
			{
				if (gclass24_1.UInt32_5 > gclass24_1.UInt32_4)
				{
					array2 = new byte[gclass24_1.UInt32_5 * 4U];
				}
				else
				{
					Array.Clear(array2, 0, array2.Length);
				}
				if (GClass16.ReadProcessMemory(intptr_0, intptr_4, array2, (uint)array2.Length, ref num))
				{
					if ((ulong)num == (ulong)((long)array2.Length))
					{
						byte[] array3 = new byte[gclass24_1.UInt32_5 * 2U];
						if (GClass16.ReadProcessMemory(intptr_0, intptr_3, array3, (uint)array3.Length, ref num) && (ulong)num == (ulong)((long)array3.Length))
						{
							byte[] array4 = new byte[GClass17.int_0];
							for (num2 = 0U; num2 < gclass24_1.UInt32_5; num2 += 1U)
							{
								IntPtr intPtr = (IntPtr)(intptr_1.ToInt64() + (long)((ulong)BitConverter.ToUInt32(array2, (int)(4U * num2))));
								if (intPtr == IntPtr.Zero || !GClass16.smethod_1(intptr_0, intPtr))
								{
									break;
								}
								Array.Clear(array4, 0, array4.Length);
								if (GClass16.ReadProcessMemory(intptr_0, intPtr, array4, (uint)array4.Length, ref num))
								{
									string text = GClass18.smethod_13(array4);
									uint num4 = (uint)BitConverter.ToUInt16(array3, (int)(2U * num2));
									array[(int)num4] = new GClass14(text, array[(int)num4].UInt32_0, array[(int)num4].UInt16_0);
								}
							}
						}
					}
				}
			}
			return array;
		}
		throw new IOException(<Module>.DeserializeFromByteArray<string>(2253104964U));
	}

	// Token: 0x0600016D RID: 365 RVA: 0x00047C9C File Offset: 0x00045E9C
	private GClass31[] method_16(byte[] byte_0, ushort ushort_0, int int_4, uint uint_0, bool bool_6)
	{
		if (ushort_0 == 0)
		{
			throw new ArgumentException(<Module>.DeserializeFromByteArray2<string>(4032390855U));
		}
		GClass31[] array = new GClass31[(int)ushort_0];
		for (uint num = 0U; num < (uint)ushort_0; num += 1U)
		{
			array[(int)num] = new GClass31(byte_0, (int)((long)int_4 + (long)((ulong)(num * GClass31.uint_0))), uint_0, bool_6);
		}
		return array;
	}

	// Token: 0x0600016E RID: 366 RVA: 0x00047CEC File Offset: 0x00045EEC
	private GClass31[] method_17(BinaryReader binaryReader_0, ushort ushort_0, int int_4, uint uint_0, bool bool_6)
	{
		if (ushort_0 == 0)
		{
			throw new ArgumentException(<Module>.DeserializeFromByteArray2<string>(4032390855U));
		}
		binaryReader_0.BaseStream.Seek((long)int_4, SeekOrigin.Begin);
		GClass31[] array = new GClass31[(int)ushort_0];
		for (uint num = 0U; num < (uint)ushort_0; num += 1U)
		{
			array[(int)num] = new GClass31(binaryReader_0, 0, uint_0, bool_6);
		}
		return array;
	}

	// Token: 0x0600016F RID: 367 RVA: 0x00047D40 File Offset: 0x00045F40
	private GClass31[] method_18(IntPtr intptr_0, ushort ushort_0, IntPtr intptr_1, uint uint_0, bool bool_6)
	{
		if (ushort_0 == 0)
		{
			throw new ArgumentException(<Module>.DeserializeFromByteArray3<string>(3366741903U));
		}
		GClass31[] array = new GClass31[(int)ushort_0];
		for (uint num = 0U; num < (uint)ushort_0; num += 1U)
		{
			array[(int)num] = new GClass31(intptr_0, (IntPtr)(intptr_1.ToInt64() + (long)((ulong)(num * GClass31.uint_0))), uint_0, bool_6);
		}
		return array;
	}

	// Token: 0x06000170 RID: 368 RVA: 0x00047D98 File Offset: 0x00045F98
	private GClass30 method_19(byte[] byte_0, GClass31[] gclass31_1, uint uint_0, GClass20 gclass20_0, bool bool_6)
	{
		if (gclass31_1 != null && gclass31_1.Length != 0)
		{
			int i = 0;
			long num = (long)byte_0.Length;
			if (gclass20_0.UInt32_0 > 0U && gclass20_0.UInt32_1 > 0U)
			{
				long num2 = (long)((ulong)GClass18.smethod_10(gclass20_0.UInt32_0, this.GClass31_0));
				if (num2 > 0L)
				{
					num = num2;
				}
			}
			long num3 = (long)((ulong)(gclass31_1[0].UInt32_4 + gclass31_1[0].UInt32_3));
			long num4;
			for (i++; i < gclass31_1.Length; i++)
			{
				num4 = (long)((ulong)(gclass31_1[i].UInt32_4 + gclass31_1[i].UInt32_3));
				if (num4 > num3)
				{
					num3 = num4;
				}
			}
			if (uint_0 > 0U && num3 % (long)((ulong)uint_0) != 0L)
			{
				int num5 = (int)((double)num3 / uint_0);
				num5++;
				num3 = (long)((ulong)uint_0 * (ulong)((long)num5));
			}
			num4 = num - num3;
			if (num4 != (long)byte_0.Length)
			{
				if (num4 > 0L)
				{
					return new GClass30(byte_0, num3, num4, bool_6);
				}
			}
			return null;
		}
		throw new ArgumentException(<Module>.DeserializeFromByteArray<string>(2403406250U));
	}

	// Token: 0x06000171 RID: 369 RVA: 0x00047E84 File Offset: 0x00046084
	private GClass30 method_20(BinaryReader binaryReader_0, GClass31[] gclass31_1, uint uint_0, GClass20 gclass20_0, bool bool_6)
	{
		if (gclass31_1 == null || gclass31_1.Length == 0)
		{
			throw new ArgumentException(<Module>.DeserializeFromByteArray3<string>(2015444589U));
		}
		int i = 0;
		long num = binaryReader_0.BaseStream.Length;
		if (gclass20_0.UInt32_0 > 0U && gclass20_0.UInt32_1 > 0U)
		{
			long num2 = (long)((ulong)GClass18.smethod_10(gclass20_0.UInt32_0, this.GClass31_0));
			if (num2 > 0L)
			{
				num = num2;
			}
		}
		long num3 = (long)((ulong)(gclass31_1[0].UInt32_4 + gclass31_1[0].UInt32_3));
		long num4;
		for (i++; i < gclass31_1.Length; i++)
		{
			num4 = (long)((ulong)(gclass31_1[i].UInt32_4 + gclass31_1[i].UInt32_3));
			if (num4 > num3)
			{
				num3 = num4;
			}
		}
		if (uint_0 > 0U && num3 % (long)((ulong)uint_0) != 0L)
		{
			int num5 = (int)((double)num3 / uint_0);
			num5++;
			num3 = (long)((ulong)uint_0 * (ulong)((long)num5));
		}
		num4 = num - num3;
		if (num4 != binaryReader_0.BaseStream.Length && num4 > 0L)
		{
			return new GClass30(binaryReader_0, num3, num4, bool_6);
		}
		return null;
	}

	// Token: 0x06000172 RID: 370 RVA: 0x00047F7C File Offset: 0x0004617C
	private GClass21 method_21(byte[] byte_0, uint uint_0)
	{
		return new GClass21(byte_0, (int)uint_0);
	}

	// Token: 0x06000173 RID: 371 RVA: 0x00047F90 File Offset: 0x00046190
	private GClass21 method_22(BinaryReader binaryReader_0, uint uint_0)
	{
		return new GClass21(binaryReader_0, (int)uint_0);
	}

	// Token: 0x06000174 RID: 372 RVA: 0x00047FA4 File Offset: 0x000461A4
	public virtual string ToString()
	{
		List<string> list = new List<string>();
		list.Add(this.Boolean_9 ? <Module>.DeserializeFromByteArray3<string>(423071921U) : <Module>.DeserializeFromByteArray3<string>(1552324843U));
		string empty = string.Empty;
		try
		{
			empty = this.String_2;
			if (empty == null)
			{
				empty = string.Empty;
			}
		}
		catch
		{
		}
		list.Add(empty);
		list.Add(this.GClass28_0.GClass29_0.UInt16_8.ToString());
		list.Add(this.GClass28_0.GClass25_0.UInt32_0.ToString());
		list.Add(this.GClass28_0.GClass29_0.UInt32_11.ToString());
		string empty2 = string.Empty;
		try
		{
			empty2 = this.String_1;
			if (empty2 == null)
			{
				empty2 = string.Empty;
			}
		}
		catch
		{
		}
		list.Add(empty2);
		List<string> list2 = new List<string>();
		try
		{
			if (this.Boolean_2 && this.GClass15_0 != null)
			{
				Dictionary<string, string[]> dictionary = new Dictionary<string, string[]>
				{
					{
						Class14.String_176.ToLowerInvariant(),
						Class14.String_45
					},
					{
						Class14.String_132.ToLowerInvariant(),
						new string[]
						{
							Class14.String_157,
							Class14.String_44,
							Class14.String_147,
							Class14.String_163,
							Class14.String_56
						}
					},
					{
						Class14.String_172.ToLowerInvariant(),
						new string[]
						{
							Class14.String_86,
							Class14.String_102,
							Class14.String_108
						}
					}
				};
				int num = 0;
				foreach (KeyValuePair<string, string[]> keyValuePair in dictionary)
				{
					string b = keyValuePair.Key.ToLowerInvariant();
					foreach (GClass15 gclass in this.GClass15_0)
					{
						if (gclass.String_0 != null && gclass.String_1 != null && gclass.String_1.ToLowerInvariant() == b)
						{
							for (int j = 0; j < keyValuePair.Value.Length; j++)
							{
								if (gclass.String_0 == keyValuePair.Value[j])
								{
									list2.Add(string.Format(<Module>.DeserializeFromByteArrayV2<string>(3662114432U), num, j));
								}
							}
						}
					}
					num++;
				}
			}
		}
		catch
		{
		}
		list.Add(Class15.ListToString(list2, ';'));
		List<string> list3 = new List<string>();
		if (this.GClass35_0 != null && this.Boolean_4)
		{
			if (this.GClass35_0.String_1 == null)
			{
				list3.Add("");
			}
			else
			{
				list3.Add(Class15.SanitizeString(this.GClass35_0.String_1));
			}
			if (this.GClass35_0.String_0 != null)
			{
				list3.Add(Class15.SanitizeString(this.GClass35_0.String_0));
			}
			else
			{
				list3.Add("");
			}
		}
		list.Add(Class15.ListToString(list3, '!'));
		List<string> list4 = new List<string>();
		try
		{
			if (this.GClass31_0 != null)
			{
				foreach (GClass31 gclass2 in this.GClass31_0)
				{
					list4.Add(gclass2.ToString());
				}
			}
		}
		catch
		{
		}
		list.Add(Class15.ListToString(list4, ';'));
		string text = string.Empty;
		try
		{
			if (this.GClass30_0 != null)
			{
				text = this.GClass30_0.ToString();
				if (text == null)
				{
					text = string.Empty;
				}
			}
		}
		catch
		{
			text = string.Empty;
		}
		list.Add(text);
		if (this.String_0 != null)
		{
			list.Add(Class15.SanitizeString(this.String_0));
		}
		else
		{
			list.Add(Class14.String_215);
		}
		string s = Class15.ListToString(list, '|');
		return Convert.ToBase64String(Encoding.UTF8.GetBytes(s));
	}

	// Token: 0x06000175 RID: 373 RVA: 0x00048414 File Offset: 0x00046614
	public static bool smethod_0(string string_4)
	{
		return new GClass17(string_4, GEnum15.const_0).Boolean_0;
	}

	// Token: 0x06000176 RID: 374 RVA: 0x00048430 File Offset: 0x00046630
	public static bool smethod_1(IntPtr intptr_0, IntPtr intptr_1)
	{
		byte[] array = new byte[GClass23.int_0];
		uint num = 0U;
		if (intptr_0 == IntPtr.Zero || intptr_1 == IntPtr.Zero || !GClass16.smethod_1(intptr_0, intptr_1))
		{
			return false;
		}
		if (!GClass16.ReadProcessMemory(intptr_0, intptr_1, array, (uint)GClass23.int_0, ref num) || num != 64U)
		{
			return false;
		}
		GClass23 gclass = new GClass23(array);
		if (gclass.UInt16_0 != 23117)
		{
			return false;
		}
		IntPtr intptr_2 = (IntPtr)(intptr_1.ToInt64() + (long)((ulong)gclass.UInt32_0));
		if (GClass16.smethod_1(intptr_0, intptr_2))
		{
			if (GClass16.ReadProcessMemory(intptr_0, intptr_2, array, 2U, ref num))
			{
				if (num == 2U)
				{
					ushort num2 = BitConverter.ToUInt16(array, 0);
					if (num2 != 17744)
					{
						if (num2 != 17742 && num2 != 17740)
						{
							return num2 == 22604;
						}
					}
					return true;
				}
			}
			return false;
		}
		return false;
	}

	// Token: 0x06000177 RID: 375 RVA: 0x00048510 File Offset: 0x00046710
	public static bool IsFileExecutable(string string_4, bool bool_6 = false)
	{
		FileStream fileStream = null;
		BinaryReader binaryReader = null;
		try
		{
			string text = string_4;
			if (bool_6 && GClass49.IsCurrentProcessElevated())
			{
				string text2 = Class15.ComposePath();
				if (text.ToLowerInvariant().StartsWith(text2.ToLowerInvariant()))
				{
					text = Class15.ComposePath2() + text.Substring(text2.Length);
				}
			}
			if (text.Length <= GClass18.int_0 && !text.Contains(<Module>.DeserializeFromByteArrayV2<string>(2747505432U)))
			{
				try
				{
					fileStream = new FileStream(text, FileMode.Open, FileAccess.Read, FileShare.Read);
					goto IL_A3;
				}
				catch
				{
					fileStream = new FileStream(text, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
					goto IL_A3;
				}
			}
			try
			{
				fileStream = GClass39.smethod_2(text, FileMode.Open, FileAccess.Read, FileShare.Read);
			}
			catch
			{
				fileStream = GClass39.smethod_2(text, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			}
			IL_A3:
			int num = (int)fileStream.Length;
			if (num < GClass23.int_0)
			{
				return false;
			}
			byte[] array = new byte[GClass23.int_0];
			binaryReader = new BinaryReader(fileStream);
			if (binaryReader.Read(array, 0, GClass23.int_0) < GClass23.int_0)
			{
				return false;
			}
			GClass23 gclass = new GClass23(array);
			if (gclass.UInt16_0 != 23117)
			{
				return false;
			}
			if ((long)num >= (long)((ulong)(gclass.UInt32_0 + 4U)))
			{
				binaryReader.BaseStream.Seek((long)((ulong)gclass.UInt32_0), SeekOrigin.Begin);
				ushort num2 = binaryReader.ReadUInt16();
				return num2 == 17744 || num2 == 17742 || num2 == 17740 || num2 == 22604;
			}
			return false;
		}
		catch
		{
		}
		finally
		{
			if (binaryReader != null)
			{
				binaryReader.Close();
			}
			if (fileStream != null)
			{
				fileStream.Close();
			}
		}
		return false;
	}

	// Token: 0x06000178 RID: 376 RVA: 0x000486FC File Offset: 0x000468FC
	public static bool smethod_3(string string_4, bool bool_6 = false)
	{
		FileStream fileStream = null;
		BinaryReader binaryReader = null;
		bool result;
		try
		{
			string text = string_4;
			if (bool_6 && GClass49.IsCurrentProcessElevated())
			{
				string text2 = Class15.ComposePath();
				if (text.ToLowerInvariant().StartsWith(text2.ToLowerInvariant()))
				{
					text = Class15.ComposePath2() + text.Substring(text2.Length);
				}
			}
			if (text.Length <= GClass18.int_0 && !text.Contains(<Module>.DeserealizeFromByteArrayV2_1<string>(3037699330U)))
			{
				try
				{
					fileStream = new FileStream(text, FileMode.Open, FileAccess.Read, FileShare.Read);
					goto IL_A2;
				}
				catch
				{
					fileStream = new FileStream(text, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
					goto IL_A2;
				}
			}
			try
			{
				fileStream = GClass39.smethod_2(text, FileMode.Open, FileAccess.Read, FileShare.Read);
			}
			catch
			{
				fileStream = GClass39.smethod_2(text, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			}
			IL_A2:
			int num = (int)fileStream.Length;
			if (num < GClass23.int_0)
			{
				result = false;
			}
			else
			{
				byte[] array = new byte[GClass23.int_0];
				binaryReader = new BinaryReader(fileStream);
				if (binaryReader.Read(array, 0, GClass23.int_0) >= GClass23.int_0)
				{
					GClass23 gclass = new GClass23(array);
					if (gclass.UInt16_0 != 23117)
					{
						result = false;
					}
					else if ((long)num < (long)((ulong)(gclass.UInt32_0 + 6U)))
					{
						result = false;
					}
					else
					{
						binaryReader.BaseStream.Seek((long)((ulong)gclass.UInt32_0), SeekOrigin.Begin);
						array = new byte[6];
						binaryReader.Read(array, 0, 6);
						ushort num2 = BitConverter.ToUInt16(array, 0);
						if (num2 != 17744)
						{
							if (num2 != 17742)
							{
								if (num2 != 17740)
								{
									if (num2 != 22604)
									{
										return false;
									}
								}
							}
						}
						if (BitConverter.ToUInt16(array, 4) == 34404)
						{
							result = true;
						}
						else
						{
							result = false;
						}
					}
				}
				else
				{
					result = false;
				}
			}
		}
		finally
		{
			if (binaryReader != null)
			{
				binaryReader.Close();
			}
			if (fileStream != null)
			{
				fileStream.Close();
			}
		}
		return result;
	}

	// Token: 0x06000179 RID: 377 RVA: 0x00048900 File Offset: 0x00046B00
	public static bool smethod_4(string string_4, bool bool_6 = false)
	{
		FileStream fileStream = null;
		BinaryReader binaryReader = null;
		bool result;
		try
		{
			string text = string_4;
			if (bool_6 && GClass49.IsCurrentProcessElevated())
			{
				string text2 = Class15.ComposePath();
				if (text.ToLowerInvariant().StartsWith(text2.ToLowerInvariant()))
				{
					text = Class15.ComposePath2() + text.Substring(text2.Length);
				}
			}
			if (text.Length <= GClass18.int_0 && !text.Contains(<Module>.DeserealizeFromByteArrayV2_1<string>(3037699330U)))
			{
				try
				{
					fileStream = new FileStream(text, FileMode.Open, FileAccess.Read, FileShare.Read);
					goto IL_A2;
				}
				catch
				{
					fileStream = new FileStream(text, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
					goto IL_A2;
				}
			}
			try
			{
				fileStream = GClass39.smethod_2(text, FileMode.Open, FileAccess.Read, FileShare.Read);
			}
			catch
			{
				fileStream = GClass39.smethod_2(text, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			}
			IL_A2:
			int num = (int)fileStream.Length;
			if (num >= GClass23.int_0)
			{
				byte[] array = new byte[GClass23.int_0];
				binaryReader = new BinaryReader(fileStream);
				if (binaryReader.Read(array, 0, GClass23.int_0) < GClass23.int_0)
				{
					result = false;
				}
				else
				{
					GClass23 gclass = new GClass23(array);
					if (gclass.UInt16_0 != 23117)
					{
						result = false;
					}
					else if ((long)num < (long)((ulong)(gclass.UInt32_0 + 6U)))
					{
						result = false;
					}
					else
					{
						binaryReader.BaseStream.Seek((long)((ulong)gclass.UInt32_0), SeekOrigin.Begin);
						array = new byte[6];
						binaryReader.Read(array, 0, 6);
						ushort num2 = BitConverter.ToUInt16(array, 0);
						if (num2 != 17744)
						{
							if (num2 != 17742)
							{
								if (num2 != 17740)
								{
									if (num2 != 22604)
									{
										return false;
									}
								}
							}
						}
						if (BitConverter.ToUInt16(array, 4) == 332)
						{
							result = true;
						}
						else
						{
							result = false;
						}
					}
				}
			}
			else
			{
				result = false;
			}
		}
		finally
		{
			if (binaryReader != null)
			{
				binaryReader.Close();
			}
			if (fileStream != null)
			{
				fileStream.Close();
			}
		}
		return result;
	}

	// Token: 0x0600017A RID: 378 RVA: 0x00048B04 File Offset: 0x00046D04
	public string method_23()
	{
		if (this.GClass15_0 != null && this.GClass15_0.Length != 0)
		{
			List<string> list = new List<string>();
			foreach (GClass15 gclass in this.GClass15_0)
			{
				string text = gclass.String_1.Split(new char[]
				{
					'.'
				})[0];
				text += <Module>.DeserializeFromByteArrayV2<string>(1083635215U);
				if (gclass.String_0 == null)
				{
					if (!(gclass.String_1 == <Module>.DeserializeFromByteArrayV2<string>(3074963345U)))
					{
						if (!(gclass.String_1 == <Module>.DeserealizeFromByteArrayV2_1<string>(739273933U)))
						{
							if (!(gclass.String_1 == <Module>.DeserealizeFromByteArrayV2_1<string>(17683577U)))
							{
								text += <Module>.DeserializeFromByteArray2<string>(475881884U);
								text += gclass.UInt16_0.ToString();
							}
							else
							{
								text += Class7.smethod_0(Class7.Enum0.const_2, (uint)gclass.UInt16_0);
							}
						}
						else
						{
							text += Class7.smethod_0(Class7.Enum0.const_1, (uint)gclass.UInt16_0);
						}
					}
					else
					{
						text += Class7.smethod_0(Class7.Enum0.const_0, (uint)gclass.UInt16_0);
					}
				}
				else
				{
					text += gclass.String_0;
				}
				list.Add(text.ToLower());
			}
			string s = string.Join(<Module>.DeserealizeFromByteArrayV2_1<string>(3591060517U), list.ToArray());
			HashAlgorithm hashAlgorithm = MD5.Create();
			byte[] bytes = Encoding.ASCII.GetBytes(s);
			byte[] array2 = hashAlgorithm.ComputeHash(bytes);
			StringBuilder stringBuilder = new StringBuilder();
			for (int j = 0; j < array2.Length; j++)
			{
				stringBuilder.Append(array2[j].ToString(<Module>.DeserializeFromByteArray<string>(4071675807U)));
			}
			return stringBuilder.ToString();
		}
		return null;
	}

	// Token: 0x0600017B RID: 379 RVA: 0x00048CE0 File Offset: 0x00046EE0
	public string method_24()
	{
		if (this.GClass14_0 != null && this.GClass14_0.Length != 0)
		{
			List<string> list = new List<string>();
			foreach (GClass14 gclass in this.GClass14_0)
			{
				string text = "";
				if (gclass.String_0 != null)
				{
					text += gclass.String_0;
				}
				else
				{
					text += <Module>.DeserializeFromByteArrayV2<string>(1535732273U);
					text += gclass.UInt16_0.ToString();
				}
				list.Add(text.ToLower());
			}
			string s = string.Join(<Module>.DeserializeFromByteArray2<string>(854660504U), list.ToArray());
			HashAlgorithm hashAlgorithm = MD5.Create();
			byte[] bytes = Encoding.ASCII.GetBytes(s);
			byte[] array2 = hashAlgorithm.ComputeHash(bytes);
			StringBuilder stringBuilder = new StringBuilder();
			for (int j = 0; j < array2.Length; j++)
			{
				stringBuilder.Append(array2[j].ToString(<Module>.DeserializeFromByteArray2<string>(57677608U)));
			}
			return stringBuilder.ToString();
		}
		return null;
	}

	// Token: 0x0600017C RID: 380 RVA: 0x00048DF8 File Offset: 0x00046FF8
	public static bool smethod_5(IntPtr intptr_0, IntPtr intptr_1)
	{
		try
		{
			GClass17 gclass = new GClass17(intptr_0, intptr_1, GEnum15.const_0);
			if (gclass.GClass28_0 != null && gclass.GClass31_0 != null)
			{
				for (int i = 0; i < gclass.GClass31_0.Length; i++)
				{
					if ((gclass.GClass31_0[i].UInt32_7 & 536870912U) == 536870912U || (gclass.GClass31_0[i].UInt32_7 & 32U) == 32U)
					{
						return true;
					}
				}
			}
		}
		catch
		{
		}
		return false;
	}

	// Token: 0x040001A1 RID: 417
	private static readonly int int_0 = 1024;

	// Token: 0x040001A2 RID: 418
	private static readonly int int_1 = 1024;

	// Token: 0x040001A3 RID: 419
	private static readonly int int_2 = 2048;

	// Token: 0x040001A4 RID: 420
	private static readonly int int_3 = 4096;

	// Token: 0x040001A5 RID: 421
	private static readonly long long_0 = 5242880L;

	// Token: 0x040001A6 RID: 422
	private string string_0;

	// Token: 0x040001A7 RID: 423
	private string string_1;

	// Token: 0x040001A8 RID: 424
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x040001A9 RID: 425
	[CompilerGenerated]
	private bool bool_1;

	// Token: 0x040001AA RID: 426
	[CompilerGenerated]
	private bool bool_2;

	// Token: 0x040001AB RID: 427
	[CompilerGenerated]
	private bool bool_3;

	// Token: 0x040001AC RID: 428
	[CompilerGenerated]
	private bool bool_4;

	// Token: 0x040001AD RID: 429
	[CompilerGenerated]
	private bool bool_5;

	// Token: 0x040001AE RID: 430
	[CompilerGenerated]
	private GClass23 gclass23_0;

	// Token: 0x040001AF RID: 431
	[CompilerGenerated]
	private GClass28 gclass28_0;

	// Token: 0x040001B0 RID: 432
	[CompilerGenerated]
	private GClass31[] gclass31_0;

	// Token: 0x040001B1 RID: 433
	[CompilerGenerated]
	private GClass30 gclass30_0;

	// Token: 0x040001B2 RID: 434
	[CompilerGenerated]
	private string string_2;

	// Token: 0x040001B3 RID: 435
	[CompilerGenerated]
	private GClass24 gclass24_0;

	// Token: 0x040001B4 RID: 436
	[CompilerGenerated]
	private GClass27[] gclass27_0;

	// Token: 0x040001B5 RID: 437
	[CompilerGenerated]
	private GClass14[] gclass14_0;

	// Token: 0x040001B6 RID: 438
	[CompilerGenerated]
	private GClass15[] gclass15_0;

	// Token: 0x040001B7 RID: 439
	[CompilerGenerated]
	private GClass21 gclass21_0;

	// Token: 0x040001B8 RID: 440
	[CompilerGenerated]
	private GClass35 gclass35_0;

	// Token: 0x040001B9 RID: 441
	[CompilerGenerated]
	private GClass36 gclass36_0;

	// Token: 0x040001BA RID: 442
	[CompilerGenerated]
	private X509Certificate2 x509Certificate2_0;

	// Token: 0x040001BB RID: 443
	[CompilerGenerated]
	private GClass37 gclass37_0;

	// Token: 0x040001BC RID: 444
	[CompilerGenerated]
	private string string_3;
}
