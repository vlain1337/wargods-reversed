﻿using System;

// Token: 0x02000042 RID: 66
internal enum Enum5
{
	// Token: 0x040001E3 RID: 483
	const_0,
	// Token: 0x040001E4 RID: 484
	const_1,
	// Token: 0x040001E5 RID: 485
	const_2,
	// Token: 0x040001E6 RID: 486
	const_3,
	// Token: 0x040001E7 RID: 487
	const_4
}
