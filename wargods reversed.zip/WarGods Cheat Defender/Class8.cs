﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200003C RID: 60
internal static class Class8
{
	// Token: 0x060001B9 RID: 441
	[DllImport("Wintrust.dll")]
	private static extern uint WinVerifyTrust(IntPtr intptr_0, IntPtr intptr_1, IntPtr intptr_2);

	// Token: 0x060001BA RID: 442 RVA: 0x00049E60 File Offset: 0x00048060
	private static uint gen_guid(string string_0)
	{
		Guid guid = new Guid(<Module>.DeserializeFromByteArray3<string>(2510299107U));
		uint result;
		using (Struct7 struct7_ = new Struct7(string_0, Guid.Empty))
		{
			using (Class9 @class = new Class9(Marshal.AllocHGlobal(Marshal.SizeOf(typeof(Guid))), Enum1.const_0))
			{
				using (Class9 class2 = new Class9(Marshal.AllocHGlobal(Marshal.SizeOf(typeof(Struct8))), Enum1.const_0))
				{
					Struct8 @struct = new Struct8(struct7_);
					IntPtr intPtr = Class9.smethod_0(@class);
					IntPtr intPtr2 = Class9.smethod_0(class2);
					Marshal.StructureToPtr(guid, intPtr, true);
					Marshal.StructureToPtr(@struct, intPtr2, true);
					result = Class8.WinVerifyTrust(IntPtr.Zero, intPtr, intPtr2);
				}
			}
		}
		return result;
	}

	// Token: 0x060001BB RID: 443 RVA: 0x00049F54 File Offset: 0x00048154
	public static bool smethod_1(string string_0)
	{
		return Class8.gen_guid(string_0) == 0U;
	}
}
