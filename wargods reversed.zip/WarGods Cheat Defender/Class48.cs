﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Management;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x020000E1 RID: 225
internal class Class48
{
	// Token: 0x17000316 RID: 790
	// (get) Token: 0x0600073A RID: 1850 RVA: 0x00068AB4 File Offset: 0x00066CB4
	// (set) Token: 0x0600073B RID: 1851 RVA: 0x00068AC8 File Offset: 0x00066CC8
	public string String_0 { get; set; }

	// Token: 0x17000317 RID: 791
	// (get) Token: 0x0600073C RID: 1852 RVA: 0x00068ADC File Offset: 0x00066CDC
	// (set) Token: 0x0600073D RID: 1853 RVA: 0x00068AF0 File Offset: 0x00066CF0
	public string String_1 { get; set; }

	// Token: 0x17000318 RID: 792
	// (get) Token: 0x0600073E RID: 1854 RVA: 0x00068B04 File Offset: 0x00066D04
	// (set) Token: 0x0600073F RID: 1855 RVA: 0x00068B18 File Offset: 0x00066D18
	public long Int64_0 { get; set; }

	// Token: 0x06000740 RID: 1856 RVA: 0x00068B2C File Offset: 0x00066D2C
	public Class48(string string_2 = "", string string_3 = "", long long_1 = 0L)
	{
		this.String_0 = string_2;
		this.String_1 = string_3;
		this.Int64_0 = long_1;
	}

	// Token: 0x06000741 RID: 1857 RVA: 0x00068B54 File Offset: 0x00066D54
	public virtual string ToString()
	{
		return string.Format(<Module>.DeserializeFromByteArrayV2<string>(3616990767U), new object[]
		{
			Class15.SanitizeString(this.String_0),
			Class15.char_2,
			Class15.SanitizeString(this.String_1),
			Class15.char_2,
			this.Int64_0
		});
	}

	// Token: 0x06000742 RID: 1858 RVA: 0x00068BBC File Offset: 0x00066DBC
	public static string smethod_0()
	{
		List<Class48> list = new List<Class48>();
		StringBuilder stringBuilder = new StringBuilder();
		try
		{
			foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher(Class14.String_14, Class14.String_19).Get())
			{
				ManagementObject managementObject = (ManagementObject)managementBaseObject;
				Class48 @class = new Class48("", "", 0L);
				try
				{
					if (Convert.ToUInt32(managementObject.GetPropertyValue(Class14.String_117).ToString().Trim()) == 3U)
					{
						@class.String_0 = managementObject.GetPropertyValue(Class14.String_100).ToString().Trim().ToUpper();
						if (@class.String_0.Length > 1)
						{
							@class.String_0 = @class.String_0[0].ToString();
						}
						@class.String_1 = managementObject.GetPropertyValue(Class14.String_41).ToString().Trim().ToUpper();
						@class.Int64_0 = Convert.ToInt64(managementObject.GetPropertyValue(Class14.String_173).ToString().Trim());
						list.Add(@class);
					}
				}
				catch
				{
				}
			}
			if (list.Count == 0)
			{
				throw new InvalidProgramException();
			}
		}
		catch
		{
			try
			{
				uint num = 0U;
				uint num2 = 0U;
				uint num3 = 0U;
				foreach (string text in Environment.GetLogicalDrives())
				{
					if (text.Length != 0)
					{
						string text2 = text[0].ToString().Trim().ToUpper();
						DriveInfo driveInfo = new DriveInfo(text2);
						if (driveInfo.DriveType == DriveType.Fixed && GClass45.GetVolumeInformation(text2 + <Module>.DeserializeFromByteArray2<string>(1668714569U), null, 0U, ref num, ref num2, ref num3, null, 0U) != 0L)
						{
							list.Add(new Class48("", "", 0L)
							{
								String_0 = text2,
								String_1 = num.ToString(<Module>.DeserializeFromByteArrayV2<string>(2190331133U)).Trim().ToUpper(),
								Int64_0 = driveInfo.TotalSize
							});
						}
					}
				}
			}
			catch
			{
			}
		}
		if (list.Count == 0)
		{
			Class48 @class = new Class48("", "", 0L);
			list.Add(@class);
		}
		for (int j = 0; j < list.Count; j++)
		{
			stringBuilder.Append(list[j].ToString());
			if (j + 1 != list.Count)
			{
				stringBuilder.Append(Class15.char_1);
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x040009DC RID: 2524
	[CompilerGenerated]
	private string string_0;

	// Token: 0x040009DD RID: 2525
	[CompilerGenerated]
	private string string_1;

	// Token: 0x040009DE RID: 2526
	[CompilerGenerated]
	private long long_0;
}
