﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;

// Token: 0x02000010 RID: 16
internal class Class5
{
	// Token: 0x0600004F RID: 79
	[DllImport("kernel32")]
	public static extern int GetPrivateProfileString(string string_1, string string_2, string string_3, StringBuilder stringBuilder_0, int int_0, string string_4);

	// Token: 0x06000050 RID: 80
	[DllImport("kernel32")]
	public static extern int GetPrivateProfileInt(string string_1, string string_2, int int_0, string string_3);

	// Token: 0x17000004 RID: 4
	// (get) Token: 0x06000051 RID: 81 RVA: 0x0003FEA0 File Offset: 0x0003E0A0
	// (set) Token: 0x06000052 RID: 82 RVA: 0x0003FEB4 File Offset: 0x0003E0B4
	public string String_0 { get; private set; }

	// Token: 0x06000053 RID: 83
	public static string GetProfileString(string string_1, string string_2, string string_3 = null, string string_4 = null)
	{
		StringBuilder stringBuilder = new StringBuilder(16777215);
		Class5.GetPrivateProfileString(string_2, string_3, string_4, stringBuilder, stringBuilder.Capacity, string_1);
		return stringBuilder.ToString().Trim();
	}

	// Token: 0x06000054 RID: 84 RVA: 0x0003FEFC File Offset: 0x0003E0FC
	public static int smethod_1(string string_1, string string_2, string string_3 = null, int int_0 = 0)
	{
		return Class5.GetPrivateProfileInt(string_2, string_3, int_0, string_1);
	}

	// Token: 0x06000055 RID: 85 RVA: 0x0003FF14 File Offset: 0x0003E114
	public static string smethod_2(string string_1)
	{
		if (string_1 == null || string_1 == string.Empty)
		{
			return string_1;
		}
		string[] array = string_1.Split(new char[]
		{
			':'
		});
		if (array.Length < 2)
		{
			return string_1;
		}
		return array[0] + <Module>.DeserializeFromByteArrayV2<string>(2747505432U) + array[1];
	}

	// Token: 0x06000056 RID: 86 RVA: 0x0003FF64 File Offset: 0x0003E164
	public static string smethod_3(string string_1)
	{
		if (string_1 == null || string_1.Length == 0)
		{
			throw new Exception();
		}
		return Class5.smethod_2(string_1) + <Module>.DeserializeFromByteArrayV2<string>(3891830818U);
	}

	// Token: 0x06000057 RID: 87 RVA: 0x0003FF98 File Offset: 0x0003E198
	public static bool smethod_4(string string_1, ref GClass0 gclass0_0)
	{
		try
		{
			string string_2 = Class5.smethod_3(string_1);
			if (GClass39.smethod_3(string_2))
			{
				gclass0_0.GEnum0_0 = (GEnum0)Class5.smethod_1(string_2, <Module>.DeserializeFromByteArray2<string>(3372783842U), <Module>.DeserializeFromByteArray2<string>(2597431238U), 0);
				gclass0_0.String_1 = Class5.GetProfileString(string_2, <Module>.DeserializeFromByteArray3<string>(4134431300U), <Module>.DeserializeFromByteArray2<string>(582729793U), null);
				gclass0_0.String_0 = Class5.GetProfileString(string_2, <Module>.DeserializeFromByteArray<string>(1916855833U), <Module>.DeserializeFromByteArray2<string>(4102344485U), null);
				return true;
			}
		}
		catch
		{
		}
		return false;
	}

	// Token: 0x04000043 RID: 67
	[CompilerGenerated]
	private string string_0;
}
