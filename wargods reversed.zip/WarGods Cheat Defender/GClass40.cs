﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x02000068 RID: 104
public class GClass40
{
	// Token: 0x1700014B RID: 331
	// (get) Token: 0x0600033C RID: 828 RVA: 0x0004E1B0 File Offset: 0x0004C3B0
	// (set) Token: 0x0600033D RID: 829 RVA: 0x0004E1C4 File Offset: 0x0004C3C4
	public GEnum20 GEnum20_0 { get; set; }

	// Token: 0x1700014C RID: 332
	// (get) Token: 0x0600033E RID: 830 RVA: 0x0004E1D8 File Offset: 0x0004C3D8
	// (set) Token: 0x0600033F RID: 831 RVA: 0x0004E1EC File Offset: 0x0004C3EC
	public string String_0 { get; set; }

	// Token: 0x1700014D RID: 333
	// (get) Token: 0x06000340 RID: 832 RVA: 0x0004E200 File Offset: 0x0004C400
	// (set) Token: 0x06000341 RID: 833 RVA: 0x0004E214 File Offset: 0x0004C414
	public byte[] Byte_0 { get; set; }

	// Token: 0x06000342 RID: 834 RVA: 0x0004E228 File Offset: 0x0004C428
	public GClass40()
	{
		this.GEnum20_0 = GEnum20.const_0;
		this.String_0 = null;
		this.Byte_0 = null;
	}

	// Token: 0x06000343 RID: 835 RVA: 0x0004E250 File Offset: 0x0004C450
	public static List<GClass40> smethod_0(string string_1)
	{
		string[] array = string_1.Split(new char[]
		{
			';'
		});
		List<GClass40> list = new List<GClass40>();
		try
		{
			string[] array2 = array;
			for (int i = 0; i < array2.Length; i++)
			{
				string[] array3 = array2[i].Split(new char[]
				{
					'!'
				});
				if (array3.Length != 4)
				{
					return null;
				}
				int num = Convert.ToInt32(array3[0]);
				int int_ = Convert.ToInt32(array3[1]);
				string text;
				byte[] array4;
				if ((num & 1) != 1)
				{
					if ((num & 2) != 2)
					{
						return null;
					}
					text = Class13.DecodeCustomBase64String(array3[2], int_);
					array4 = null;
					if (text == null)
					{
						return null;
					}
				}
				else
				{
					text = Class13.DecodeCustomBase64String(array3[2], int_);
					array4 = Class13.DecodeCustomBase64ToBytes(array3[3], int_);
					if (array4 == null || text == null)
					{
						return null;
					}
				}
				list.Add(new GClass40
				{
					GEnum20_0 = (GEnum20)num,
					Byte_0 = array4,
					String_0 = text
				});
			}
		}
		catch
		{
			return null;
		}
		if (list.Count == 0)
		{
			return null;
		}
		return list;
	}

	// Token: 0x04000300 RID: 768
	[CompilerGenerated]
	private GEnum20 genum20_0;

	// Token: 0x04000301 RID: 769
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04000302 RID: 770
	[CompilerGenerated]
	private byte[] byte_0;
}
