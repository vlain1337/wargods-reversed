﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020000B2 RID: 178
public class GClass53
{
	// Token: 0x170002CC RID: 716
	// (get) Token: 0x060005BC RID: 1468 RVA: 0x00058160 File Offset: 0x00056360
	// (set) Token: 0x060005BD RID: 1469 RVA: 0x00058174 File Offset: 0x00056374
	public byte[] Byte_0 { get; private set; }

	// Token: 0x170002CD RID: 717
	// (get) Token: 0x060005BE RID: 1470 RVA: 0x00058188 File Offset: 0x00056388
	// (set) Token: 0x060005BF RID: 1471 RVA: 0x0005819C File Offset: 0x0005639C
	public string String_0 { get; private set; }

	// Token: 0x170002CE RID: 718
	// (get) Token: 0x060005C0 RID: 1472 RVA: 0x000581B0 File Offset: 0x000563B0
	// (set) Token: 0x060005C1 RID: 1473 RVA: 0x000581C4 File Offset: 0x000563C4
	public int[] Int32_0 { get; private set; }

	// Token: 0x060005C2 RID: 1474 RVA: 0x000581D8 File Offset: 0x000563D8
	public GClass53(byte[] byte_1, string string_1, int int_1)
	{
		if (byte_1 == null || string_1.Length != byte_1.Length)
		{
			throw new ArgumentException();
		}
		this.Byte_0 = byte_1;
		this.String_0 = string_1;
		this.Int32_0 = new int[]
		{
			int_1
		};
	}

	// Token: 0x060005C3 RID: 1475 RVA: 0x00058220 File Offset: 0x00056420
	public GClass53(byte[] byte_1, string string_1, int[] int_1)
	{
		if (byte_1 == null || string_1.Length != byte_1.Length)
		{
			throw new ArgumentException();
		}
		this.Byte_0 = byte_1;
		this.String_0 = string_1;
		this.Int32_0 = int_1;
	}

	// Token: 0x040008F8 RID: 2296
	[CompilerGenerated]
	private byte[] byte_0;

	// Token: 0x040008F9 RID: 2297
	[CompilerGenerated]
	private string string_0;

	// Token: 0x040008FA RID: 2298
	[CompilerGenerated]
	private int[] int_0;
}
