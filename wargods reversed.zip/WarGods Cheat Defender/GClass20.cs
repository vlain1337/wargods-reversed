﻿using System;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x02000047 RID: 71
public class GClass20
{
	// Token: 0x060001C5 RID: 453 RVA: 0x0004A200 File Offset: 0x00048400
	public GClass20(byte[] byte_0, int int_0)
	{
		this.UInt32_0 = BitConverter.ToUInt32(byte_0, int_0);
		this.UInt32_1 = BitConverter.ToUInt32(byte_0, int_0 + 4);
	}

	// Token: 0x170000BF RID: 191
	// (get) Token: 0x060001C6 RID: 454 RVA: 0x0004A230 File Offset: 0x00048430
	// (set) Token: 0x060001C7 RID: 455 RVA: 0x0004A244 File Offset: 0x00048444
	public uint UInt32_0 { get; set; }

	// Token: 0x170000C0 RID: 192
	// (get) Token: 0x060001C8 RID: 456 RVA: 0x0004A258 File Offset: 0x00048458
	// (set) Token: 0x060001C9 RID: 457 RVA: 0x0004A26C File Offset: 0x0004846C
	public uint UInt32_1 { get; set; }

	// Token: 0x060001CA RID: 458 RVA: 0x0004A280 File Offset: 0x00048480
	public virtual string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder(<Module>.DeserealizeFromByteArrayV2_1<string>(2780792419U));
		stringBuilder.Append(GClass18.smethod_9(this, <Module>.DeserializeFromByteArrayV2<string>(3099891174U)));
		return stringBuilder.ToString();
	}

	// Token: 0x04000205 RID: 517
	[NonSerialized]
	public static readonly uint uint_0 = 8U;

	// Token: 0x04000206 RID: 518
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x04000207 RID: 519
	[CompilerGenerated]
	private uint uint_2;
}
