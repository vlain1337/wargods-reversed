﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("2.4.0.4")]
[assembly: AssemblyTrademark("www.wargods.ro")]
[assembly: AssemblyCopyright("Tiger @ wGods")]
[assembly: AssemblyProduct("WarGods Cheat Defender")]
[assembly: ComVisible(false)]
[assembly: AssemblyFileVersion("2.4.0.4")]
[assembly: Guid("92505951-2e5c-49e3-81dc-1915fce80c85")]
[assembly: AssemblyTitle("WarGods Cheat Defender")]
[assembly: AssemblyCompany("WarGods.ro")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyDescription("WarGods Cheat Defender")]
