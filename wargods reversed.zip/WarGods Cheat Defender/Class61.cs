﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Token: 0x020000FC RID: 252
[CompilerGenerated]
internal sealed class Class61
{
	// Token: 0x04000B3C RID: 2876 RVA: 0x0003DDD0 File Offset: 0x0003BFD0
	internal static readonly Class61.Struct14 struct14_0;

	// Token: 0x04000B3D RID: 2877 RVA: 0x0003DDE0 File Offset: 0x0003BFE0
	internal static readonly Class61.Struct16 struct16_0;

	// Token: 0x04000B3E RID: 2878 RVA: 0x0003DE18 File Offset: 0x0003C018
	internal static readonly Class61.Struct18 struct18_0;

	// Token: 0x04000B3F RID: 2879 RVA: 0x0003DEC8 File Offset: 0x0003C0C8
	internal static readonly Class61.Struct14 struct14_1;

	// Token: 0x04000B40 RID: 2880 RVA: 0x0003DED8 File Offset: 0x0003C0D8
	internal static readonly Class61.Struct17 ABE69AAFF70004185DE3840359F3E54293990D39;

	// Token: 0x04000B41 RID: 2881 RVA: 0x0003DF28 File Offset: 0x0003C128
	internal static readonly Class61.Struct15 D7BA698E8BD34AEBA3C3325392B84E1B3F353ECE;

	// Token: 0x04000B42 RID: 2882 RVA: 0x0003DF40 File Offset: 0x0003C140
	internal static readonly Class61.Struct14 FA02FDCB10A1BA9EA6ED99E12A52BF2A3E64CD47;

	// Token: 0x020000FD RID: 253
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 16)]
	private struct Struct14
	{
	}

	// Token: 0x020000FE RID: 254
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 24)]
	private struct Struct15
	{
	}

	// Token: 0x020000FF RID: 255
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 56)]
	private struct Struct16
	{
	}

	// Token: 0x02000100 RID: 256
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 80)]
	private struct Struct17
	{
	}

	// Token: 0x02000101 RID: 257
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 172)]
	private struct Struct18
	{
	}
}
