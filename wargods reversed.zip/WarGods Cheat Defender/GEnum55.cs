﻿using System;

// Token: 0x020000F4 RID: 244
public enum GEnum55 : uint
{
	// Token: 0x04000AF3 RID: 2803
	const_0,
	// Token: 0x04000AF4 RID: 2804
	const_1,
	// Token: 0x04000AF5 RID: 2805
	const_2,
	// Token: 0x04000AF6 RID: 2806
	const_3 = 4U,
	// Token: 0x04000AF7 RID: 2807
	const_4 = 8U,
	// Token: 0x04000AF8 RID: 2808
	const_5 = 16U,
	// Token: 0x04000AF9 RID: 2809
	const_6 = 32U,
	// Token: 0x04000AFA RID: 2810
	const_7 = 64U,
	// Token: 0x04000AFB RID: 2811
	const_8 = 128U,
	// Token: 0x04000AFC RID: 2812
	const_9 = 256U,
	// Token: 0x04000AFD RID: 2813
	const_10 = 512U
}
