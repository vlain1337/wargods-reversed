﻿using System;
using System.IO;
using System.Runtime.CompilerServices;

// Token: 0x02000049 RID: 73
public class GClass22
{
	// Token: 0x060001E1 RID: 481 RVA: 0x0004A578 File Offset: 0x00048778
	public GClass22(byte[] byte_0, int int_1)
	{
		this.method_0(byte_0, int_1);
	}

	// Token: 0x060001E2 RID: 482 RVA: 0x0004A594 File Offset: 0x00048794
	public GClass22(BinaryReader binaryReader_0, int int_1)
	{
		if (int_1 == 0 || (long)int_1 >= binaryReader_0.BaseStream.Length)
		{
			throw new ArgumentException(<Module>.DeserealizeFromByteArrayV2_1<string>(2452969155U));
		}
		binaryReader_0.BaseStream.Seek((long)int_1, SeekOrigin.Begin);
		byte[] array = new byte[GClass22.int_0];
		if (binaryReader_0.Read(array, 0, array.Length) != array.Length)
		{
			throw new IOException(<Module>.DeserealizeFromByteArrayV2_1<string>(3827000187U));
		}
		this.method_0(array, 0);
	}

	// Token: 0x060001E3 RID: 483 RVA: 0x0004A60C File Offset: 0x0004880C
	private void method_0(byte[] byte_0, int int_1)
	{
		this.UInt32_0 = BitConverter.ToUInt32(byte_0, int_1);
		int_1 += 4;
		this.UInt32_1 = BitConverter.ToUInt32(byte_0, int_1);
		int_1 += 4;
		this.UInt32_2 = BitConverter.ToUInt32(byte_0, int_1);
		int_1 += 4;
		this.UInt32_3 = BitConverter.ToUInt32(byte_0, int_1);
		int_1 += 4;
		this.UInt32_4 = BitConverter.ToUInt32(byte_0, int_1);
		int_1 += 4;
		this.UInt32_5 = BitConverter.ToUInt32(byte_0, int_1);
		int_1 += 4;
		this.UInt32_6 = BitConverter.ToUInt32(byte_0, int_1);
		int_1 += 4;
		this.UInt32_7 = BitConverter.ToUInt32(byte_0, int_1);
		int_1 += 4;
	}

	// Token: 0x170000C9 RID: 201
	// (get) Token: 0x060001E4 RID: 484 RVA: 0x0004A6AC File Offset: 0x000488AC
	// (set) Token: 0x060001E5 RID: 485 RVA: 0x0004A6C0 File Offset: 0x000488C0
	public uint UInt32_0 { get; set; }

	// Token: 0x170000CA RID: 202
	// (get) Token: 0x060001E6 RID: 486 RVA: 0x0004A6D4 File Offset: 0x000488D4
	// (set) Token: 0x060001E7 RID: 487 RVA: 0x0004A6E8 File Offset: 0x000488E8
	public uint UInt32_1 { get; set; }

	// Token: 0x170000CB RID: 203
	// (get) Token: 0x060001E8 RID: 488 RVA: 0x0004A6FC File Offset: 0x000488FC
	// (set) Token: 0x060001E9 RID: 489 RVA: 0x0004A710 File Offset: 0x00048910
	public uint UInt32_2 { get; set; }

	// Token: 0x170000CC RID: 204
	// (get) Token: 0x060001EA RID: 490 RVA: 0x0004A724 File Offset: 0x00048924
	// (set) Token: 0x060001EB RID: 491 RVA: 0x0004A738 File Offset: 0x00048938
	public uint UInt32_3 { get; set; }

	// Token: 0x170000CD RID: 205
	// (get) Token: 0x060001EC RID: 492 RVA: 0x0004A74C File Offset: 0x0004894C
	// (set) Token: 0x060001ED RID: 493 RVA: 0x0004A760 File Offset: 0x00048960
	public uint UInt32_4 { get; set; }

	// Token: 0x170000CE RID: 206
	// (get) Token: 0x060001EE RID: 494 RVA: 0x0004A774 File Offset: 0x00048974
	// (set) Token: 0x060001EF RID: 495 RVA: 0x0004A788 File Offset: 0x00048988
	public uint UInt32_5 { get; set; }

	// Token: 0x170000CF RID: 207
	// (get) Token: 0x060001F0 RID: 496 RVA: 0x0004A79C File Offset: 0x0004899C
	// (set) Token: 0x060001F1 RID: 497 RVA: 0x0004A7B0 File Offset: 0x000489B0
	public uint UInt32_6 { get; set; }

	// Token: 0x170000D0 RID: 208
	// (get) Token: 0x060001F2 RID: 498 RVA: 0x0004A7C4 File Offset: 0x000489C4
	// (set) Token: 0x060001F3 RID: 499 RVA: 0x0004A7D8 File Offset: 0x000489D8
	public uint UInt32_7 { get; set; }

	// Token: 0x04000211 RID: 529
	[NonSerialized]
	public static readonly int int_0 = 32;

	// Token: 0x04000212 RID: 530
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x04000213 RID: 531
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x04000214 RID: 532
	[CompilerGenerated]
	private uint uint_2;

	// Token: 0x04000215 RID: 533
	[CompilerGenerated]
	private uint uint_3;

	// Token: 0x04000216 RID: 534
	[CompilerGenerated]
	private uint uint_4;

	// Token: 0x04000217 RID: 535
	[CompilerGenerated]
	private uint uint_5;

	// Token: 0x04000218 RID: 536
	[CompilerGenerated]
	private uint uint_6;

	// Token: 0x04000219 RID: 537
	[CompilerGenerated]
	private uint uint_7;
}
