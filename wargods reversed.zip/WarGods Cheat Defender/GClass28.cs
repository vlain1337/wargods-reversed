﻿using System;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x0200004F RID: 79
public class GClass28
{
	// Token: 0x170000FD RID: 253
	// (get) Token: 0x0600025B RID: 603 RVA: 0x0004B3D0 File Offset: 0x000495D0
	// (set) Token: 0x0600025C RID: 604 RVA: 0x0004B3E4 File Offset: 0x000495E4
	public GClass25 GClass25_0 { get; private set; }

	// Token: 0x170000FE RID: 254
	// (get) Token: 0x0600025D RID: 605 RVA: 0x0004B3F8 File Offset: 0x000495F8
	// (set) Token: 0x0600025E RID: 606 RVA: 0x0004B40C File Offset: 0x0004960C
	public GClass29 GClass29_0 { get; private set; }

	// Token: 0x0600025F RID: 607 RVA: 0x0004B420 File Offset: 0x00049620
	public GClass28(byte[] byte_0, uint uint_3, bool bool_0)
	{
		this.UInt32_0 = BitConverter.ToUInt32(byte_0, (int)uint_3);
		this.GClass25_0 = new GClass25(byte_0, (int)(uint_3 + 4U));
		this.GClass29_0 = new GClass29(byte_0, (int)(uint_3 + 24U), bool_0);
	}

	// Token: 0x06000260 RID: 608 RVA: 0x0004B460 File Offset: 0x00049660
	public GClass28(byte[] byte_0, bool bool_0)
	{
		this.UInt32_0 = BitConverter.ToUInt32(byte_0, 0);
		this.GClass25_0 = new GClass25(byte_0, 4);
		this.GClass29_0 = new GClass29(byte_0, 24, bool_0);
	}

	// Token: 0x170000FF RID: 255
	// (get) Token: 0x06000261 RID: 609 RVA: 0x0004B49C File Offset: 0x0004969C
	// (set) Token: 0x06000262 RID: 610 RVA: 0x0004B4B0 File Offset: 0x000496B0
	public uint UInt32_0 { get; set; }

	// Token: 0x06000263 RID: 611 RVA: 0x0004B4C4 File Offset: 0x000496C4
	public virtual string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder(<Module>.DeserializeFromByteArrayV2<string>(3062420189U));
		stringBuilder.Append(GClass18.smethod_9(this, <Module>.DeserealizeFromByteArrayV2_1<string>(1190186032U)));
		stringBuilder.Append(this.GClass25_0);
		stringBuilder.Append(this.GClass29_0);
		return stringBuilder.ToString();
	}

	// Token: 0x0400024A RID: 586
	[NonSerialized]
	public static readonly uint uint_0 = 4U + GClass25.uint_0 + GClass29.uint_0;

	// Token: 0x0400024B RID: 587
	[NonSerialized]
	public static readonly uint uint_1 = 4U + GClass25.uint_0 + GClass29.uint_1;

	// Token: 0x0400024C RID: 588
	[CompilerGenerated]
	private GClass25 gclass25_0;

	// Token: 0x0400024D RID: 589
	[CompilerGenerated]
	private GClass29 gclass29_0;

	// Token: 0x0400024E RID: 590
	[CompilerGenerated]
	private uint uint_2;
}
