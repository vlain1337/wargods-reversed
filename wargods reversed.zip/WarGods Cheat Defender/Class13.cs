﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

// Token: 0x0200006B RID: 107
internal class Class13
{
	// Token: 0x17000155 RID: 341
	// (get) Token: 0x06000351 RID: 849 RVA: 0x0004E50C File Offset: 0x0004C70C
	public static string String_0
	{
		get
		{
			return Class13.DecodeCustomBase64String(Class13.string_0, Class13.int_0);
		}
	}

	// Token: 0x17000156 RID: 342
	// (get) Token: 0x06000352 RID: 850 RVA: 0x0004E528 File Offset: 0x0004C728
	public static string String_1
	{
		get
		{
			return Class13.DecodeCustomBase64String(Class13.string_1, Class13.int_1);
		}
	}

	// Token: 0x17000157 RID: 343
	// (get) Token: 0x06000353 RID: 851 RVA: 0x0004E544 File Offset: 0x0004C744
	public static string String_2
	{
		get
		{
			return Class13.DecodeCustomBase64String(Class13.string_2, Class13.int_2);
		}
	}

	// Token: 0x17000158 RID: 344
	// (get) Token: 0x06000354 RID: 852 RVA: 0x0004E560 File Offset: 0x0004C760
	public static string String_3
	{
		get
		{
			return Class13.DecodeCustomBase64String(Class13.string_3, Class13.int_3);
		}
	}

	// Token: 0x06000355 RID: 853
	public static string GenerateRandomBase64String(int int_4 = 32)
	{
		RandomNumberGenerator randomNumberGenerator = new RNGCryptoServiceProvider();
		byte[] array = new byte[int_4];
		randomNumberGenerator.GetBytes(array);
		return Convert.ToBase64String(array);
	}

	// Token: 0x06000356 RID: 854
	public static byte[] GenerateRandomBytes(int int_4 = 32)
	{
		RandomNumberGenerator randomNumberGenerator = new RNGCryptoServiceProvider();
		byte[] array = new byte[int_4];
		randomNumberGenerator.GetBytes(array);
		return array;
	}

	// Token: 0x06000357 RID: 855
	public static string EncryptToBase64String(string string_6, byte[] byte_2, byte[] byte_3)
	{
		byte[] inArray = null;
		using (RijndaelManaged rijndaelManaged = new RijndaelManaged())
		{
			rijndaelManaged.Key = byte_2;
			rijndaelManaged.Padding = PaddingMode.PKCS7;
			rijndaelManaged.IV = byte_3;
			rijndaelManaged.Mode = CipherMode.CBC;
			ICryptoTransform transform = rijndaelManaged.CreateEncryptor(rijndaelManaged.Key, rijndaelManaged.IV);
			using (MemoryStream memoryStream = new MemoryStream())
			{
				using (CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Write))
				{
					using (StreamWriter streamWriter = new StreamWriter(cryptoStream))
					{
						streamWriter.Write(string_6);
						streamWriter.Flush();
					}
					cryptoStream.Flush();
				}
				inArray = memoryStream.ToArray();
			}
		}
		return Convert.ToBase64String(inArray);
	}

	// Token: 0x06000358 RID: 856
	public static string EncryptStringToBase64(string string_6, byte[] byte_2, byte[] byte_3)
	{
		string result = null;
		using (RijndaelManaged rijndaelManaged = new RijndaelManaged())
		{
			rijndaelManaged.Key = byte_2;
			rijndaelManaged.IV = byte_3;
			byte[] buffer = Convert.FromBase64String(string_6);
			rijndaelManaged.Padding = PaddingMode.PKCS7;
			rijndaelManaged.Mode = CipherMode.CBC;
			ICryptoTransform transform = rijndaelManaged.CreateDecryptor(rijndaelManaged.Key, rijndaelManaged.IV);
			using (MemoryStream memoryStream = new MemoryStream(buffer))
			{
				using (CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Read))
				{
					cryptoStream.Flush();
					using (StreamReader streamReader = new StreamReader(cryptoStream))
					{
						result = streamReader.ReadToEnd();
					}
				}
			}
		}
		return result;
	}

	// Token: 0x06000359 RID: 857
	public static byte[] DecryptBase64StringToString(string string_6, byte[] byte_2, byte[] byte_3)
	{
		byte[] result = null;
		using (RijndaelManaged rijndaelManaged = new RijndaelManaged())
		{
			rijndaelManaged.Key = byte_2;
			rijndaelManaged.IV = byte_3;
			byte[] buffer = Convert.FromBase64String(string_6);
			rijndaelManaged.Padding = PaddingMode.PKCS7;
			rijndaelManaged.Mode = CipherMode.CBC;
			ICryptoTransform transform = rijndaelManaged.CreateDecryptor(rijndaelManaged.Key, rijndaelManaged.IV);
			using (MemoryStream memoryStream = new MemoryStream(buffer))
			{
				using (CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Read))
				{
					cryptoStream.Flush();
				}
				result = memoryStream.ToArray();
			}
		}
		return result;
	}

	// Token: 0x0600035A RID: 858
	public static string EncryptString(string string_6, byte[] byte_2)
	{
		return Class13.EncryptToBase64String(string_6, byte_2, Class13.byte_0);
	}

	// Token: 0x0600035B RID: 859 RVA: 0x0004E858 File Offset: 0x0004CA58
	public static string smethod_6(string string_6, byte[] byte_2)
	{
		return Class13.EncryptStringToBase64(string_6, byte_2, Class13.byte_1);
	}

	// Token: 0x0600035C RID: 860
	public static byte[] EncryptBytesWithRSA(byte[] byte_2, string string_6)
	{
		RSACryptoServiceProvider rsacryptoServiceProvider = new RSACryptoServiceProvider();
		rsacryptoServiceProvider.PersistKeyInCsp = false;
		rsacryptoServiceProvider.FromXmlString(string_6);
		rsacryptoServiceProvider.PersistKeyInCsp = false;
		byte[] result = rsacryptoServiceProvider.Encrypt(byte_2, true);
		rsacryptoServiceProvider.Clear();
		return result;
	}

	// Token: 0x0600035D RID: 861
	public static byte[] SignBytesWithRSA(byte[] byte_2, string string_6)
	{
		RSACryptoServiceProvider rsacryptoServiceProvider = new RSACryptoServiceProvider();
		rsacryptoServiceProvider.PersistKeyInCsp = false;
		rsacryptoServiceProvider.FromXmlString(string_6);
		rsacryptoServiceProvider.PersistKeyInCsp = false;
		byte[] result = rsacryptoServiceProvider.SignData(byte_2, new SHA1CryptoServiceProvider());
		rsacryptoServiceProvider.Clear();
		return result;
	}

	// Token: 0x0600035E RID: 862
	public static bool VerifyRSASignature(byte[] byte_2, byte[] byte_3, string string_6)
	{
		RSACryptoServiceProvider rsacryptoServiceProvider = new RSACryptoServiceProvider();
		rsacryptoServiceProvider.PersistKeyInCsp = false;
		rsacryptoServiceProvider.FromXmlString(string_6);
		rsacryptoServiceProvider.PersistKeyInCsp = false;
		bool result = rsacryptoServiceProvider.VerifyData(byte_2, new SHA1CryptoServiceProvider(), byte_3);
		rsacryptoServiceProvider.Clear();
		return result;
	}

	// Token: 0x0600035F RID: 863
	public static byte[] DecryptRSA(byte[] byte_2, string string_6)
	{
		RSACryptoServiceProvider rsacryptoServiceProvider = new RSACryptoServiceProvider();
		rsacryptoServiceProvider.PersistKeyInCsp = false;
		rsacryptoServiceProvider.FromXmlString(string_6);
		rsacryptoServiceProvider.PersistKeyInCsp = false;
		byte[] result = rsacryptoServiceProvider.Decrypt(byte_2, true);
		rsacryptoServiceProvider.Clear();
		return result;
	}

	// Token: 0x06000360 RID: 864
	public static string DecryptRSAFromBase64String_UTF8(string string_6)
	{
		byte[] bytes = Class13.DecryptRSA(Convert.FromBase64String(string_6), Class13.String_3);
		return Encoding.UTF8.GetString(bytes);
	}

	// Token: 0x06000361 RID: 865
	public static byte[] DecryptRSAFromBase64(string string_6)
	{
		return Class13.DecryptRSA(Convert.FromBase64String(string_6), Class13.String_3);
	}

	// Token: 0x06000362 RID: 866
	public static string RSAStringEncryptionToBase64(string string_6)
	{
		return Convert.ToBase64String(Class13.EncryptBytesWithRSA(Encoding.ASCII.GetBytes(string_6), Class13.String_1));
	}

	// Token: 0x06000363 RID: 867
	public static string ConvertRSASignToBase64(string string_6)
	{
		return Convert.ToBase64String(Class13.SignBytesWithRSA(Encoding.ASCII.GetBytes(string_6), Class13.String_0));
	}

	// Token: 0x06000364 RID: 868
	public static bool CompareSignature(string string_6, string string_7)
	{
		byte[] byte_ = Convert.FromBase64String(string_6);
		byte[] byte_2 = Convert.FromBase64String(string_7);
		return Class13.VerifyRSASignature(byte_, byte_2, Class13.String_2);
	}

	// Token: 0x06000365 RID: 869
	public static string GenerateRandomString(int int_4)
	{
		StringBuilder stringBuilder = new StringBuilder();
		Random random = new Random();
		for (int i = 0; i < int_4; i++)
		{
			char value = <Module>.DeserializeFromByteArray<string>(1019844748U)[random.Next(0, <Module>.DeserealizeFromByteArrayV2_1<string>(1585556050U).Length)];
			stringBuilder.Append(value);
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000366 RID: 870
	public static string xorEncryptStrings(string string_6, string string_7)
	{
		try
		{
			StringBuilder stringBuilder = new StringBuilder();
			for (int i = 0; i < string_6.Length; i++)
			{
				stringBuilder.Append(string_6[i] ^ string_7[i % string_7.Length]);
			}
			return stringBuilder.ToString();
		}
		catch
		{
		}
		return null;
	}

	// Token: 0x06000367 RID: 871
	public static string DecodeCustomBase64String(string string_6, int int_4)
	{
		if (int_4 >= 0 && int_4 < Class13.string_5.Length)
		{
			string text = Class13.string_5[int_4];
			StringBuilder stringBuilder = new StringBuilder();
			foreach (char value in string_6)
			{
				int num = text.IndexOf(value);
				if (num == -1)
				{
					return null;
				}
				stringBuilder.Append(Class13.string_4[num]);
			}
			text = stringBuilder.ToString();
			byte[] bytes = Convert.FromBase64String(text);
			return Encoding.UTF8.GetString(bytes);
		}
		return null;
	}

	// Token: 0x06000368 RID: 872
	public static byte[] DecodeCustomBase64ToBytes(string string_6, int int_4)
	{
		if (int_4 >= 0 && int_4 < Class13.string_5.Length)
		{
			string text = Class13.string_5[int_4];
			StringBuilder stringBuilder = new StringBuilder();
			foreach (char value in string_6)
			{
				int num = text.IndexOf(value);
				if (num == -1)
				{
					return null;
				}
				stringBuilder.Append(Class13.string_4[num]);
			}
			text = stringBuilder.ToString();
			return Convert.FromBase64String(text);
		}
		return null;
	}

	// Token: 0x06000369 RID: 873
	public static bool ComputeMD5Hash(BinaryReader binaryReader_0, out string string_6, long long_0 = 0L, long long_1 = 0L, int int_4 = 4096)
	{
		MD5CryptoServiceProvider md5CryptoServiceProvider = new MD5CryptoServiceProvider();
		if (long_1 == 0L)
		{
			long_1 = binaryReader_0.BaseStream.Length;
		}
		if (long_0 < long_1)
		{
			long num = long_0;
			byte[] array = new byte[int_4];
			long position = binaryReader_0.BaseStream.Position;
			binaryReader_0.BaseStream.Seek(long_0, SeekOrigin.Begin);
			for (;;)
			{
				if (num + (long)int_4 > long_1)
				{
					int_4 = (int)(long_1 - num);
				}
				if (int_4 == 0)
				{
					goto IL_85;
				}
				if (binaryReader_0.BaseStream.Read(array, 0, int_4) <= 0)
				{
					break;
				}
				md5CryptoServiceProvider.TransformBlock(array, 0, int_4, null, 0);
				num += (long)int_4;
				if (num >= long_1)
				{
					goto IL_85;
				}
			}
			string_6 = null;
			return false;
			IL_85:
			binaryReader_0.BaseStream.Seek(position, SeekOrigin.Begin);
			md5CryptoServiceProvider.TransformFinalBlock(array, 0, 0);
			string_6 = BitConverter.ToString(md5CryptoServiceProvider.Hash).Replace(<Module>.DeserealizeFromByteArrayV2_1<string>(504609695U), "");
			return true;
		}
		string_6 = null;
		return false;
	}

	// Token: 0x0600036A RID: 874
	public static bool ComputeMD5HashFromByteArray(byte[] byte_2, out string string_6, long long_0 = 0L, long long_1 = 0L, int int_4 = 4096)
	{
		MD5CryptoServiceProvider md5CryptoServiceProvider = new MD5CryptoServiceProvider();
		if (long_1 == 0L)
		{
			long_1 = (long)byte_2.Length;
		}
		if (long_0 < long_1)
		{
			long num = long_0;
			do
			{
				if (num + (long)int_4 > long_1)
				{
					int_4 = (int)(long_1 - num);
				}
				if (int_4 == 0)
				{
					break;
				}
				md5CryptoServiceProvider.TransformBlock(byte_2, (int)num, int_4, null, 0);
				num += (long)int_4;
			}
			while (num < long_1);
			md5CryptoServiceProvider.TransformFinalBlock(byte_2, 0, 0);
			string_6 = BitConverter.ToString(md5CryptoServiceProvider.Hash).Replace(<Module>.DeserializeFromByteArray<string>(3133938773U), "");
			return true;
		}
		string_6 = null;
		return false;
	}

	// Token: 0x0600036B RID: 875
	public static string CaesarCipher(string string_6, int int_4 = 13)
	{
		char[] array = string_6.ToCharArray();
		for (int i = 0; i < array.Length; i++)
		{
			int num = (int)array[i];
			if (num >= 97 && num <= 122)
			{
				if (num > 109)
				{
					num -= int_4;
				}
				else
				{
					num += int_4;
				}
			}
			else if (num >= 65 && num <= 90)
			{
				if (num <= 77)
				{
					num += int_4;
				}
				else
				{
					num -= int_4;
				}
			}
			array[i] = (char)num;
		}
		return new string(array);
	}

	// Token: 0x0400030C RID: 780
	private static readonly int int_0 = 4;

	// Token: 0x0400030D RID: 781
	private static readonly string string_0 = <Module>.DeserializeFromByteArray2<string>(3293498013U);

	// Token: 0x0400030E RID: 782
	private static readonly int int_1 = 9;

	// Token: 0x0400030F RID: 783
	private static readonly string string_1 = <Module>.DeserializeFromByteArray2<string>(2444936207U);

	// Token: 0x04000310 RID: 784
	public static byte[] byte_0 = new byte[]
	{
		125,
		96,
		242,
		101,
		0,
		23,
		63,
		155,
		214,
		13,
		133,
		133,
		142,
		216,
		4,
		247
	};

	// Token: 0x04000311 RID: 785
	private static readonly int int_2 = 0;

	// Token: 0x04000312 RID: 786
	private static readonly string string_2 = <Module>.DeserializeFromByteArray2<string>(1025530255U);

	// Token: 0x04000313 RID: 787
	private static readonly int int_3 = 4;

	// Token: 0x04000314 RID: 788
	private static readonly string string_3 = <Module>.DeserializeFromByteArray3<string>(2237538487U);

	// Token: 0x04000315 RID: 789
	public static byte[] byte_1 = new byte[]
	{
		23,
		246,
		65,
		50,
		110,
		172,
		29,
		131,
		25,
		81,
		247,
		18,
		145,
		12,
		126,
		92
	};

	// Token: 0x04000316 RID: 790
	private static readonly string string_4 = <Module>.DeserializeFromByteArray2<string>(2004811961U);

	// Token: 0x04000317 RID: 791
	private static readonly string[] string_5 = new string[]
	{
		<Module>.DeserealizeFromByteArrayV2_1<string>(3960982010U),
		<Module>.DeserializeFromByteArray<string>(3894755706U),
		<Module>.DeserealizeFromByteArrayV2_1<string>(1346738022U),
		<Module>.DeserealizeFromByteArrayV2_1<string>(298927328U),
		<Module>.DeserializeFromByteArray<string>(50692268U),
		<Module>.DeserializeFromByteArray<string>(200993554U),
		<Module>.DeserializeFromByteArrayV2<string>(1607753556U),
		<Module>.DeserealizeFromByteArrayV2_1<string>(195202808U),
		<Module>.DeserealizeFromByteArrayV2_1<string>(2275777418U),
		<Module>.DeserializeFromByteArrayV2<string>(121140346U)
	};
}
