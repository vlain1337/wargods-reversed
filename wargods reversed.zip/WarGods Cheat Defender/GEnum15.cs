﻿using System;

// Token: 0x02000038 RID: 56
public enum GEnum15
{
	// Token: 0x04000193 RID: 403
	const_0,
	// Token: 0x04000194 RID: 404
	const_1,
	// Token: 0x04000195 RID: 405
	const_2,
	// Token: 0x04000196 RID: 406
	const_3 = 4,
	// Token: 0x04000197 RID: 407
	const_4 = 8,
	// Token: 0x04000198 RID: 408
	const_5 = 16,
	// Token: 0x04000199 RID: 409
	const_6 = 32,
	// Token: 0x0400019A RID: 410
	const_7 = 64,
	// Token: 0x0400019B RID: 411
	const_8 = 128,
	// Token: 0x0400019C RID: 412
	const_9 = 256,
	// Token: 0x0400019D RID: 413
	const_10 = 512,
	// Token: 0x0400019E RID: 414
	const_11 = 1024,
	// Token: 0x0400019F RID: 415
	const_12 = 2048,
	// Token: 0x040001A0 RID: 416
	const_13 = 4095
}
