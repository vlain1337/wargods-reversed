﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x02000057 RID: 87
public class GClass36
{
	// Token: 0x060002FA RID: 762 RVA: 0x0004CD78 File Offset: 0x0004AF78
	public GClass36(byte[] byte_1, int int_0)
	{
		this.UInt32_0 = BitConverter.ToUInt32(byte_1, int_0);
		this.UInt16_0 = BitConverter.ToUInt16(byte_1, int_0 + 4);
		this.UInt16_1 = BitConverter.ToUInt16(byte_1, int_0 + 6);
		this.Byte_0 = new byte[this.UInt32_0 - 8U];
		Array.Copy(byte_1, (long)(int_0 + 8), this.Byte_0, 0L, (long)((ulong)(this.UInt32_0 - 8U)));
	}

	// Token: 0x060002FB RID: 763 RVA: 0x0004CDEC File Offset: 0x0004AFEC
	public GClass36(BinaryReader binaryReader_0, int int_0)
	{
		binaryReader_0.BaseStream.Seek((long)int_0, SeekOrigin.Begin);
		int num = 8;
		byte[] array = new byte[8];
		if (binaryReader_0.Read(array, 0, array.Length) != array.Length)
		{
			throw new IOException(<Module>.DeserializeFromByteArray2<string>(1104816084U));
		}
		this.UInt32_0 = BitConverter.ToUInt32(array, 0);
		this.UInt16_0 = BitConverter.ToUInt16(array, 4);
		this.UInt16_1 = BitConverter.ToUInt16(array, 6);
		num = (int)(this.UInt32_0 - (uint)num);
		this.Byte_0 = new byte[num];
		if (binaryReader_0.Read(this.Byte_0, 0, this.Byte_0.Length) != this.Byte_0.Length)
		{
			throw new IOException(<Module>.DeserializeFromByteArray3<string>(2535681974U));
		}
	}

	// Token: 0x1700013F RID: 319
	// (get) Token: 0x060002FC RID: 764 RVA: 0x0004CEA4 File Offset: 0x0004B0A4
	// (set) Token: 0x060002FD RID: 765 RVA: 0x0004CEB8 File Offset: 0x0004B0B8
	public uint UInt32_0 { get; private set; }

	// Token: 0x17000140 RID: 320
	// (get) Token: 0x060002FE RID: 766 RVA: 0x0004CECC File Offset: 0x0004B0CC
	// (set) Token: 0x060002FF RID: 767 RVA: 0x0004CEE0 File Offset: 0x0004B0E0
	public ushort UInt16_0 { get; private set; }

	// Token: 0x17000141 RID: 321
	// (get) Token: 0x06000300 RID: 768 RVA: 0x0004CEF4 File Offset: 0x0004B0F4
	// (set) Token: 0x06000301 RID: 769 RVA: 0x0004CF08 File Offset: 0x0004B108
	public ushort UInt16_1 { get; private set; }

	// Token: 0x17000142 RID: 322
	// (get) Token: 0x06000302 RID: 770 RVA: 0x0004CF1C File Offset: 0x0004B11C
	// (set) Token: 0x06000303 RID: 771 RVA: 0x0004CF30 File Offset: 0x0004B130
	public byte[] Byte_0 { get; private set; }

	// Token: 0x06000304 RID: 772 RVA: 0x0004CF44 File Offset: 0x0004B144
	public virtual string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder(<Module>.DeserealizeFromByteArrayV2_1<string>(3819476798U));
		stringBuilder.Append(GClass18.smethod_9(this, <Module>.DeserializeFromByteArray3<string>(1825134969U)));
		return stringBuilder.ToString();
	}

	// Token: 0x04000294 RID: 660
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x04000295 RID: 661
	[CompilerGenerated]
	private ushort ushort_0;

	// Token: 0x04000296 RID: 662
	[CompilerGenerated]
	private ushort ushort_1;

	// Token: 0x04000297 RID: 663
	[CompilerGenerated]
	private byte[] byte_0;
}
