﻿using System;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

// Token: 0x02000060 RID: 96
public class GClass39
{
	// Token: 0x0600032D RID: 813 RVA: 0x0004DF30 File Offset: 0x0004C130
	public static string smethod_0(string string_0)
	{
		if (string_0 == null)
		{
			return string_0;
		}
		if (!string_0.StartsWith(<Module>.DeserealizeFromByteArrayV2_1<string>(3312858871U)))
		{
			return <Module>.DeserealizeFromByteArrayV2_1<string>(3312858871U) + string_0;
		}
		return string_0;
	}

	// Token: 0x0600032E RID: 814 RVA: 0x0004DF68 File Offset: 0x0004C168
	public static void smethod_1(string string_0)
	{
		if (string_0 != null)
		{
			GClass39.DeleteFile(GClass39.smethod_0(string_0));
		}
	}

	// Token: 0x0600032F RID: 815 RVA: 0x0004DF84 File Offset: 0x0004C184
	public static FileStream smethod_2(string string_0, FileMode fileMode_0, FileAccess fileAccess_0, FileShare fileShare_0)
	{
		/*
An exception occurred when decompiling this method (0600032F)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.IO.FileStream GClass39::smethod_2(System.String,System.IO.FileMode,System.IO.FileAccess,System.IO.FileShare)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 271
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06000330 RID: 816 RVA: 0x0004E054 File Offset: 0x0004C254
	public static bool smethod_3(string string_0)
	{
		GClass39.Enum9 fileAttributes = GClass39.GetFileAttributes(GClass39.smethod_0(string_0));
		return fileAttributes != (GClass39.Enum9)(-1) && (fileAttributes & GClass39.Enum9.flag_3) != GClass39.Enum9.flag_3;
	}

	// Token: 0x06000331 RID: 817 RVA: 0x0004E080 File Offset: 0x0004C280
	public static void smethod_4(string string_0, string string_1, bool bool_0)
	{
		bool flag = GClass39.CopyFile(GClass39.smethod_0(string_0), GClass39.smethod_0(string_1), bool_0);
		int lastWin32Error = Marshal.GetLastWin32Error();
		if (!flag)
		{
			throw new Win32Exception(lastWin32Error);
		}
	}

	// Token: 0x06000332 RID: 818 RVA: 0x0004E0B0 File Offset: 0x0004C2B0
	public static void smethod_5(string string_0, string string_1, bool bool_0)
	{
		GClass39.smethod_4(string_0, string_1, bool_0);
		GClass39.smethod_1(string_0);
	}

	// Token: 0x06000333 RID: 819 RVA: 0x0004E0CC File Offset: 0x0004C2CC
	private static GClass39.GEnum17 smethod_6(FileShare fileShare_0)
	{
		switch (fileShare_0)
		{
		case FileShare.None:
			return GClass39.GEnum17.flag_0;
		case FileShare.Read:
			return GClass39.GEnum17.flag_1;
		case FileShare.Write:
			return GClass39.GEnum17.flag_2;
		case FileShare.ReadWrite:
			return GClass39.GEnum17.flag_1 | GClass39.GEnum17.flag_2;
		case FileShare.Delete:
			return GClass39.GEnum17.flag_3;
		default:
			if (fileShare_0 == FileShare.Inheritable)
			{
				throw new NotSupportedException(<Module>.DeserializeFromByteArrayV2<string>(1903106409U));
			}
			throw new NotSupportedException();
		}
	}

	// Token: 0x06000334 RID: 820 RVA: 0x0004E118 File Offset: 0x0004C318
	private static GClass39.GEnum16 smethod_7(FileAccess fileAccess_0)
	{
		switch (fileAccess_0)
		{
		case FileAccess.Read:
			return (GClass39.GEnum16)2147483648U;
		case FileAccess.Write:
			return GClass39.GEnum16.flag_1;
		case FileAccess.ReadWrite:
			return (GClass39.GEnum16)3221225472U;
		default:
			throw new NotSupportedException();
		}
	}

	// Token: 0x06000335 RID: 821 RVA: 0x0004E150 File Offset: 0x0004C350
	private static GClass39.GEnum18 smethod_8(FileMode fileMode_0)
	{
		switch (fileMode_0)
		{
		case FileMode.CreateNew:
			return GClass39.GEnum18.const_0;
		case FileMode.Create:
			return GClass39.GEnum18.const_1;
		case FileMode.Open:
			return GClass39.GEnum18.const_2;
		case FileMode.OpenOrCreate:
			return GClass39.GEnum18.const_3;
		case FileMode.Truncate:
			return GClass39.GEnum18.const_4;
		case FileMode.Append:
			return GClass39.GEnum18.const_3;
		default:
			throw new NotSupportedException();
		}
	}

	// Token: 0x06000336 RID: 822
	[DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
	[return: MarshalAs(UnmanagedType.Bool)]
	internal static extern bool DeleteFile(string string_0);

	// Token: 0x06000337 RID: 823
	[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	internal static extern GClass39.Enum9 GetFileAttributes(string string_0);

	// Token: 0x06000338 RID: 824
	[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	internal static extern SafeFileHandle CreateFile(string string_0, GClass39.GEnum16 genum16_0, GClass39.GEnum17 genum17_0, IntPtr intptr_1, GClass39.GEnum18 genum18_0, GClass39.GEnum19 genum19_0, IntPtr intptr_2);

	// Token: 0x06000339 RID: 825
	[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	internal static extern bool CopyFile(string string_0, string string_1, bool bool_0);

	// Token: 0x040002BF RID: 703
	internal static IntPtr intptr_0 = new IntPtr(-1);

	// Token: 0x040002C0 RID: 704
	internal static int int_0 = 16;

	// Token: 0x02000061 RID: 97
	[Flags]
	internal enum Enum9
	{
		// Token: 0x040002C2 RID: 706
		flag_0 = 1,
		// Token: 0x040002C3 RID: 707
		flag_1 = 2,
		// Token: 0x040002C4 RID: 708
		flag_2 = 4,
		// Token: 0x040002C5 RID: 709
		flag_3 = 16,
		// Token: 0x040002C6 RID: 710
		flag_4 = 32,
		// Token: 0x040002C7 RID: 711
		flag_5 = 64,
		// Token: 0x040002C8 RID: 712
		flag_6 = 128,
		// Token: 0x040002C9 RID: 713
		flag_7 = 256,
		// Token: 0x040002CA RID: 714
		flag_8 = 512,
		// Token: 0x040002CB RID: 715
		flag_9 = 1024,
		// Token: 0x040002CC RID: 716
		flag_10 = 2048,
		// Token: 0x040002CD RID: 717
		flag_11 = 4096,
		// Token: 0x040002CE RID: 718
		flag_12 = 8192,
		// Token: 0x040002CF RID: 719
		flag_13 = 16384,
		// Token: 0x040002D0 RID: 720
		flag_14 = 65536
	}

	// Token: 0x02000062 RID: 98
	[Flags]
	public enum GEnum16 : uint
	{
		// Token: 0x040002D2 RID: 722
		flag_0 = 2147483648U,
		// Token: 0x040002D3 RID: 723
		flag_1 = 1073741824U,
		// Token: 0x040002D4 RID: 724
		flag_2 = 536870912U,
		// Token: 0x040002D5 RID: 725
		flag_3 = 268435456U
	}

	// Token: 0x02000063 RID: 99
	[Flags]
	public enum GEnum17 : uint
	{
		// Token: 0x040002D7 RID: 727
		flag_0 = 0U,
		// Token: 0x040002D8 RID: 728
		flag_1 = 1U,
		// Token: 0x040002D9 RID: 729
		flag_2 = 2U,
		// Token: 0x040002DA RID: 730
		flag_3 = 4U
	}

	// Token: 0x02000064 RID: 100
	public enum GEnum18 : uint
	{
		// Token: 0x040002DC RID: 732
		const_0 = 1U,
		// Token: 0x040002DD RID: 733
		const_1,
		// Token: 0x040002DE RID: 734
		const_2,
		// Token: 0x040002DF RID: 735
		const_3,
		// Token: 0x040002E0 RID: 736
		const_4
	}

	// Token: 0x02000065 RID: 101
	[Flags]
	public enum GEnum19 : uint
	{
		// Token: 0x040002E2 RID: 738
		flag_0 = 1U,
		// Token: 0x040002E3 RID: 739
		flag_1 = 2U,
		// Token: 0x040002E4 RID: 740
		flag_2 = 4U,
		// Token: 0x040002E5 RID: 741
		flag_3 = 16U,
		// Token: 0x040002E6 RID: 742
		flag_4 = 32U,
		// Token: 0x040002E7 RID: 743
		flag_5 = 64U,
		// Token: 0x040002E8 RID: 744
		flag_6 = 128U,
		// Token: 0x040002E9 RID: 745
		flag_7 = 256U,
		// Token: 0x040002EA RID: 746
		flag_8 = 512U,
		// Token: 0x040002EB RID: 747
		flag_9 = 1024U,
		// Token: 0x040002EC RID: 748
		flag_10 = 2048U,
		// Token: 0x040002ED RID: 749
		flag_11 = 4096U,
		// Token: 0x040002EE RID: 750
		flag_12 = 8192U,
		// Token: 0x040002EF RID: 751
		flag_13 = 16384U,
		// Token: 0x040002F0 RID: 752
		flag_14 = 2147483648U,
		// Token: 0x040002F1 RID: 753
		flag_15 = 1073741824U,
		// Token: 0x040002F2 RID: 754
		flag_16 = 536870912U,
		// Token: 0x040002F3 RID: 755
		flag_17 = 268435456U,
		// Token: 0x040002F4 RID: 756
		flag_18 = 134217728U,
		// Token: 0x040002F5 RID: 757
		flag_19 = 67108864U,
		// Token: 0x040002F6 RID: 758
		flag_20 = 33554432U,
		// Token: 0x040002F7 RID: 759
		flag_21 = 16777216U,
		// Token: 0x040002F8 RID: 760
		flag_22 = 2097152U,
		// Token: 0x040002F9 RID: 761
		flag_23 = 1048576U,
		// Token: 0x040002FA RID: 762
		flag_24 = 524288U
	}

	// Token: 0x02000066 RID: 102
	internal struct Struct10
	{
		// Token: 0x040002FB RID: 763
		internal uint uint_0;

		// Token: 0x040002FC RID: 764
		internal uint uint_1;
	}

	// Token: 0x02000067 RID: 103
	public struct GStruct1
	{
		// Token: 0x040002FD RID: 765
		public int int_0;

		// Token: 0x040002FE RID: 766
		public IntPtr intptr_0;

		// Token: 0x040002FF RID: 767
		public int int_1;
	}
}
