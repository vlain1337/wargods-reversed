﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x0200006C RID: 108
public class GClass41
{
	// Token: 0x17000159 RID: 345
	// (get) Token: 0x0600036E RID: 878 RVA: 0x0004EED8 File Offset: 0x0004D0D8
	// (set) Token: 0x0600036F RID: 879 RVA: 0x0004EEEC File Offset: 0x0004D0EC
	public GEnum21 GEnum21_0 { get; set; }

	// Token: 0x1700015A RID: 346
	// (get) Token: 0x06000370 RID: 880 RVA: 0x0004EF00 File Offset: 0x0004D100
	// (set) Token: 0x06000371 RID: 881 RVA: 0x0004EF14 File Offset: 0x0004D114
	public int Int32_0 { get; set; }

	// Token: 0x1700015B RID: 347
	// (get) Token: 0x06000372 RID: 882 RVA: 0x0004EF28 File Offset: 0x0004D128
	// (set) Token: 0x06000373 RID: 883 RVA: 0x0004EF3C File Offset: 0x0004D13C
	public string String_0 { get; set; }

	// Token: 0x1700015C RID: 348
	// (get) Token: 0x06000374 RID: 884 RVA: 0x0004EF50 File Offset: 0x0004D150
	// (set) Token: 0x06000375 RID: 885 RVA: 0x0004EF64 File Offset: 0x0004D164
	public long Int64_0 { get; set; }

	// Token: 0x1700015D RID: 349
	// (get) Token: 0x06000376 RID: 886 RVA: 0x0004EF78 File Offset: 0x0004D178
	// (set) Token: 0x06000377 RID: 887 RVA: 0x0004EF8C File Offset: 0x0004D18C
	public GEnum23 GEnum23_0 { get; set; }

	// Token: 0x06000378 RID: 888 RVA: 0x0004EFA0 File Offset: 0x0004D1A0
	public GClass41()
	{
		this.GEnum21_0 = GEnum21.const_0;
		this.GEnum23_0 = GEnum23.const_0;
		this.Int32_0 = -1;
		this.String_0 = string.Empty;
	}

	// Token: 0x06000379 RID: 889 RVA: 0x0004EFD4 File Offset: 0x0004D1D4
	public virtual string ToString()
	{
		return string.Format(<Module>.DeserealizeFromByteArrayV2_1<string>(1554187062U), new object[]
		{
			(int)this.GEnum21_0,
			(int)this.GEnum23_0,
			this.Int32_0,
			Class15.SanitizeString(this.String_0),
			this.Int64_0
		});
	}

	// Token: 0x04000318 RID: 792
	[CompilerGenerated]
	private GEnum21 genum21_0;

	// Token: 0x04000319 RID: 793
	[CompilerGenerated]
	private int int_0;

	// Token: 0x0400031A RID: 794
	[CompilerGenerated]
	private string string_0;

	// Token: 0x0400031B RID: 795
	[CompilerGenerated]
	private long long_0;

	// Token: 0x0400031C RID: 796
	[CompilerGenerated]
	private GEnum23 genum23_0;
}
