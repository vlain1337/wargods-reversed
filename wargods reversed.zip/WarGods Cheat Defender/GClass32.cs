﻿using System;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x02000053 RID: 83
public class GClass32
{
	// Token: 0x060002CE RID: 718 RVA: 0x0004C678 File Offset: 0x0004A878
	public GClass32(byte[] byte_0, int int_0, bool bool_0)
	{
		this.UInt64_0 = (bool_0 ? BitConverter.ToUInt64(byte_0, int_0) : ((ulong)BitConverter.ToUInt32(byte_0, int_0)));
		this.UInt64_1 = this.UInt64_0;
		this.UInt64_2 = this.UInt64_0;
		this.UInt64_3 = this.UInt64_0;
	}

	// Token: 0x1700012F RID: 303
	// (get) Token: 0x060002CF RID: 719 RVA: 0x0004C6CC File Offset: 0x0004A8CC
	// (set) Token: 0x060002D0 RID: 720 RVA: 0x0004C6E0 File Offset: 0x0004A8E0
	public ulong UInt64_0 { get; private set; }

	// Token: 0x17000130 RID: 304
	// (get) Token: 0x060002D1 RID: 721 RVA: 0x0004C6F4 File Offset: 0x0004A8F4
	// (set) Token: 0x060002D2 RID: 722 RVA: 0x0004C708 File Offset: 0x0004A908
	public ulong UInt64_1 { get; private set; }

	// Token: 0x17000131 RID: 305
	// (get) Token: 0x060002D3 RID: 723 RVA: 0x0004C71C File Offset: 0x0004A91C
	// (set) Token: 0x060002D4 RID: 724 RVA: 0x0004C730 File Offset: 0x0004A930
	public ulong UInt64_2 { get; private set; }

	// Token: 0x17000132 RID: 306
	// (get) Token: 0x060002D5 RID: 725 RVA: 0x0004C744 File Offset: 0x0004A944
	// (set) Token: 0x060002D6 RID: 726 RVA: 0x0004C758 File Offset: 0x0004A958
	public ulong UInt64_3 { get; private set; }

	// Token: 0x060002D7 RID: 727 RVA: 0x0004C76C File Offset: 0x0004A96C
	public virtual string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder(<Module>.DeserializeFromByteArray<string>(3159992070U));
		stringBuilder.Append(GClass18.smethod_9(this, <Module>.DeserializeFromByteArray<string>(1696200535U)));
		return stringBuilder.ToString();
	}

	// Token: 0x04000281 RID: 641
	[CompilerGenerated]
	private ulong ulong_0;

	// Token: 0x04000282 RID: 642
	[CompilerGenerated]
	private ulong ulong_1;

	// Token: 0x04000283 RID: 643
	[CompilerGenerated]
	private ulong ulong_2;

	// Token: 0x04000284 RID: 644
	[CompilerGenerated]
	private ulong ulong_3;
}
