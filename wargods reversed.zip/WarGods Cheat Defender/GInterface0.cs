﻿using System;
using System.Collections.Generic;

// Token: 0x02000012 RID: 18
public interface GInterface0
{
	// Token: 0x17000005 RID: 5
	// (get) Token: 0x06000059 RID: 89
	byte[] Byte_0 { get; }

	// Token: 0x17000006 RID: 6
	// (get) Token: 0x0600005A RID: 90
	string String_0 { get; }

	// Token: 0x17000007 RID: 7
	// (get) Token: 0x0600005B RID: 91
	DateTimeOffset DateTimeOffset_0 { get; }

	// Token: 0x17000008 RID: 8
	// (get) Token: 0x0600005C RID: 92
	DateTimeOffset DateTimeOffset_1 { get; }

	// Token: 0x17000009 RID: 9
	// (get) Token: 0x0600005D RID: 93
	DateTimeOffset DateTimeOffset_2 { get; }

	// Token: 0x1700000A RID: 10
	// (get) Token: 0x0600005E RID: 94
	GClass2 GClass2_0 { get; }

	// Token: 0x1700000B RID: 11
	// (get) Token: 0x0600005F RID: 95
	int Int32_0 { get; }

	// Token: 0x1700000C RID: 12
	// (get) Token: 0x06000060 RID: 96
	int Int32_1 { get; }

	// Token: 0x1700000D RID: 13
	// (get) Token: 0x06000061 RID: 97
	int Int32_2 { get; }

	// Token: 0x1700000E RID: 14
	// (get) Token: 0x06000062 RID: 98
	int Int32_3 { get; }

	// Token: 0x1700000F RID: 15
	// (get) Token: 0x06000063 RID: 99
	int Int32_4 { get; }

	// Token: 0x17000010 RID: 16
	// (get) Token: 0x06000064 RID: 100
	int Int32_5 { get; }

	// Token: 0x17000011 RID: 17
	// (get) Token: 0x06000065 RID: 101
	int Int32_6 { get; }

	// Token: 0x17000012 RID: 18
	// (get) Token: 0x06000066 RID: 102
	int Int32_7 { get; }

	// Token: 0x17000013 RID: 19
	// (get) Token: 0x06000067 RID: 103
	int Int32_8 { get; }

	// Token: 0x17000014 RID: 20
	// (get) Token: 0x06000068 RID: 104
	int Int32_9 { get; }

	// Token: 0x17000015 RID: 21
	// (get) Token: 0x06000069 RID: 105
	List<DateTimeOffset> Prop_0 { get; }

	// Token: 0x17000016 RID: 22
	// (get) Token: 0x0600006A RID: 106
	List<GClass11> Prop_1 { get; }

	// Token: 0x17000017 RID: 23
	// (get) Token: 0x0600006B RID: 107
	int Int32_10 { get; }

	// Token: 0x17000018 RID: 24
	// (get) Token: 0x0600006C RID: 108
	List<string> Prop_2 { get; }

	// Token: 0x17000019 RID: 25
	// (get) Token: 0x0600006D RID: 109
	List<GClass1> Prop_3 { get; }

	// Token: 0x1700001A RID: 26
	// (get) Token: 0x0600006E RID: 110
	List<GClass4> Prop_4 { get; }
}
