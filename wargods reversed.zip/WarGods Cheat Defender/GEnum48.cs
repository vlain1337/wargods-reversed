﻿using System;

// Token: 0x020000AF RID: 175
public enum GEnum48 : uint
{
	// Token: 0x04000647 RID: 1607
	const_0,
	// Token: 0x04000648 RID: 1608
	const_1,
	// Token: 0x04000649 RID: 1609
	const_2,
	// Token: 0x0400064A RID: 1610
	const_3 = 4U,
	// Token: 0x0400064B RID: 1611
	const_4 = 8U,
	// Token: 0x0400064C RID: 1612
	const_5 = 16U,
	// Token: 0x0400064D RID: 1613
	const_6 = 32U,
	// Token: 0x0400064E RID: 1614
	const_7 = 64U,
	// Token: 0x0400064F RID: 1615
	const_8 = 128U,
	// Token: 0x04000650 RID: 1616
	const_9 = 256U,
	// Token: 0x04000651 RID: 1617
	const_10 = 512U,
	// Token: 0x04000652 RID: 1618
	const_11 = 1024U
}
