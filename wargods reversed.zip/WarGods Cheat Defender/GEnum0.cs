﻿using System;

// Token: 0x0200000E RID: 14
public enum GEnum0
{
	// Token: 0x04000036 RID: 54
	const_0 = -1,
	// Token: 0x04000037 RID: 55
	const_1,
	// Token: 0x04000038 RID: 56
	const_2 = 0,
	// Token: 0x04000039 RID: 57
	const_3,
	// Token: 0x0400003A RID: 58
	const_4,
	// Token: 0x0400003B RID: 59
	const_5,
	// Token: 0x0400003C RID: 60
	const_6,
	// Token: 0x0400003D RID: 61
	const_7 = 999,
	// Token: 0x0400003E RID: 62
	const_8,
	// Token: 0x0400003F RID: 63
	const_9 = 10000
}
