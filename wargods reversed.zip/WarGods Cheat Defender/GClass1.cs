﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x02000013 RID: 19
public class GClass1
{
	// Token: 0x0600006F RID: 111 RVA: 0x00040038 File Offset: 0x0003E238
	public GClass1(byte[] byte_0, bool bool_0)
	{
		if (bool_0)
		{
			this.Int32_0 = BitConverter.ToInt32(byte_0, 0);
			this.Int32_1 = BitConverter.ToInt32(byte_0, 4);
			this.Int32_2 = BitConverter.ToInt32(byte_0, 8);
			this.Int32_3 = BitConverter.ToInt32(byte_0, 12);
			this.Int32_4 = BitConverter.ToInt32(byte_0, 16);
			return;
		}
		this.Int32_0 = BitConverter.ToInt32(byte_0, 0);
		this.Int32_1 = BitConverter.ToInt32(byte_0, 4);
		this.Int32_4 = BitConverter.ToInt32(byte_0, 8);
		this.Int32_2 = BitConverter.ToInt32(byte_0, 12);
		this.Int32_3 = BitConverter.ToInt32(byte_0, 16);
		this.Int32_5 = BitConverter.ToInt32(byte_0, 20);
		this.GClass3_0 = new GClass3(GClass5.smethod_0(byte_0, 24, 8));
	}

	// Token: 0x1700001B RID: 27
	// (get) Token: 0x06000070 RID: 112 RVA: 0x000400F8 File Offset: 0x0003E2F8
	public int Int32_0 { get; }

	// Token: 0x1700001C RID: 28
	// (get) Token: 0x06000071 RID: 113 RVA: 0x0004010C File Offset: 0x0003E30C
	public int Int32_1 { get; }

	// Token: 0x1700001D RID: 29
	// (get) Token: 0x06000072 RID: 114 RVA: 0x00040120 File Offset: 0x0003E320
	public int Int32_2 { get; }

	// Token: 0x1700001E RID: 30
	// (get) Token: 0x06000073 RID: 115 RVA: 0x00040134 File Offset: 0x0003E334
	public int Int32_3 { get; }

	// Token: 0x1700001F RID: 31
	// (get) Token: 0x06000074 RID: 116 RVA: 0x00040148 File Offset: 0x0003E348
	public int Int32_4 { get; }

	// Token: 0x17000020 RID: 32
	// (get) Token: 0x06000075 RID: 117 RVA: 0x0004015C File Offset: 0x0003E35C
	public int Int32_5 { get; }

	// Token: 0x17000021 RID: 33
	// (get) Token: 0x06000076 RID: 118 RVA: 0x00040170 File Offset: 0x0003E370
	public GClass3 GClass3_0 { get; }

	// Token: 0x06000077 RID: 119 RVA: 0x00040184 File Offset: 0x0003E384
	public virtual string ToString()
	{
		return string.Format(<Module>.DeserializeFromByteArray<string>(3942631187U), this.Int32_2, this.Int32_3, this.GClass3_0);
	}

	// Token: 0x04000049 RID: 73
	[CompilerGenerated]
	private readonly int int_0;

	// Token: 0x0400004A RID: 74
	[CompilerGenerated]
	private readonly int int_1;

	// Token: 0x0400004B RID: 75
	[CompilerGenerated]
	private readonly int int_2;

	// Token: 0x0400004C RID: 76
	[CompilerGenerated]
	private readonly int int_3;

	// Token: 0x0400004D RID: 77
	[CompilerGenerated]
	private readonly int int_4;

	// Token: 0x0400004E RID: 78
	[CompilerGenerated]
	private readonly int int_5;

	// Token: 0x0400004F RID: 79
	[CompilerGenerated]
	private readonly GClass3 gclass3_0;
}
