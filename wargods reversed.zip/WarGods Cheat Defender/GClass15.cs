﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x02000030 RID: 48
public class GClass15
{
	// Token: 0x06000113 RID: 275 RVA: 0x00042890 File Offset: 0x00040A90
	public GClass15(string string_2, string string_3, ushort ushort_1, ulong ulong_0 = 0UL)
	{
		this.String_0 = string_2;
		this.String_1 = string_3;
		this.UInt16_0 = ushort_1;
		this.IntPtr_0 = (IntPtr)((long)ulong_0);
	}

	// Token: 0x17000090 RID: 144
	// (get) Token: 0x06000114 RID: 276 RVA: 0x000428C8 File Offset: 0x00040AC8
	// (set) Token: 0x06000115 RID: 277 RVA: 0x000428DC File Offset: 0x00040ADC
	public string String_0 { get; set; }

	// Token: 0x17000091 RID: 145
	// (get) Token: 0x06000116 RID: 278 RVA: 0x000428F0 File Offset: 0x00040AF0
	// (set) Token: 0x06000117 RID: 279 RVA: 0x00042904 File Offset: 0x00040B04
	public IntPtr IntPtr_0 { get; set; }

	// Token: 0x17000092 RID: 146
	// (get) Token: 0x06000118 RID: 280 RVA: 0x00042918 File Offset: 0x00040B18
	// (set) Token: 0x06000119 RID: 281 RVA: 0x0004292C File Offset: 0x00040B2C
	public string String_1 { get; set; }

	// Token: 0x17000093 RID: 147
	// (get) Token: 0x0600011A RID: 282 RVA: 0x00042940 File Offset: 0x00040B40
	// (set) Token: 0x0600011B RID: 283 RVA: 0x00042954 File Offset: 0x00040B54
	public ushort UInt16_0 { get; set; }

	// Token: 0x04000167 RID: 359
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04000168 RID: 360
	[CompilerGenerated]
	private IntPtr intptr_0;

	// Token: 0x04000169 RID: 361
	[CompilerGenerated]
	private string string_1;

	// Token: 0x0400016A RID: 362
	[CompilerGenerated]
	private ushort ushort_0;
}
