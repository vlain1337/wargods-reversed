﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Text;

// Token: 0x020000E3 RID: 227
internal class Class50
{
	// Token: 0x0600074E RID: 1870
	public static string GenerateSystemInfoString(string string_0 = "", string string_1 = "")
	{
		List<string> list = new List<string>();
		list.Add(string_0);
		list.Add(DateTime.Now.ToString(Class15.string_0, CultureInfo.InvariantCulture));
		string item = Class54.smethod_1();
		list.Add(item);
		string item2 = Class45.smethod_0();
		list.Add(item2);
		string item3 = Class46.smethod_0();
		list.Add(item3);
		string item4 = Class47.smethod_0();
		list.Add(item4);
		string item5 = Class48.smethod_0();
		list.Add(item5);
		string item6 = Class53.smethod_1();
		list.Add(item6);
		string item7 = Class44.smethod_0();
		list.Add(item7);
		string item8 = Class52.smethod_0();
		list.Add(item8);
		string item9 = Class51.smethod_0();
		list.Add(item9);
		string item10 = Class49.smethod_0();
		list.Add(item10);
		string item11 = Class56.smethod_0();
		list.Add(item11);
		try
		{
			CultureInfo installedUICulture = CultureInfo.InstalledUICulture;
			list.Add(installedUICulture.TwoLetterISOLanguageName.ToLower());
		}
		catch
		{
			list.Add("");
		}
		try
		{
			RegionInfo regionInfo = new RegionInfo(CultureInfo.InstalledUICulture.LCID);
			list.Add(regionInfo.TwoLetterISORegionName.ToLower());
		}
		catch
		{
			list.Add("");
		}
		string item12 = Class15.ExtractRelativePath(Process.GetCurrentProcess().MainModule.FileName);
		list.Add(item12);
		list.Add(string_1);
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < list.Count; i++)
		{
			stringBuilder.Append(list[i]);
			if (i + 1 != list.Count)
			{
				stringBuilder.Append(Class15.char_0);
			}
		}
		return stringBuilder.ToString();
	}
}
