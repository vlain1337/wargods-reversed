﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x0200001A RID: 26
public class GClass8 : GInterface0
{
	// Token: 0x060000BF RID: 191 RVA: 0x00041404 File Offset: 0x0003F604
	public GClass8(byte[] byte_1, string string_1)
	{
		this.String_0 = string_1;
		this.Byte_0 = byte_1;
		byte[] dst = new byte[84];
		Buffer.BlockCopy(byte_1, 0, dst, 0, 84);
		this.GClass2_0 = new GClass2(dst);
		FileInfo fileInfo = new FileInfo(string_1);
		this.DateTimeOffset_0 = new DateTimeOffset(fileInfo.CreationTimeUtc);
		this.DateTimeOffset_1 = new DateTimeOffset(fileInfo.LastWriteTimeUtc);
		this.DateTimeOffset_2 = new DateTimeOffset(fileInfo.LastAccessTimeUtc);
		byte[] array = new byte[224];
		Buffer.BlockCopy(byte_1, 84, array, 0, 224);
		this.Int32_0 = BitConverter.ToInt32(array, 0);
		this.Int32_1 = BitConverter.ToInt32(array, 4);
		this.Int32_2 = BitConverter.ToInt32(array, 8);
		this.Int32_3 = BitConverter.ToInt32(array, 12);
		this.Int32_4 = BitConverter.ToInt32(array, 16);
		this.Int32_5 = BitConverter.ToInt32(array, 20);
		this.Int32_6 = BitConverter.ToInt32(array, 24);
		this.Int32_7 = BitConverter.ToInt32(array, 28);
		this.Int32_8 = BitConverter.ToInt32(array, 32);
		this.Int32_9 = BitConverter.ToInt32(array, 36);
		byte[] value = GClass5.smethod_0(array, 44, 64);
		this.Prop_0 = new List<DateTimeOffset>();
		for (int i = 0; i < 8; i++)
		{
			long num = BitConverter.ToInt64(value, i * 8);
			if (num > 0L)
			{
				this.Prop_0.Add(DateTimeOffset.FromFileTime(num).ToUniversalTime());
			}
		}
		this.Int32_10 = BitConverter.ToInt32(array, 124);
		BitConverter.ToInt32(array, 128);
		BitConverter.ToInt32(array, 132);
		BitConverter.ToInt32(array, 128);
		byte[] array2 = new byte[this.Int32_1 * 32];
		Buffer.BlockCopy(byte_1, this.Int32_0, array2, 0, this.Int32_1 * 32);
		int j = 0;
		this.Prop_3 = new List<GClass1>();
		byte[] dst2 = new byte[32];
		while (j < array2.Length)
		{
			Buffer.BlockCopy(array2, j, dst2, 0, 32);
			this.Prop_3.Add(new GClass1(dst2, false));
			j += 32;
		}
		this.Prop_4 = new List<GClass4>();
		byte[] array3 = new byte[12 * this.Int32_3];
		Buffer.BlockCopy(byte_1, this.Int32_2, array3, 0, 12 * this.Int32_3);
		int k = 0;
		byte[] array4 = new byte[12];
		while (k < array3.Length)
		{
			Buffer.BlockCopy(array3, k, array4, 0, 12);
			this.Prop_4.Add(new GClass4(array4, false));
			k += 12;
		}
		byte[] array5 = new byte[this.Int32_5];
		Buffer.BlockCopy(byte_1, this.Int32_4, array5, 0, this.Int32_5);
		string[] collection = Encoding.Unicode.GetString(array5).Split(new char[1], StringSplitOptions.RemoveEmptyEntries);
		this.Prop_2 = new List<string>();
		this.Prop_2.AddRange(collection);
		byte[] array6 = new byte[this.Int32_8];
		Buffer.BlockCopy(byte_1, this.Int32_6, array6, 0, this.Int32_8);
		this.Prop_1 = new List<GClass11>();
		byte[] array7 = new byte[104];
		for (int l = 0; l < this.Int32_7; l++)
		{
			int srcOffset = l * 104;
			Buffer.BlockCopy(array6, srcOffset, array7, 0, 104);
			int num2 = BitConverter.ToInt32(array7, 0);
			int num3 = BitConverter.ToInt32(array7, 4);
			long fileTime = BitConverter.ToInt64(array7, 8);
			byte[] array8 = new byte[num3 * 2];
			Buffer.BlockCopy(byte_1, this.Int32_6 + num2, array8, 0, num3 * 2);
			string @string = Encoding.Unicode.GetString(array8);
			string string_2 = BitConverter.ToInt32(array7, 16).ToString(<Module>.DeserializeFromByteArray3<string>(4115400338U));
			this.Prop_1.Add(new GClass11(num2, DateTimeOffset.FromFileTime(fileTime).ToUniversalTime(), string_2, @string));
			int num4 = BitConverter.ToInt32(array7, 20);
			int num5 = BitConverter.ToInt32(array7, 24);
			int num6 = BitConverter.ToInt32(array7, 28);
			int num7 = BitConverter.ToInt32(array7, 32);
			int srcOffset2 = this.Int32_6 + num4;
			byte[] array9 = new byte[num5];
			Buffer.BlockCopy(byte_1, srcOffset2, array9, 0, num5);
			BitConverter.ToInt32(array9, 0);
			int num8 = BitConverter.ToInt32(array9, 4);
			j = 8;
			byte[] dst3 = new byte[8];
			while (j < array9.Length && this.Prop_1[this.Prop_1.Count - 1].List_0.Count < num8)
			{
				Buffer.BlockCopy(array9, j, dst3, 0, 8);
				this.Prop_1[this.Prop_1.Count - 1].List_0.Add(new GClass3(dst3));
				j += 8;
			}
			int num9 = this.Int32_6 + num6;
			byte[] array10 = new byte[byte_1.Length - num9];
			Buffer.BlockCopy(byte_1, num9, array10, 0, byte_1.Length - num9);
			j = 0;
			for (int m = 0; m < num7; m++)
			{
				int num10 = (int)(BitConverter.ToInt16(array10, j) * 2 + 2);
				j += 2;
				string item = Encoding.Unicode.GetString(array10, j, num10).Trim(new char[1]);
				this.Prop_1[this.Prop_1.Count - 1].List_1.Add(item);
				j += num10;
			}
		}
	}

	// Token: 0x1700005A RID: 90
	// (get) Token: 0x060000C0 RID: 192 RVA: 0x0004194C File Offset: 0x0003FB4C
	public byte[] Byte_0 { get; }

	// Token: 0x1700005B RID: 91
	// (get) Token: 0x060000C1 RID: 193 RVA: 0x00041960 File Offset: 0x0003FB60
	public string String_0 { get; }

	// Token: 0x1700005C RID: 92
	// (get) Token: 0x060000C2 RID: 194 RVA: 0x00041974 File Offset: 0x0003FB74
	public DateTimeOffset DateTimeOffset_0 { get; }

	// Token: 0x1700005D RID: 93
	// (get) Token: 0x060000C3 RID: 195 RVA: 0x00041988 File Offset: 0x0003FB88
	public DateTimeOffset DateTimeOffset_1 { get; }

	// Token: 0x1700005E RID: 94
	// (get) Token: 0x060000C4 RID: 196 RVA: 0x0004199C File Offset: 0x0003FB9C
	public DateTimeOffset DateTimeOffset_2 { get; }

	// Token: 0x1700005F RID: 95
	// (get) Token: 0x060000C5 RID: 197 RVA: 0x000419B0 File Offset: 0x0003FBB0
	public GClass2 GClass2_0 { get; }

	// Token: 0x17000060 RID: 96
	// (get) Token: 0x060000C6 RID: 198 RVA: 0x000419C4 File Offset: 0x0003FBC4
	public int Int32_0 { get; }

	// Token: 0x17000061 RID: 97
	// (get) Token: 0x060000C7 RID: 199 RVA: 0x000419D8 File Offset: 0x0003FBD8
	public int Int32_1 { get; }

	// Token: 0x17000062 RID: 98
	// (get) Token: 0x060000C8 RID: 200 RVA: 0x000419EC File Offset: 0x0003FBEC
	public int Int32_2 { get; }

	// Token: 0x17000063 RID: 99
	// (get) Token: 0x060000C9 RID: 201 RVA: 0x00041A00 File Offset: 0x0003FC00
	public int Int32_3 { get; }

	// Token: 0x17000064 RID: 100
	// (get) Token: 0x060000CA RID: 202 RVA: 0x00041A14 File Offset: 0x0003FC14
	public int Int32_4 { get; }

	// Token: 0x17000065 RID: 101
	// (get) Token: 0x060000CB RID: 203 RVA: 0x00041A28 File Offset: 0x0003FC28
	public int Int32_5 { get; }

	// Token: 0x17000066 RID: 102
	// (get) Token: 0x060000CC RID: 204 RVA: 0x00041A3C File Offset: 0x0003FC3C
	public int Int32_6 { get; }

	// Token: 0x17000067 RID: 103
	// (get) Token: 0x060000CD RID: 205 RVA: 0x00041A50 File Offset: 0x0003FC50
	public int Int32_7 { get; }

	// Token: 0x17000068 RID: 104
	// (get) Token: 0x060000CE RID: 206 RVA: 0x00041A64 File Offset: 0x0003FC64
	public int Int32_8 { get; }

	// Token: 0x17000069 RID: 105
	// (get) Token: 0x060000CF RID: 207 RVA: 0x00041A78 File Offset: 0x0003FC78
	public int Int32_9 { get; }

	// Token: 0x1700006A RID: 106
	// (get) Token: 0x060000D0 RID: 208 RVA: 0x00041A8C File Offset: 0x0003FC8C
	public List<DateTimeOffset> Prop_0 { get; }

	// Token: 0x1700006B RID: 107
	// (get) Token: 0x060000D1 RID: 209 RVA: 0x00041AA0 File Offset: 0x0003FCA0
	public List<GClass11> Prop_1 { get; }

	// Token: 0x1700006C RID: 108
	// (get) Token: 0x060000D2 RID: 210 RVA: 0x00041AB4 File Offset: 0x0003FCB4
	public int Int32_10 { get; }

	// Token: 0x1700006D RID: 109
	// (get) Token: 0x060000D3 RID: 211 RVA: 0x00041AC8 File Offset: 0x0003FCC8
	public List<string> Prop_2 { get; }

	// Token: 0x1700006E RID: 110
	// (get) Token: 0x060000D4 RID: 212 RVA: 0x00041ADC File Offset: 0x0003FCDC
	public List<GClass1> Prop_3 { get; }

	// Token: 0x1700006F RID: 111
	// (get) Token: 0x060000D5 RID: 213 RVA: 0x00041AF0 File Offset: 0x0003FCF0
	public List<GClass4> Prop_4 { get; }

	// Token: 0x04000089 RID: 137
	[CompilerGenerated]
	private readonly byte[] byte_0;

	// Token: 0x0400008A RID: 138
	[CompilerGenerated]
	private readonly string string_0;

	// Token: 0x0400008B RID: 139
	[CompilerGenerated]
	private readonly DateTimeOffset dateTimeOffset_0;

	// Token: 0x0400008C RID: 140
	[CompilerGenerated]
	private readonly DateTimeOffset dateTimeOffset_1;

	// Token: 0x0400008D RID: 141
	[CompilerGenerated]
	private readonly DateTimeOffset dateTimeOffset_2;

	// Token: 0x0400008E RID: 142
	[CompilerGenerated]
	private readonly GClass2 gclass2_0;

	// Token: 0x0400008F RID: 143
	[CompilerGenerated]
	private readonly int int_0;

	// Token: 0x04000090 RID: 144
	[CompilerGenerated]
	private readonly int int_1;

	// Token: 0x04000091 RID: 145
	[CompilerGenerated]
	private readonly int int_2;

	// Token: 0x04000092 RID: 146
	[CompilerGenerated]
	private readonly int int_3;

	// Token: 0x04000093 RID: 147
	[CompilerGenerated]
	private readonly int int_4;

	// Token: 0x04000094 RID: 148
	[CompilerGenerated]
	private readonly int int_5;

	// Token: 0x04000095 RID: 149
	[CompilerGenerated]
	private readonly int int_6;

	// Token: 0x04000096 RID: 150
	[CompilerGenerated]
	private readonly int int_7;

	// Token: 0x04000097 RID: 151
	[CompilerGenerated]
	private readonly int int_8;

	// Token: 0x04000098 RID: 152
	[CompilerGenerated]
	private readonly int int_9;

	// Token: 0x04000099 RID: 153
	[CompilerGenerated]
	private readonly List<DateTimeOffset> list_0;

	// Token: 0x0400009A RID: 154
	[CompilerGenerated]
	private readonly List<GClass11> list_1;

	// Token: 0x0400009B RID: 155
	[CompilerGenerated]
	private readonly int int_10;

	// Token: 0x0400009C RID: 156
	[CompilerGenerated]
	private readonly List<string> list_2;

	// Token: 0x0400009D RID: 157
	[CompilerGenerated]
	private readonly List<GClass1> list_3;

	// Token: 0x0400009E RID: 158
	[CompilerGenerated]
	private readonly List<GClass4> list_4;
}
