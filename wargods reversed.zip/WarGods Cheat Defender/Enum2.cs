﻿using System;

// Token: 0x0200003F RID: 63
internal enum Enum2
{
	// Token: 0x040001D5 RID: 469
	const_0 = 1,
	// Token: 0x040001D6 RID: 470
	const_1,
	// Token: 0x040001D7 RID: 471
	const_2,
	// Token: 0x040001D8 RID: 472
	const_3,
	// Token: 0x040001D9 RID: 473
	const_4
}
