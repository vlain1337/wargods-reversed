﻿using System;

// Token: 0x020000FB RID: 251
public enum GEnum58 : uint
{
	// Token: 0x04000B3A RID: 2874
	const_0,
	// Token: 0x04000B3B RID: 2875
	const_1
}
