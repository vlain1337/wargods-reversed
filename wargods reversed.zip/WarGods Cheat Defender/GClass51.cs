﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x020000AE RID: 174
public class GClass51
{
	// Token: 0x17000177 RID: 375
	// (get) Token: 0x0600043C RID: 1084 RVA: 0x000534A8 File Offset: 0x000516A8
	// (set) Token: 0x0600043D RID: 1085 RVA: 0x000534BC File Offset: 0x000516BC
	public GEnum23 GEnum23_0 { get; set; }

	// Token: 0x17000178 RID: 376
	// (get) Token: 0x0600043E RID: 1086 RVA: 0x000534D0 File Offset: 0x000516D0
	// (set) Token: 0x0600043F RID: 1087 RVA: 0x000534E4 File Offset: 0x000516E4
	public DateTime DateTime_0 { get; set; }

	// Token: 0x17000179 RID: 377
	// (get) Token: 0x06000440 RID: 1088 RVA: 0x000534F8 File Offset: 0x000516F8
	// (set) Token: 0x06000441 RID: 1089 RVA: 0x0005350C File Offset: 0x0005170C
	public string String_0 { get; set; }

	// Token: 0x1700017A RID: 378
	// (get) Token: 0x06000442 RID: 1090 RVA: 0x00053520 File Offset: 0x00051720
	// (set) Token: 0x06000443 RID: 1091 RVA: 0x00053534 File Offset: 0x00051734
	public string String_1 { get; set; }

	// Token: 0x1700017B RID: 379
	// (get) Token: 0x06000444 RID: 1092 RVA: 0x00053548 File Offset: 0x00051748
	// (set) Token: 0x06000445 RID: 1093 RVA: 0x0005355C File Offset: 0x0005175C
	public string String_2 { get; set; }

	// Token: 0x1700017C RID: 380
	// (get) Token: 0x06000446 RID: 1094 RVA: 0x00053570 File Offset: 0x00051770
	// (set) Token: 0x06000447 RID: 1095 RVA: 0x00053584 File Offset: 0x00051784
	public string String_3 { get; set; }

	// Token: 0x1700017D RID: 381
	// (get) Token: 0x06000448 RID: 1096 RVA: 0x00053598 File Offset: 0x00051798
	// (set) Token: 0x06000449 RID: 1097 RVA: 0x000535AC File Offset: 0x000517AC
	public bool Boolean_0 { get; set; }

	// Token: 0x1700017E RID: 382
	// (get) Token: 0x0600044A RID: 1098 RVA: 0x000535C0 File Offset: 0x000517C0
	// (set) Token: 0x0600044B RID: 1099 RVA: 0x000535D4 File Offset: 0x000517D4
	public List<GClass41> List_0 { get; set; }

	// Token: 0x1700017F RID: 383
	// (get) Token: 0x0600044C RID: 1100 RVA: 0x000535E8 File Offset: 0x000517E8
	// (set) Token: 0x0600044D RID: 1101 RVA: 0x000535FC File Offset: 0x000517FC
	public string String_4 { get; set; }

	// Token: 0x17000180 RID: 384
	// (get) Token: 0x0600044E RID: 1102 RVA: 0x00053610 File Offset: 0x00051810
	// (set) Token: 0x0600044F RID: 1103 RVA: 0x00053624 File Offset: 0x00051824
	public string String_5 { get; set; }

	// Token: 0x17000181 RID: 385
	// (get) Token: 0x06000450 RID: 1104 RVA: 0x00053638 File Offset: 0x00051838
	// (set) Token: 0x06000451 RID: 1105 RVA: 0x0005364C File Offset: 0x0005184C
	public string String_6 { get; set; }

	// Token: 0x17000182 RID: 386
	// (get) Token: 0x06000452 RID: 1106 RVA: 0x00053660 File Offset: 0x00051860
	// (set) Token: 0x06000453 RID: 1107 RVA: 0x00053674 File Offset: 0x00051874
	public string String_7 { get; set; }

	// Token: 0x17000183 RID: 387
	// (get) Token: 0x06000454 RID: 1108 RVA: 0x00053688 File Offset: 0x00051888
	// (set) Token: 0x06000455 RID: 1109 RVA: 0x0005369C File Offset: 0x0005189C
	public List<GClass44> List_1 { get; set; }

	// Token: 0x17000184 RID: 388
	// (get) Token: 0x06000456 RID: 1110 RVA: 0x000536B0 File Offset: 0x000518B0
	// (set) Token: 0x06000457 RID: 1111 RVA: 0x000536C4 File Offset: 0x000518C4
	public List<string> List_2 { get; set; }

	// Token: 0x17000185 RID: 389
	// (get) Token: 0x06000458 RID: 1112 RVA: 0x000536D8 File Offset: 0x000518D8
	// (set) Token: 0x06000459 RID: 1113 RVA: 0x000536EC File Offset: 0x000518EC
	public List<string> List_3 { get; set; }

	// Token: 0x17000186 RID: 390
	// (get) Token: 0x0600045A RID: 1114 RVA: 0x00053700 File Offset: 0x00051900
	// (set) Token: 0x0600045B RID: 1115 RVA: 0x00053714 File Offset: 0x00051914
	public string String_8 { get; set; }

	// Token: 0x17000187 RID: 391
	// (get) Token: 0x0600045C RID: 1116 RVA: 0x00053728 File Offset: 0x00051928
	// (set) Token: 0x0600045D RID: 1117 RVA: 0x0005373C File Offset: 0x0005193C
	public string String_9 { get; set; }

	// Token: 0x17000188 RID: 392
	// (get) Token: 0x0600045E RID: 1118 RVA: 0x00053750 File Offset: 0x00051950
	// (set) Token: 0x0600045F RID: 1119 RVA: 0x00053764 File Offset: 0x00051964
	public string String_10 { get; set; }

	// Token: 0x17000189 RID: 393
	// (get) Token: 0x06000460 RID: 1120 RVA: 0x00053778 File Offset: 0x00051978
	// (set) Token: 0x06000461 RID: 1121 RVA: 0x0005378C File Offset: 0x0005198C
	public List<string> List_4 { get; set; }

	// Token: 0x1700018A RID: 394
	// (get) Token: 0x06000462 RID: 1122 RVA: 0x000537A0 File Offset: 0x000519A0
	// (set) Token: 0x06000463 RID: 1123 RVA: 0x000537B4 File Offset: 0x000519B4
	public string String_11 { get; set; }

	// Token: 0x1700018B RID: 395
	// (get) Token: 0x06000464 RID: 1124 RVA: 0x000537C8 File Offset: 0x000519C8
	// (set) Token: 0x06000465 RID: 1125 RVA: 0x000537DC File Offset: 0x000519DC
	public string String_12 { get; set; }

	// Token: 0x1700018C RID: 396
	// (get) Token: 0x06000466 RID: 1126 RVA: 0x000537F0 File Offset: 0x000519F0
	// (set) Token: 0x06000467 RID: 1127 RVA: 0x00053804 File Offset: 0x00051A04
	public string String_13 { get; set; }

	// Token: 0x1700018D RID: 397
	// (get) Token: 0x06000468 RID: 1128 RVA: 0x00053818 File Offset: 0x00051A18
	// (set) Token: 0x06000469 RID: 1129 RVA: 0x0005382C File Offset: 0x00051A2C
	public string String_14 { get; set; }

	// Token: 0x1700018E RID: 398
	// (get) Token: 0x0600046A RID: 1130 RVA: 0x00053840 File Offset: 0x00051A40
	// (set) Token: 0x0600046B RID: 1131 RVA: 0x00053854 File Offset: 0x00051A54
	public List<string> List_5 { get; set; }

	// Token: 0x1700018F RID: 399
	// (get) Token: 0x0600046C RID: 1132 RVA: 0x00053868 File Offset: 0x00051A68
	// (set) Token: 0x0600046D RID: 1133 RVA: 0x0005387C File Offset: 0x00051A7C
	public List<string> List_6 { get; set; }

	// Token: 0x17000190 RID: 400
	// (get) Token: 0x0600046E RID: 1134 RVA: 0x00053890 File Offset: 0x00051A90
	// (set) Token: 0x0600046F RID: 1135 RVA: 0x000538A4 File Offset: 0x00051AA4
	public List<string> List_7 { get; set; }

	// Token: 0x17000191 RID: 401
	// (get) Token: 0x06000470 RID: 1136 RVA: 0x000538B8 File Offset: 0x00051AB8
	// (set) Token: 0x06000471 RID: 1137 RVA: 0x000538CC File Offset: 0x00051ACC
	public GClass45.GEnum34 GEnum34_0 { get; set; }

	// Token: 0x17000192 RID: 402
	// (get) Token: 0x06000472 RID: 1138 RVA: 0x000538E0 File Offset: 0x00051AE0
	// (set) Token: 0x06000473 RID: 1139 RVA: 0x000538F4 File Offset: 0x00051AF4
	public GClass55 GClass55_0 { get; set; }

	// Token: 0x17000193 RID: 403
	// (get) Token: 0x06000474 RID: 1140 RVA: 0x00053908 File Offset: 0x00051B08
	// (set) Token: 0x06000475 RID: 1141 RVA: 0x0005391C File Offset: 0x00051B1C
	public List<string> List_8 { get; set; }

	// Token: 0x17000194 RID: 404
	// (get) Token: 0x06000476 RID: 1142 RVA: 0x00053930 File Offset: 0x00051B30
	// (set) Token: 0x06000477 RID: 1143 RVA: 0x00053944 File Offset: 0x00051B44
	public List<string> List_9 { get; set; }

	// Token: 0x17000195 RID: 405
	// (get) Token: 0x06000478 RID: 1144 RVA: 0x00053958 File Offset: 0x00051B58
	// (set) Token: 0x06000479 RID: 1145 RVA: 0x0005396C File Offset: 0x00051B6C
	public List<string> List_10 { get; set; }

	// Token: 0x17000196 RID: 406
	// (get) Token: 0x0600047A RID: 1146 RVA: 0x00053980 File Offset: 0x00051B80
	// (set) Token: 0x0600047B RID: 1147 RVA: 0x00053994 File Offset: 0x00051B94
	public List<long> List_11 { get; set; }

	// Token: 0x0600047C RID: 1148 RVA: 0x000539A8 File Offset: 0x00051BA8
	public static string smethod_0(Dictionary<GEnum49, long> dictionary_1)
	{
		string text = "";
		foreach (KeyValuePair<GEnum49, long> keyValuePair in dictionary_1)
		{
			if (text != "")
			{
				text += Class15.char_0.ToString();
			}
			text = text + ((long)keyValuePair.Key).ToString() + Class15.char_2.ToString() + keyValuePair.Value.ToString();
		}
		return text;
	}

	// Token: 0x0600047D RID: 1149 RVA: 0x00053A50 File Offset: 0x00051C50
	public GClass51()
	{
		this.DateTime_0 = DateTime.Now;
		this.String_0 = "";
		this.String_1 = "";
		this.String_2 = "";
		this.String_3 = "";
		this.String_4 = "";
		this.String_5 = Class14.String_161;
		this.String_6 = Class14.String_215;
		this.String_7 = "";
		this.String_8 = "";
		this.String_10 = "";
		this.String_9 = "";
		this.String_11 = "";
		this.String_12 = "";
		this.String_13 = "";
		this.String_14 = "";
		this.GEnum23_0 = GEnum23.const_0;
		this.List_1 = new List<GClass44>();
		this.List_2 = new List<string>();
		this.List_3 = new List<string>();
		this.List_0 = new List<GClass41>();
		this.List_4 = new List<string>();
		this.List_5 = new List<string>();
		this.List_6 = new List<string>();
		this.List_7 = new List<string>();
		this.List_9 = new List<string>();
		this.List_10 = new List<string>();
		this.GEnum34_0 = GClass45.GEnum34.const_0;
		this.GClass55_0 = null;
		this.long_0 = -1L;
		this.long_1 = -1L;
		this.long_2 = -1L;
		this.List_8 = new List<string>();
		this.string_15 = "";
		this.Boolean_0 = false;
		this.List_11 = new List<long>();
		this.long_3 = -1L;
		this.long_4 = -1L;
		this.dictionary_0 = new Dictionary<GEnum49, long>();
		this.double_0 = 0.0;
		this.double_1 = 0.0;
		this.int_0 = 0;
		this.bool_1 = false;
	}

	// Token: 0x0400061B RID: 1563
	[CompilerGenerated]
	private GEnum23 genum23_0;

	// Token: 0x0400061C RID: 1564
	[CompilerGenerated]
	private DateTime dateTime_0;

	// Token: 0x0400061D RID: 1565
	[CompilerGenerated]
	private string string_0;

	// Token: 0x0400061E RID: 1566
	[CompilerGenerated]
	private string string_1;

	// Token: 0x0400061F RID: 1567
	[CompilerGenerated]
	private string string_2;

	// Token: 0x04000620 RID: 1568
	[CompilerGenerated]
	private string string_3;

	// Token: 0x04000621 RID: 1569
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x04000622 RID: 1570
	[CompilerGenerated]
	private List<GClass41> list_0;

	// Token: 0x04000623 RID: 1571
	[CompilerGenerated]
	private string string_4;

	// Token: 0x04000624 RID: 1572
	[CompilerGenerated]
	private string string_5;

	// Token: 0x04000625 RID: 1573
	[CompilerGenerated]
	private string string_6;

	// Token: 0x04000626 RID: 1574
	[CompilerGenerated]
	private string string_7;

	// Token: 0x04000627 RID: 1575
	[CompilerGenerated]
	private List<GClass44> list_1;

	// Token: 0x04000628 RID: 1576
	[CompilerGenerated]
	private List<string> list_2;

	// Token: 0x04000629 RID: 1577
	[CompilerGenerated]
	private List<string> list_3;

	// Token: 0x0400062A RID: 1578
	[CompilerGenerated]
	private string string_8;

	// Token: 0x0400062B RID: 1579
	[CompilerGenerated]
	private string string_9;

	// Token: 0x0400062C RID: 1580
	[CompilerGenerated]
	private string string_10;

	// Token: 0x0400062D RID: 1581
	[CompilerGenerated]
	private List<string> list_4;

	// Token: 0x0400062E RID: 1582
	[CompilerGenerated]
	private string string_11;

	// Token: 0x0400062F RID: 1583
	[CompilerGenerated]
	private string string_12;

	// Token: 0x04000630 RID: 1584
	[CompilerGenerated]
	private string string_13;

	// Token: 0x04000631 RID: 1585
	[CompilerGenerated]
	private string string_14;

	// Token: 0x04000632 RID: 1586
	[CompilerGenerated]
	private List<string> list_5;

	// Token: 0x04000633 RID: 1587
	[CompilerGenerated]
	private List<string> list_6;

	// Token: 0x04000634 RID: 1588
	[CompilerGenerated]
	private List<string> list_7;

	// Token: 0x04000635 RID: 1589
	[CompilerGenerated]
	private GClass45.GEnum34 genum34_0;

	// Token: 0x04000636 RID: 1590
	[CompilerGenerated]
	private GClass55 gclass55_0;

	// Token: 0x04000637 RID: 1591
	public long long_0;

	// Token: 0x04000638 RID: 1592
	public long long_1;

	// Token: 0x04000639 RID: 1593
	public long long_2;

	// Token: 0x0400063A RID: 1594
	[CompilerGenerated]
	private List<string> list_8;

	// Token: 0x0400063B RID: 1595
	[CompilerGenerated]
	private List<string> list_9;

	// Token: 0x0400063C RID: 1596
	[CompilerGenerated]
	private List<string> list_10;

	// Token: 0x0400063D RID: 1597
	[CompilerGenerated]
	private List<long> list_11;

	// Token: 0x0400063E RID: 1598
	public string string_15;

	// Token: 0x0400063F RID: 1599
	public long long_3;

	// Token: 0x04000640 RID: 1600
	public long long_4;

	// Token: 0x04000641 RID: 1601
	public double double_0;

	// Token: 0x04000642 RID: 1602
	public double double_1;

	// Token: 0x04000643 RID: 1603
	public int int_0;

	// Token: 0x04000644 RID: 1604
	public bool bool_1;

	// Token: 0x04000645 RID: 1605
	public Dictionary<GEnum49, long> dictionary_0;
}
