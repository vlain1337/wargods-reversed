﻿using System;

// Token: 0x0200005C RID: 92
public class GException4 : Exception
{
	// Token: 0x06000321 RID: 801 RVA: 0x00042334 File Offset: 0x00040534
	public GException4(string string_0) : base(string_0)
	{
	}
}
