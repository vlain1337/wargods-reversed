﻿using System;

// Token: 0x020000F6 RID: 246
public enum GEnum56
{
	// Token: 0x04000AFF RID: 2815
	const_0,
	// Token: 0x04000B00 RID: 2816
	const_1,
	// Token: 0x04000B01 RID: 2817
	const_2,
	// Token: 0x04000B02 RID: 2818
	const_3,
	// Token: 0x04000B03 RID: 2819
	const_4,
	// Token: 0x04000B04 RID: 2820
	const_5,
	// Token: 0x04000B05 RID: 2821
	const_6,
	// Token: 0x04000B06 RID: 2822
	const_7,
	// Token: 0x04000B07 RID: 2823
	const_8,
	// Token: 0x04000B08 RID: 2824
	const_9,
	// Token: 0x04000B09 RID: 2825
	const_10,
	// Token: 0x04000B0A RID: 2826
	const_11,
	// Token: 0x04000B0B RID: 2827
	const_12,
	// Token: 0x04000B0C RID: 2828
	const_13,
	// Token: 0x04000B0D RID: 2829
	const_14,
	// Token: 0x04000B0E RID: 2830
	const_15,
	// Token: 0x04000B0F RID: 2831
	const_16,
	// Token: 0x04000B10 RID: 2832
	const_17,
	// Token: 0x04000B11 RID: 2833
	const_18,
	// Token: 0x04000B12 RID: 2834
	const_19,
	// Token: 0x04000B13 RID: 2835
	const_20,
	// Token: 0x04000B14 RID: 2836
	const_21,
	// Token: 0x04000B15 RID: 2837
	const_22,
	// Token: 0x04000B16 RID: 2838
	const_23,
	// Token: 0x04000B17 RID: 2839
	const_24,
	// Token: 0x04000B18 RID: 2840
	const_25,
	// Token: 0x04000B19 RID: 2841
	const_26,
	// Token: 0x04000B1A RID: 2842
	const_27,
	// Token: 0x04000B1B RID: 2843
	const_28,
	// Token: 0x04000B1C RID: 2844
	const_29,
	// Token: 0x04000B1D RID: 2845
	const_30,
	// Token: 0x04000B1E RID: 2846
	const_31,
	// Token: 0x04000B1F RID: 2847
	const_32,
	// Token: 0x04000B20 RID: 2848
	const_33,
	// Token: 0x04000B21 RID: 2849
	const_34,
	// Token: 0x04000B22 RID: 2850
	const_35,
	// Token: 0x04000B23 RID: 2851
	const_36,
	// Token: 0x04000B24 RID: 2852
	const_37,
	// Token: 0x04000B25 RID: 2853
	const_38,
	// Token: 0x04000B26 RID: 2854
	const_39,
	// Token: 0x04000B27 RID: 2855
	const_40,
	// Token: 0x04000B28 RID: 2856
	const_41,
	// Token: 0x04000B29 RID: 2857
	const_42,
	// Token: 0x04000B2A RID: 2858
	const_43,
	// Token: 0x04000B2B RID: 2859
	const_44,
	// Token: 0x04000B2C RID: 2860
	const_45,
	// Token: 0x04000B2D RID: 2861
	const_46
}
