﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x02000018 RID: 24
public class GClass6 : GInterface0
{
	// Token: 0x06000091 RID: 145 RVA: 0x000406B0 File Offset: 0x0003E8B0
	public GClass6(byte[] byte_1, string string_1)
	{
		this.String_0 = string_1;
		this.Byte_0 = byte_1;
		byte[] dst = new byte[84];
		Buffer.BlockCopy(byte_1, 0, dst, 0, 84);
		this.GClass2_0 = new GClass2(dst);
		FileInfo fileInfo = new FileInfo(string_1);
		this.DateTimeOffset_0 = new DateTimeOffset(fileInfo.CreationTimeUtc);
		this.DateTimeOffset_1 = new DateTimeOffset(fileInfo.LastWriteTimeUtc);
		this.DateTimeOffset_2 = new DateTimeOffset(fileInfo.LastAccessTimeUtc);
		byte[] array = new byte[68];
		Buffer.BlockCopy(byte_1, 84, array, 0, 68);
		this.Int32_0 = BitConverter.ToInt32(array, 0);
		this.Int32_1 = BitConverter.ToInt32(array, 4);
		this.Int32_2 = BitConverter.ToInt32(array, 8);
		this.Int32_3 = BitConverter.ToInt32(array, 12);
		this.Int32_4 = BitConverter.ToInt32(array, 16);
		this.Int32_5 = BitConverter.ToInt32(array, 20);
		this.Int32_6 = BitConverter.ToInt32(array, 24);
		this.Int32_7 = BitConverter.ToInt32(array, 28);
		this.Int32_8 = BitConverter.ToInt32(array, 32);
		long fileTime = BitConverter.ToInt64(array, 36);
		this.Prop_0 = new List<DateTimeOffset>();
		this.Prop_0.Add(DateTimeOffset.FromFileTime(fileTime).ToUniversalTime());
		this.Int32_9 = -1;
		this.Int32_10 = BitConverter.ToInt32(array, 60);
		byte[] array2 = new byte[this.Int32_1 * 20];
		Buffer.BlockCopy(byte_1, this.Int32_0, array2, 0, this.Int32_1 * 20);
		int i = 0;
		this.Prop_3 = new List<GClass1>();
		byte[] dst2 = new byte[20];
		while (i < array2.Length)
		{
			Buffer.BlockCopy(array2, i, dst2, 0, 20);
			this.Prop_3.Add(new GClass1(dst2, true));
			i += 20;
		}
		this.Prop_4 = new List<GClass4>();
		byte[] array3 = new byte[12 * this.Int32_3];
		Buffer.BlockCopy(byte_1, this.Int32_2, array3, 0, 12 * this.Int32_3);
		int j = 0;
		byte[] array4 = new byte[12];
		while (j < array3.Length)
		{
			Buffer.BlockCopy(array3, j, array4, 0, 12);
			this.Prop_4.Add(new GClass4(array4, false));
			j += 12;
		}
		byte[] array5 = new byte[this.Int32_5];
		Buffer.BlockCopy(byte_1, this.Int32_4, array5, 0, this.Int32_5);
		string[] collection = Encoding.Unicode.GetString(array5).Split(new char[1], StringSplitOptions.RemoveEmptyEntries);
		this.Prop_2 = new List<string>();
		this.Prop_2.AddRange(collection);
		byte[] array6 = new byte[this.Int32_8];
		Buffer.BlockCopy(byte_1, this.Int32_6, array6, 0, this.Int32_8);
		this.Prop_1 = new List<GClass11>();
		byte[] array7 = new byte[40];
		for (int k = 0; k < this.Int32_7; k++)
		{
			int srcOffset = k * 40;
			Buffer.BlockCopy(array6, srcOffset, array7, 0, 40);
			int num = BitConverter.ToInt32(array7, 0);
			int num2 = BitConverter.ToInt32(array7, 4);
			long fileTime2 = BitConverter.ToInt64(array7, 8);
			byte[] array8 = new byte[num2 * 2];
			Buffer.BlockCopy(byte_1, this.Int32_6 + num, array8, 0, num2 * 2);
			string @string = Encoding.Unicode.GetString(array8);
			string string_2 = BitConverter.ToInt32(array7, 16).ToString(<Module>.DeserializeFromByteArrayV2<string>(2190331133U));
			this.Prop_1.Add(new GClass11(num, DateTimeOffset.FromFileTime(fileTime2).ToUniversalTime(), string_2, @string));
			int num3 = BitConverter.ToInt32(array7, 20);
			int num4 = BitConverter.ToInt32(array7, 24);
			int num5 = BitConverter.ToInt32(array7, 28);
			int num6 = BitConverter.ToInt32(array7, 32);
			int srcOffset2 = this.Int32_6 + num3;
			byte[] array9 = new byte[num4];
			Buffer.BlockCopy(byte_1, srcOffset2, array9, 0, num4);
			BitConverter.ToInt32(array9, 0);
			int num7 = BitConverter.ToInt32(array9, 4);
			i = 8;
			byte[] dst3 = new byte[8];
			while (i < array9.Length && this.Prop_1[this.Prop_1.Count - 1].List_0.Count < num7)
			{
				Buffer.BlockCopy(array9, i, dst3, 0, 8);
				this.Prop_1[this.Prop_1.Count - 1].List_0.Add(new GClass3(dst3));
				i += 8;
			}
			int num8 = this.Int32_6 + num5;
			byte[] array10 = new byte[byte_1.Length - num8];
			Buffer.BlockCopy(byte_1, num8, array10, 0, byte_1.Length - num8);
			i = 0;
			for (int l = 0; l < num6; l++)
			{
				int num9 = (int)(BitConverter.ToInt16(array10, i) * 2 + 2);
				i += 2;
				string item = Encoding.Unicode.GetString(array10, i, num9).Trim(new char[1]);
				this.Prop_1[this.Prop_1.Count - 1].List_1.Add(item);
				i += num9;
			}
		}
	}

	// Token: 0x1700002E RID: 46
	// (get) Token: 0x06000092 RID: 146 RVA: 0x00040B9C File Offset: 0x0003ED9C
	public byte[] Byte_0 { get; }

	// Token: 0x1700002F RID: 47
	// (get) Token: 0x06000093 RID: 147 RVA: 0x00040BB0 File Offset: 0x0003EDB0
	public string String_0 { get; }

	// Token: 0x17000030 RID: 48
	// (get) Token: 0x06000094 RID: 148 RVA: 0x00040BC4 File Offset: 0x0003EDC4
	public DateTimeOffset DateTimeOffset_0 { get; }

	// Token: 0x17000031 RID: 49
	// (get) Token: 0x06000095 RID: 149 RVA: 0x00040BD8 File Offset: 0x0003EDD8
	public DateTimeOffset DateTimeOffset_1 { get; }

	// Token: 0x17000032 RID: 50
	// (get) Token: 0x06000096 RID: 150 RVA: 0x00040BEC File Offset: 0x0003EDEC
	public DateTimeOffset DateTimeOffset_2 { get; }

	// Token: 0x17000033 RID: 51
	// (get) Token: 0x06000097 RID: 151 RVA: 0x00040C00 File Offset: 0x0003EE00
	public GClass2 GClass2_0 { get; }

	// Token: 0x17000034 RID: 52
	// (get) Token: 0x06000098 RID: 152 RVA: 0x00040C14 File Offset: 0x0003EE14
	public int Int32_0 { get; }

	// Token: 0x17000035 RID: 53
	// (get) Token: 0x06000099 RID: 153 RVA: 0x00040C28 File Offset: 0x0003EE28
	public int Int32_1 { get; }

	// Token: 0x17000036 RID: 54
	// (get) Token: 0x0600009A RID: 154 RVA: 0x00040C3C File Offset: 0x0003EE3C
	public int Int32_2 { get; }

	// Token: 0x17000037 RID: 55
	// (get) Token: 0x0600009B RID: 155 RVA: 0x00040C50 File Offset: 0x0003EE50
	public int Int32_3 { get; }

	// Token: 0x17000038 RID: 56
	// (get) Token: 0x0600009C RID: 156 RVA: 0x00040C64 File Offset: 0x0003EE64
	public int Int32_4 { get; }

	// Token: 0x17000039 RID: 57
	// (get) Token: 0x0600009D RID: 157 RVA: 0x00040C78 File Offset: 0x0003EE78
	public int Int32_5 { get; }

	// Token: 0x1700003A RID: 58
	// (get) Token: 0x0600009E RID: 158 RVA: 0x00040C8C File Offset: 0x0003EE8C
	public int Int32_6 { get; }

	// Token: 0x1700003B RID: 59
	// (get) Token: 0x0600009F RID: 159 RVA: 0x00040CA0 File Offset: 0x0003EEA0
	public int Int32_7 { get; }

	// Token: 0x1700003C RID: 60
	// (get) Token: 0x060000A0 RID: 160 RVA: 0x00040CB4 File Offset: 0x0003EEB4
	public int Int32_8 { get; }

	// Token: 0x1700003D RID: 61
	// (get) Token: 0x060000A1 RID: 161 RVA: 0x00040CC8 File Offset: 0x0003EEC8
	public int Int32_9 { get; }

	// Token: 0x1700003E RID: 62
	// (get) Token: 0x060000A2 RID: 162 RVA: 0x00040CDC File Offset: 0x0003EEDC
	public List<DateTimeOffset> Prop_0 { get; }

	// Token: 0x1700003F RID: 63
	// (get) Token: 0x060000A3 RID: 163 RVA: 0x00040CF0 File Offset: 0x0003EEF0
	public List<GClass11> Prop_1 { get; }

	// Token: 0x17000040 RID: 64
	// (get) Token: 0x060000A4 RID: 164 RVA: 0x00040D04 File Offset: 0x0003EF04
	public int Int32_10 { get; }

	// Token: 0x17000041 RID: 65
	// (get) Token: 0x060000A5 RID: 165 RVA: 0x00040D18 File Offset: 0x0003EF18
	public List<string> Prop_2 { get; }

	// Token: 0x17000042 RID: 66
	// (get) Token: 0x060000A6 RID: 166 RVA: 0x00040D2C File Offset: 0x0003EF2C
	public List<GClass1> Prop_3 { get; }

	// Token: 0x17000043 RID: 67
	// (get) Token: 0x060000A7 RID: 167 RVA: 0x00040D40 File Offset: 0x0003EF40
	public List<GClass4> Prop_4 { get; }

	// Token: 0x0400005D RID: 93
	[CompilerGenerated]
	private readonly byte[] byte_0;

	// Token: 0x0400005E RID: 94
	[CompilerGenerated]
	private readonly string string_0;

	// Token: 0x0400005F RID: 95
	[CompilerGenerated]
	private readonly DateTimeOffset dateTimeOffset_0;

	// Token: 0x04000060 RID: 96
	[CompilerGenerated]
	private readonly DateTimeOffset dateTimeOffset_1;

	// Token: 0x04000061 RID: 97
	[CompilerGenerated]
	private readonly DateTimeOffset dateTimeOffset_2;

	// Token: 0x04000062 RID: 98
	[CompilerGenerated]
	private readonly GClass2 gclass2_0;

	// Token: 0x04000063 RID: 99
	[CompilerGenerated]
	private readonly int int_0;

	// Token: 0x04000064 RID: 100
	[CompilerGenerated]
	private readonly int int_1;

	// Token: 0x04000065 RID: 101
	[CompilerGenerated]
	private readonly int int_2;

	// Token: 0x04000066 RID: 102
	[CompilerGenerated]
	private readonly int int_3;

	// Token: 0x04000067 RID: 103
	[CompilerGenerated]
	private readonly int int_4;

	// Token: 0x04000068 RID: 104
	[CompilerGenerated]
	private readonly int int_5;

	// Token: 0x04000069 RID: 105
	[CompilerGenerated]
	private readonly int int_6;

	// Token: 0x0400006A RID: 106
	[CompilerGenerated]
	private readonly int int_7;

	// Token: 0x0400006B RID: 107
	[CompilerGenerated]
	private readonly int int_8;

	// Token: 0x0400006C RID: 108
	[CompilerGenerated]
	private readonly int int_9;

	// Token: 0x0400006D RID: 109
	[CompilerGenerated]
	private readonly List<DateTimeOffset> list_0;

	// Token: 0x0400006E RID: 110
	[CompilerGenerated]
	private readonly List<GClass11> list_1;

	// Token: 0x0400006F RID: 111
	[CompilerGenerated]
	private readonly int int_10;

	// Token: 0x04000070 RID: 112
	[CompilerGenerated]
	private readonly List<string> list_2;

	// Token: 0x04000071 RID: 113
	[CompilerGenerated]
	private readonly List<GClass1> list_3;

	// Token: 0x04000072 RID: 114
	[CompilerGenerated]
	private readonly List<GClass4> list_4;
}
