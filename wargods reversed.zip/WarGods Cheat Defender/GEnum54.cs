﻿using System;

// Token: 0x020000F1 RID: 241
public enum GEnum54
{
	// Token: 0x04000A57 RID: 2647
	const_0,
	// Token: 0x04000A58 RID: 2648
	const_1,
	// Token: 0x04000A59 RID: 2649
	const_2,
	// Token: 0x04000A5A RID: 2650
	const_3,
	// Token: 0x04000A5B RID: 2651
	const_4,
	// Token: 0x04000A5C RID: 2652
	const_5,
	// Token: 0x04000A5D RID: 2653
	const_6,
	// Token: 0x04000A5E RID: 2654
	const_7,
	// Token: 0x04000A5F RID: 2655
	const_8,
	// Token: 0x04000A60 RID: 2656
	const_9,
	// Token: 0x04000A61 RID: 2657
	const_10,
	// Token: 0x04000A62 RID: 2658
	const_11,
	// Token: 0x04000A63 RID: 2659
	const_12,
	// Token: 0x04000A64 RID: 2660
	const_13,
	// Token: 0x04000A65 RID: 2661
	const_14,
	// Token: 0x04000A66 RID: 2662
	const_15,
	// Token: 0x04000A67 RID: 2663
	const_16,
	// Token: 0x04000A68 RID: 2664
	const_17,
	// Token: 0x04000A69 RID: 2665
	const_18,
	// Token: 0x04000A6A RID: 2666
	const_19,
	// Token: 0x04000A6B RID: 2667
	const_20,
	// Token: 0x04000A6C RID: 2668
	const_21,
	// Token: 0x04000A6D RID: 2669
	const_22,
	// Token: 0x04000A6E RID: 2670
	const_23,
	// Token: 0x04000A6F RID: 2671
	const_24,
	// Token: 0x04000A70 RID: 2672
	const_25,
	// Token: 0x04000A71 RID: 2673
	const_26,
	// Token: 0x04000A72 RID: 2674
	const_27,
	// Token: 0x04000A73 RID: 2675
	const_28,
	// Token: 0x04000A74 RID: 2676
	const_29,
	// Token: 0x04000A75 RID: 2677
	const_30,
	// Token: 0x04000A76 RID: 2678
	const_31,
	// Token: 0x04000A77 RID: 2679
	const_32,
	// Token: 0x04000A78 RID: 2680
	const_33,
	// Token: 0x04000A79 RID: 2681
	const_34,
	// Token: 0x04000A7A RID: 2682
	const_35,
	// Token: 0x04000A7B RID: 2683
	const_36,
	// Token: 0x04000A7C RID: 2684
	const_37,
	// Token: 0x04000A7D RID: 2685
	const_38,
	// Token: 0x04000A7E RID: 2686
	const_39,
	// Token: 0x04000A7F RID: 2687
	const_40,
	// Token: 0x04000A80 RID: 2688
	const_41,
	// Token: 0x04000A81 RID: 2689
	const_42,
	// Token: 0x04000A82 RID: 2690
	const_43,
	// Token: 0x04000A83 RID: 2691
	const_44,
	// Token: 0x04000A84 RID: 2692
	const_45,
	// Token: 0x04000A85 RID: 2693
	const_46,
	// Token: 0x04000A86 RID: 2694
	const_47,
	// Token: 0x04000A87 RID: 2695
	const_48,
	// Token: 0x04000A88 RID: 2696
	const_49,
	// Token: 0x04000A89 RID: 2697
	const_50,
	// Token: 0x04000A8A RID: 2698
	const_51,
	// Token: 0x04000A8B RID: 2699
	const_52,
	// Token: 0x04000A8C RID: 2700
	const_53,
	// Token: 0x04000A8D RID: 2701
	const_54,
	// Token: 0x04000A8E RID: 2702
	const_55,
	// Token: 0x04000A8F RID: 2703
	const_56,
	// Token: 0x04000A90 RID: 2704
	const_57,
	// Token: 0x04000A91 RID: 2705
	const_58,
	// Token: 0x04000A92 RID: 2706
	const_59,
	// Token: 0x04000A93 RID: 2707
	const_60,
	// Token: 0x04000A94 RID: 2708
	const_61,
	// Token: 0x04000A95 RID: 2709
	const_62,
	// Token: 0x04000A96 RID: 2710
	const_63,
	// Token: 0x04000A97 RID: 2711
	const_64,
	// Token: 0x04000A98 RID: 2712
	const_65,
	// Token: 0x04000A99 RID: 2713
	const_66,
	// Token: 0x04000A9A RID: 2714
	const_67,
	// Token: 0x04000A9B RID: 2715
	const_68,
	// Token: 0x04000A9C RID: 2716
	const_69,
	// Token: 0x04000A9D RID: 2717
	const_70,
	// Token: 0x04000A9E RID: 2718
	const_71,
	// Token: 0x04000A9F RID: 2719
	const_72,
	// Token: 0x04000AA0 RID: 2720
	const_73,
	// Token: 0x04000AA1 RID: 2721
	const_74,
	// Token: 0x04000AA2 RID: 2722
	const_75,
	// Token: 0x04000AA3 RID: 2723
	const_76,
	// Token: 0x04000AA4 RID: 2724
	const_77,
	// Token: 0x04000AA5 RID: 2725
	const_78,
	// Token: 0x04000AA6 RID: 2726
	const_79,
	// Token: 0x04000AA7 RID: 2727
	const_80,
	// Token: 0x04000AA8 RID: 2728
	const_81,
	// Token: 0x04000AA9 RID: 2729
	const_82,
	// Token: 0x04000AAA RID: 2730
	const_83,
	// Token: 0x04000AAB RID: 2731
	const_84,
	// Token: 0x04000AAC RID: 2732
	const_85,
	// Token: 0x04000AAD RID: 2733
	const_86,
	// Token: 0x04000AAE RID: 2734
	const_87,
	// Token: 0x04000AAF RID: 2735
	const_88,
	// Token: 0x04000AB0 RID: 2736
	const_89,
	// Token: 0x04000AB1 RID: 2737
	const_90,
	// Token: 0x04000AB2 RID: 2738
	const_91,
	// Token: 0x04000AB3 RID: 2739
	const_92,
	// Token: 0x04000AB4 RID: 2740
	const_93,
	// Token: 0x04000AB5 RID: 2741
	const_94,
	// Token: 0x04000AB6 RID: 2742
	const_95,
	// Token: 0x04000AB7 RID: 2743
	const_96,
	// Token: 0x04000AB8 RID: 2744
	const_97,
	// Token: 0x04000AB9 RID: 2745
	const_98,
	// Token: 0x04000ABA RID: 2746
	const_99,
	// Token: 0x04000ABB RID: 2747
	const_100,
	// Token: 0x04000ABC RID: 2748
	const_101,
	// Token: 0x04000ABD RID: 2749
	const_102,
	// Token: 0x04000ABE RID: 2750
	const_103,
	// Token: 0x04000ABF RID: 2751
	const_104,
	// Token: 0x04000AC0 RID: 2752
	const_105,
	// Token: 0x04000AC1 RID: 2753
	const_106,
	// Token: 0x04000AC2 RID: 2754
	const_107,
	// Token: 0x04000AC3 RID: 2755
	const_108,
	// Token: 0x04000AC4 RID: 2756
	const_109,
	// Token: 0x04000AC5 RID: 2757
	const_110,
	// Token: 0x04000AC6 RID: 2758
	const_111,
	// Token: 0x04000AC7 RID: 2759
	const_112,
	// Token: 0x04000AC8 RID: 2760
	const_113,
	// Token: 0x04000AC9 RID: 2761
	const_114,
	// Token: 0x04000ACA RID: 2762
	const_115,
	// Token: 0x04000ACB RID: 2763
	const_116,
	// Token: 0x04000ACC RID: 2764
	const_117,
	// Token: 0x04000ACD RID: 2765
	const_118,
	// Token: 0x04000ACE RID: 2766
	const_119,
	// Token: 0x04000ACF RID: 2767
	const_120,
	// Token: 0x04000AD0 RID: 2768
	const_121,
	// Token: 0x04000AD1 RID: 2769
	const_122,
	// Token: 0x04000AD2 RID: 2770
	const_123,
	// Token: 0x04000AD3 RID: 2771
	const_124,
	// Token: 0x04000AD4 RID: 2772
	const_125,
	// Token: 0x04000AD5 RID: 2773
	const_126,
	// Token: 0x04000AD6 RID: 2774
	const_127,
	// Token: 0x04000AD7 RID: 2775
	const_128,
	// Token: 0x04000AD8 RID: 2776
	const_129,
	// Token: 0x04000AD9 RID: 2777
	const_130,
	// Token: 0x04000ADA RID: 2778
	const_131,
	// Token: 0x04000ADB RID: 2779
	const_132,
	// Token: 0x04000ADC RID: 2780
	const_133,
	// Token: 0x04000ADD RID: 2781
	const_134
}
