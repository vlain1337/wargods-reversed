﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x02000015 RID: 21
public class GClass3
{
	// Token: 0x0600007F RID: 127 RVA: 0x0003F08C File Offset: 0x0003D28C
	public GClass3()
	{
	}

	// Token: 0x06000080 RID: 128 RVA: 0x00040358 File Offset: 0x0003E558
	public GClass3(byte[] byte_0)
	{
		if (byte_0.Length != 8)
		{
			throw new ArgumentException(<Module>.DeserializeFromByteArray3<string>(1736356817U));
		}
		ushort num = BitConverter.ToUInt16(byte_0, 6);
		ulong num2 = (ulong)BitConverter.ToUInt32(byte_0, 0);
		ulong num3 = (ulong)BitConverter.ToUInt16(byte_0, 4);
		ulong value;
		if (num3 != 0UL)
		{
			num3 *= 16777216UL;
			value = num2 + num3;
		}
		else
		{
			value = num2;
		}
		this.Nullable_0 = new ulong?(value);
		this.Nullable_1 = new int?((int)num);
		if (num == 0)
		{
			this.Nullable_1 = null;
		}
	}

	// Token: 0x17000027 RID: 39
	// (get) Token: 0x06000081 RID: 129 RVA: 0x000403E8 File Offset: 0x0003E5E8
	// (set) Token: 0x06000082 RID: 130 RVA: 0x000403FC File Offset: 0x0003E5FC
	public ulong? Nullable_0 { get; set; }

	// Token: 0x17000028 RID: 40
	// (get) Token: 0x06000083 RID: 131 RVA: 0x00040410 File Offset: 0x0003E610
	// (set) Token: 0x06000084 RID: 132 RVA: 0x00040424 File Offset: 0x0003E624
	public int? Nullable_1 { get; set; }

	// Token: 0x06000085 RID: 133 RVA: 0x00040438 File Offset: 0x0003E638
	public virtual string ToString()
	{
		return string.Format(<Module>.DeserializeFromByteArray2<string>(1342818410U), this.Nullable_0, this.Nullable_1);
	}

	// Token: 0x04000055 RID: 85
	[CompilerGenerated]
	private ulong? nullable_0;

	// Token: 0x04000056 RID: 86
	[CompilerGenerated]
	private int? nullable_1;
}
