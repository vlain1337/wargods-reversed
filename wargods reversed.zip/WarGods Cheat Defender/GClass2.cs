﻿using System;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x02000014 RID: 20
public class GClass2
{
	// Token: 0x06000078 RID: 120 RVA: 0x000401BC File Offset: 0x0003E3BC
	public GClass2(byte[] byte_0)
	{
		int num = 0;
		int num2 = BitConverter.ToInt32(byte_0, 0);
		if (num2 <= 23)
		{
			if (num2 != 17)
			{
				if (num2 == 23)
				{
					this.GEnum1_0 = 23;
				}
			}
			else
			{
				this.GEnum1_0 = 17;
			}
		}
		else if (num2 != 26)
		{
			if (num2 == 30)
			{
				this.GEnum1_0 = 30;
			}
		}
		else
		{
			this.GEnum1_0 = 26;
		}
		num += 4;
		this.String_0 = Encoding.ASCII.GetString(byte_0, num, 4);
		num += 4;
		num += 4;
		this.Int32_0 = BitConverter.ToInt32(byte_0, num);
		num += 4;
		string @string = Encoding.Unicode.GetString(byte_0, num, 60);
		this.String_1 = @string.Substring(0, @string.IndexOf('\0')).Trim();
		num += 60;
		this.String_2 = BitConverter.ToInt32(byte_0, num).ToString(<Module>.DeserializeFromByteArray3<string>(4115400338U));
	}

	// Token: 0x17000022 RID: 34
	// (get) Token: 0x06000079 RID: 121 RVA: 0x00040298 File Offset: 0x0003E498
	public GEnum1 GEnum1_0 { get; }

	// Token: 0x17000023 RID: 35
	// (get) Token: 0x0600007A RID: 122 RVA: 0x000402AC File Offset: 0x0003E4AC
	public string String_0 { get; }

	// Token: 0x17000024 RID: 36
	// (get) Token: 0x0600007B RID: 123 RVA: 0x000402C0 File Offset: 0x0003E4C0
	public int Int32_0 { get; }

	// Token: 0x17000025 RID: 37
	// (get) Token: 0x0600007C RID: 124 RVA: 0x000402D4 File Offset: 0x0003E4D4
	public string String_1 { get; }

	// Token: 0x17000026 RID: 38
	// (get) Token: 0x0600007D RID: 125 RVA: 0x000402E8 File Offset: 0x0003E4E8
	public string String_2 { get; }

	// Token: 0x0600007E RID: 126 RVA: 0x000402FC File Offset: 0x0003E4FC
	public virtual string ToString()
	{
		return string.Format(<Module>.DeserealizeFromByteArrayV2_1<string>(1740341367U), new object[]
		{
			this.GEnum1_0,
			this.String_0,
			this.Int32_0,
			this.String_1,
			this.String_2
		});
	}

	// Token: 0x04000050 RID: 80
	[CompilerGenerated]
	private readonly GEnum1 genum1_0;

	// Token: 0x04000051 RID: 81
	[CompilerGenerated]
	private readonly string string_0;

	// Token: 0x04000052 RID: 82
	[CompilerGenerated]
	private readonly int int_0;

	// Token: 0x04000053 RID: 83
	[CompilerGenerated]
	private readonly string string_1;

	// Token: 0x04000054 RID: 84
	[CompilerGenerated]
	private readonly string string_2;
}
