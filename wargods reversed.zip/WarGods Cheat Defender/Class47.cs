﻿using System;
using System.Management;
using System.Runtime.CompilerServices;
using Microsoft.Win32;

// Token: 0x020000E0 RID: 224
internal class Class47
{
	// Token: 0x17000313 RID: 787
	// (get) Token: 0x06000731 RID: 1841 RVA: 0x00068888 File Offset: 0x00066A88
	// (set) Token: 0x06000732 RID: 1842 RVA: 0x0006889C File Offset: 0x00066A9C
	public string String_0 { get; set; }

	// Token: 0x17000314 RID: 788
	// (get) Token: 0x06000733 RID: 1843 RVA: 0x000688B0 File Offset: 0x00066AB0
	// (set) Token: 0x06000734 RID: 1844 RVA: 0x000688C4 File Offset: 0x00066AC4
	public string String_1 { get; set; }

	// Token: 0x17000315 RID: 789
	// (get) Token: 0x06000735 RID: 1845 RVA: 0x000688D8 File Offset: 0x00066AD8
	// (set) Token: 0x06000736 RID: 1846 RVA: 0x000688EC File Offset: 0x00066AEC
	public int Int32_0 { get; set; }

	// Token: 0x06000737 RID: 1847 RVA: 0x00068900 File Offset: 0x00066B00
	public Class47(string string_2 = "", string string_3 = "", int int_1 = 1)
	{
		this.String_0 = string_2;
		this.String_1 = string_3;
		this.Int32_0 = int_1;
	}

	// Token: 0x06000738 RID: 1848 RVA: 0x00068928 File Offset: 0x00066B28
	public virtual string ToString()
	{
		return string.Format(<Module>.DeserializeFromByteArray2<string>(1403874358U), new object[]
		{
			Class15.SanitizeString(this.String_0),
			Class15.char_2,
			Class15.SanitizeString(this.String_1),
			Class15.char_2,
			this.Int32_0.ToString()
		});
	}

	// Token: 0x06000739 RID: 1849 RVA: 0x00068994 File Offset: 0x00066B94
	public static string smethod_0()
	{
		string text = string.Empty;
		string string_ = string.Empty;
		try
		{
			using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = new ManagementObjectSearcher(Class14.String_14, Class14.String_55).Get().GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					ManagementObject managementObject = (ManagementObject)enumerator.Current;
					try
					{
						text = managementObject.GetPropertyValue(Class14.String_222).ToString().Trim();
					}
					catch
					{
						text = string.Empty;
					}
					try
					{
						IL_5C:
						string_ = managementObject.GetPropertyValue(Class14.String_105).ToString().Trim();
					}
					catch
					{
						string_ = string.Empty;
					}
					if (text.Length == 0)
					{
						continue;
					}
					break;
					goto IL_5C;
				}
			}
		}
		catch
		{
		}
		if (text == string.Empty || text.Length == 0)
		{
			text = RegistryStuff.GetStringValueFromRegistry(Registry.LocalMachine, Class14.String_79, Class14.String_10);
			if (text == null)
			{
				text = string.Empty;
			}
		}
		return new Class47(text, string_, Environment.ProcessorCount).ToString();
	}

	// Token: 0x040009D9 RID: 2521
	[CompilerGenerated]
	private string string_0;

	// Token: 0x040009DA RID: 2522
	[CompilerGenerated]
	private string string_1;

	// Token: 0x040009DB RID: 2523
	[CompilerGenerated]
	private int int_0;
}
