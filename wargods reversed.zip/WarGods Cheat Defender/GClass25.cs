﻿using System;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x0200004C RID: 76
public class GClass25
{
	// Token: 0x06000237 RID: 567 RVA: 0x0004AFB8 File Offset: 0x000491B8
	public GClass25(byte[] byte_0, int int_0)
	{
		this.UInt16_0 = BitConverter.ToUInt16(byte_0, int_0);
		this.UInt16_1 = BitConverter.ToUInt16(byte_0, int_0 + 2);
		this.UInt32_0 = BitConverter.ToUInt32(byte_0, int_0 + 4);
		this.UInt32_1 = BitConverter.ToUInt32(byte_0, int_0 + 8);
		this.UInt32_2 = BitConverter.ToUInt32(byte_0, int_0 + 12);
		this.UInt16_2 = BitConverter.ToUInt16(byte_0, int_0 + 16);
		this.UInt16_3 = BitConverter.ToUInt16(byte_0, int_0 + 18);
	}

	// Token: 0x170000EF RID: 239
	// (get) Token: 0x06000238 RID: 568 RVA: 0x0004B038 File Offset: 0x00049238
	// (set) Token: 0x06000239 RID: 569 RVA: 0x0004B04C File Offset: 0x0004924C
	public ushort UInt16_0 { get; set; }

	// Token: 0x170000F0 RID: 240
	// (get) Token: 0x0600023A RID: 570 RVA: 0x0004B060 File Offset: 0x00049260
	// (set) Token: 0x0600023B RID: 571 RVA: 0x0004B074 File Offset: 0x00049274
	public ushort UInt16_1 { get; set; }

	// Token: 0x170000F1 RID: 241
	// (get) Token: 0x0600023C RID: 572 RVA: 0x0004B088 File Offset: 0x00049288
	// (set) Token: 0x0600023D RID: 573 RVA: 0x0004B09C File Offset: 0x0004929C
	public uint UInt32_0 { get; set; }

	// Token: 0x170000F2 RID: 242
	// (get) Token: 0x0600023E RID: 574 RVA: 0x0004B0B0 File Offset: 0x000492B0
	// (set) Token: 0x0600023F RID: 575 RVA: 0x0004B0C4 File Offset: 0x000492C4
	public uint UInt32_1 { get; set; }

	// Token: 0x170000F3 RID: 243
	// (get) Token: 0x06000240 RID: 576 RVA: 0x0004B0D8 File Offset: 0x000492D8
	// (set) Token: 0x06000241 RID: 577 RVA: 0x0004B0EC File Offset: 0x000492EC
	public uint UInt32_2 { get; set; }

	// Token: 0x170000F4 RID: 244
	// (get) Token: 0x06000242 RID: 578 RVA: 0x0004B100 File Offset: 0x00049300
	// (set) Token: 0x06000243 RID: 579 RVA: 0x0004B114 File Offset: 0x00049314
	public ushort UInt16_2 { get; set; }

	// Token: 0x170000F5 RID: 245
	// (get) Token: 0x06000244 RID: 580 RVA: 0x0004B128 File Offset: 0x00049328
	// (set) Token: 0x06000245 RID: 581 RVA: 0x0004B13C File Offset: 0x0004933C
	public ushort UInt16_3 { get; set; }

	// Token: 0x06000246 RID: 582 RVA: 0x0004B150 File Offset: 0x00049350
	public virtual string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder(<Module>.DeserealizeFromByteArrayV2_1<string>(975213603U));
		stringBuilder.Append(GClass18.smethod_9(this, <Module>.DeserializeFromByteArrayV2<string>(3969376509U)));
		return stringBuilder.ToString();
	}

	// Token: 0x0400023A RID: 570
	[NonSerialized]
	public static readonly uint uint_0 = 20U;

	// Token: 0x0400023B RID: 571
	[CompilerGenerated]
	private ushort ushort_0;

	// Token: 0x0400023C RID: 572
	[CompilerGenerated]
	private ushort ushort_1;

	// Token: 0x0400023D RID: 573
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x0400023E RID: 574
	[CompilerGenerated]
	private uint uint_2;

	// Token: 0x0400023F RID: 575
	[CompilerGenerated]
	private uint uint_3;

	// Token: 0x04000240 RID: 576
	[CompilerGenerated]
	private ushort ushort_2;

	// Token: 0x04000241 RID: 577
	[CompilerGenerated]
	private ushort ushort_3;
}
