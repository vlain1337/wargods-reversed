﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x02000016 RID: 22
public class GClass4
{
	// Token: 0x06000086 RID: 134 RVA: 0x0004046C File Offset: 0x0003E66C
	public GClass4(byte[] byte_2, bool bool_0)
	{
		if (bool_0)
		{
			this.Int32_1 = BitConverter.ToInt32(byte_2, 0);
			this.Byte_0 = byte_2[4];
			this.Byte_1 = byte_2[5];
			this.Int16_0 = BitConverter.ToInt16(byte_2, 6);
			return;
		}
		this.Int32_0 = BitConverter.ToInt32(byte_2, 0);
		this.Int32_1 = BitConverter.ToInt32(byte_2, 4);
		this.Byte_0 = byte_2[8];
		this.Byte_1 = byte_2[9];
		this.Int16_0 = BitConverter.ToInt16(byte_2, 10);
	}

	// Token: 0x17000029 RID: 41
	// (get) Token: 0x06000087 RID: 135 RVA: 0x000404EC File Offset: 0x0003E6EC
	public int Int32_0 { get; }

	// Token: 0x1700002A RID: 42
	// (get) Token: 0x06000088 RID: 136 RVA: 0x00040500 File Offset: 0x0003E700
	public int Int32_1 { get; }

	// Token: 0x1700002B RID: 43
	// (get) Token: 0x06000089 RID: 137 RVA: 0x00040514 File Offset: 0x0003E714
	public byte Byte_0 { get; }

	// Token: 0x1700002C RID: 44
	// (get) Token: 0x0600008A RID: 138 RVA: 0x00040528 File Offset: 0x0003E728
	public byte Byte_1 { get; }

	// Token: 0x1700002D RID: 45
	// (get) Token: 0x0600008B RID: 139 RVA: 0x0004053C File Offset: 0x0003E73C
	public short Int16_0 { get; }

	// Token: 0x0600008C RID: 140 RVA: 0x00040550 File Offset: 0x0003E750
	public virtual string ToString()
	{
		return string.Format(<Module>.DeserializeFromByteArray2<string>(2505847316U), this.Int32_0, this.Int32_1);
	}

	// Token: 0x04000057 RID: 87
	[CompilerGenerated]
	private readonly int int_0;

	// Token: 0x04000058 RID: 88
	[CompilerGenerated]
	private readonly int int_1;

	// Token: 0x04000059 RID: 89
	[CompilerGenerated]
	private readonly byte byte_0;

	// Token: 0x0400005A RID: 90
	[CompilerGenerated]
	private readonly byte byte_1;

	// Token: 0x0400005B RID: 91
	[CompilerGenerated]
	private readonly short short_0;
}
