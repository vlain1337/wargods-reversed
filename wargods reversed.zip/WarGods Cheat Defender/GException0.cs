﻿using System;

// Token: 0x0200001E RID: 30
public class GException0 : Exception
{
	// Token: 0x060000F8 RID: 248 RVA: 0x00042320 File Offset: 0x00040520
	public GException0()
	{
	}

	// Token: 0x060000F9 RID: 249 RVA: 0x00042334 File Offset: 0x00040534
	public GException0(string string_0) : base(string_0)
	{
	}

	// Token: 0x060000FA RID: 250 RVA: 0x00042348 File Offset: 0x00040548
	public GException0(string string_0, Exception exception_0) : base(string_0, exception_0)
	{
	}
}
