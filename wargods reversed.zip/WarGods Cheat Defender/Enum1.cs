﻿using System;

// Token: 0x0200003E RID: 62
internal enum Enum1
{
	// Token: 0x040001D2 RID: 466
	const_0,
	// Token: 0x040001D3 RID: 467
	const_1
}
