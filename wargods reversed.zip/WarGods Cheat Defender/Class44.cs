﻿using System;
using System.Management;
using System.Runtime.CompilerServices;
using Microsoft.Win32;

// Token: 0x020000DD RID: 221
internal class Class44
{
	// Token: 0x17000303 RID: 771
	// (get) Token: 0x06000708 RID: 1800 RVA: 0x00067C2C File Offset: 0x00065E2C
	// (set) Token: 0x06000709 RID: 1801 RVA: 0x00067C40 File Offset: 0x00065E40
	public string String_0 { get; set; }

	// Token: 0x17000304 RID: 772
	// (get) Token: 0x0600070A RID: 1802 RVA: 0x00067C54 File Offset: 0x00065E54
	// (set) Token: 0x0600070B RID: 1803 RVA: 0x00067C68 File Offset: 0x00065E68
	public string String_1 { get; set; }

	// Token: 0x17000305 RID: 773
	// (get) Token: 0x0600070C RID: 1804 RVA: 0x00067C7C File Offset: 0x00065E7C
	// (set) Token: 0x0600070D RID: 1805 RVA: 0x00067C90 File Offset: 0x00065E90
	public string String_2 { get; set; }

	// Token: 0x17000306 RID: 774
	// (get) Token: 0x0600070E RID: 1806 RVA: 0x00067CA4 File Offset: 0x00065EA4
	// (set) Token: 0x0600070F RID: 1807 RVA: 0x00067CB8 File Offset: 0x00065EB8
	public string String_3 { get; set; }

	// Token: 0x06000710 RID: 1808 RVA: 0x00067CCC File Offset: 0x00065ECC
	public Class44(string string_4 = "", string string_5 = "", string string_6 = "", string string_7 = "")
	{
		this.String_0 = string_4;
		this.String_1 = string_5;
		this.String_2 = string_6;
		this.String_3 = string_7;
	}

	// Token: 0x06000711 RID: 1809 RVA: 0x00067CFC File Offset: 0x00065EFC
	public virtual string ToString()
	{
		return string.Format(<Module>.DeserializeFromByteArray3<string>(2421199166U), new object[]
		{
			Class15.SanitizeString(this.String_0),
			Class15.char_2,
			Class15.SanitizeString(this.String_1),
			Class15.char_2,
			Class15.SanitizeString(this.String_2),
			Class15.char_2,
			Class15.SanitizeString(this.String_3)
		});
	}

	// Token: 0x06000712 RID: 1810 RVA: 0x00067D80 File Offset: 0x00065F80
	public static string smethod_0()
	{
		Class44 @class = new Class44("", "", "", "");
		try
		{
			using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = new ManagementObjectSearcher(Class14.String_14, Class14.String_62).Get().GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					ManagementObject managementObject = (ManagementObject)enumerator.Current;
					try
					{
						@class.String_0 = managementObject.GetPropertyValue(Class14.String_179).ToString().Trim();
					}
					catch
					{
						@class.String_0 = string.Empty;
					}
					try
					{
						IL_7D:
						@class.String_1 = managementObject.GetPropertyValue(Class14.String_84).ToString().Trim();
					}
					catch
					{
						@class.String_1 = string.Empty;
					}
					try
					{
						@class.String_2 = managementObject.GetPropertyValue(Class14.String_32).ToString().Trim();
					}
					catch
					{
						@class.String_2 = string.Empty;
					}
					try
					{
						@class.String_3 = managementObject.GetPropertyValue(Class14.String_174).ToString().Trim();
					}
					catch
					{
						@class.String_3 = string.Empty;
					}
					if (!(@class.String_0 == string.Empty) || !(@class.String_1 == string.Empty))
					{
						break;
					}
					if (!(@class.String_2 == string.Empty))
					{
						break;
					}
					continue;
					goto IL_7D;
				}
			}
		}
		catch
		{
		}
		if (@class.String_0.Length == 0)
		{
			@class.String_0 = RegistryStuff.GetStringValueFromRegistry(Registry.LocalMachine, Class14.String_38, Class14.String_99);
			if (@class.String_0 == null)
			{
				@class.String_0 = string.Empty;
			}
		}
		if (@class.String_3.Length == 0)
		{
			@class.String_3 = RegistryStuff.GetStringValueFromRegistry(Registry.LocalMachine, Class14.String_38, Class14.String_218);
			if (@class.String_3 == null)
			{
				@class.String_3 = string.Empty;
			}
		}
		return @class.ToString();
	}

	// Token: 0x040009C9 RID: 2505
	[CompilerGenerated]
	private string string_0;

	// Token: 0x040009CA RID: 2506
	[CompilerGenerated]
	private string string_1;

	// Token: 0x040009CB RID: 2507
	[CompilerGenerated]
	private string string_2;

	// Token: 0x040009CC RID: 2508
	[CompilerGenerated]
	private string string_3;
}
