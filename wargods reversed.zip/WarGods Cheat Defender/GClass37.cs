﻿using System;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;

// Token: 0x02000058 RID: 88
public class GClass37
{
	// Token: 0x06000305 RID: 773 RVA: 0x0003F08C File Offset: 0x0003D28C
	public GClass37()
	{
	}

	// Token: 0x06000306 RID: 774 RVA: 0x0004CF7C File Offset: 0x0004B17C
	public GClass37(X509Certificate2 x509Certificate2_0)
	{
		if (x509Certificate2_0 == null)
		{
			throw new ArgumentNullException();
		}
		this.Boolean_0 = x509Certificate2_0.HasPrivateKey;
		this.String_0 = x509Certificate2_0.IssuerName.Name;
		this.String_1 = x509Certificate2_0.SubjectName.Name;
		this.DateTime_0 = x509Certificate2_0.NotAfter;
		this.DateTime_1 = x509Certificate2_0.NotBefore;
		this.String_2 = x509Certificate2_0.SerialNumber;
		this.String_3 = x509Certificate2_0.Thumbprint;
		this.Int32_0 = x509Certificate2_0.Version;
	}

	// Token: 0x17000143 RID: 323
	// (get) Token: 0x06000307 RID: 775 RVA: 0x0004D004 File Offset: 0x0004B204
	// (set) Token: 0x06000308 RID: 776 RVA: 0x0004D018 File Offset: 0x0004B218
	public bool Boolean_0 { get; set; }

	// Token: 0x17000144 RID: 324
	// (get) Token: 0x06000309 RID: 777 RVA: 0x0004D02C File Offset: 0x0004B22C
	// (set) Token: 0x0600030A RID: 778 RVA: 0x0004D040 File Offset: 0x0004B240
	public string String_0 { get; set; }

	// Token: 0x17000145 RID: 325
	// (get) Token: 0x0600030B RID: 779 RVA: 0x0004D054 File Offset: 0x0004B254
	// (set) Token: 0x0600030C RID: 780 RVA: 0x0004D068 File Offset: 0x0004B268
	public string String_1 { get; set; }

	// Token: 0x17000146 RID: 326
	// (get) Token: 0x0600030D RID: 781 RVA: 0x0004D07C File Offset: 0x0004B27C
	// (set) Token: 0x0600030E RID: 782 RVA: 0x0004D090 File Offset: 0x0004B290
	public DateTime DateTime_0 { get; set; }

	// Token: 0x17000147 RID: 327
	// (get) Token: 0x0600030F RID: 783 RVA: 0x0004D0A4 File Offset: 0x0004B2A4
	// (set) Token: 0x06000310 RID: 784 RVA: 0x0004D0B8 File Offset: 0x0004B2B8
	public DateTime DateTime_1 { get; set; }

	// Token: 0x17000148 RID: 328
	// (get) Token: 0x06000311 RID: 785 RVA: 0x0004D0CC File Offset: 0x0004B2CC
	// (set) Token: 0x06000312 RID: 786 RVA: 0x0004D0E0 File Offset: 0x0004B2E0
	public string String_2 { get; set; }

	// Token: 0x17000149 RID: 329
	// (get) Token: 0x06000313 RID: 787 RVA: 0x0004D0F4 File Offset: 0x0004B2F4
	// (set) Token: 0x06000314 RID: 788 RVA: 0x0004D108 File Offset: 0x0004B308
	public string String_3 { get; set; }

	// Token: 0x1700014A RID: 330
	// (get) Token: 0x06000315 RID: 789 RVA: 0x0004D11C File Offset: 0x0004B31C
	// (set) Token: 0x06000316 RID: 790 RVA: 0x0004D130 File Offset: 0x0004B330
	public int Int32_0 { get; set; }

	// Token: 0x06000317 RID: 791 RVA: 0x0004D144 File Offset: 0x0004B344
	public virtual string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder(<Module>.DeserializeFromByteArray2<string>(4160434539U));
		stringBuilder.Append(GClass18.smethod_9(this, <Module>.DeserealizeFromByteArrayV2_1<string>(1190186032U)));
		return stringBuilder.ToString();
	}

	// Token: 0x04000298 RID: 664
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x04000299 RID: 665
	[CompilerGenerated]
	private string string_0;

	// Token: 0x0400029A RID: 666
	[CompilerGenerated]
	private string string_1;

	// Token: 0x0400029B RID: 667
	[CompilerGenerated]
	private DateTime dateTime_0;

	// Token: 0x0400029C RID: 668
	[CompilerGenerated]
	private DateTime dateTime_1;

	// Token: 0x0400029D RID: 669
	[CompilerGenerated]
	private string string_2;

	// Token: 0x0400029E RID: 670
	[CompilerGenerated]
	private string string_3;

	// Token: 0x0400029F RID: 671
	[CompilerGenerated]
	private int int_0;
}
