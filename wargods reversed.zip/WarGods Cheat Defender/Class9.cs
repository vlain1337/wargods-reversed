﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000046 RID: 70
internal sealed class Class9 : IDisposable
{
	// Token: 0x060001C0 RID: 448 RVA: 0x0004A128 File Offset: 0x00048328
	internal Class9(IntPtr intptr_1, Enum1 enum1_1)
	{
		this.enum1_0 = enum1_1;
		this.intptr_0 = intptr_1;
	}

	// Token: 0x060001C1 RID: 449 RVA: 0x0004A14C File Offset: 0x0004834C
	~Class9()
	{
		this.method_0(false);
	}

	// Token: 0x060001C2 RID: 450 RVA: 0x0004A17C File Offset: 0x0004837C
	private void method_0(bool bool_0)
	{
		if (this.intptr_0 != IntPtr.Zero)
		{
			if (this.enum1_0 != Enum1.const_0)
			{
				if (this.enum1_0 == Enum1.const_1)
				{
					Marshal.FreeCoTaskMem(this.intptr_0);
				}
			}
			else
			{
				Marshal.FreeHGlobal(this.intptr_0);
			}
			this.intptr_0 = IntPtr.Zero;
		}
		if (bool_0)
		{
			GC.SuppressFinalize(this);
		}
	}

	// Token: 0x060001C3 RID: 451 RVA: 0x0004A1D8 File Offset: 0x000483D8
	public void Dispose()
	{
		this.method_0(true);
	}

	// Token: 0x060001C4 RID: 452 RVA: 0x0004A1EC File Offset: 0x000483EC
	public static IntPtr smethod_0(Class9 class9_0)
	{
		return class9_0.intptr_0;
	}

	// Token: 0x04000203 RID: 515
	private IntPtr intptr_0;

	// Token: 0x04000204 RID: 516
	private Enum1 enum1_0;
}
