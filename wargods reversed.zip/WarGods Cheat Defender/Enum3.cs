﻿using System;

// Token: 0x02000040 RID: 64
internal enum Enum3
{
	// Token: 0x040001DB RID: 475
	const_0 = 1,
	// Token: 0x040001DC RID: 476
	const_1,
	// Token: 0x040001DD RID: 477
	const_2,
	// Token: 0x040001DE RID: 478
	const_3
}
