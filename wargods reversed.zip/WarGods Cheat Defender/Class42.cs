﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020000D9 RID: 217
internal class Class42
{
	// Token: 0x170002ED RID: 749
	// (get) Token: 0x060006DB RID: 1755 RVA: 0x0006774C File Offset: 0x0006594C
	// (set) Token: 0x060006DC RID: 1756 RVA: 0x00067760 File Offset: 0x00065960
	public uint UInt32_0 { get; private set; }

	// Token: 0x170002EE RID: 750
	// (get) Token: 0x060006DD RID: 1757 RVA: 0x00067774 File Offset: 0x00065974
	// (set) Token: 0x060006DE RID: 1758 RVA: 0x00067788 File Offset: 0x00065988
	public uint UInt32_1 { get; private set; }

	// Token: 0x170002EF RID: 751
	// (get) Token: 0x060006DF RID: 1759 RVA: 0x0006779C File Offset: 0x0006599C
	// (set) Token: 0x060006E0 RID: 1760 RVA: 0x000677B0 File Offset: 0x000659B0
	public uint UInt32_2 { get; private set; }

	// Token: 0x170002F0 RID: 752
	// (get) Token: 0x060006E1 RID: 1761 RVA: 0x000677C4 File Offset: 0x000659C4
	// (set) Token: 0x060006E2 RID: 1762 RVA: 0x000677D8 File Offset: 0x000659D8
	public uint UInt32_3 { get; private set; }

	// Token: 0x170002F1 RID: 753
	// (get) Token: 0x060006E3 RID: 1763 RVA: 0x000677EC File Offset: 0x000659EC
	// (set) Token: 0x060006E4 RID: 1764 RVA: 0x00067800 File Offset: 0x00065A00
	public uint UInt32_4 { get; private set; }

	// Token: 0x170002F2 RID: 754
	// (get) Token: 0x060006E5 RID: 1765 RVA: 0x00067814 File Offset: 0x00065A14
	// (set) Token: 0x060006E6 RID: 1766 RVA: 0x00067828 File Offset: 0x00065A28
	public uint UInt32_5 { get; private set; }

	// Token: 0x170002F3 RID: 755
	// (get) Token: 0x060006E7 RID: 1767 RVA: 0x0006783C File Offset: 0x00065A3C
	// (set) Token: 0x060006E8 RID: 1768 RVA: 0x00067850 File Offset: 0x00065A50
	public uint UInt32_6 { get; private set; }

	// Token: 0x170002F4 RID: 756
	// (get) Token: 0x060006E9 RID: 1769 RVA: 0x00067864 File Offset: 0x00065A64
	// (set) Token: 0x060006EA RID: 1770 RVA: 0x00067878 File Offset: 0x00065A78
	public uint UInt32_7 { get; private set; }

	// Token: 0x170002F5 RID: 757
	// (get) Token: 0x060006EB RID: 1771 RVA: 0x0006788C File Offset: 0x00065A8C
	// (set) Token: 0x060006EC RID: 1772 RVA: 0x000678A0 File Offset: 0x00065AA0
	public uint UInt32_8 { get; private set; }

	// Token: 0x170002F6 RID: 758
	// (get) Token: 0x060006ED RID: 1773 RVA: 0x000678B4 File Offset: 0x00065AB4
	// (set) Token: 0x060006EE RID: 1774 RVA: 0x000678C8 File Offset: 0x00065AC8
	public uint UInt32_9 { get; private set; }

	// Token: 0x170002F7 RID: 759
	// (get) Token: 0x060006EF RID: 1775 RVA: 0x000678DC File Offset: 0x00065ADC
	// (set) Token: 0x060006F0 RID: 1776 RVA: 0x000678F0 File Offset: 0x00065AF0
	public uint UInt32_10 { get; private set; }

	// Token: 0x170002F8 RID: 760
	// (get) Token: 0x060006F1 RID: 1777 RVA: 0x00067904 File Offset: 0x00065B04
	// (set) Token: 0x060006F2 RID: 1778 RVA: 0x00067918 File Offset: 0x00065B18
	public uint UInt32_11 { get; private set; }

	// Token: 0x170002F9 RID: 761
	// (get) Token: 0x060006F3 RID: 1779 RVA: 0x0006792C File Offset: 0x00065B2C
	// (set) Token: 0x060006F4 RID: 1780 RVA: 0x00067940 File Offset: 0x00065B40
	public uint UInt32_12 { get; private set; }

	// Token: 0x170002FA RID: 762
	// (get) Token: 0x060006F5 RID: 1781 RVA: 0x00067954 File Offset: 0x00065B54
	// (set) Token: 0x060006F6 RID: 1782 RVA: 0x00067968 File Offset: 0x00065B68
	public uint UInt32_13 { get; private set; }

	// Token: 0x170002FB RID: 763
	// (get) Token: 0x060006F7 RID: 1783 RVA: 0x0006797C File Offset: 0x00065B7C
	// (set) Token: 0x060006F8 RID: 1784 RVA: 0x00067990 File Offset: 0x00065B90
	public uint UInt32_14 { get; private set; }

	// Token: 0x170002FC RID: 764
	// (get) Token: 0x060006F9 RID: 1785 RVA: 0x000679A4 File Offset: 0x00065BA4
	// (set) Token: 0x060006FA RID: 1786 RVA: 0x000679B8 File Offset: 0x00065BB8
	public long Int64_0 { get; private set; }

	// Token: 0x170002FD RID: 765
	// (get) Token: 0x060006FB RID: 1787 RVA: 0x000679CC File Offset: 0x00065BCC
	// (set) Token: 0x060006FC RID: 1788 RVA: 0x000679E0 File Offset: 0x00065BE0
	public uint UInt32_15 { get; private set; }

	// Token: 0x060006FD RID: 1789 RVA: 0x000679F4 File Offset: 0x00065BF4
	public Class42(byte[] byte_0)
	{
		if (byte_0 == null)
		{
			throw new ArgumentNullException();
		}
		if ((long)byte_0.Length != (long)((ulong)Class42.uint_0))
		{
			throw new ArgumentOutOfRangeException();
		}
		this.UInt32_0 = BitConverter.ToUInt32(byte_0, 0);
		this.UInt32_1 = BitConverter.ToUInt32(byte_0, 4);
		this.UInt32_2 = BitConverter.ToUInt32(byte_0, 8);
		this.UInt32_3 = BitConverter.ToUInt32(byte_0, 12);
		this.UInt32_4 = BitConverter.ToUInt32(byte_0, 16);
		this.UInt32_5 = BitConverter.ToUInt32(byte_0, 20);
		this.UInt32_6 = BitConverter.ToUInt32(byte_0, 24);
		this.UInt32_7 = BitConverter.ToUInt32(byte_0, 28);
		this.UInt32_8 = BitConverter.ToUInt32(byte_0, 32);
		this.UInt32_9 = BitConverter.ToUInt32(byte_0, 36);
		this.UInt32_10 = BitConverter.ToUInt32(byte_0, 40);
		this.UInt32_11 = BitConverter.ToUInt32(byte_0, 44);
		this.UInt32_12 = BitConverter.ToUInt32(byte_0, 48);
		this.UInt32_13 = BitConverter.ToUInt32(byte_0, 52);
		this.UInt32_14 = BitConverter.ToUInt32(byte_0, 56);
		this.Int64_0 = (long)BitConverter.ToUInt64(byte_0, 60);
		this.UInt32_15 = BitConverter.ToUInt32(byte_0, 68);
	}

	// Token: 0x040009B0 RID: 2480
	public static readonly uint uint_0 = 72U;

	// Token: 0x040009B1 RID: 2481
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x040009B2 RID: 2482
	[CompilerGenerated]
	private uint uint_2;

	// Token: 0x040009B3 RID: 2483
	[CompilerGenerated]
	private uint uint_3;

	// Token: 0x040009B4 RID: 2484
	[CompilerGenerated]
	private uint uint_4;

	// Token: 0x040009B5 RID: 2485
	[CompilerGenerated]
	private uint uint_5;

	// Token: 0x040009B6 RID: 2486
	[CompilerGenerated]
	private uint uint_6;

	// Token: 0x040009B7 RID: 2487
	[CompilerGenerated]
	private uint uint_7;

	// Token: 0x040009B8 RID: 2488
	[CompilerGenerated]
	private uint uint_8;

	// Token: 0x040009B9 RID: 2489
	[CompilerGenerated]
	private uint uint_9;

	// Token: 0x040009BA RID: 2490
	[CompilerGenerated]
	private uint uint_10;

	// Token: 0x040009BB RID: 2491
	[CompilerGenerated]
	private uint uint_11;

	// Token: 0x040009BC RID: 2492
	[CompilerGenerated]
	private uint uint_12;

	// Token: 0x040009BD RID: 2493
	[CompilerGenerated]
	private uint uint_13;

	// Token: 0x040009BE RID: 2494
	[CompilerGenerated]
	private uint uint_14;

	// Token: 0x040009BF RID: 2495
	[CompilerGenerated]
	private uint uint_15;

	// Token: 0x040009C0 RID: 2496
	[CompilerGenerated]
	private long long_0;

	// Token: 0x040009C1 RID: 2497
	[CompilerGenerated]
	private uint uint_16;
}
