﻿using System;
using System.IO;
using System.Runtime.CompilerServices;

// Token: 0x02000051 RID: 81
public class GClass30
{
	// Token: 0x060002A8 RID: 680 RVA: 0x0004BDAC File Offset: 0x00049FAC
	public GClass30(byte[] byte_0, long long_0, long long_1, bool bool_0 = true)
	{
		this.UInt32_1 = (uint)long_0;
		this.UInt32_0 = (uint)long_1;
		if (bool_0)
		{
			try
			{
				string text;
				if (Class6.smethod_3(byte_0, out text, (long)((ulong)this.UInt32_1), (long)((ulong)(this.UInt32_1 + this.UInt32_0)), 4096))
				{
					this.String_0 = text;
				}
				else
				{
					this.String_0 = null;
				}
				return;
			}
			catch
			{
				this.String_0 = null;
				return;
			}
		}
		this.String_0 = null;
	}

	// Token: 0x060002A9 RID: 681 RVA: 0x0004BE2C File Offset: 0x0004A02C
	public GClass30(BinaryReader binaryReader_0, long long_0, long long_1, bool bool_0 = true)
	{
		this.UInt32_1 = (uint)long_0;
		this.UInt32_0 = (uint)long_1;
		if (bool_0)
		{
			try
			{
				string text;
				if (Class6.md5_crypto(binaryReader_0, out text, (long)((ulong)this.UInt32_1), (long)((ulong)(this.UInt32_1 + this.UInt32_0)), 4096))
				{
					this.String_0 = text;
				}
				else
				{
					this.String_0 = null;
				}
				return;
			}
			catch
			{
				this.String_0 = null;
				return;
			}
		}
		this.String_0 = null;
	}

	// Token: 0x17000120 RID: 288
	// (get) Token: 0x060002AA RID: 682 RVA: 0x0004BEAC File Offset: 0x0004A0AC
	// (set) Token: 0x060002AB RID: 683 RVA: 0x0004BEC0 File Offset: 0x0004A0C0
	public uint UInt32_0 { get; private set; }

	// Token: 0x17000121 RID: 289
	// (get) Token: 0x060002AC RID: 684 RVA: 0x0004BED4 File Offset: 0x0004A0D4
	// (set) Token: 0x060002AD RID: 685 RVA: 0x0004BEE8 File Offset: 0x0004A0E8
	public uint UInt32_1 { get; private set; }

	// Token: 0x17000122 RID: 290
	// (get) Token: 0x060002AE RID: 686 RVA: 0x0004BEFC File Offset: 0x0004A0FC
	// (set) Token: 0x060002AF RID: 687 RVA: 0x0004BF10 File Offset: 0x0004A110
	public string String_0 { get; private set; }

	// Token: 0x060002B0 RID: 688 RVA: 0x0004BF24 File Offset: 0x0004A124
	public virtual string ToString()
	{
		return string.Format(<Module>.DeserializeFromByteArray3<string>(194700377U), this.String_0 ?? Class14.String_215, this.UInt32_1, this.UInt32_0);
	}

	// Token: 0x04000271 RID: 625
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x04000272 RID: 626
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x04000273 RID: 627
	[CompilerGenerated]
	private string string_0;
}
