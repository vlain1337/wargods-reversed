﻿using System;

// Token: 0x02000044 RID: 68
internal enum Enum7
{
	// Token: 0x040001F5 RID: 501
	const_0,
	// Token: 0x040001F6 RID: 502
	const_1
}
