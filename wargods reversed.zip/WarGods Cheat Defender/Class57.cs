﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x020000F2 RID: 242
internal class Class57
{
	// Token: 0x1700033B RID: 827
	// (get) Token: 0x060007A6 RID: 1958 RVA: 0x0006AD38 File Offset: 0x00068F38
	// (set) Token: 0x060007A7 RID: 1959 RVA: 0x0006AD4C File Offset: 0x00068F4C
	public IntPtr IntPtr_0 { get; set; }

	// Token: 0x1700033C RID: 828
	// (get) Token: 0x060007A8 RID: 1960 RVA: 0x0006AD60 File Offset: 0x00068F60
	// (set) Token: 0x060007A9 RID: 1961 RVA: 0x0006AD74 File Offset: 0x00068F74
	public string String_0 { get; set; }

	// Token: 0x1700033D RID: 829
	// (get) Token: 0x060007AA RID: 1962 RVA: 0x0006AD88 File Offset: 0x00068F88
	// (set) Token: 0x060007AB RID: 1963 RVA: 0x0006AD9C File Offset: 0x00068F9C
	public IntPtr IntPtr_1 { get; set; }

	// Token: 0x1700033E RID: 830
	// (get) Token: 0x060007AC RID: 1964 RVA: 0x0006ADB0 File Offset: 0x00068FB0
	// (set) Token: 0x060007AD RID: 1965 RVA: 0x0006ADC4 File Offset: 0x00068FC4
	public IntPtr IntPtr_2 { get; set; }

	// Token: 0x1700033F RID: 831
	// (get) Token: 0x060007AE RID: 1966 RVA: 0x0006ADD8 File Offset: 0x00068FD8
	// (set) Token: 0x060007AF RID: 1967 RVA: 0x0006ADEC File Offset: 0x00068FEC
	public uint UInt32_0 { get; set; }

	// Token: 0x060007B0 RID: 1968 RVA: 0x0006AE00 File Offset: 0x00069000
	public Class57()
	{
		this.IntPtr_0 = IntPtr.Zero;
		this.String_0 = string.Empty;
		this.IntPtr_1 = IntPtr.Zero;
		this.IntPtr_2 = IntPtr.Zero;
		this.UInt32_0 = 0U;
	}

	// Token: 0x060007B1 RID: 1969 RVA: 0x0006AE48 File Offset: 0x00069048
	public static Class57 smethod_0(byte[] byte_0)
	{
		if (byte_0 != null && (long)byte_0.Length >= 16L)
		{
			return new Class57
			{
				IntPtr_0 = (IntPtr)BitConverter.ToInt32(byte_0, 0),
				IntPtr_1 = (IntPtr)BitConverter.ToInt32(byte_0, 4),
				IntPtr_2 = (IntPtr)BitConverter.ToInt32(byte_0, 8),
				UInt32_0 = (uint)BitConverter.ToInt32(byte_0, 12)
			};
		}
		return null;
	}

	// Token: 0x060007B2 RID: 1970 RVA: 0x0006AEB4 File Offset: 0x000690B4
	public static Class57 smethod_1(IntPtr intptr_3, byte[] byte_0)
	{
		Class57 @class = Class57.smethod_0(byte_0);
		if (@class == null)
		{
			return @class;
		}
		if (intptr_3 != IntPtr.Zero && @class.IntPtr_1 != IntPtr.Zero)
		{
			@class.String_0 = GClass49.ReadProcessMemoryString(intptr_3, @class.IntPtr_1, 256, true, "");
		}
		return @class;
	}

	// Token: 0x060007B3 RID: 1971 RVA: 0x0006AF0C File Offset: 0x0006910C
	public static Class57[] smethod_2(IntPtr intptr_3, IntPtr intptr_4)
	{
		if (!(intptr_3 == IntPtr.Zero) && !(intptr_4 == IntPtr.Zero))
		{
			List<Class57> list = new List<Class57>();
			byte[] array = new byte[16];
			uint num = 0U;
			int num2 = 0;
			IntPtr intPtr = intptr_4;
			while ((long)num2 < (long)((ulong)Class57.uint_1) && GClass45.ReadProcessMemory(intptr_3, intPtr, array, (uint)array.Length, ref num))
			{
				if ((ulong)num != (ulong)((long)array.Length))
				{
					break;
				}
				Class57 @class = Class57.smethod_1(intptr_3, array);
				if (@class == null)
				{
					break;
				}
				list.Add(@class);
				if (@class.IntPtr_0 == IntPtr.Zero)
				{
					break;
				}
				intPtr = @class.IntPtr_0;
				num2++;
			}
			return list.ToArray();
		}
		return null;
	}

	// Token: 0x04000ADE RID: 2782
	public const uint uint_0 = 16U;

	// Token: 0x04000ADF RID: 2783
	public static readonly uint uint_1 = 1024U;

	// Token: 0x04000AE0 RID: 2784
	public static readonly uint uint_2 = 1024U;

	// Token: 0x04000AE1 RID: 2785
	public static readonly uint uint_3 = 128U;

	// Token: 0x04000AE2 RID: 2786
	[CompilerGenerated]
	private IntPtr intptr_0;

	// Token: 0x04000AE3 RID: 2787
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04000AE4 RID: 2788
	[CompilerGenerated]
	private IntPtr intptr_1;

	// Token: 0x04000AE5 RID: 2789
	[CompilerGenerated]
	private IntPtr intptr_2;

	// Token: 0x04000AE6 RID: 2790
	[CompilerGenerated]
	private uint uint_4;
}
